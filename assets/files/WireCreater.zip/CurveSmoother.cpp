#include "CurveSmoother.h"
CurveSmoother::CurveSmoother(QWidget* parent)
{
	addParam();
    QVBoxLayout* layout = new QVBoxLayout;
    curveViewer = new CurveViewer(NULL);
    layout->addWidget(curveViewer,3);
    layout->addWidget(tabCurveParam,1);


    QWidget* window = new QWidget();
    window->setLayout(layout);
    this->setCentralWidget(window);
    //this->addToolBar()
    load_mesh = new QAction("Load Mesh");
    load_path = new QAction("Load Path");
    smooth_curve = new QAction("Smooth Curve");
    plane = new QAction("Plane");
    outputFile = new QAction("outputFile");
    auto fileMenu = menuBar()->addMenu(tr("&File"));
    fileMenu->addAction(load_mesh);
    fileMenu->addAction(load_path);
    auto editMenu = menuBar()->addMenu(tr("&Edit"));
    editMenu->addAction(smooth_curve);
    editMenu->addAction(plane);
    editMenu->addAction(outputFile);
    setConnection();

}

void CurveSmoother::addParam()
{
	tabCurveParam = new CPropertyBrowser();
	tabCurveParam->setObjectName(QStringLiteral("tabCurveParam"));
	//ui.PropertyTabWidget->addTab(tabCurveParam, QString());
	//ui.PropertyTabWidget->setTabText(1, "Curve Settings");
	QtVariantProperty* thisProperty, * displayProperty, * curveProperty;
    tabCurveParam->clear();
    curveProperty = tabCurveParam->getOneNewProperty(QtVariantPropertyManager::groupTypeId(), QLatin1String("Curve"), "Curve");
    thisProperty = tabCurveParam->getOneNewProperty(QVariant::Int, QLatin1String("LineSegment"), "Curve.LineSegment");
    thisProperty->setValue(20);
    curveProperty->addSubProperty(thisProperty);

    thisProperty = tabCurveParam->getOneNewProperty(QVariant::Double, QLatin1String("ErrorMagnitude"), "Curve.ErrorMagnitude");
    thisProperty->setValue(2.0);
    curveProperty->addSubProperty(thisProperty);

    thisProperty = tabCurveParam->getOneNewProperty(QVariant::Int, QLatin1String("SmoothIterTime"), "Curve.SmoothIterTime");
    thisProperty->setValue(1);
    curveProperty->addSubProperty(thisProperty);

    thisProperty = tabCurveParam->getOneNewProperty(QVariant::Double, QLatin1String("MinRadiusOfCurvature"), "Curve.MinRadiusOfCurvature");
    thisProperty->setValue(1);
    curveProperty->addSubProperty(thisProperty);

    thisProperty = tabCurveParam->getOneNewProperty(QVariant::Double, QLatin1String("SimulatedAnnealingWeight"), "Curve.SimulatedAnnealingWeight");
    thisProperty->setValue(1);
    curveProperty->addSubProperty(thisProperty);

    thisProperty = tabCurveParam->getOneNewProperty(QVariant::Bool, QLatin1String("DrawOriginPath"), "Curve.DrawOriginPath");
    thisProperty->setValue(false);
    curveProperty->addSubProperty(thisProperty);

    thisProperty = tabCurveParam->getOneNewProperty(QVariant::Bool, QLatin1String("DrawSmoothPath"), "Curve.DrawSmoothPath");
    thisProperty->setValue(false);
    curveProperty->addSubProperty(thisProperty);

    thisProperty = tabCurveParam->getOneNewProperty(QVariant::Bool, QLatin1String("DrawCtrlPts"), "Curve.DrawCtrlPts");
    thisProperty->setValue(false);
    curveProperty->addSubProperty(thisProperty);

    tabCurveParam->addOneProperty(curveProperty);
}

void CurveSmoother::callSmooth()
{   
    const double error_mag = tabCurveParam->getVariantProperty("Curve.ErrorMagnitude")->value().toDouble();
    const int segment_times = tabCurveParam->getVariantProperty("Curve.LineSegment")->value().toInt();
    const double min_radix_of_curvature = tabCurveParam->getVariantProperty("Curve.MinRadiusOfCurvature")->value().toDouble();
    curveViewer->smooth(segment_times, error_mag, min_radix_of_curvature);
}

void CurveSmoother::callLoadMesh()
{
    QString filename = QFileDialog::getOpenFileName(NULL, "load config", ".", "*");
    std::ifstream input(filename.toStdString());
    input >> curveViewer->mesh;
    //assert(CGAL::is_triangle_mesh(mesh_poly_));

    curveViewer->mesh.set_id_to_items_map();
    curveViewer->mesh.set_hds_items_id();
    curveViewer->mesh.init();
    curveViewer->mesh.get_avg_edge_len(true);
    curveViewer->mesh.build_paths();
    curveViewer->update();
}

void CurveSmoother::callLoadPath()
{
    QString filename = QFileDialog::getOpenFileName(NULL, "load path", ".", "*");
    std::ifstream input(filename.toStdString());
    curveViewer->path_idx.clear();
    while (!input.eof())
    {   
        //std::cout << "1" << std::endl;
        int size; int idx;
        input >> size;
        curveViewer->path_idx.push_back(std::vector<int>());
        if (size > 0)
        {
            while (size--)
            {
                std::cout << size << std::endl;
                input >> idx;
                curveViewer->path_idx.back().push_back(idx);
            }
        }
    }
    curveViewer->path_idx.erase(curveViewer->path_idx.end() - 1);
    curveViewer->update();
}

void CurveSmoother::setConnection()
{
    connect(load_mesh, SIGNAL(triggered()), this, SLOT(callLoadMesh()));
    connect(load_path, SIGNAL(triggered()), this, SLOT(callLoadPath()));
    connect(smooth_curve, SIGNAL(triggered()), this, SLOT(callSmooth()));
    connect(plane, SIGNAL(triggered()), this, SLOT(callPlane()));
    connect(outputFile, SIGNAL(triggered()), this, SLOT(callOutputImg()));
    connect(tabCurveParam->getVariantManager(), SIGNAL(valueChanged(QtProperty*, const QVariant&)),
        this, SLOT(curveParamsChanged(QtProperty*, const QVariant&)));
}

void CurveSmoother::curveParamsChanged(QtProperty* prop, const QVariant& value)
{
    std::string id = tabCurveParam->getPropertyId(prop);
    if (id == "Curve.DrawOriginPath")
    {
        curveViewer->draw_origin_path = value.toBool();
    }
    else if (id == "Curve.DrawSmoothPath")
    {
        curveViewer->draw_smooth_path = value.toBool();
    }
    else if (id == "Curve.DrawCtrlPts")
    {
        curveViewer->draw_ctrl_pts = value.toBool();
    }
    curveViewer->update();
}

void CurveSmoother::callPlane()
{   
    const double weight = tabCurveParam->getVariantProperty("Curve.SimulatedAnnealingWeight")->value().toDouble();
    curveViewer->plane(weight);
    //callOutputImg();
}

void CurveSmoother::callOutputImg()
{   
    {
        std::ofstream of("fab.obj", std::ofstream::out);
        if (of.fail())
        {
            std::cout << "open file error!\n";
            return;
        }
        std::vector<Eigen::Vector3d>output_pts;
        for (int i = 0; i < curveViewer->smooth_path.planer_curve.size(); ++i)
        {
            for (int j = 0; j < curveViewer->smooth_path.planer_curve[i].size(); ++j)
            {
                for (int k = 0; k < curveViewer->smooth_path.planer_curve[i][j].size(); ++k)
                {
                    output_pts.push_back(curveViewer->smooth_path.planer_curve[i][j][k]);
                    //std::cout << vtx << std::endl;
                }
            }
        }
        for (auto v : output_pts)
        {
            of << "v " << v.x() << " " << v.y() << " " << v.z() << std::endl;
        }
        of << "g " << "curve" << std::endl;
        of << "l";
        for (int idx = 0; idx < output_pts.size(); ++idx)
        {
            of << " " << idx + 1;
        }
        of << std::endl;
        of.close();
    }

    {
        std::ofstream of("start_points.obj", std::ofstream::out);
        if (of.fail())
        {
            std::cout << "open file error!\n";
            return;
        }
        std::vector<Eigen::Vector3d>output_pts;
        for (int i = 0; i < curveViewer->smooth_path.planer_curve.size(); ++i)
        {
            for (int j = 0; j < curveViewer->smooth_path.planer_curve[i].size(); ++j)
            {
                output_pts.push_back(curveViewer->smooth_path.planer_curve[i][j].front());
            }
        }
        for (auto v : output_pts)
        {
            of << "v " << v.x() << " " << v.y() << " " << v.z() << std::endl;
        }
        of << "g " << "curve" << std::endl;
        of << "l";
        for (int idx = 0; idx < output_pts.size(); ++idx)
        {
            of << " " << idx + 1;
        }
        of << std::endl;
        of.close();
    }

    for (int i = 0; i < curveViewer->smooth_path.planer_curve.size(); ++i)
    {   
        std::vector<std::pair<Eigen::Vector3d, Eigen::Vector3d>>plane_params;
        for (int j = 0; j < curveViewer->smooth_path.planer_curve[i].size(); ++j)
        {   
            auto plane_param = curveViewer->smooth_path.bestPlaneFromPoints(curveViewer->smooth_path.planer_curve[i][j]);
            //double bias = plane_param.second.dot(plane_param.);
            plane_params.push_back(plane_param);
        }
        std::vector<std::pair<Eigen::Vector3d, Eigen::Vector3d>>bound_dir(plane_params.size(),
            std::pair<Eigen::Vector3d,Eigen::Vector3d>(Eigen::Vector3d::Zero(), Eigen::Vector3d::Zero()));

        std::ofstream of("angles.ag", std::ofstream::out);
        if (of.fail()) 
        {
            std::cout << "open file error!\n";
            return;
        }
        //the "left-side" 
        for (int j = 1; j < plane_params.size(); ++j)
        {
            auto plane_param0 = plane_params[j - 1];
            auto plane_param1 = plane_params[j];
            Eigen::Vector3d intersection_dir = plane_param0.second.cross(plane_param1.second);
            intersection_dir = intersection_dir.normalized();
            bound_dir[j].first = intersection_dir;
        }
        for (int j = 0; j < plane_params.size() - 1; ++j)
        {
            auto plane_param0 = plane_params[j];
            auto plane_param1 = plane_params[j + 1];
            Eigen::Vector3d intersection_dir = plane_param0.second.cross(plane_param1.second);
            intersection_dir = intersection_dir.normalized();
            bound_dir[j].second = intersection_dir;
        }


        for (int j = 1; j < plane_params.size(); ++j)
        {
            auto plane_param0 = plane_params[j - 1];
            auto plane_param1 = plane_params[j];

            auto vec0 = plane_param0.first - curveViewer->smooth_path.planer_curve[i][j - 1].back();
            auto vec1 = plane_param1.first - curveViewer->smooth_path.planer_curve[i][j].front();

            auto cross1 = vec0.cross(bound_dir[j].first).normalized();
            auto cross2 = vec1.cross(bound_dir[j].first).normalized();

            double theta = cross1.dot(cross2);
            of << std::acos(theta)/std::acos(-1)*180 << std::endl;
        }
        of.close();




        for (int j = 0; j < curveViewer->smooth_path.planer_curve[i].size(); ++j)
        {
            auto plane_param = curveViewer->smooth_path.bestPlaneFromPoints(curveViewer->smooth_path.planer_curve[i][j]);
            //double bias = plane_param.second.dot(plane_param.);
            double bias = plane_param.second.dot(plane_param.first);
            bias = bias / plane_param.second.z();
double cos_theta = plane_param.second.z();
double sin_theta = std::sqrt(1 - cos_theta * cos_theta);
double u1 = plane_param.second.y() / std::sqrt(std::pow(plane_param.second.x(), 2) + std::pow(plane_param.second.y(), 2));
double u2 = -plane_param.second.x() / std::sqrt(std::pow(plane_param.second.x(), 2) + std::pow(plane_param.second.y(), 2));;
Eigen::Matrix3d m;
m << cos_theta + u1 * u1 * (1 - cos_theta), u1* u2* (1 - cos_theta), u2* sin_theta,
u1* u2* (1 - cos_theta), cos_theta + u2 * u2 * (1 - cos_theta), -u1 * sin_theta,
-u2 * sin_theta, u1* sin_theta, cos_theta;

{
bound_dir[j].first = curveViewer->smooth_path.planer_curve[i][j].front() + 0.2 * bound_dir[j].first;
bound_dir[j].first = bound_dir[j].first + Eigen::Vector3d(0, 0, bias);
bound_dir[j].first = m * bound_dir[j].first;

bound_dir[j].second = curveViewer->smooth_path.planer_curve[i][j].back() + 0.2 * bound_dir[j].second;
bound_dir[j].second = bound_dir[j].second + Eigen::Vector3d(0, 0, bias);
bound_dir[j].second = m * bound_dir[j].second;
}

for (int k = 0; k < curveViewer->smooth_path.planer_curve[i][j].size(); ++k)
{
curveViewer->smooth_path.planer_curve[i][j][k] = curveViewer->smooth_path.planer_curve[i][j][k] + Eigen::Vector3d(0, 0, bias);
curveViewer->smooth_path.planer_curve[i][j][k] = m * curveViewer->smooth_path.planer_curve[i][j][k];
//curveViewer->smooth_path.planer_curve[i][j][k] = curveViewer->smooth_path.planer_curve[i][j][k]*m;
}
        }
        for (int j = 0; j < curveViewer->smooth_path.planer_curve[i].size(); ++j)
        {
            /**/
            Eigen::Vector3d left_up_corner(std::numeric_limits<double>::max(),
                std::numeric_limits<double>::max(), 0);
            Eigen::Vector3d right_down_corner(std::numeric_limits<double>::min(),
                std::numeric_limits<double>::min(), 0);
            for (int k = 0; k < curveViewer->smooth_path.planer_curve[i][j].size(); ++k)
            {
                left_up_corner.x() = std::min(left_up_corner.x(), curveViewer->smooth_path.planer_curve[i][j][k].x());
                left_up_corner.y() = std::min(left_up_corner.y(), curveViewer->smooth_path.planer_curve[i][j][k].y());
            }

            {
                left_up_corner.x() = std::min(left_up_corner.x(), bound_dir[j].first.x());
                left_up_corner.x() = std::min(left_up_corner.x(), (curveViewer->smooth_path.planer_curve[i][j].front() +
                    (curveViewer->smooth_path.planer_curve[i][j].front() - bound_dir[j].first)).x());
                left_up_corner.y() = std::min(left_up_corner.y(), bound_dir[j].first.y());
                left_up_corner.y() = std::min(left_up_corner.y(), (curveViewer->smooth_path.planer_curve[i][j].front() +
                    (curveViewer->smooth_path.planer_curve[i][j].front() - bound_dir[j].first)).y());

                left_up_corner.x() = std::min(left_up_corner.x(), bound_dir[j].second.x());
                left_up_corner.x() = std::min(left_up_corner.x(), (curveViewer->smooth_path.planer_curve[i][j].back() +
                    (curveViewer->smooth_path.planer_curve[i][j].back() - bound_dir[j].second)).x());
                left_up_corner.y() = std::min(left_up_corner.y(), bound_dir[j].second.y());
                left_up_corner.y() = std::min(left_up_corner.y(), (curveViewer->smooth_path.planer_curve[i][j].back() +
                    (curveViewer->smooth_path.planer_curve[i][j].back() - bound_dir[j].second)).y());

            }

            Eigen::Vector3d origin_bound_box = right_down_corner - left_up_corner;

            const double dimension = 1000;
            const double multiplier = 300;
            const double bias = 100;
            svg::Dimensions dimensions(dimension, dimension);
            svg::Document doc(std::string("fab") + std::to_string(j) + std::string(".svg"), svg::Layout(dimensions, svg::Layout::TopLeft));

            svg::LineChart chart(5.0);
            svg::Polyline polyline_a(svg::Stroke(.5, svg::Color::Blue));
            svg::Polyline polyline_b(svg::Stroke(.5, svg::Color::Red));
            svg::Polyline polyline_c(svg::Stroke(.5, svg::Color::Red));

            for (int k = 0; k < curveViewer->smooth_path.planer_curve[i][j].size(); ++k)
            {
                auto pt = curveViewer->smooth_path.planer_curve[i][j][k] - left_up_corner;
                polyline_a << svg::Point(pt.x() * multiplier + bias, pt.y() * multiplier + bias);
            }
            {

                auto pt0 = bound_dir[j].first - left_up_corner;
                auto pt2 = (curveViewer->smooth_path.planer_curve[i][j].front() +
                    (curveViewer->smooth_path.planer_curve[i][j].front() - bound_dir[j].first)) - left_up_corner;

                svg::Line line1(svg::Point(pt0.x() * multiplier + bias, pt0.y() * multiplier + bias),
                    svg::Point(pt2.x() * multiplier + bias, pt2.y() * multiplier + bias), svg::Stroke(.5, svg::Color::Red));

                auto pt3 = bound_dir[j].second - left_up_corner;
                auto pt4 = curveViewer->smooth_path.planer_curve[i][j].back() - left_up_corner;
                auto pt5 = curveViewer->smooth_path.planer_curve[i][j].back() +
                    (curveViewer->smooth_path.planer_curve[i][j].back() - bound_dir[j].second) - left_up_corner;
                svg::Line line2(svg::Point(pt3.x() * multiplier + bias, pt3.y() * multiplier + bias),
                    svg::Point(pt5.x() * multiplier + bias, pt5.y() * multiplier + bias), svg::Stroke(.5, svg::Color::Red));
                doc << line1 << line2;
            }
            auto start_pt = curveViewer->smooth_path.planer_curve[i][j].front() - left_up_corner;
            svg::Circle start_circle(svg::Point(start_pt.x() * multiplier + bias, start_pt.y() * multiplier + bias), 10, svg::Fill(svg::Color::Green));
            doc << polyline_a << polyline_b << polyline_c << start_circle;
            //doc << chart;
            doc.save();
        }
    }

    {
        std::ofstream of("origin_result.obj", std::ofstream::out);
        if (of.fail())
        {
            std::cout << "open file error!\n";
            return;
        }
        for (auto v : curveViewer->smooth_path.curve.front())
        {
            of << "v " << v.x() << " " << v.y() << " " << v.z() << std::endl;
        }
        of << "g " << "curve" << std::endl;
        of << "l";
        for (int idx = 0; idx < curveViewer->smooth_path.curve.front().size(); ++idx)
        {
            of << " " << idx + 1;
        }
        of << std::endl;
        of.close();
    }

    //then output it with oencv.polylines
}
