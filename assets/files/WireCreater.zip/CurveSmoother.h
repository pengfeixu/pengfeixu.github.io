#pragma once
#include <QtWidgets/QMainWindow>
#include "PropertyBrowser.h"
#include <qfiledialog.h>
#include <QAction>
#include <QMenu>
#include <QMenuBar>
#include <QVBoxLayout>
#include "CurveViewer.h"
#include "simple_svg_1.0.0.hpp"

class CurveSmoother : public QMainWindow
{
    Q_OBJECT
public:
    CurveSmoother(QWidget* parent = Q_NULLPTR);
private:
    QAction* load_mesh;
    QAction* load_path;
    QAction* smooth_curve;
    QAction* plane;
    QAction* outputFile;
    CPropertyBrowser* tabCurveParam;
    CurveViewer* curveViewer;

    void setConnection();
    void addParam();

private slots:

    void callLoadMesh();
    void callLoadPath();
    void curveParamsChanged(QtProperty* prop, const QVariant& value);
    void callSmooth();
    void callPlane();
    void callOutputImg();
};