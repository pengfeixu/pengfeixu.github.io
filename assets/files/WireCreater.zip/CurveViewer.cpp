#include "CurveViewer.h"
CurveViewer::CurveViewer(QWidget* parent=NULL) :QGLViewer(parent)
{
	draw_origin_path=false;
	draw_smooth_path=false;
	draw_ctrl_pts=false;
}

void CurveViewer::load_path(std::vector<Eigen::Vector3d>res)
{
	this->origin_path = res;
}

void CurveViewer::smooth(int segment_times,double error_mag,double min_radix_of_curvature)
{	
	std::vector<int>selectPointsIndex;//empty is fine.
	//a new constructor 4 Curve is needed.
	smooth_path = Curve(path_idx, selectPointsIndex, mesh, segment_times,
		error_mag, mesh.get_avg_edge_len(), NULL, false, min_radix_of_curvature);
}

void CurveViewer::draw()
{
	if (draw_origin_path)
	{	
		for (int i = 0; i < smooth_path.planer_curve.size(); ++i)
		{
			for (int j = 0; j < smooth_path.planer_curve[i].size(); ++j)
			{
				glColor3d(rand_uniform(0,1), rand_uniform(0, 1), rand_uniform(0, 1));
				glBegin(GL_LINE_STRIP);
				for (int k = 0; k < smooth_path.planer_curve[i][j].size(); ++k)
				{
					auto vtx = smooth_path.planer_curve[i][j][k];
					glVertex3d(vtx.x(), vtx.y(), vtx.z());
					//std::cout << vtx << std::endl;
				}
				glEnd();
			}
		}
	}
	smooth_path.draw(draw_smooth_path, false, draw_ctrl_pts, -1, -1);
}