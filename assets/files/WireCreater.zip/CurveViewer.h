#pragma once
#include <QGLViewer/qglviewer.h>
#include <CGAL/Polyhedron_3.h>
#include <CGAL/Polyhedron_items_with_id_3.h>
#include <CGAL/Exact_predicates_inexact_constructions_kernel.h>
#include "polygon.h"
#include "curve.h"


typedef CGAL::Exact_predicates_inexact_constructions_kernel Kernel;
typedef Kernel::Plane_3 Plane;
typedef Kernel::Line_3 Line;
typedef CGAL::Polyhedron_3<Kernel, CGAL::Polyhedron_items_with_id_3> Polyhedron;
class CurveViewer : public QGLViewer {
public:
    CurveViewer(QWidget* parent);
    void load_path(std::vector<Eigen::Vector3d>path);
    void smooth(int segment_times, double error_mag, double min_radix_of_curvature);
    bool draw_origin_path;
    bool draw_smooth_path;
    bool draw_ctrl_pts;
    Enriched_polyhedron<Kernel, Enriched_items> mesh;
    std::vector<std::vector<int>>path_idx;
    void plane(double weight) { smooth_path.piecewisePlanerazation(weight); };
    Curve smooth_path;
protected:
    virtual void draw();
private:
    std::vector<Eigen::Vector3d>origin_path;
};