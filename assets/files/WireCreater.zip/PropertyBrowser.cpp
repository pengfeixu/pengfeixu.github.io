#include "PropertyBrowser.h"
#include <qteditorfactory.h>

CPropertyBrowser::CPropertyBrowser()
{
	QtVariantEditorFactory *variantFactory = new QtVariantEditorFactory;
	setFactoryForManager(&variantManager, variantFactory);
	setFont(QFont("Consolas", 8, -1));
	setRootIsDecorated(true);
	setResizeMode(QtTreePropertyBrowser::ResizeToContents);
	setSplitterPosition(150);
}


CPropertyBrowser::~CPropertyBrowser()
{
}


QtVariantPropertyManager* CPropertyBrowser::getVariantManager(){
	return &variantManager;
}

QtVariantProperty * CPropertyBrowser::getOneNewProperty(int propertyType, const QString &name, const std::string &key){
	QtVariantProperty *property = variantManager.addProperty(propertyType, name);
	propertyToId[property] = key;
	idToProperty[key] = property;
	return property;
}

QtVariantProperty * CPropertyBrowser::getOneNewProperty(int propertyType, const QString &name){
	QtVariantProperty *property = variantManager.addProperty(propertyType, name);
	std::string key = name.toStdString();
	propertyToId[property] = key;
	idToProperty[key] = property;
	return property;
}

void CPropertyBrowser::addOneProperty(QtProperty *property){
	QtBrowserItem *item = addProperty(property);
	//setExpanded(item, false);
	setExpanded(item, false);
}

std::string CPropertyBrowser::getPropertyId(QtProperty *property){
	if (propertyToId.contains(property)){
		return propertyToId[property];
	}
	else{
		return "";
	}
}

QtVariantProperty* CPropertyBrowser::getVariantProperty(std::string key){
	if (idToProperty.contains(key)){
		return (QtVariantProperty*)idToProperty[key];
	}
	else{
		return NULL;
	}
}