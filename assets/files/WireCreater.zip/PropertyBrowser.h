#pragma once
#include <qtpropertymanager.h>
#include <qtvariantproperty.h>
#include <qttreepropertybrowser.h>

class CPropertyBrowser :
	public QtTreePropertyBrowser
{
public:
	CPropertyBrowser();
	~CPropertyBrowser();
	QtVariantPropertyManager* getVariantManager();
	QtVariantProperty * getOneNewProperty(int propertyType, const QString &name, const std::string &key);
	QtVariantProperty * getOneNewProperty(int propertyType, const QString &name);
	void addOneProperty(QtProperty *property);
	std::string getPropertyId(QtProperty *property);
	QtVariantProperty* getVariantProperty(std::string key);
	QMap<std::string, QtVariantProperty *>* getIdToProperty(){ return &idToProperty; }

protected:
	QtVariantPropertyManager variantManager;
	QMap<QtProperty *, std::string> propertyToId;
	QMap<std::string, QtVariantProperty *> idToProperty;
};

