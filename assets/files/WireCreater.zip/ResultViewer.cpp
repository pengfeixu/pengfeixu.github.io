#include "ResultViewer.h"
ResultViewer::ResultViewer(QWidget* parent)
{   
    resultWidget = new ResultWidget(NULL);
    addParam();
    QHBoxLayout* layout = new QHBoxLayout;
    layout->addWidget(resultWidget, 3);
    layout->addWidget(tabDrawParam, 1);


    QWidget* window = new QWidget();
    window->setLayout(layout);
    this->setCentralWidget(window);
    //this->addToolBar()
    load_mesh = new QAction("Load Mesh");
    load_field = new QAction("Load Field");
    load_curve = new QAction("Load Curve");
    load_second_curve = new QAction("Load Second Curve");
    load_line_drawing = new QAction("Load Line Drawing");
    load_anchor_points = new QAction("Load Anchor Points");
    load_scene_param = new QAction("Load Scene Param");
    save_scene_param = new QAction("Save Scene Param");
    auto fileMenu = menuBar()->addMenu(tr("&File"));
    fileMenu->addAction(load_mesh);
    fileMenu->addAction(load_field);
    fileMenu->addAction(load_curve);
    fileMenu->addAction(load_second_curve);
    fileMenu->addAction(load_line_drawing);
    fileMenu->addAction(load_anchor_points);
    fileMenu->addAction(load_scene_param);
    fileMenu->addAction(save_scene_param);
    setConnection();
}

void ResultViewer::setConnection()
{
    connect(load_mesh, SIGNAL(triggered()), this, SLOT(callLoadMesh()));
    connect(load_field, SIGNAL(triggered()), this, SLOT(callLoadField()));
    connect(load_curve, SIGNAL(triggered()), this, SLOT(callLoadCurve()));
    connect(load_second_curve, SIGNAL(triggered()), this, SLOT(callLoadSecondCurve()));
    connect(load_line_drawing, SIGNAL(triggered()), this, SLOT(callLoadLineDrawing()));
    connect(load_anchor_points, SIGNAL(triggered()), this, SLOT(callLoadAnchorPoints()));
    connect(load_scene_param, SIGNAL(triggered()), this, SLOT(callLoadState()));
    connect(save_scene_param, SIGNAL(triggered()), this, SLOT(callSaveState()));
    connect(tabDrawParam->getVariantManager(), SIGNAL(valueChanged(QtProperty*, const QVariant&)),
        this, SLOT(curveParamsChanged(QtProperty*, const QVariant&)));
}

void ResultViewer::addParam()
{
    tabDrawParam = new CPropertyBrowser();
    tabDrawParam->setObjectName(QStringLiteral("tabDrawParam"));
    QtVariantProperty* thisProperty, * displayProperty, * curveProperty;
    tabDrawParam->clear();
    curveProperty = tabDrawParam->getOneNewProperty(QtVariantPropertyManager::groupTypeId(), QLatin1String("Curve"), "Curve");
    thisProperty = tabDrawParam->getOneNewProperty(QVariant::Bool, QLatin1String("DrawModel"), "Curve.DrawModel");
    thisProperty->setValue(true);
    curveProperty->addSubProperty(thisProperty);
    resultWidget->draw_model = true;

    thisProperty = tabDrawParam->getOneNewProperty(QVariant::Bool, QLatin1String("DrawField"), "Curve.DrawField");
    thisProperty->setValue(true);
    curveProperty->addSubProperty(thisProperty);
    resultWidget->draw_field = true;

    thisProperty = tabDrawParam->getOneNewProperty(QVariant::Bool, QLatin1String("ModelLightning"), "Curve.ModelLightning");
    thisProperty->setValue(true);
    curveProperty->addSubProperty(thisProperty);
    resultWidget->model_lightning = true;

    thisProperty = tabDrawParam->getOneNewProperty(QVariant::Bool, QLatin1String("DrawCurve"), "Curve.DrawCurve");
    thisProperty->setValue(true);
    curveProperty->addSubProperty(thisProperty);
    resultWidget->draw_curve =true;

    thisProperty = tabDrawParam->getOneNewProperty(QVariant::Bool, QLatin1String("DrawSecondCurve"), "Curve.DrawSecondCurve");
    thisProperty->setValue(true);
    curveProperty->addSubProperty(thisProperty);
    resultWidget->draw_second_curve = true;

    thisProperty = tabDrawParam->getOneNewProperty(QVariant::Bool, QLatin1String("DrawFeature"), "Curve.DrawFeature");
    thisProperty->setValue(true);
    curveProperty->addSubProperty(thisProperty);
    resultWidget->draw_line_drawings = true;

    thisProperty = tabDrawParam->getOneNewProperty(QVariant::Bool, QLatin1String("DrawAnchorPts"), "Curve.DrawAnchorPts");
    thisProperty->setValue(true);
    curveProperty->addSubProperty(thisProperty);
    resultWidget->draw_anchor_points = true;

    thisProperty = tabDrawParam->getOneNewProperty(QVariant::Color, QLatin1String("ModelColor"), "Curve.ModelColor");
    thisProperty->setValue(QColor(221, 221, 221));
    curveProperty->addSubProperty(thisProperty);
    resultWidget->model_color = QColor(221, 221, 221);

    thisProperty = tabDrawParam->getOneNewProperty(QVariant::Color, QLatin1String("CurveColor"), "Curve.CurveColor");
    thisProperty->setValue(QColor(168, 0, 0));
    curveProperty->addSubProperty(thisProperty);
    resultWidget->curve_color = QColor(168, 0, 0);

    thisProperty = tabDrawParam->getOneNewProperty(QVariant::Color, QLatin1String("CurveColor"), "Curve.SecondCurveColor");
    thisProperty->setValue(QColor(168, 0, 0));
    curveProperty->addSubProperty(thisProperty);
    resultWidget->second_curve_color = QColor(168, 0, 0);

    thisProperty = tabDrawParam->getOneNewProperty(QVariant::Color, QLatin1String("FeatureColor"), "Curve.FeatureColor");
    thisProperty->setValue(QColor(255, 255, 255));
    curveProperty->addSubProperty(thisProperty);
    resultWidget->line_drawing_color = QColor(255, 255, 255);

    thisProperty = tabDrawParam->getOneNewProperty(QVariant::Color, QLatin1String("AnchorPtsColor"), "Curve.AnchorPtsColor");
    thisProperty->setValue(QColor(255, 221, 221));
    curveProperty->addSubProperty(thisProperty);
    resultWidget->anchor_points_color = QColor(255, 221, 221);

    thisProperty = tabDrawParam->getOneNewProperty(QVariant::Double, QLatin1String("AnchorPtsRadius"), "Curve.AnchorPtsRadius");
    thisProperty->setValue(0.1);
    curveProperty->addSubProperty(thisProperty);
    resultWidget->anchor_points_radius = 0.1;

    thisProperty = tabDrawParam->getOneNewProperty(QVariant::Double, QLatin1String("FieldLowerBound"), "Curve.FieldLowerBound");
    thisProperty->setValue(0.1);
    curveProperty->addSubProperty(thisProperty);
    resultWidget->field_lower_bound = 0.1;

    thisProperty = tabDrawParam->getOneNewProperty(QVariant::Double, QLatin1String("FieldUpperBound"), "Curve.FieldUpperBound");
    thisProperty->setValue(1.0);
    curveProperty->addSubProperty(thisProperty);
    resultWidget->field_upper_bound = 1.0;
    
    tabDrawParam->addOneProperty(curveProperty);
}

void ResultViewer::curveParamsChanged(QtProperty* prop, const QVariant& value)
{
    std::string id = tabDrawParam->getPropertyId(prop);
    if (id == "Curve.DrawModel")
    {
        resultWidget->draw_model = value.toBool();
    }
    else if (id == "Curve.DrawField")
    {
        resultWidget->draw_field = value.toBool();
    }
    else if (id == "Curve.ModelLightning")
    {
        resultWidget->model_lightning = value.toBool();
    }
    else if (id == "Curve.DrawCurve")
    {
        resultWidget->draw_curve = value.toBool();
    }
    else if (id == "Curve.DrawSecondCurve")
    {
        resultWidget->draw_second_curve = value.toBool();
    }
    else if (id == "Curve.DrawFeature")
    {
        resultWidget->draw_line_drawings = value.toBool();
    }
    else if (id == "Curve.DrawAnchorPts")
    {
        resultWidget->draw_anchor_points = value.toBool();
    }
    else if (id == "Curve.ModelColor")
    {
        resultWidget->model_color= value.value<QColor>();
    }
    else if (id == "Curve.CurveColor")
    {
        resultWidget->curve_color = value.value<QColor>();
    }
    else if (id == "Curve.SecondCurveColor")
    {
        resultWidget->second_curve_color = value.value<QColor>();
    }
    else if (id == "Curve.FeatureColor")
    {
        resultWidget->line_drawing_color = value.value<QColor>();
    }
    else if (id == "Curve.AnchorPtsColor")
    {
        resultWidget->anchor_points_color = value.value<QColor>();
    }
    else if (id == "Curve.AnchorPtsRadius")
    {
        resultWidget->anchor_points_radius = value.toDouble();
    }
    else if (id == "Curve.FieldLowerBound")
    {
        resultWidget->field_lower_bound = value.toDouble();
    }
    else if (id == "Curve.FieldUpperBound")
    {
        resultWidget->field_upper_bound = value.toDouble();
    }
    resultWidget->update();
}

void ResultViewer::callLoadMesh()
{   
    QString filename = QFileDialog::getOpenFileName(NULL, "load model", ".", "*.off");
    std::string filename_=filename.toStdString();
    std::ifstream input(filename_);
    input >> resultWidget->mesh;
    input.close();
    //assert(CGAL::is_triangle_mesh(mesh_poly_));

    resultWidget->mesh.set_id_to_items_map();
    resultWidget->mesh.set_hds_items_id();
    resultWidget->mesh.init();
    resultWidget->mesh.get_avg_edge_len(true);
    resultWidget->mesh.build_paths();

    resultWidget->themesh = *(trimesh::TriMesh::read(filename_));
    resultWidget->themesh.need_neighbors();
    resultWidget->themesh.need_tstrips();
    resultWidget->themesh.need_bsphere();
    resultWidget->themesh.need_normals();
    resultWidget->themesh.need_curvatures();
    resultWidget->themesh.need_dcurv();
    resultWidget->update();
}

void ResultViewer::callLoadCurve()
{
    std::string filename_;
    QString filename_q = QFileDialog::getOpenFileName(NULL, "curve result select", ".", "*.cve");
    std::ifstream input(filename_q.toStdString());
    size_t ctrl_pts_group_num;
    input >> ctrl_pts_group_num;
    std::cout << ctrl_pts_group_num << std::endl;
    std::vector<std::vector<Eigen::Vector3d>>ctrl_pts;
    while (ctrl_pts_group_num--)
    {
        size_t ctrl_pts_num;
        input >> ctrl_pts_num;
        std::cout << ctrl_pts_num << std::endl;
        ctrl_pts.push_back(std::vector<Eigen::Vector3d>());
        while (ctrl_pts_num--)
        {
            double x, y, z;
            Eigen::Vector3d pt;
            input >> x >> y >> z;
            std::cout << x << std::endl;
            std::cout << y << std::endl;
            std::cout << z << std::endl;
            std::cout << ctrl_pts_num << std::endl;
            ctrl_pts.back().push_back(Eigen::Vector3d(x, y, z));
        }
    }
    size_t overlap_pts_group_num;
    std::vector<std::vector<std::pair<int, double>>>overlap_pts_vec;
    input >> overlap_pts_group_num;
    while (overlap_pts_group_num--)
    {
        int idx;
        double weight;
        overlap_pts_vec.push_back(std::vector<std::pair<int, double>>());
        input >> idx;
        input >> weight;
        overlap_pts_vec.back().push_back(std::pair<int, double>(idx, weight));
        input >> idx;
        input >> weight;
        overlap_pts_vec.back().push_back(std::pair<int, double>(idx, weight));
    }
    input.close();
    resultWidget->curve = Curve(ctrl_pts, overlap_pts_vec, 20, 2);
    resultWidget->update();
}

void ResultViewer::callLoadSecondCurve()
{
    std::string filename_;
    QString filename_q = QFileDialog::getOpenFileName(NULL, "curve result select", ".", "*.cve");
    std::ifstream input(filename_q.toStdString());
    size_t ctrl_pts_group_num;
    input >> ctrl_pts_group_num;
    std::cout << ctrl_pts_group_num << std::endl;
    std::vector<std::vector<Eigen::Vector3d>>ctrl_pts;
    while (ctrl_pts_group_num--)
    {
        size_t ctrl_pts_num;
        input >> ctrl_pts_num;
        std::cout << ctrl_pts_num << std::endl;
        ctrl_pts.push_back(std::vector<Eigen::Vector3d>());
        while (ctrl_pts_num--)
        {
            double x, y, z;
            Eigen::Vector3d pt;
            input >> x >> y >> z;
            std::cout << x << std::endl;
            std::cout << y << std::endl;
            std::cout << z << std::endl;
            std::cout << ctrl_pts_num << std::endl;
            ctrl_pts.back().push_back(Eigen::Vector3d(x, y, z));
        }
    }
    size_t overlap_pts_group_num;
    std::vector<std::vector<std::pair<int, double>>>overlap_pts_vec;
    input >> overlap_pts_group_num;
    while (overlap_pts_group_num--)
    {
        int idx;
        double weight;
        overlap_pts_vec.push_back(std::vector<std::pair<int, double>>());
        input >> idx;
        input >> weight;
        overlap_pts_vec.back().push_back(std::pair<int, double>(idx, weight));
        input >> idx;
        input >> weight;
        overlap_pts_vec.back().push_back(std::pair<int, double>(idx, weight));
    }
    input.close();
    resultWidget->second_curve = Curve(ctrl_pts, overlap_pts_vec, 20, 2);
    resultWidget->update();
}

void ResultViewer::callLoadLineDrawing()
{   
    QString filename_q = QFileDialog::getOpenFileName(NULL, "feature select", ".", "*.fea");
    std::string filename_ = filename_q.toStdString();
    std::ifstream input(filename_);

    std::vector<std::string>input_feature;
    resultWidget->line_drawings.clear();
    while (!input.eof())
    {
        int line_num;
        int line_seg;
        std::string feature_type;
        input >> feature_type;
        input >> line_num;
        std::cout << feature_type << " " << line_num << std::endl;
        double x, y, z;
        for (int i = 0; i < line_num; ++i)
        {
            resultWidget->line_drawings.push_back(std::vector<Eigen::Vector3d>());
            input >> line_seg;
            for (int j = 0; j < line_seg; ++j)
            {
                input >> x >> y >> z;
                resultWidget->line_drawings.back().push_back(Eigen::Vector3d(x, y, z));
            }
        }
        int segment;
        input >> segment;
        std::cout << "seg" << segment << std::endl;
        for (int i = 0; i < segment; ++i)
        {
            int seg;
            input >> seg;
            for (int j = 0; j < seg; ++j)
            {
                int val;
                input >> val;
            }
        }

        input >> segment;
        std::cout << "seg" << segment << std::endl;
        for (int i = 0; i < segment; ++i)
        {
            int seg;
            input >> seg;
            for (int j = 0; j < seg; ++j)
            {
                int val;
                input >> val;
            }
        }
        //break;
    }
    input.close();
    resultWidget->update();
}

void ResultViewer::callLoadAnchorPoints()
{
    QString filename_q = QFileDialog::getOpenFileName(NULL, "apt select", ".", "*.apt");
    std::string filename_ = filename_q.toStdString();
    std::ifstream input(filename_);
    int select_pt_idx;
    resultWidget->anchor_points_idx.clear();
    while (!input.eof())
    {   
        input >> select_pt_idx;
        resultWidget->anchor_points_idx.push_back(select_pt_idx);
    }
    input.close();
    resultWidget->update();
}

void ResultViewer::callLoadField()
{
    QString filename_q = QFileDialog::getOpenFileName(NULL, "apt select", ".", "*.fid");
    std::string filename_ = filename_q.toStdString();
    resultWidget->field_val.clear();
    std::ifstream input(filename_);
    double val;
    while (!input.eof())
    {
        input >> val;
        resultWidget->field_val.push_back(val);
    }
    input.close();
    resultWidget->update();
}

void ResultViewer::callSaveState()
{
    QString filename = QFileDialog::getSaveFileName(NULL, "save scene params", ".", ".sp");
    resultWidget->setStateFileName(filename);
    resultWidget->saveStateToFile();
}

void ResultViewer::callLoadState()
{
    QString filename_q = QFileDialog::getOpenFileName(NULL, "load scene params", ".", "*.sp");
    resultWidget->setStateFileName(filename_q);
    resultWidget->restoreStateFromFile();
}