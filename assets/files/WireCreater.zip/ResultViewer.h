#pragma once
#include <QtWidgets/QMainWindow>
#include "PropertyBrowser.h"
#include <qfiledialog.h>
#include <QAction>
#include <QMenu>
#include <QMenuBar>
#include <QVBoxLayout>
#include "ResultWidget.h"
#include "simple_svg_1.0.0.hpp"

class ResultViewer : public QMainWindow
{
    Q_OBJECT
public:
    ResultViewer(QWidget* parent = Q_NULLPTR);
private:
    QAction* load_mesh;
    QAction* load_curve;
    QAction* load_second_curve;
    QAction* load_line_drawing;
    QAction* load_anchor_points;
    QAction* load_scene_param;
    QAction* load_field;
    QAction* save_scene_param;

    CPropertyBrowser* tabDrawParam;
    ResultWidget* resultWidget;

    void setConnection();
    void addParam();

private slots:
    void callLoadMesh();
    void callLoadCurve();
    void callLoadSecondCurve();
    void callLoadLineDrawing();
    void callLoadAnchorPoints();
    void curveParamsChanged(QtProperty* prop, const QVariant& value);
    void callSaveState();
    void callLoadState();
    void callLoadField();
};
