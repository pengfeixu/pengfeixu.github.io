#include"ResultWidget.h"

ResultWidget::ResultWidget(QWidget* parent = NULL) :QGLViewer(parent)
{   
    draw_model=true;
    draw_curve=true;
    draw_line_drawings=true;
    draw_anchor_points=true;
    //this->setBackgroundColor(QColor(255, 255, 255));
}

void ResultWidget::draw()
{   
    const qglviewer::Vec cameraPos = camera()->position();
    const GLfloat pos[4] = { (float)cameraPos[0], (float)cameraPos[1],
                            (float)cameraPos[2], 1.0f };

    glLightfv(GL_LIGHT0, GL_POSITION, pos);
    glLightfv(GL_LIGHT0, GL_SPOT_DIRECTION, camera()->viewDirection());



    if(draw_model)drawModel();
    drawCurve();
    if(draw_line_drawings)drawLineDrawings();
    if(draw_anchor_points)drwaAnchorPoints();

    glClearColor(1.0, 1.0, 1.0,1.0);
}

void ResultWidget::drawModel()
{   
    if (!model_lightning)
    {
        glDisable(GL_LIGHTING);
    }
    glEnable(GL_POLYGON_SMOOTH);
    glColor3ub(model_color.red(), model_color.green(), model_color.blue());
    glEnable(GL_POLYGON_OFFSET_FILL);
    glPolygonOffset(1, 1);
    glBegin(GL_TRIANGLES);
    if (!draw_field)
    {
        for (unsigned int i = 0; i < themesh.faces.size(); i++)
        {
            trimesh::TriMesh::Face* thisFace;
            thisFace = &(themesh.faces[i]);

            trimesh::vec n0 = themesh.normals[(*thisFace)[0]];
            trimesh::vec v0 = themesh.vertices[(*thisFace)[0]];
            glNormal3d(n0[0], n0[1], n0[2]);
            if (!model_lightning)
                v0 -= 0.002 * n0;
            glVertex3f(v0[0], v0[1], v0[2]);

            trimesh::vec n1 = themesh.normals[(*thisFace)[1]];
            trimesh::vec v1 = themesh.vertices[(*thisFace)[1]];
            glNormal3d(n1[0], n1[1], n1[2]);
            if (!model_lightning)
                v1 -= 0.002 * n1;
            glVertex3f(v1[0], v1[1], v1[2]);

            trimesh::vec n2 = themesh.normals[(*thisFace)[2]];
            trimesh::vec v2 = themesh.vertices[(*thisFace)[2]];
            glNormal3d(n2[0], n2[1], n2[2]);
            if (!model_lightning)
                v2 -= 0.002 * n2;
            glVertex3f(v2[0], v2[1], v2[2]);
        }
    }
    else
    {   
        if (!field_val.empty())
        {   
            std::vector<float>color_vec;
            field_color = std::vector<Eigen::Vector3d>(themesh.vertices.size());
            for (unsigned int i = 0; i < themesh.vertices.size(); i++)
            {
                auto neibour = themesh.neighbors[i];
                Eigen::Vector3d c = val_color_func(field_val[i]);
                for (int j = 0; j < neibour.size(); ++j)
                {
                    c += val_color_func(field_val[neibour[j]]);
                }
                c /= (neibour.size() + 1);
                field_color[i] = c;
                color_vec.push_back(c.x());
                color_vec.push_back(c.y());
                color_vec.push_back(c.z());
            }
            /*
            glEnableClientState(GL_VERTEX_ARRAY);
            glEnableClientState(GL_NORMAL_ARRAY);
            glVertexPointer(3, GL_FLOAT, 0, &themesh.vertices[0][0]);
            glNormalPointer(GL_FLOAT, 0, &themesh.normals[0][0]);
            glEnableClientState(GL_COLOR_ARRAY);
            glColorPointer(3, GL_FLOAT, 0,color_vec.data());
           //glColor3ub(255-model_color.red(), 255-model_color.green(), 255-model_color.blue());
            const int* t = &themesh.tstrips[0];
            const int* end = t + themesh.tstrips.size();
            while (likely(t < end)) {
                int striplen = *t++;
                glDrawElements(GL_TRIANGLE_STRIP, striplen, GL_UNSIGNED_INT, t);
                t += striplen;
            }
            glDisableClientState(GL_COLOR_ARRAY);
            glDisableClientState(GL_VERTEX_ARRAY);
            glDisableClientState(GL_NORMAL_ARRAY);
            */
            glShadeModel(GL_SMOOTH);
            glEnable(GL_POINT_SMOOTH);
            glEnable(GL_LINE_SMOOTH);
            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
            for (unsigned int i = 0; i < themesh.faces.size(); i++)
            {
                trimesh::TriMesh::Face* thisFace;
                thisFace = &(themesh.faces[i]);

                trimesh::vec n0 = themesh.normals[(*thisFace)[0]];
                trimesh::vec v0 = themesh.vertices[(*thisFace)[0]];
                glNormal3d(n0[0], n0[1], n0[2]);
                glVertex3f(v0[0], v0[1], v0[2]);
                auto c0 = field_color[(*thisFace)[0]];
                glColor3f(c0.x(), c0.y(), c0.z());

                trimesh::vec n1 = themesh.normals[(*thisFace)[1]];
                trimesh::vec v1 = themesh.vertices[(*thisFace)[1]];
                glNormal3d(n1[0], n1[1], n1[2]);
                glVertex3f(v1[0], v1[1], v1[2]);
                auto c1 = field_color[(*thisFace)[1]];
                glColor3f(c1.x(), c1.y(), c1.z());

                trimesh::vec n2 = themesh.normals[(*thisFace)[2]];
                trimesh::vec v2 = themesh.vertices[(*thisFace)[2]];
                glNormal3d(n2[0], n2[1], n2[2]);
                glVertex3f(v2[0], v2[1], v2[2]);
                auto c2 = field_color[(*thisFace)[2]];
                glColor3f(c2.x(), c2.y(), c2.z());
            }
            glDisable(GL_LINE_SMOOTH);
            glDisable(GL_POINT_SMOOTH);
            glDisable(GL_BLEND);
            glDepthMask(GL_TRUE);
        }
    }
    glEnd();
    if (!model_lightning)
    {
        glEnable(GL_LIGHTING);
    }
}

void ResultWidget::drawCurve()
{
    glEnable(GL_LINE_SMOOTH);

    //glColor4ub(150, 255, 224, 255);
    if (draw_curve)
    {   
        /*
        glDisable(GL_LIGHTING);
        glLineWidth(5);
        glEnable(GL_POINT_SMOOTH);
        glEnable(GL_LINE_SMOOTH);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        for (int i = 0; i < curve.curve.size(); ++i)
        {
            glBegin(GL_LINE_STRIP);
            for (int j = 0; j < curve.curve[i].size(); ++j)
            {
                glVertex3f(curve.curve[i][j].x(), curve.curve[i][j].y(), curve.curve[i][j].z());
            }
            glEnd();
        }
        glDisable(GL_LINE_SMOOTH);
        glDisable(GL_POINT_SMOOTH);
        glDisable(GL_BLEND);
        glDepthMask(GL_TRUE);
        glEnable(GL_LIGHTING);
        */
        glColor3d(curve_color.redF(), curve_color.greenF(), curve_color.blueF());
        GLfloat ambient[] = { 0.23125f, 0.23125f, 0.23125f, 1.0 };
        GLfloat diffuse[] = { 0.2775f, 0.2775f, 0.2775f,1.0f };
        GLfloat specular[] = { 0.508273f, 0.508273f, 0.508273f, 1.0f };
        glMaterialfv(GL_FRONT, GL_AMBIENT, ambient);
        glMaterialfv(GL_FRONT, GL_DIFFUSE, diffuse);
        glMaterialfv(GL_FRONT, GL_SPECULAR, specular);
        for (int i = 0; i < curve.pipes.size(); ++i)
        {
            int count = curve.pipes[i].getContourCount();
            for (int j = 0; j < count - 1; ++j)
            {
                auto c1 = curve.pipes[i].getContour(j);
                auto c2 = curve.pipes[i].getContour(j + 1);
                auto n1 = curve.pipes[i].getNormal(j);
                auto n2 = curve.pipes[i].getNormal(j + 1);
                glBegin(GL_TRIANGLE_STRIP);
                for (int k = 0; k < (int)c2.size(); ++k) {
                    glNormal3f(n2[k][0], n2[k][1], n2[k][2]);
                    glVertex3f(c2[k][0], c2[k][1], c2[k][2]);
                    glNormal3f(n1[k][0], n1[k][1], n1[k][2]);
                    glVertex3f(c1[k][0], c1[k][1], c1[k][2]);
                }
                glEnd();
            }
        }
    }
    if (draw_second_curve)
    {   
        /*
        glColor3d(second_curve_color.redF(), second_curve_color.greenF(), second_curve_color.blueF());
        glDisable(GL_LIGHTING);
        glLineWidth(5);
        glEnable(GL_POINT_SMOOTH);
        glEnable(GL_LINE_SMOOTH);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        for (int i = 0; i < second_curve.curve.size(); ++i)
        {
            glBegin(GL_LINE_STRIP);
            for (int j = 0; j < second_curve.curve[i].size(); ++j)
            {
                glVertex3f(second_curve.curve[i][j].x(), second_curve.curve[i][j].y(), second_curve.curve[i][j].z());
            }
            glEnd();
        }
        glDisable(GL_LINE_SMOOTH);
        glDisable(GL_POINT_SMOOTH);
        glDisable(GL_BLEND);
        glDepthMask(GL_TRUE);
        glEnable(GL_LIGHTING);
        */

        /*
        for (int i = 0; i < second_curve.pipes.size(); ++i)
        {
            int count = second_curve.pipes[i].getContourCount();
            for (int j = 0; j < count - 1; ++j)
            {
                auto c1 = second_curve.pipes[i].getContour(j);
                auto c2 = second_curve.pipes[i].getContour(j + 1);
                auto n1 = second_curve.pipes[i].getNormal(j);
                auto n2 = second_curve.pipes[i].getNormal(j + 1);
                glBegin(GL_TRIANGLE_STRIP);
                for (int k = 0; k < (int)c2.size(); ++k) {
                    glNormal3f(n2[k][0], n2[k][1], n2[k][2]);
                    glVertex3f(c2[k][0], c2[k][1], c2[k][2]);
                    glNormal3f(n1[k][0], n1[k][1], n1[k][2]);
                    glVertex3f(c1[k][0], c1[k][1], c1[k][2]);
                }
                glEnd();
            }
        }
        */
    }
    glDisable(GL_LINE_SMOOTH);
}

void ResultWidget::drawLineDrawings()
{   
    glDisable(GL_LIGHTING);
    glLineWidth(2);
    glEnable(GL_POINT_SMOOTH);
    glEnable(GL_LINE_SMOOTH);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glColor3ub(line_drawing_color.red(), line_drawing_color.green(), line_drawing_color.blue());
    for (int i = 0; i < line_drawings.size(); ++i)
    {
        glBegin(GL_LINE_STRIP);
        for (int j = 0; j < line_drawings[i].size(); ++j)
        {
            glVertex3f(line_drawings[i][j].x(), line_drawings[i][j].y(), line_drawings[i][j].z());
        }
        glEnd();
    }
    glDisable(GL_LINE_SMOOTH);
    glDisable(GL_POINT_SMOOTH);
    glDisable(GL_BLEND);
    glDepthMask(GL_TRUE);
    glEnable(GL_LIGHTING);
}

void ResultWidget::drwaAnchorPoints()
{
    glColor3ub(anchor_points_color.red(), anchor_points_color.green(), anchor_points_color.blue());
    for (int i = 0; i < anchor_points_idx.size(); ++i)
    {
        trimesh::vec& v0 = themesh.vertices[anchor_points_idx[i]];
        drawSphere(v0.x, v0.y, v0.z, anchor_points_radius);
    }
}

void ResultWidget::drawSphere(double xc, double yc, double zc, double r)
{
    int lats = 20; int longs = 20;
    int i, j;
    for (i = 0; i <= lats; i++) {
        double lat0 = M_PI * (-0.5 + (double)(i - 1) / lats);
        double z0 = sin(lat0);
        double zr0 = cos(lat0);

        double lat1 = M_PI * (-0.5 + (double)i / lats);
        double z1 = sin(lat1);
        double zr1 = cos(lat1);

        glBegin(GL_QUAD_STRIP);
        for (j = 0; j <= longs; j++) {
            double lng = 2 * M_PI * (double)(j - 1) / longs;
            double x = cos(lng);
            double y = sin(lng);

            glNormal3f(x * zr0, y * zr0, z0);
            glVertex3f(xc + r * x * zr0, yc + r * y * zr0, zc + r * z0);
            glNormal3f(x * zr1, y * zr1, z1);
            glVertex3f(xc + r * x * zr1, yc + r * y * zr1, zc + r * z1);
        }
        glEnd();
    }
}

Eigen::Vector3d ResultWidget::val_color_func(double x)
{
    const Eigen::Vector3d high_color = Eigen::Vector3d(1.0, 1.0, 0);
    const Eigen::Vector3d low_color = Eigen::Vector3d(0, 0, 1.0);
    auto c=(std::min(0.1,std::max(0.0,x-field_lower_bound))/ (field_upper_bound - field_lower_bound))
        * (high_color - low_color) + low_color;
    return c;
}