#pragma once
#pragma once
#include <QGLViewer/qglviewer.h>
#include <CGAL/Polyhedron_3.h>
#include <CGAL/Polyhedron_items_with_id_3.h>
#include <CGAL/Exact_predicates_inexact_constructions_kernel.h>
#include <Trimesh.h>
#include "polygon.h"
#include "curve.h"


typedef CGAL::Exact_predicates_inexact_constructions_kernel Kernel;
typedef Kernel::Plane_3 Plane;
typedef Kernel::Line_3 Line;
typedef CGAL::Polyhedron_3<Kernel, CGAL::Polyhedron_items_with_id_3> Polyhedron;

class ResultWidget : public QGLViewer {
public:
    ResultWidget(QWidget* parent);
    bool draw_model;
    bool model_lightning;
    bool draw_curve;
    bool draw_second_curve;
    bool draw_line_drawings;
    bool draw_anchor_points;
    bool draw_field;

    QColor model_color;
    QColor curve_color;
    QColor second_curve_color;
    QColor line_drawing_color;
    QColor anchor_points_color;

    double anchor_points_radius;
    double field_lower_bound;
    double field_upper_bound;

    trimesh::TriMesh themesh;
    Enriched_polyhedron<Kernel, Enriched_items> mesh;
    std::vector<std::vector<Eigen::Vector3d>>line_drawings;
    std::vector<double>field_val;
    Curve curve;
    Curve second_curve;
    std::vector<int>anchor_points_idx;
protected:
    virtual void draw();
private:
    void drawSphere(double xc, double yc, double zc, double r);
    void drawModel();
    void drawCurve();
    void drawLineDrawings();
    void drwaAnchorPoints();
    Eigen::Vector3d val_color_func(double x);
    std::vector<Eigen::Vector3d> field_color;
};