#include "WireCreater.h"

WireCreater::WireCreater(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
    setMouseAction();
    setFeatureOpt();
    createPropertyBrowser();
    setconnection();

    sublayout = new QGridLayout();
    ui.ResSubWidget->setLayout(sublayout);


    bridge_pt = -1;
    select_move_pt_idx_i = -1;
    select_move_pt_idx_j = -1;

    ui.MainWidget->cur_mouse = kMouse::DEFAULT;
    ui.MainWidget->cur_edit = kEdit::NONE;
    need_modify_ctrl_pts_draw = true;
    last_op_create_new_line = true;
    is_user_study_start = false;
    initUserRecord();

    ui.mainToolBar->setIconSize(QSize(40, 40));

    ui.actionCamera_Mode->setIcon(QIcon("CameraMode.png"));

    ui.actionRevoke_User_Edit->setIcon(QIcon("Undo"));
    ui.actionRedo_User_Edit->setIcon(QIcon("Redo"));

    ui.actionAdd_Curve->setIcon(QIcon("AddCurve"));
    ui.actionModify_Curve->setIcon(QIcon("RemoveCurve"));
    ui.actionAttach_to_Path->setIcon(QIcon("AttractCurve"));
    ui.actionSmooth_Curve->setIcon(QIcon("SmoothCurve"));
    ui.actionMove_Ctrl_Pt->setIcon(QIcon("MoveTool"));

    ui.actionSelect_Start_Points->setIcon(QIcon("SelectStartPoint"));
    ui.actionSelect_Last_Point->setIcon(QIcon("SelectLastPoint"));
    ui.actionSelect_Next_Point->setIcon(QIcon("SelectNextPoint"));
    ui.actionForm_Next_Line->setIcon(QIcon("Formlines"));
    ui.actionMove_Ctrl_Pt_->setIcon(QIcon("MoveTool"));

    ui.actionCreate_New_Line->setIcon(QIcon("CreateNewLine"));
    ui.actionLink_to_Last_Line->setIcon(QIcon("LinkToLastLine"));

    camera_operation_times = 0;
    user_edit_times = 0;
    redo_times = 0;
    undo_times = 0;

    camera_operation_cost_time = 0;
    user_edit_cost_time = 0;
    form_line_cost_time = 0;

    is_user_study_start = false;
    is_user_algo_start = false;
    callStartUserAlgo();
}

void WireCreater::setMouseAction()
{
    ag_mouseAction = new QActionGroup(this);

    ui.actionCamera_Mode->setCheckable(true);


    //add may not be added since it's similar to the link func
    //ag_mouseAction->addAction(ui.actionAdd_Curve);
    //ui.actionAdd_Curve->setCheckable(false);
    ag_mouseAction->addAction(ui.actionModify_Curve);
    ui.actionModify_Curve->setCheckable(false);
    ag_mouseAction->addAction(ui.actionAttach_to_Path);
    ui.actionAttach_to_Path->setCheckable(false);
    ag_mouseAction->addAction(ui.actionSmooth_Curve);
    ui.actionSmooth_Curve->setCheckable(false);
    ag_mouseAction->addAction(ui.actionSelect_Last_Point);
    ui.actionSelect_Last_Point->setCheckable(false);
    ag_mouseAction->addAction(ui.actionSelect_Next_Point);
    ui.actionSelect_Next_Point->setCheckable(false);
    ag_mouseAction->addAction(ui.actionForm_Next_Line);
    ag_mouseAction->addAction(ui.actionLink_to_Last_Line);
    ui.actionLink_to_Last_Line->setCheckable(false);
    ag_mouseAction->addAction(ui.actionMove_Ctrl_Pt_);
    ui.actionMove_Ctrl_Pt_->setCheckable(false);
    /*
    ag_userStudyMouseAction->addAction(ui.actionSelect_Start_Points);
    ui.actionSelect_Start_Points->setCheckable(false);
    ag_userStudyMouseAction->addAction(ui.actionSelect_Last_Point);
    ui.actionSelect_Last_Point->setCheckable(false);
    ag_userStudyMouseAction->addAction(ui.actionSelect_Next_Point);
    ui.actionSelect_Next_Point->setCheckable(false);
    ag_userStudyMouseAction->addAction(ui.actionForm_Next_Line);
    ag_userStudyMouseAction->addAction(ui.actionCreate_New_Line);
    ui.actionCreate_New_Line->setCheckable(false);
    ag_userStudyMouseAction->addAction(ui.actionLink_to_Last_Line);
    ui.actionLink_to_Last_Line->setCheckable(false);
    //ui.actionSelect_Next_Point->setCheckable(false);
    ag_userStudyMouseAction->addAction(ui.actionMove_Ctrl_Pt_);
    ui.actionMove_Ctrl_Pt_->setCheckable(false);
    */
    ag_mouseAction->addAction(ui.actionSelect_Model_Pts);
    ui.actionSelect_Model_Pts->setCheckable(false);
    ag_mouseAction->addAction(ui.actionSelect_Anchor_Path);
    ui.actionSelect_Anchor_Path->setCheckable(false);
    /*
    ag_mouseAction->addAction(ui.actionMove_Ctrl_Pt);
    ui.actionMove_Ctrl_Pt->setCheckable(false);
    */
    ag_userStudyMouseAction = new QActionGroup(this);


    //ag_userStudyMouseAction->addAction(ui.actionCamera_Mode);
    /*
    ag_userStudyMouseAction->addAction(ui.actionCreate_New_Line);
    ui.actionCreate_New_Line->setCheckable(false);
    ag_userStudyMouseAction->addAction(ui.actionLink_to_Last_Line);
    ui.actionLink_to_Last_Line->setCheckable(false);
    ag_userStudyMouseAction->addAction(ui.actionLink_End_to_End);
    ui.actionLink_End_to_End->setCheckable(false);
    ag_userStudyMouseAction->addAction(ui.actionAttach_to_Nearest_Line);
    ui.actionAttach_to_Nearest_Line->setCheckable(false);
    ag_userStudyMouseAction->addAction(ui.actionMove_Ctrl_Pt_);
    ui.actionMove_Ctrl_Pt_->setCheckable(false);
    */

    ag_mouseAction->setExclusive(true);
    ag_userStudyMouseAction->setExclusive(true);
    ui.actionCamera_Mode->setChecked(true);
}

void WireCreater::callChangeMouse()
{   
    if (ag_mouseAction->actions()[7]->isChecked())
    {
        //ag_mouseAction->actions().front()->setChecked(false);
        ui.actionCamera_Mode->setChecked(false);
        ui.MainWidget->cur_mouse = kMouse::MOVE_CTRL_PT + static_cast<int>(tabCurveParam->getVariantProperty("Curve.ConstrainedMove")->value().toBool());
        ui.MainWidget->cur_edit = kEdit::NONE;
        ui.MainWidget->mouseChanged();
        ui.MainWidget->update();
    }
    for (int i = 0; i < ag_mouseAction->actions().size(); ++i)
    {   
        if (ag_mouseAction->actions()[i]->isChecked())
        {
            ui.actionCamera_Mode->setChecked(false);
        }
    }
}

void WireCreater::callUserStudyChangeMouse()
{
    if (ag_userStudyMouseAction->actions().back()->isChecked())
    {
        ui.actionCamera_Mode->setChecked(false);
        ui.MainWidget->cur_mouse = kMouse::MOVE_CTRL_PT + static_cast<int>(tabCurveParam->getVariantProperty("Curve.ConstrainedMove")->value().toBool());
        ui.MainWidget->cur_edit = kEdit::NONE;
        ui.MainWidget->mouseChanged();
        ui.MainWidget->update();
    }
    for (int i = 0; i < ag_userStudyMouseAction->actions().size() - 1; ++i)
    {
        if (ag_userStudyMouseAction->actions()[i]->isChecked())
        {
            ui.actionCamera_Mode->setChecked(false);
            ui.MainWidget->mouseChanged();
        }
    }
}


void WireCreater::setFeatureOpt()
{
    ag_feature_silhouette = new QActionGroup(this);
    ag_feature_silhouette->addAction(ui.actiondraw_immediately_silhouette);
    ui.actiondraw_immediately_silhouette->setCheckable(true);
    ag_feature_silhouette->addAction(ui.actiondraw_nothing_silhouette);
    ui.actiondraw_nothing_silhouette->setCheckable(true);
    ag_feature_silhouette->addAction(ui.actiondraw_saved_result_silhouette);
    ui.actiondraw_saved_result_silhouette->setCheckable(true);
    ag_feature_silhouette->addAction(ui.actionnot_draw_saved_result_silhouette);
    ui.actionnot_draw_saved_result_silhouette->setCheckable(true);
    ag_feature_silhouette->setExclusive(true);
    ag_feature_silhouette->setVisible(true);
    ui.actiondraw_nothing_silhouette->setChecked(true);

    ag_feature_topolines = new QActionGroup(this);
    ag_feature_topolines->addAction(ui.actiondraw_immediately_topolines);
    ui.actiondraw_immediately_topolines->setCheckable(true);
    ag_feature_topolines->addAction(ui.actiondraw_nothing_topolines);
    ui.actiondraw_nothing_topolines->setCheckable(true);
    ag_feature_topolines->addAction(ui.actiondraw_saved_result_topolines);
    ui.actiondraw_saved_result_topolines->setCheckable(true);
    ag_feature_topolines->addAction(ui.actionnot_draw_saved_result_topolines);
    ui.actionnot_draw_saved_result_topolines->setCheckable(true);
    ag_feature_topolines->setExclusive(true);
    ag_feature_topolines->setVisible(true);
    ui.actiondraw_nothing_topolines->setChecked(true);

    ag_feature_miscK = new QActionGroup(this);
    ag_feature_miscK->addAction(ui.actiondraw_immediately_miscK);
    ui.actiondraw_immediately_miscK->setCheckable(true);
    ag_feature_miscK->addAction(ui.actiondraw_nothing_miscK);
    ui.actiondraw_nothing_miscK->setCheckable(true);
    ag_feature_miscK->addAction(ui.actiondraw_saved_result_miscK);
    ui.actiondraw_saved_result_miscK->setCheckable(true);
    ag_feature_miscK->addAction(ui.actionnot_draw_saved_result_miscK);
    ui.actionnot_draw_saved_result_miscK->setCheckable(true);
    ag_feature_miscK->setExclusive(true);
    ag_feature_miscK->setVisible(true);
    ui.actiondraw_nothing_miscK->setChecked(true);

    ag_feature_miscH = new QActionGroup(this);
    ag_feature_miscH->addAction(ui.actiondraw_immediately_miscH);
    ui.actiondraw_immediately_miscH->setCheckable(true);
    ag_feature_miscH->addAction(ui.actiondraw_nothing_miscH);
    ui.actiondraw_nothing_miscH->setCheckable(true);
    ag_feature_miscH->addAction(ui.actiondraw_saved_result_miscH);
    ui.actiondraw_saved_result_miscH->setCheckable(true);
    ag_feature_miscH->addAction(ui.actionnot_draw_saved_result_miscH);
    ui.actionnot_draw_saved_result_miscH->setCheckable(true);
    ag_feature_miscH->setExclusive(true);
    ag_feature_miscH->setVisible(true);
    ui.actiondraw_nothing_miscH->setChecked(true);

    ag_feature_miscDwKr = new QActionGroup(this);
    ag_feature_miscDwKr->addAction(ui.actiondraw_immediately_miscDwKr);
    ui.actiondraw_immediately_miscDwKr->setCheckable(true);
    ag_feature_miscDwKr->addAction(ui.actiondraw_nothing_miscDwKr);
    ui.actiondraw_nothing_miscDwKr->setCheckable(true);
    ag_feature_miscDwKr->addAction(ui.actiondraw_saved_result_miscDwKr);
    ui.actiondraw_saved_result_miscDwKr->setCheckable(true);
    ag_feature_miscDwKr->addAction(ui.actionnot_draw_saved_result_miscDwKr);
    ui.actionnot_draw_saved_result_miscDwKr->setCheckable(true);
    ag_feature_miscDwKr->setExclusive(true);
    ag_feature_miscDwKr->setVisible(true);
    ui.actiondraw_nothing_miscDwKr->setChecked(true);

    ag_feature_ridges = new QActionGroup(this);
    ag_feature_ridges->addAction(ui.actiondraw_immediately_ridges);
    ui.actiondraw_immediately_ridges->setCheckable(true);
    ag_feature_ridges->addAction(ui.actiondraw_nothing_ridges);
    ui.actiondraw_nothing_ridges->setCheckable(true);
    ag_feature_ridges->addAction(ui.actiondraw_saved_result_ridges);
    ui.actiondraw_saved_result_ridges->setCheckable(true);
    ag_feature_ridges->addAction(ui.actionnot_draw_saved_result_ridges);
    ui.actionnot_draw_saved_result_ridges->setCheckable(true);
    ag_feature_ridges->setExclusive(true);
    ag_feature_ridges->setVisible(true);
    ui.actiondraw_nothing_ridges->setChecked(true);

    ag_feature_valleys = new QActionGroup(this);
    ag_feature_valleys->addAction(ui.actiondraw_immediately_valleys);
    ui.actiondraw_immediately_valleys->setCheckable(true);
    ag_feature_valleys->addAction(ui.actiondraw_nothing_valleys);
    ui.actiondraw_nothing_valleys->setCheckable(true);
    ag_feature_valleys->addAction(ui.actiondraw_saved_result_valleys);
    ui.actiondraw_saved_result_valleys->setCheckable(true);
    ag_feature_valleys->addAction(ui.actionnot_draw_saved_result_valleys);
    ui.actionnot_draw_saved_result_valleys->setCheckable(true);
    ag_feature_valleys->setExclusive(true);
    ag_feature_valleys->setVisible(true);
    ui.actiondraw_nothing_valleys->setChecked(true);

    ag_feature_sh = new QActionGroup(this);
    ag_feature_sh->addAction(ui.actiondraw_immediately_sh);
    ui.actiondraw_immediately_sh->setCheckable(true);
    ag_feature_sh->addAction(ui.actiondraw_nothing_sh);
    ui.actiondraw_nothing_sh->setCheckable(true);
    ag_feature_sh->addAction(ui.actiondraw_saved_result_sh);
    ui.actiondraw_saved_result_sh->setCheckable(true);
    ag_feature_sh->addAction(ui.actionnot_draw_saved_result_sh);
    ui.actionnot_draw_saved_result_sh->setCheckable(true);
    ag_feature_sh->setExclusive(true);
    ag_feature_sh->setVisible(true);
    ui.actiondraw_nothing_sh->setChecked(true);

    ag_feature_sc = new QActionGroup(this);
    ag_feature_sc->addAction(ui.actiondraw_immediately_sc);
    ui.actiondraw_immediately_sc->setCheckable(true);
    ag_feature_sc->addAction(ui.actiondraw_nothing_sc);
    ui.actiondraw_nothing_sc->setCheckable(true);
    ag_feature_sc->addAction(ui.actiondraw_saved_result_sc);
    ui.actiondraw_saved_result_sc->setCheckable(true);
    ag_feature_sc->addAction(ui.actionnot_draw_saved_result_sc);
    ui.actionnot_draw_saved_result_sc->setCheckable(true);
    ag_feature_sc->setExclusive(true);
    ag_feature_sc->setVisible(true);
    ui.actiondraw_nothing_sc->setChecked(true);

    ag_feature_contours = new QActionGroup(this);
    ag_feature_contours->addAction(ui.actiondraw_immediately_contours);
    ui.actiondraw_immediately_contours->setCheckable(true);
    ag_feature_contours->addAction(ui.actiondraw_nothing_contours);
    ui.actiondraw_nothing_contours->setCheckable(true);
    ag_feature_contours->addAction(ui.actiondraw_saved_result_contours);
    ui.actiondraw_saved_result_contours->setCheckable(true);
    ag_feature_contours->addAction(ui.actionnot_draw_saved_result_contours);
    ui.actionnot_draw_saved_result_contours->setCheckable(true);
    ag_feature_contours->setExclusive(true);
    ag_feature_contours->setVisible(true);
    ui.actiondraw_nothing_contours->setChecked(true);
}

void WireCreater::createPropertyBrowser()
{   
    tabDrawOpt = new CPropertyBrowser();
    tabDrawOpt->setObjectName(QStringLiteral("tabDrawOpt"));
    ui.PropertyTabWidget->addTab(tabDrawOpt, QString());


    tabCurveParam = new CPropertyBrowser();
    tabCurveParam->setObjectName(QStringLiteral("tabCurveParam"));
    ui.PropertyTabWidget->addTab(tabCurveParam, QString());

    ui.PropertyTabWidget->setTabText(0, "Draw Option");
    ui.PropertyTabWidget->setTabText(1, "Curve Settings");
    
    QtVariantProperty* thisProperty, *displayProperty,*curveProperty;
    tabDrawOpt->clear();
    displayProperty = tabDrawOpt->getOneNewProperty(QtVariantPropertyManager::groupTypeId(), QLatin1String("Draw"), "Draw");
    thisProperty= tabDrawOpt->getOneNewProperty(QVariant::Bool, QLatin1String("Face"), "Display.Face");
    thisProperty->setValue(true);
    displayProperty->addSubProperty(thisProperty);

    thisProperty = tabDrawOpt->getOneNewProperty(QVariant::Double, QLatin1String("Face Alpha"), "Display.Face_Alpha");
    thisProperty->setValue(0.5);
    displayProperty->addSubProperty(thisProperty);

    thisProperty = tabDrawOpt->getOneNewProperty(QVariant::Bool, QLatin1String("Line"), "Display.Line");
    thisProperty->setValue(false);
    displayProperty->addSubProperty(thisProperty);

    thisProperty = tabDrawOpt->getOneNewProperty(QVariant::Bool, QLatin1String("Vertex"), "Display.Vertex");
    thisProperty->setValue(false);
    displayProperty->addSubProperty(thisProperty);

    thisProperty = tabDrawOpt->getOneNewProperty(QVariant::Bool, QLatin1String("AnchorVertex"), "Display.AnchorVertex");
    thisProperty->setValue(false);
    displayProperty->addSubProperty(thisProperty);

    thisProperty = tabDrawOpt->getOneNewProperty(QVariant::Bool, QLatin1String("Segment"), "Display.Segment");
    thisProperty->setValue(false);
    displayProperty->addSubProperty(thisProperty);

    thisProperty = tabDrawOpt->getOneNewProperty(QVariant::Bool, QLatin1String("Field"), "Display.Field");
    thisProperty->setValue(false);
    displayProperty->addSubProperty(thisProperty);

    thisProperty = tabDrawOpt->getOneNewProperty(QVariant::Bool, QLatin1String("SigmaField"), "Display.SigmaField");
    thisProperty->setValue(false);
    displayProperty->addSubProperty(thisProperty);

    thisProperty = tabDrawOpt->getOneNewProperty(QVariant::Bool, QLatin1String("FeatureField"), "Display.FeatureField");
    thisProperty->setValue(false);
    displayProperty->addSubProperty(thisProperty);

    thisProperty = tabDrawOpt->getOneNewProperty(QVariant::Bool, QLatin1String("UncutLineField"), "Display.UncutLineField");
    thisProperty->setValue(false);
    displayProperty->addSubProperty(thisProperty);

    thisProperty = tabDrawOpt->getOneNewProperty(QVariant::Bool, QLatin1String("Curve"), "Display.Curve");
    thisProperty->setValue(true);
    displayProperty->addSubProperty(thisProperty);

    thisProperty = tabDrawOpt->getOneNewProperty(QVariant::Bool, QLatin1String("CtrlPts"), "Display.CtrlPts");
    thisProperty->setValue(false);
    displayProperty->addSubProperty(thisProperty);

    thisProperty = tabDrawOpt->getOneNewProperty(QVariant::Bool, QLatin1String("CurveCylinder"), "Display.CurveCylinder");
    thisProperty->setValue(false);
    displayProperty->addSubProperty(thisProperty);

    thisProperty = tabDrawOpt->getOneNewProperty(QVariant::Int, QLatin1String("VertexSize"), "Display.VertexSize");
    thisProperty->setValue(3);
    displayProperty->addSubProperty(thisProperty);

    thisProperty = tabDrawOpt->getOneNewProperty(QVariant::Int, QLatin1String("LineWidth"), "Display.LineWidth");
    thisProperty->setValue(1);
    displayProperty->addSubProperty(thisProperty);
    tabDrawOpt->addOneProperty(displayProperty);


    tabCurveParam->clear();
    curveProperty = tabCurveParam->getOneNewProperty(QtVariantPropertyManager::groupTypeId(), QLatin1String("Curve"), "Curve");
    thisProperty = tabCurveParam->getOneNewProperty(QVariant::Int, QLatin1String("LineSegment"), "Curve.LineSegment");
    thisProperty->setValue(20);
    curveProperty->addSubProperty(thisProperty);

    thisProperty = tabCurveParam->getOneNewProperty(QVariant::Double, QLatin1String("ErrorMagnitude"), "Curve.ErrorMagnitude");
    thisProperty->setValue(2.0);
    curveProperty->addSubProperty(thisProperty);

    thisProperty = tabCurveParam->getOneNewProperty(QVariant::Int, QLatin1String("SmoothIterTime"), "Curve.SmoothIterTime");
    thisProperty->setValue(1);
    curveProperty->addSubProperty(thisProperty);
    
    thisProperty = tabCurveParam->getOneNewProperty(QVariant::Int, QLatin1String("MaxLineNums"), "Curve.MaxLineNums");
    thisProperty->setValue(1);
    curveProperty->addSubProperty(thisProperty);

    thisProperty = tabCurveParam->getOneNewProperty(QVariant::Double, QLatin1String("BridgeDensity"), "Curve.BridgeDensity");
    thisProperty->setValue(20);
    curveProperty->addSubProperty(thisProperty);

    thisProperty = tabCurveParam->getOneNewProperty(QVariant::Double, QLatin1String("FeatureModifier"), "Curve.FeatureModifier");
    thisProperty->setValue(1);
    curveProperty->addSubProperty(thisProperty);

    thisProperty = tabCurveParam->getOneNewProperty(QVariant::Double, QLatin1String("MinRadiusOfCurvature"), "Curve.MinRadiusOfCurvature");
    thisProperty->setValue(1);
    curveProperty->addSubProperty(thisProperty);

    thisProperty = tabCurveParam->getOneNewProperty(QVariant::Bool, QLatin1String("ConstrainedMove"), "Curve.ConstrainedMove");
    thisProperty->setValue(false);
    curveProperty->addSubProperty(thisProperty);

    thisProperty = tabCurveParam->getOneNewProperty(QVariant::Int, QLatin1String("NewBranchSize"), "Curve.NewBranchSize");
    thisProperty->setValue(5);
    curveProperty->addSubProperty(thisProperty);

    thisProperty = tabCurveParam->getOneNewProperty(QVariant::Int, QLatin1String("MaxCandidateSize"), "Curve.MaxCandidateSize");
    thisProperty->setValue(10);
    curveProperty->addSubProperty(thisProperty);

    thisProperty = tabCurveParam->getOneNewProperty(QVariant::Double, QLatin1String("Logi1a"), "Curve.Logi1a");
    thisProperty->setValue(1.8);
    curveProperty->addSubProperty(thisProperty);

    thisProperty = tabCurveParam->getOneNewProperty(QVariant::Double, QLatin1String("Logi1b"), "Curve.Logi1b");
    thisProperty->setValue(0.5);
    curveProperty->addSubProperty(thisProperty);

    thisProperty = tabCurveParam->getOneNewProperty(QVariant::Double, QLatin1String("Logi2a"), "Curve.Logi2a");
    thisProperty->setValue(1.98);
    curveProperty->addSubProperty(thisProperty);

    thisProperty = tabCurveParam->getOneNewProperty(QVariant::Double, QLatin1String("Logi2b"), "Curve.Logi2b");
    thisProperty->setValue(0.5);
    curveProperty->addSubProperty(thisProperty);

    thisProperty = tabCurveParam->getOneNewProperty(QVariant::Double, QLatin1String("RedundancyWeight"), "Curve.RedundancyWeight");
    thisProperty->setValue(1);
    curveProperty->addSubProperty(thisProperty);

    tabCurveParam->addOneProperty(curveProperty);
}

void WireCreater::setconnection()
{
    connect(tabDrawOpt->getVariantManager(), SIGNAL(valueChanged(QtProperty*, const QVariant&)),
        this, SLOT(drawOptChanged(QtProperty*, const QVariant&)));
    connect(tabCurveParam->getVariantManager(), SIGNAL(valueChanged(QtProperty*, const QVariant&)),
        this, SLOT(curveParamsChanged(QtProperty*, const QVariant&)));

    connect(ui.actionOpen, SIGNAL(triggered()), this, SLOT(callLoadModel()));
    connect(ui.actionLoad_Segment, SIGNAL(triggered()), this, SLOT(callLoadSegment()));
    connect(ui.actionLoad_Anchors, SIGNAL(triggered()), this, SLOT(callLoadApt()));
    connect(ui.actionLoad_Feature, SIGNAL(triggered()), this, SLOT(callLoadFeature()));
    connect(ui.actionLoad_Curve, SIGNAL(triggered()), this, SLOT(callLoadPathCurve()));
    connect(ui.actionSave_Anchors, SIGNAL(triggered()), this, SLOT(callSaveApt()));
    connect(ui.actionSave_Feature, SIGNAL(triggered()), this, SLOT(callSaveFeature()));
    connect(ui.actionSave_Curve_Param, SIGNAL(triggered()), this, SLOT(callSaveCurveParam()));
    connect(ui.actionSave_Current_Path, SIGNAL(triggered()), this, SLOT(callSaveCurOriginPath()));
    connect(ui.actionSave_Current_Curve, SIGNAL(triggered()), this, SLOT(callSavePathCurve()));
    connect(ui.actionSave_Curve_Mesh, SIGNAL(triggered()), this, SLOT(callSaveCurveMesh()));

    connect(ag_feature_silhouette, SIGNAL(triggered(QAction*)), this, SLOT(setDrawFeatureOption()));
    connect(ag_feature_topolines, SIGNAL(triggered(QAction*)), this, SLOT(setDrawFeatureOption()));
    connect(ag_feature_miscK, SIGNAL(triggered(QAction*)), this, SLOT(setDrawFeatureOption()));
    connect(ag_feature_miscH, SIGNAL(triggered(QAction*)), this, SLOT(setDrawFeatureOption()));
    connect(ag_feature_miscDwKr, SIGNAL(triggered(QAction*)), this, SLOT(setDrawFeatureOption()));
    connect(ag_feature_ridges, SIGNAL(triggered(QAction*)), this, SLOT(setDrawFeatureOption()));
    connect(ag_feature_valleys, SIGNAL(triggered(QAction*)), this, SLOT(setDrawFeatureOption()));
    connect(ag_feature_sh, SIGNAL(triggered(QAction*)), this, SLOT(setDrawFeatureOption()));
    connect(ag_feature_sc, SIGNAL(triggered(QAction*)), this, SLOT(setDrawFeatureOption()));
    connect(ag_feature_contours, SIGNAL(triggered(QAction*)), this, SLOT(setDrawFeatureOption()));

    connect(ui.actionCamera_Mode, SIGNAL(triggered()), this, SLOT(callCameraMode()));
    connect(ag_mouseAction, SIGNAL(triggered(QAction*)), this, SLOT(callChangeMouse()));
    connect(ag_userStudyMouseAction, SIGNAL(triggered(QAction*)), this, SLOT(callUserStudyChangeMouse()));
    connect(ui.actionForm_Lines, SIGNAL(triggered()), this, SLOT(callFormLines()));
    connect(ui.btn_load_res, SIGNAL(clicked()), this, SLOT(callLoadRes()));

    connect(ui.actionAdd_Curve, SIGNAL(triggered()), this, SLOT(callAddCurveStateChange()));
    connect(ui.MainWidget, SIGNAL(Viewer_AddCurve()), this, SLOT(callAddCurve()));
    connect(ui.MainWidget, SIGNAL(Viewer_MoveCurveDone()), this, SLOT(callMoveCurve()));
    connect(ui.actionMove_Ctrl_Pt, SIGNAL(triggered()), this, SLOT(callMoveCurveStateChange()));
    //connect(ui.actionAttach_to_Point, SIGNAL(triggered()), this, SLOT(callAttachToPt()));
    connect(ui.actionAttach_to_Path, SIGNAL(triggered()), this, SLOT(callAttachToCurveStateChange()));
    connect(ui.MainWidget, SIGNAL(Viewer_AttachToCurve()), this, SLOT(callAttachToCurve()));
    connect(ui.actionModify_Curve, SIGNAL(triggered()), this, SLOT(callModifyCurveStateChange()));
    connect(ui.MainWidget, SIGNAL(Viewer_ModifyCurve()), this, SLOT(callModifyCurve()));
    connect(ui.actionSmooth_Curve, SIGNAL(triggered()), this, SLOT(callSmoothPartStateChange()));
    connect(ui.MainWidget, SIGNAL(Viewer_SmoothPart()), this, SLOT(callSmoothPart()));

    connect(ui.actionSelect_Model_Pts, SIGNAL(triggered()), this, SLOT(callSelectModelPtStateChange()));
    connect(ui.actionSelect_Anchor_Path, SIGNAL(triggered()), this, SLOT(callPrelocatePathsStateChange()));

    connect(ui.actionRevoke_User_Edit, SIGNAL(triggered()), this, SLOT(callRevoke()));
    connect(ui.actionRedo_User_Edit, SIGNAL(triggered()), this, SLOT(callRedo()));


    /*
    connect(ui.actionCreate_New_Line, SIGNAL(triggered()), this, SLOT(callCreateNewLineStateChange()));
    connect(ui.MainWidget, SIGNAL(Viewer_UserStudyCreateNewLine()), this, SLOT(callCreateNewLine()));
    connect(ui.actionLink_to_Last_Line, SIGNAL(triggered()), this, SLOT(callLinkToLastLineStateChange()));
    connect(ui.MainWidget, SIGNAL(Viewer_UserStudyLineToLastLine()), this, SLOT(callLinkToLastLine()));
    connect(ui.actionLink_End_to_End, SIGNAL(triggered()), this, SLOT(callLinkEndtoEnd()));
    connect(ui.actionAttach_to_Nearest_Line, SIGNAL(triggered()), this, SLOT(callAttachToNearestLine()));
    */
    //connect(ui.actionSelect_Start_Points, SIGNAL(triggered()), this, SLOT(callSelectStartPointStateChange()));
    connect(ui.actionSelect_Last_Point, SIGNAL(triggered()), this, SLOT(callSelectLastPointStateChange()));
    connect(ui.actionSelect_Next_Point, SIGNAL(triggered()), this, SLOT(callSelectNextPointStateChange()));
    connect(ui.actionForm_Next_Line, SIGNAL(triggered()), this, SLOT(callUserFormLines()));
    connect(ui.actionCreate_New_Line, SIGNAL(triggered()), this, SLOT(callCreateNewLineStateChange()));
    connect(ui.MainWidget, SIGNAL(Viewer_UserStudyCreateNewLine()), this, SLOT(callCreateNewLine()));
    connect(ui.actionLink_to_Last_Line, SIGNAL(triggered()), this, SLOT(callLinkToLastLineStateChange()));
    connect(ui.MainWidget, SIGNAL(Viewer_UserStudyLineToLastLine()), this, SLOT(callLinkToLastLine()));
    connect(ui.actionMove_Ctrl_Pt_, SIGNAL(triggered()), this, SLOT(callMoveCurveStateChange()));

    //connect(ui.actionRevoke_User_Study, SIGNAL(triggered()), this, SLOT(callRevokeUserStudy()));
    //connect(ui.actionRedo_User_Study, SIGNAL(triggered()), this, SLOT(callRedoUserStudy()));

    connect(ui.actionStart_User_Study, SIGNAL(triggered()), this, SLOT(callStartUserStudy()));
    connect(ui.actionEnd_User_Study, SIGNAL(triggered()), this, SLOT(callEndUserStudy()));
    connect(ui.actionStart_User_Algo, SIGNAL(triggered()), this, SLOT(callStartUserAlgo()));
    connect(ui.actionEnd_User_Algo, SIGNAL(triggered()), this, SLOT(callEndUserAlgo()));

    connect(ui.MainWidget, SIGNAL(Viewer_MoveCamera()), this, SLOT(recordMoveCamera()));
    connect(ui.MainWidget, SIGNAL(Viewer_RotateCamera()), this, SLOT(recordRotateCamera()));
    connect(ui.MainWidget, SIGNAL(Viewer_ScaleCamera()), this, SLOT(recordScaleCamera()));
    connect(ui.MainWidget, SIGNAL(Viewer_MoveCameraDone()), this, SLOT(recordMoveCameraDone()));
    connect(ui.MainWidget, SIGNAL(Viewer_RotateCameraDone()), this, SLOT(recordRotateCameraDone()));
    connect(ui.MainWidget, SIGNAL(Viewer_ScaleCameraDone()), this, SLOT(recordScaleCameraDone()));
    connect(ui.MainWidget, SIGNAL(Viewer_AnchorPathDone()), this, SLOT(callPrelocatePaths()));

    connect(ui.actionBind_Curves, SIGNAL(triggered()), this, SLOT(callSaveField()));
    connect(ui.actionAuto_Select_Landmarks, SIGNAL(triggered()), this, SLOT(callAutoSelectLandmarks()));
}

void WireCreater::drawOptChanged(QtProperty* prop, const QVariant& value)
{
    std::string id = tabDrawOpt->getPropertyId(prop);
    if (id == "Display.Face")
    {
        ui.MainWidget->draw_face = value.toBool();
    }
    else if (id=="Display.Face_Alpha")
    {
        ui.MainWidget->draw_face_alpha = tabDrawOpt->getVariantProperty("Display.Face_Alpha")->value().toDouble();
    }
    else if (id == "Display.Line")
    {
        ui.MainWidget->draw_line = value.toBool();
    }
    else if (id == "Display.Vertex")
    {
        ui.MainWidget->draw_vertex = value.toBool();
    }
    else if (id == "Display.AnchorVertex")
    {
        ui.MainWidget->draw_anchor_vertex = value.toBool();
    }
    else if (id == "Display.Segment")
    {
        ui.MainWidget->draw_segment = value.toBool();
    }
    else if (id == "Display.Field")
    {
        ui.MainWidget->draw_field = value.toBool();
    }
    else if (id == "Display.SigmaField")
    {
        ui.MainWidget->draw_sigma_field = value.toBool();
    }
    else if (id == "Display.FeatureField")
    {
        ui.MainWidget->draw_feature_field = value.toBool();
    }
    else if (id == "Display.UncutLineField")
    {
        ui.MainWidget->draw_uncut_line_field = value.toBool();
    }
    else if (id == "Display.VertexSize")
    {
        ui.MainWidget->vertex_size = value.toInt();
    }
    else if (id == "Display.LineWidth")
    {
        ui.MainWidget->line_width = value.toInt();
    }
    else if (id == "Display.Curve")
    {
        ui.MainWidget->draw_curve = value.toBool();
    }
    else if (id == "Display.CtrlPts")
    {
        ui.MainWidget->draw_ctrlpts = value.toBool();
        need_modify_ctrl_pts_draw = !value.toBool();
    }
    else if (id == "Display.CurveCylinder")
    {
        ui.MainWidget->draw_curvecyliner = value.toBool();
    }
    ui.MainWidget->update();
}
void WireCreater::curveParamsChanged(QtProperty* prop, const QVariant& value)
{
    std::string id = tabCurveParam->getPropertyId(prop);
    if (id == "Curve.LineSegment")
    {
        segment_iter_times = value.toInt();
    }
    else if (id == "Curve.ErrorMagnitude")
    {
        error_magnitude = value.toDouble();
    }
    else if (id == "Curve.SmoothIterTime")
    {
        smooth_iter_times = value.toInt();
    }
    else if (id == "Curve.MaxLineNums")
    {
        max_line_num = value.toInt();
    }
    else if (id == "Curve.BridgeDensity")
    {
        bridge_density = value.toDouble();
    }
    else if (id == "Curve.ConstrainedMove")
    {   
        if ((ui.MainWidget->cur_mouse == kMouse::MOVE_CTRL_PT) ||
            (ui.MainWidget->cur_mouse == kMouse::MOVE_CTRL_PT_SOFT))
        {
            ui.MainWidget->cur_mouse = kMouse::MOVE_CTRL_PT + static_cast<int>(value.toBool());
        }
    }
}

void WireCreater::loadModel(std::string filename)
{   
    std::string filename_;
    if (filename.empty())
    {
        QString filename_q = QFileDialog::getOpenFileName(NULL, "mesh select", ".", "*.off");
        filename_ = filename_q.toStdString();
    }
    else
    {
        filename_ = filename;
    }
    std::ifstream input(filename_);
    input >> mesh_poly_;
    //assert(CGAL::is_triangle_mesh(mesh_poly_));

    mesh_poly_.set_id_to_items_map();
    mesh_poly_.set_hds_items_id();
    mesh_poly_.init();
    mesh_poly_.get_avg_edge_len(true);
    mesh_poly_.build_paths();
    feature_ = new Feature(filename);
    selectRects.resize(mesh_poly_.size_of_vertices());
    is_pt_selected = std::vector<bool>(mesh_poly_.size_of_vertices(), false);

    ui.MainWidget->mesh_poly_ = &mesh_poly_;
    ui.MainWidget->feature_ = feature_;
    ui.MainWidget->selectRects = &selectRects;
    ui.MainWidget->is_pt_selected = &is_pt_selected;
    ui.MainWidget->selectPointsIndex = &selectPointsIndex;
    ui.MainWidget->selectRects = &selectRects;
    ui.MainWidget->user_input = &user_input;
    ui.MainWidget->user_input_MST = &user_input_MST;
    ui.MainWidget->select_rect_paths = &select_rect_paths;
    ui.MainWidget->seg = &seg;
    ui.MainWidget->path_res;//
    ui.MainWidget->select_ctrl_pt_vec=&select_ctrl_pt_vec;//
    ui.MainWidget->bridge_pt = &bridge_pt;
    ui.MainWidget->select_move_pt_idx_i = &select_move_pt_idx_i;
    ui.MainWidget->select_move_pt_idx_j = &select_move_pt_idx_j;
    ui.MainWidget->draw_face = tabDrawOpt->getVariantProperty("Display.Face")->value().toBool();
    ui.MainWidget->draw_face_alpha = tabDrawOpt->getVariantProperty("Display.Face_Alpha")->value().toDouble();
    ui.MainWidget->draw_line = tabDrawOpt->getVariantProperty("Display.Line")->value().toBool();
    ui.MainWidget->draw_vertex = tabDrawOpt->getVariantProperty("Display.Vertex")->value().toBool();
    ui.MainWidget->draw_anchor_vertex = tabDrawOpt->getVariantProperty("Display.AnchorVertex")->value().toBool();
    ui.MainWidget->draw_segment = tabDrawOpt->getVariantProperty("Display.Segment")->value().toBool();
    ui.MainWidget->draw_field = tabDrawOpt->getVariantProperty("Display.Field")->value().toBool();
    ui.MainWidget->draw_sigma_field = tabDrawOpt->getVariantProperty("Display.SigmaField")->value().toBool();
    ui.MainWidget->draw_feature_field = tabDrawOpt->getVariantProperty("Display.FeatureField")->value().toBool();
    ui.MainWidget->draw_uncut_line_field = tabDrawOpt->getVariantProperty("Display.UncutLineField")->value().toBool();
    ui.MainWidget->vertex_size= tabDrawOpt->getVariantProperty("Display.VertexSize")->value().toInt();
    ui.MainWidget->line_width = tabDrawOpt->getVariantProperty("Display.LineWidth")->value().toInt();
    ui.MainWidget->draw_curve = tabDrawOpt->getVariantProperty("Display.Curve")->value().toBool();
    ui.MainWidget->draw_ctrlpts = tabDrawOpt->getVariantProperty("Display.CtrlPts")->value().toBool();
    ui.MainWidget->draw_curvecyliner= tabDrawOpt->getVariantProperty("Display.CurveCylinder")->value().toBool();
    ui.MainWidget->is_bridge_poly = false;
    ui.MainWidget->res_idx_poly = -1;

    ui.MainWidget->user_study_start_pt_idx_i = -1;
    ui.MainWidget->user_study_start_pt_idx_j = -1;
    ui.MainWidget->user_study_end_pt_idx_i = -1;
    ui.MainWidget->user_study_end_pt_idx_j = -1;
}

void WireCreater::loadSegment(std::string filename)
{
    std::string filename_;
    if (filename.empty())
    {
        QString filename_q = QFileDialog::getOpenFileName(NULL, "segment select", ".", "*.seg");
        filename_ = filename_q.toStdString();
    }
    else
    {
        filename_ = filename;
    }
    std::ifstream input(filename_);
    input >> seg;
    mesh_poly_.detect_seg_lines(seg);
}

void WireCreater::loadApt(std::string filename)
{
    std::string filename_;
    if (filename.empty())
    {
        QString filename_q = QFileDialog::getOpenFileName(NULL, "apt select", ".", "*.apt");
        filename_ = filename_q.toStdString();
    }
    else
    {
        filename_ = filename;
    }
    std::ifstream input(filename_);
    int select_pt_idx;
    std::vector<int>read_idx;
    while (!input.eof())
    {
        input >> select_pt_idx;
        if (select_pt_idx >= mesh_poly_.size_of_vertices())
        {
            break;
        }
        read_idx.push_back(select_pt_idx);
    }
    for (int i : read_idx)
    {
        if (std::find(selectPointsIndex.begin(), selectPointsIndex.end(), i) == selectPointsIndex.end())
        {
            selectPointsIndex.push_back(i);
            is_pt_selected[i] = true;
        }
    }
    update();
}

void WireCreater::callLoadFeature()
{
    this->loadFeature(std::string());
}

void WireCreater::callLoadApt()
{
    this->loadApt(std::string());
}

void WireCreater::callLoadSegment()
{
    this->loadSegment(std::string());
}

void WireCreater::callSaveField()
{   
    const double logi1a = tabCurveParam->getVariantProperty("Curve.Logi1a")->value().toDouble();
    const double logi1b = tabCurveParam->getVariantProperty("Curve.Logi1b")->value().toDouble();
    const double logi2a = tabCurveParam->getVariantProperty("Curve.Logi2a")->value().toDouble();
    const double logi2b = tabCurveParam->getVariantProperty("Curve.Logi2b")->value().toDouble();
    {
        QString filename = QFileDialog::getSaveFileName(NULL, "save w1 field", ".", ".fid");
        std::ofstream f(filename.toStdString(), std::ios::out | std::ios::trunc);
        for (int i = 0; i < s_f.front().size(); ++i)
        {
            f << logistic_1(s_f.front()[i] / mesh_poly_.get_avg_edge_len(false),logi1a,logi1b) << std::endl;
        }
        f.close();
    }
    {
        QString filename = QFileDialog::getSaveFileName(NULL, "save w1 and w2 field", ".", ".fid");
        std::ofstream f(filename.toStdString(), std::ios::out | std::ios::trunc);
        bool is_bridge; int res_idx;
        std::vector<double>line_scalar_field;
        selectRes(is_bridge, res_idx);
        if (is_bridge)
        {   
            std::cout << "aaaa" << std::endl;
            line_scalar_field = mesh_poly_.vec_4_scalar_field_bridge[res_idx]; 
            std::cout << "aaaa" << std::endl;
        }
        else
        {   
            std::cout << "bbbb" << std::endl;
            line_scalar_field = mesh_poly_.vec_4_scalar_field[res_idx];
            std::cout << "bbbb" << std::endl;
        }
        for (int i = 0; i < s_f.front().size(); ++i)
        {
            f << logistic_1(s_f.front()[i]/mesh_poly_.get_avg_edge_len(false), logi1a, logi1b)/ logistic_2(line_scalar_field[i] / mesh_poly_.get_avg_edge_len(false), logi2a, logi2b) << std::endl;
        }
        f.close();
    }
}

void WireCreater::callSaveFeature()
{
    QString filename = QFileDialog::getSaveFileName(NULL, "save anchor points", ".", ".fea");
    std::ofstream f(filename.toStdString(), std::ios::out | std::ios::trunc);
    for (auto i : feature_->features_draw_option_)
    {
        if (i.second == kDrawingOption::DRAW_SAVED_RES)
        {
            f << i.first << std::endl;
            f << feature_->feature_lines[i.first].size() << std::endl;
            for (int j = 0; j < feature_->feature_lines[i.first].size(); ++j)
            {
                f << feature_->feature_lines[i.first][j].size() << std::endl;
                for (int k = 0; k < feature_->feature_lines[i.first][j].size(); ++k)
                {
                    auto pt = feature_->feature_lines[i.first][j][k];
                    f << pt.x() << " " << pt.y() << " " << pt.z() << std::endl;
                }
            }
            f << feature_->feature_lines_cross_faces[i.first].size() << std::endl;
            for (int j = 0; j < feature_->feature_lines_cross_faces[i.first].size(); ++j)
            {
                f << feature_->feature_lines_cross_faces[i.first][j].size() << std::endl;
                for (int k = 0; k < feature_->feature_lines_cross_faces[i.first][j].size(); ++k)
                {
                    int pt = feature_->feature_lines_cross_faces[i.first][j][k];
                    f << pt << std::endl;
                }
            }

            f << feature_->feature_paths[i.first].size() << std::endl;
            for (int j = 0; j < feature_->feature_paths[i.first].size(); ++j)
            {
                f << feature_->feature_paths[i.first][j].size() << std::endl;
                for (int k = 0; k < feature_->feature_paths[i.first][j].size(); ++k)
                {
                    int pt = feature_->feature_paths[i.first][j][k];
                    f << pt << std::endl;
                }
            }
        }
    }
    f.close();
}

void WireCreater::callSaveApt()
{
    QString filename = QFileDialog::getSaveFileName(NULL, "save anchor points", ".", ".apt");
    std::ofstream f(filename.toStdString(), std::ios::out | std::ios::trunc);
    for (auto i : selectPointsIndex)
    {
        f << i << std::endl;
    }
    f.close();
    for (int pt_i=0;pt_i< selectPointsIndex.size();++pt_i)
    {
        auto v = mesh_poly_.index_to_vertex_map[selectPointsIndex[pt_i]];
        double xc = v->point().x();
        double yc = v->point().y();
        double zc = v->point().z();
        double r = 0.05;
        int lats = 20; int longs = 20;
        int i, j;
        std::vector<std::vector<Eigen::Vector3d>>vtx(lats + 2);
        std::vector<std::vector<Eigen::Vector3d>>normals(lats + 2);
        std::vector<std::vector<int>>(lats + 2);
        for (i = 0; i <= lats; i++) {
            double lat0 = M_PI * (-0.5 + (double)(i - 1) / lats);
            double z0 = sin(lat0);
            double zr0 = cos(lat0);

            double lat1 = M_PI * (-0.5 + (double)i / lats);
            double z1 = sin(lat1);
            double zr1 = cos(lat1);

            //glBegin(GL_QUAD_STRIP);
            for (j = 0; j <= longs; j++) {
                double lng = 2 * M_PI * (double)(j - 1) / longs;
                double x = cos(lng);
                double y = sin(lng);

                //glNormal3f(x * zr0, y * zr0, z0);
                normals[i].push_back(Eigen::Vector3d(x * zr0, y * zr0, z0));
                vtx[i].push_back(Eigen::Vector3d(xc + r * x * zr0, yc + r * y * zr0, zc + r * z0));
                normals[i+1].push_back(Eigen::Vector3d(x * zr1, y * zr1, z1));
                vtx[i+1].push_back(Eigen::Vector3d(xc + r * x * zr1, yc + r * y * zr1, zc + r * z1));
            }
            //glEnd();
        }
        std::string sphere_filename = "select_sphere" + std::to_string(pt_i) + ".obj";
        std::ofstream f_sphere(sphere_filename, std::ios::out | std::ios::trunc);
        for (int i = 0; i < vtx.size(); ++i)
        {
            for (int j = 0; j < vtx.front().size(); ++j)
            {
                f_sphere << "v " << vtx[i][j].x() << " " << vtx[i][j].y() << " "<< vtx[i][j].z() << std::endl;
            }
        }
        for (int i = 0; i < vtx.size(); ++i)
        {
            for (int j = 0; j < vtx.front().size(); ++j)
            {
                f_sphere << "vn " << normals[i][j].x() << " " << normals[i][j].y() << " " << normals[i][j].z() << std::endl;
            }
        }
        for (int i = 0; i < vtx.size()-1; ++i)
        {
            for (int j = 0; j < vtx.front().size(); ++j)
            {
                f_sphere << "f " << i * vtx.front().size() + j +1<< "/" << i * vtx.front().size() + j +1<< " ";
                f_sphere << i * vtx.front().size() + ((j +1)% vtx.front().size())+1<< "/" << i * vtx.front().size() + ((j + 1) % vtx.front().size())+1 << " ";
                f_sphere << (i +1) * vtx.front().size() + ((j + 1) % vtx.front().size()) +1<< "/" << (i + 1) * vtx.front().size() + ((j + 1) % vtx.front().size()) +1<< " ";
                f_sphere << (i + 1) * vtx.front().size() + j + 1 << "/" << (i + 1) * vtx.front().size() + j + 1 << std::endl;;
            }
        }
        f_sphere.close();
    }

    f.close();
}

void WireCreater::callSaveCurveParam()
{
    QString filename = QFileDialog::getSaveFileName(NULL, "save curve params", ".", ".prm");
    std::ofstream f(filename.toStdString(), std::ios::out | std::ios::trunc);
    f << tabCurveParam->getVariantProperty("Curve.LineSegment")->value().toInt() << std::endl;
    f << tabCurveParam->getVariantProperty("Curve.ErrorMagnitude")->value().toDouble() << std::endl;
    f << tabCurveParam->getVariantProperty("Curve.SmoothIterTime")->value().toInt() << std::endl;
    f << tabCurveParam->getVariantProperty("Curve.MaxLineNums")->value().toInt() << std::endl;
    f << tabCurveParam->getVariantProperty("Curve.BridgeDensity")->value().toDouble() << std::endl;
    f << tabCurveParam->getVariantProperty("Curve.FeatureModifier")->value().toDouble()<<std::endl;
    f << tabCurveParam->getVariantProperty("Curve.MinRadiusOfCurvature")->value().toDouble() << std::endl;
    f.close();
}

void WireCreater::loadCurveParam(std::string filename)
{
    std::string filename_;
    if (filename.empty())
    {
        QString filename_q = QFileDialog::getOpenFileName(NULL, "curve param select", ".", "*.prm");
        filename_ = filename_q.toStdString();
    }
    else
    {
        filename_ = filename;
    }
    std::ifstream input(filename_);

    int input_line_segment;
    double input_error_magnitude;
    int input_smooth_itertime;
    int input_max_line_nums;
    double input_bridge_den;
    double feature_modifier;
    double min_radix_of_curvature;
    input >> input_line_segment;
    input >> input_error_magnitude;
    input >> input_smooth_itertime;
    input >> input_max_line_nums;
    input >> input_bridge_den;
    input >> feature_modifier;
    input >> min_radix_of_curvature;
    tabCurveParam->getVariantProperty("Curve.LineSegment")->setValue(input_line_segment);
    tabCurveParam->getVariantProperty("Curve.ErrorMagnitude")->setValue(input_error_magnitude);
    tabCurveParam->getVariantProperty("Curve.SmoothIterTime")->setValue(input_smooth_itertime);
    tabCurveParam->getVariantProperty("Curve.MaxLineNums")->setValue(input_max_line_nums);
    tabCurveParam->getVariantProperty("Curve.BridgeDensity")->setValue(input_bridge_den);
    tabCurveParam->getVariantProperty("Curve.FeatureModifier")->setValue(feature_modifier);
    tabCurveParam->getVariantProperty("Curve.MinRadiusOfCurvature")->setValue(min_radix_of_curvature);
    input.close();
}

void WireCreater::loadFeature(std::string filename)
{
    std::string filename_;
    if (filename.empty())
    {
        QString filename_q = QFileDialog::getOpenFileName(NULL, "feature select", ".", "*.fea");
        filename_ = filename_q.toStdString();
    }
    else
    {
        filename_ = filename;
    }
    std::ifstream input(filename_);

    std::vector<std::string>input_feature;

    while (!input.eof())
    {
        int line_num;
        int line_seg;
        std::string feature_type;
        std::vector<std::vector<Eigen::RowVector3d>>f_lines;
        std::vector<std::vector<int>>f_lines_cross_faces;
        std::vector<std::vector<int>>f_paths;
        input >> feature_type;
        input_feature.push_back(feature_type);
        input >> line_num;
        double x, y, z;
        for (int i = 0; i < line_num; ++i)
        {
            f_lines.push_back(std::vector<Eigen::RowVector3d>());
            input >> line_seg;
            for (int j = 0; j < line_seg; ++j)
            {
                input >> x >> y >> z;
                f_lines.back().push_back(Eigen::RowVector3d(x, y, z));
            }
        }
        input >> line_num;
        int facet;
        for (int i = 0; i < line_num; ++i)
        {
            f_lines_cross_faces.push_back(std::vector<int>());
            input >> line_seg;
            for (int j = 0; j < line_seg; ++j)
            {
                input >> facet;
                f_lines_cross_faces.back().push_back(facet);
            }
        }
        input >> line_num;
        int idx;
        for (int i = 0; i < line_num; ++i)
        {
            f_paths.push_back(std::vector<int>());
            input >> line_seg;
            for (int j = 0; j < line_seg; ++j)
            {
                input >> idx;
                f_paths.back().push_back(idx);
            }
        }
        if (feature_type.compare("suggestiveHighlights")==0)
        {
            feature_type = "suggestive highlights";
        }
        if (feature_type.compare("suggestiveContours") == 0)
        {
            feature_type = "suggestive contours";
        }
        feature_->feature_lines[feature_type] = f_lines;
        feature_->feature_lines_cross_faces[feature_type] = f_lines_cross_faces;
        feature_->feature_paths[feature_type] = f_paths;
        std::cout << feature_type<<std::endl;
    }
    //need change slots func
    for (int i = 0; i < input_feature.size(); ++i)
    {
        if (input_feature[i].compare("silhouette") == 0)
        {
            ui.actiondraw_saved_result_silhouette->setChecked(true);
            feature_->features_draw_option_["silhouette"] = kDrawingOption::DRAW_SAVED_RES;
        }
        else if (input_feature[i].compare("topolines") == 0)
        {
            ui.actiondraw_saved_result_topolines->setChecked(true);
            feature_->features_draw_option_["topolines"] = kDrawingOption::DRAW_SAVED_RES;
        }
        else if (input_feature[i].compare("misc_K") == 0)
        {
            ui.actiondraw_saved_result_miscK->setChecked(true);
            feature_->features_draw_option_["misc_K"] = kDrawingOption::DRAW_SAVED_RES;
        }
        else if (input_feature[i].compare("misc_H") == 0)
        {
            ui.actiondraw_saved_result_miscH->setChecked(true);
            feature_->features_draw_option_["misc_K"] = kDrawingOption::DRAW_SAVED_RES;
        }
        else if (input_feature[i].compare("misc_DwKr") == 0)
        {
            ui.actiondraw_saved_result_miscDwKr->setChecked(true);
            feature_->features_draw_option_["misc_DwKr"] = kDrawingOption::DRAW_SAVED_RES;
        }
        else if (input_feature[i].compare("ridges") == 0)
        {
            ui.actiondraw_saved_result_ridges->setChecked(true);
            feature_->features_draw_option_["ridges"] = kDrawingOption::DRAW_SAVED_RES;
        }
        else if (input_feature[i].compare("valleys") == 0)
        {
            ui.actiondraw_saved_result_valleys->setChecked(true);
            feature_->features_draw_option_["valleys"] = kDrawingOption::DRAW_SAVED_RES;
        }
        else if (input_feature[i].compare("suggestiveHighlights") == 0)
        {
            ui.actiondraw_saved_result_sh->setChecked(true);
            feature_->features_draw_option_["suggestive highlights"] = kDrawingOption::DRAW_SAVED_RES;
        }
        else if (input_feature[i].compare("suggestiveContours") == 0)
        {
            ui.actiondraw_saved_result_sc->setChecked(true);
            feature_->features_draw_option_["suggestive contours"] = kDrawingOption::DRAW_SAVED_RES;
        }
        else if (input_feature[i].compare("contours") == 0)
        {
            ui.actiondraw_saved_result_contours->setChecked(true);
            feature_->features_draw_option_["contours"] = kDrawingOption::DRAW_SAVED_RES;
        }
        else
        {
            break;
        }
    }
    if (v_f.empty())
    {
        if (!load_from_cfg)
        {
            stripsMerge();
        }
        computeField();
        for (auto i : feature_->features_draw_option_)
        {
            if (i.second == kDrawingOption::DRAW_SAVED_RES)
            {
                v_f.push_back(feature_->feature_vector_field[i.first]);
                s_f.push_back(feature_->feature_scalar_field[i.first]);
            }
        }
        if (feature_->user_input_feature.size() > 0)
        {
            mesh_poly_.compute_optimal_orien(feature_->user_input_feature, feature_->user_input_vector_field);
            mesh_poly_.compute_heat_val(feature_->user_input_feature, feature_->user_input_scalar_field);
            v_f.push_back(feature_->user_input_vector_field);
            s_f.push_back(feature_->user_input_scalar_field);
        }
    }
    update();
}

void WireCreater::callLoadModel()
{
    QString filename = QFileDialog::getOpenFileName(NULL, "load config", ".", "*");
    QString dir_path = filename.left(filename.lastIndexOf("/"));
    std::ifstream input(filename.toStdString());
    QString file_name_local=filename.right(filename.size()- filename.lastIndexOf("/")-1);
    model_name = file_name_local.left(file_name_local.lastIndexOf("."));
    std::cout << model_name.toStdString() << std::endl;
    std::string file_name;
    load_from_cfg = false;
    if (filename.endsWith(".cfg"))
    {
        while (!input.eof())
        {
            input >> file_name;
            std::cout << file_name << std::endl;;
            QString file_name_(file_name.c_str());
            file_name_ = dir_path + QString('/') + file_name_;
            //std::ifstream input_(file_name_.toStdString());
            if (file_name_.endsWith(".off"))
            {
                loadModel(file_name_.toStdString());
            }
            else if (file_name_.endsWith(".seg"))
            {
                loadSegment(file_name_.toStdString());
            }
            else if (file_name_.endsWith(".apt"))
            {
                loadApt(file_name_.toStdString());
            }
            else if (file_name_.endsWith(".fea"))
            {   
                load_from_cfg = true;
                loadFeature(file_name_.toStdString());
            }
            else if (file_name_.endsWith(".prm"))
            {
                loadCurveParam(file_name_.toStdString());
            }
        }
    }
    else if (filename.endsWith(".off"))
    {   
        //load_from_cfg = false;
        loadModel(filename.toStdString());
    }
}

void WireCreater::setDrawFeatureOption()
{
    for (int i = 0; i < 4; ++i)
    {
        if (ag_feature_silhouette->actions()[i]->isChecked())
        {
            feature_->features_draw_option_["silhouette"] = i;
        }
        if (ag_feature_topolines->actions()[i]->isChecked())
        {
            feature_->features_draw_option_["topolines"] = i;
        }
        if (ag_feature_miscK->actions()[i]->isChecked())
        {
            feature_->features_draw_option_["misc_K"] = i;
        }
        if (ag_feature_miscH->actions()[i]->isChecked())
        {
            feature_->features_draw_option_["misc_H"] = i;
        }
        if (ag_feature_miscDwKr->actions()[i]->isChecked())
        {
            feature_->features_draw_option_["misc_DwKr"] = i;
        }
        if (ag_feature_ridges->actions()[i]->isChecked())
        {
            feature_->features_draw_option_["ridges"] = i;
        }
        if (ag_feature_valleys->actions()[i]->isChecked())
        {
            feature_->features_draw_option_["valleys"] = i;
        }
        if (ag_feature_sh->actions()[i]->isChecked())
        {
            feature_->features_draw_option_["suggestive highlights"] = i;
        }
        if (ag_feature_sc->actions()[i]->isChecked())
        {
            feature_->features_draw_option_["suggestive contours"] = i;
        }
        if (ag_feature_contours->actions()[i]->isChecked())
        {
            feature_->features_draw_option_["contours"] = i;
        }
    }
}

void WireCreater::stripsMerge()
{
    feature_->merge_stripes_pipeline();
}

void WireCreater::computeField()
{
    for (auto i : feature_->features_draw_option_)
    {
        if (i.second == kDrawingOption::DRAW_SAVED_RES|| i.second == kDrawingOption::DRAW_SAVED_RES_NOTHING)
        {
            mesh_poly_.compute_optimal_orien(feature_->feature_lines[i.first],
                feature_->feature_lines_cross_faces[i.first],
                feature_->feature_vector_field[i.first]);
            mesh_poly_.compute_heat_val(feature_->feature_lines[i.first],
                feature_->feature_lines_cross_faces[i.first],
                feature_->feature_scalar_field[i.first]);
            std::vector<std::set<int>>f_p;
            std::vector<std::vector<int>>f_p_vec;
            for (int j = 0; j < feature_->feature_lines_cross_faces[i.first].size(); ++j)
            {
                f_p.push_back(std::set<int>());
                for (int k = 0; k < feature_->feature_lines_cross_faces[i.first][j].size(); ++k)
                {   
                    auto f = feature_->feature_lines_cross_faces[i.first][j][k];
                    int p1 = feature_->themesh->faces[f][0];
                    int p2 = feature_->themesh->faces[f][1];
                    int p3 = feature_->themesh->faces[f][2];
                    f_p.back().insert(p1);
                    f_p.back().insert(p2);
                    f_p.back().insert(p3);
                }
                f_p_vec.push_back(std::vector<int>(f_p.back().begin(), f_p.back().end()));
            }
            feature_->feature_paths[i.first] = f_p_vec;
        }
    }
}

void WireCreater::computeFieldAssemble(std::vector<std::vector<std::vector<int>>>&feature_paths)
{   
    std::vector<std::vector<Eigen::RowVector3d>>feature_lines;
    std::vector<std::vector<int>>feature_lines_cross_faces;
    std::vector<Eigen::RowVector3d>feature_vector_field;
    std::vector<double>feature_scalar_field;
    for (auto i : feature_->features_draw_option_)
    {
        if (i.second == kDrawingOption::DRAW_SAVED_RES)
        {
            feature_lines.insert(feature_lines.end(), feature_->feature_lines[i.first].begin(), feature_->feature_lines[i.first].end());
            feature_lines_cross_faces.insert(feature_lines_cross_faces.end(),
                feature_->feature_lines_cross_faces[i.first].begin(),
                feature_->feature_lines_cross_faces[i.first].end());
        }
    }
    mesh_poly_.compute_optimal_orien(feature_lines, feature_lines_cross_faces, feature_vector_field);
    mesh_poly_.compute_heat_val(feature_lines, feature_lines_cross_faces, feature_scalar_field);
    
    v_f.push_back(feature_vector_field);
    s_f.push_back(feature_scalar_field);

    std::vector<std::set<int>>f_p;
    std::vector<std::vector<int>>f_p_vec;

    for (int j = 0; j < feature_lines_cross_faces.size(); ++j)
    {
        f_p.push_back(std::set<int>());
        for (int k = 0; k < feature_lines_cross_faces[j].size(); ++k)
        {
            auto f = feature_lines_cross_faces[j][k];
            int p1 = feature_->themesh->faces[f][0];
            int p2 = feature_->themesh->faces[f][1];
            int p3 = feature_->themesh->faces[f][2];
            f_p.back().insert(p1);
            f_p.back().insert(p2);
            f_p.back().insert(p3);
        }
        f_p_vec.push_back(std::vector<int>(f_p.back().begin(), f_p.back().end()));
    }
    feature_paths.clear();
    feature_paths.push_back(f_p_vec);
}

void WireCreater::callFormLines()
{   
    recordAlgoFormLines();
    if (v_f.empty())
    {
        if (!load_from_cfg)
        {
            stripsMerge();
        }
        computeField();
        for (auto i : feature_->features_draw_option_)
        {
            if (i.second == kDrawingOption::DRAW_SAVED_RES)
            {
                v_f.push_back(feature_->feature_vector_field[i.first]);
                s_f.push_back(feature_->feature_scalar_field[i.first]);
            }
        }
        if (feature_->user_input_feature.size() > 0)
        {
            mesh_poly_.compute_optimal_orien(feature_->user_input_feature, feature_->user_input_vector_field);
            mesh_poly_.compute_heat_val(feature_->user_input_feature, feature_->user_input_scalar_field);
            v_f.push_back(feature_->user_input_vector_field);
            s_f.push_back(feature_->user_input_scalar_field);
        }
    }

    double featureModifier = tabCurveParam->getVariantProperty("Curve.FeatureModifier")->value().toDouble();
    progressDialog = new QProgressDialog(this);
    progressDialog->setMinimum(0);
    progressDialog->setMaximum(100);
    progressDialog->show();
    progressDialog->setValue(0);
    QApplication::processEvents();
    progressDialog->update();

    std::vector<std::vector<std::vector<int>>>feature_paths;
    for (auto i : feature_->feature_paths)
    {
        if (!i.second.empty())
        {
            feature_paths.push_back(i.second);
        }
    }

    //std::cout << s_f.size() << std::endl;
    std::vector<double>feature_modifier = std::vector<double>(v_f.size(), 1);
    //const int max_line_num = le_max_line_num->text().toInt();
    const int max_line_num = tabCurveParam->getVariantProperty("Curve.MaxLineNums")->value().toInt();
    const int new_branch_size = tabCurveParam->getVariantProperty("Curve.NewBranchSize")->value().toInt();
    const int max_candidate_size = tabCurveParam->getVariantProperty("Curve.MaxCandidateSize")->value().toInt();

    const double logi1a = tabCurveParam->getVariantProperty("Curve.Logi1a")->value().toDouble();
    const double logi1b = tabCurveParam->getVariantProperty("Curve.Logi1b")->value().toDouble();
    const double logi2a = tabCurveParam->getVariantProperty("Curve.Logi2a")->value().toDouble();
    const double logi2b = tabCurveParam->getVariantProperty("Curve.Logi2b")->value().toDouble();
    const double redundancyWeight = tabCurveParam->getVariantProperty("Curve.RedundancyWeight")->value().toDouble();
    /*
    mesh_poly_.multiple_circuit_traverse(seg,
        v_f, s_f, feature_modifier, selectPointsIndex,
        feature_->multiple_assemble_paths, true, max_line_num, 0, progressDialog,featureModifier);
    */
    mesh_poly_.multiple_traverse_copy(seg,
        v_f, s_f, feature_modifier, selectPointsIndex,
        feature_->multiple_assemble_paths, true, max_line_num, 0, progressDialog, max_candidate_size,new_branch_size, 
        logi1a, logi1b, logi2a, logi2b);
    update();
    mesh_poly_.compute_coveragence(feature_->multiple_assemble_paths,
        mesh_poly_.vec_4_curve_apt,
        feature_->multiple_assemble_paths_coveragence,
        feature_paths, s_f,
        mesh_poly_.sigma_field_paths,
        mesh_poly_.feature_field_paths, 
        mesh_poly_.uncut_line_field_paths, redundancyWeight);
    auto res_arg_sort = sort_indexes(feature_->multiple_assemble_paths_coveragence);

    progressDialog->setValue(80);
    QApplication::processEvents();
    progressDialog->update();
    double bridge_den= tabCurveParam->getVariantProperty("Curve.BridgeDensity")->value().toDouble();
    //debug?
    mesh_poly_.auto_bridge(seg, v_f, s_f, feature_->multiple_assemble_paths,
        feature_->multiple_assemble_bridges, feature_->multiple_bridges_str, feature_->multiple_assemble_smooth_twice_paths,
        bridge_den, logi1a, logi1b, logi2a, logi2b);
    std::cout << "done" << std::endl;
    mesh_poly_.compute_coveragence(feature_->multiple_assemble_bridges,
        mesh_poly_.vec_4_curve_apt_bridge,
        feature_->multiple_assemble_bridges_coveragence,
        feature_paths, s_f,
        mesh_poly_.sigma_field_bridges,
        mesh_poly_.feature_field_bridges,
        mesh_poly_.uncut_line_field_bridges, redundancyWeight);
    //createBridgeShowOpts();
    progressDialog->setValue(90);
    QApplication::processEvents();
    progressDialog->update();
    emit ui.MainWidget->Viewer_Sender();
    callGetRes();
    progressDialog->setValue(100);
    QApplication::processEvents();
    progressDialog->update();
    recordAlgoFormLinesDone();
}

void WireCreater::callFormLinesAlter()
{
    recordAlgoFormLines();
    if (v_f.empty())
    {
        if (!load_from_cfg)
        {
            stripsMerge();
        }
        computeField();
        for (auto i : feature_->features_draw_option_)
        {
            if (i.second == kDrawingOption::DRAW_SAVED_RES)
            {
                v_f.push_back(feature_->feature_vector_field[i.first]);
                s_f.push_back(feature_->feature_scalar_field[i.first]);
            }
        }
        if (feature_->user_input_feature.size() > 0)
        {
            mesh_poly_.compute_optimal_orien(feature_->user_input_feature, feature_->user_input_vector_field);
            mesh_poly_.compute_heat_val(feature_->user_input_feature, feature_->user_input_scalar_field);
            v_f.push_back(feature_->user_input_vector_field);
            s_f.push_back(feature_->user_input_scalar_field);
        }
    }

    double featureModifier = tabCurveParam->getVariantProperty("Curve.FeatureModifier")->value().toDouble();

    const int max_line_num = tabCurveParam->getVariantProperty("Curve.MaxLineNums")->value().toInt();
    const int new_branch_size = tabCurveParam->getVariantProperty("Curve.NewBranchSize")->value().toInt();
    const int max_candidate_size = tabCurveParam->getVariantProperty("Curve.MaxCandidateSize")->value().toInt();

    const double logi1a = tabCurveParam->getVariantProperty("Curve.Logi1a")->value().toDouble();
    const double logi1b = tabCurveParam->getVariantProperty("Curve.Logi1b")->value().toDouble();
    const double logi2a = tabCurveParam->getVariantProperty("Curve.Logi2a")->value().toDouble();
    const double logi2b = tabCurveParam->getVariantProperty("Curve.Logi2b")->value().toDouble();
    const double redundancyWeight = tabCurveParam->getVariantProperty("Curve.RedundancyWeight")->value().toDouble();
    progressDialog = new QProgressDialog(this);
    progressDialog->setMinimum(0);
    progressDialog->setMaximum(100);
    progressDialog->show();
    progressDialog->setValue(0);
    QApplication::processEvents();
    progressDialog->update();

    std::vector<std::vector<std::vector<int>>>feature_paths;
    for (auto i : feature_->feature_paths)
    {
        if (!i.second.empty())
        {
            feature_paths.push_back(i.second);
        }
    }

    //std::cout << s_f.size() << std::endl;
    std::vector<double>feature_modifier = std::vector<double>(v_f.size(), 1);
    //const int max_line_num = le_max_line_num->text().toInt();
    std::vector<std::vector<int>>select_pts;
    for (int i = 0; i < selectPointsIndex.size(); ++i)
    {
        select_pts.push_back(std::vector<int>());
        select_pts.back().push_back(selectPointsIndex[i]);
    }
    for (int i = 0; i < pre_anchor_paths.size(); ++i)
    {
        select_pts.push_back(pre_anchor_paths[i]);
    }
    mesh_poly_.multiple_circuit_traverse(seg,
        v_f, s_f, feature_modifier, select_pts,
        feature_->multiple_assemble_paths, true, max_line_num, 0, progressDialog, max_candidate_size, new_branch_size, logi1a,logi1b,logi2a,logi2b);
    /*
    mesh_poly_.single_traverse(seg,
        v_f, s_f, feature_modifier, selectPointsIndex,
        feature_->multiple_assemble_paths, true, max_line_num, 0, progressDialog, logi1a, logi1b, logi2a, logi2b);
        */
    update();
    mesh_poly_.compute_coveragence(feature_->multiple_assemble_paths,
        mesh_poly_.vec_4_curve_apt,
        feature_->multiple_assemble_paths_coveragence,
        feature_paths, s_f,
        mesh_poly_.sigma_field_paths,
        mesh_poly_.feature_field_paths,
        mesh_poly_.uncut_line_field_paths, redundancyWeight);
    auto res_arg_sort = sort_indexes(feature_->multiple_assemble_paths_coveragence);

    progressDialog->setValue(80);
    QApplication::processEvents();
    progressDialog->update();
    double bridge_den = tabCurveParam->getVariantProperty("Curve.BridgeDensity")->value().toDouble();
    progressDialog->setValue(90);
    QApplication::processEvents();
    progressDialog->update();
    emit ui.MainWidget->Viewer_Sender();
    callGetRes();
    progressDialog->setValue(100);
    QApplication::processEvents();
    progressDialog->update();
    recordAlgoFormLinesDone();
}


void WireCreater::callFormLinesAssemble()
{   
    /*
    std::vector<std::vector<std::vector<int>>>feature_paths;
    if (v_f.empty())
    {
        if (!load_from_cfg)
        {
            stripsMerge();
        }
        computeFieldAssemble(feature_paths);
    }

    double featureModifier = tabCurveParam->getVariantProperty("Curve.FeatureModifier")->value().toDouble();
    progressDialog = new QProgressDialog(this);
    progressDialog->setMinimum(0);
    progressDialog->setMaximum(100);
    progressDialog->show();
    progressDialog->setValue(0);
    QApplication::processEvents();
    progressDialog->update();

    //std::cout << s_f.size() << std::endl;
    std::vector<double>feature_modifier = std::vector<double>(v_f.size(), 1);
    //const int max_line_num = le_max_line_num->text().toInt();
    const int max_line_num = tabCurveParam->getVariantProperty("Curve.MaxLineNums")->value().toInt();
    mesh_poly_.multiple_circuit_traverse(seg,
        v_f, s_f, feature_modifier, selectPointsIndex,
        feature_->multiple_assemble_paths, true, max_line_num, 0, progressDialog, featureModifier);
    update();
    mesh_poly_.compute_coveragence(feature_->multiple_assemble_paths,
        mesh_poly_.vec_4_curve_apt,
        feature_->multiple_assemble_paths_coveragence,
        feature_paths, s_f,
        mesh_poly_.sigma_field_paths,
        mesh_poly_.feature_field_paths,
        mesh_poly_.uncut_line_field_paths);
    auto res_arg_sort = sort_indexes(feature_->multiple_assemble_paths_coveragence);

    progressDialog->setValue(80);
    QApplication::processEvents();
    progressDialog->update();
    double bridge_den = tabCurveParam->getVariantProperty("Curve.BridgeDensity")->value().toDouble();
    //debug?
    mesh_poly_.auto_bridge(seg, v_f, s_f, feature_->multiple_assemble_paths,
        feature_->multiple_assemble_bridges, feature_->multiple_bridges_str, feature_->multiple_assemble_smooth_twice_paths,
        bridge_den, featureModifier, );
    std::cout << "done" << std::endl;
    mesh_poly_.compute_coveragence(feature_->multiple_assemble_bridges,
        mesh_poly_.vec_4_curve_apt_bridge,
        feature_->multiple_assemble_bridges_coveragence,
        feature_paths, s_f,
        mesh_poly_.sigma_field_bridges,
        mesh_poly_.feature_field_bridges,
        mesh_poly_.uncut_line_field_bridges);
    //createBridgeShowOpts();
    progressDialog->setValue(90);
    QApplication::processEvents();
    progressDialog->update();
    emit ui.MainWidget->Viewer_Sender();
    callGetRes();
    progressDialog->setValue(100);
    QApplication::processEvents();
    progressDialog->update();
    statusLabel->setText("this is another test");
    */
}

void WireCreater::selectRes(bool& is_bridge, int& res_idx)
{
    QString qstr = vec_4_res_qstr[load_path_idx];
    //std::vector<std::vector<int>>path_res_idx;
    if (qstr.lastIndexOf("b") != -1)
    {
        is_bridge = true;
        for (int i = 0; i < feature_->multiple_bridges_str.size(); ++i)
        {
            if (qstr.compare(feature_->multiple_bridges_str[i].c_str()) == 0)
            {
                res_idx = i;
                break;
            }
        }
    }
    else
    {
        is_bridge = false;
        res_idx = qstr.right(qstr.size() - 1).toInt();
    }
}

void WireCreater::callClearBridgeApts()
{
    //setMouseTracking(true);
    bridge_pt = -1;
    select_move_pt_idx_i = -1;
    select_move_pt_idx_j = -1;
    ui.MainWidget->update();
}

void WireCreater::callClearUserInput()
{
    user_input.clear();
    select_rect_paths.clear();
    ui.MainWidget->repaint();
}


void WireCreater::callAttachToPt()
{   
    if (bridge_pt < 0)
    {
        return;
    }

    bool is_bridge; int res_idx;
    selectRes(is_bridge, res_idx);
    stk_user_edit.push(path_res);
    stk_load_path_idx.push(load_path_idx);
    if (is_bridge)
    {
        stk_line_scalar_field.push(mesh_poly_.vec_4_scalar_field_bridge[res_idx]);
        stk_apts.push(mesh_poly_.vec_4_curve_apt_bridge[res_idx]);
        stk_paths.push(mesh_poly_.vec_4_paths_bridge[res_idx]);
    }
    else
    {
        stk_line_scalar_field.push(mesh_poly_.vec_4_scalar_field[res_idx]);
        stk_apts.push(mesh_poly_.vec_4_curve_apt[res_idx]);
        stk_paths.push(mesh_poly_.vec_4_paths[res_idx]);
    }
    while (!redo_stk_user_edit.empty())
    {
        redo_stk_user_edit.pop();
        redo_stk_load_path_idx.pop();
        redo_stk_line_scalar_field.pop();
        redo_stk_apts.pop();
        redo_stk_paths.pop();
    }

    std::vector<std::vector<int>>path_res_idx;
    //mesh_poly_.curve_attach_to_apt(seg, v_f, s_f, is_bridge, res_idx, bridge_pt, path_res_idx);
    callClearBridgeApts();
    const double error_mag= tabCurveParam->getVariantProperty("Curve.ErrorMagnitude")->value().toDouble();
    const int segment_times= tabCurveParam->getVariantProperty("Curve.LineSegment")->value().toInt();
    const double min_radix_of_curvature = tabCurveParam->getVariantProperty("Curve.MinRadiusOfCurvature")->value().toDouble();
    path_res = Curve(path_res_idx, selectPointsIndex, mesh_poly_, segment_times,
        error_mag, mesh_poly_.get_avg_edge_len(), feature_,false,min_radix_of_curvature);
    ui.MainWidget->path_res = &path_res;
    ui.MainWidget->update();
    callClearUserInput();
}

void WireCreater::callAttachToCurve()
{   
    if (user_input.empty())
    {
        return;
    }

    bool is_bridge; int res_idx;
    if (is_user_algo_start)
    {
        selectRes(is_bridge, res_idx);
    }
    callClearRedoStack();
    const double error_mag = tabCurveParam->getVariantProperty("Curve.ErrorMagnitude")->value().toDouble();
    const int segment_times = tabCurveParam->getVariantProperty("Curve.LineSegment")->value().toInt();
    const double min_radix_of_curvature = tabCurveParam->getVariantProperty("Curve.MinRadiusOfCurvature")->value().toDouble();
    const double logi1a = tabCurveParam->getVariantProperty("Curve.Logi1a")->value().toDouble();
    const double logi1b = tabCurveParam->getVariantProperty("Curve.Logi1b")->value().toDouble();
    const double logi2a = tabCurveParam->getVariantProperty("Curve.Logi2a")->value().toDouble();
    const double logi2b = tabCurveParam->getVariantProperty("Curve.Logi2b")->value().toDouble();
    std::vector<std::vector<int>>path_res_idx;
    std::vector<int>insert_idx;
    std::vector<int>res;
    ui.MainWidget->backProject2Mesh();
    std::vector<Eigen::Vector3d>curve_projected;
    //ui.MainWidget->backProject2Mesh();
    ui.MainWidget->backProject2Mesh(curve_projected);
    //ui.MainWidget->backProject2Mesh();
    if (curve_projected.size() < 3)
    {
        callClearUserInput();
        ui.MainWidget->update();
        return;
    }
    Curve MST_curve(curve_projected, segment_times,
        error_mag, mesh_poly_.get_avg_edge_len(), feature_, min_radix_of_curvature);
    std::vector<std::vector<int>>path_project_idx_;
    mesh_poly_.BackProject2Mesh(MST_curve.curve, path_project_idx_, error_mag);
    std::vector<std::vector<int>>insert_curve_idx;
    double feature_modifier = tabCurveParam->getVariantProperty("Curve.FeatureModifier")->value().toDouble();
    if (is_user_algo_start)
    {
        mesh_poly_.curve_attach_to_curve(seg, v_f, s_f, is_bridge, res_idx, path_project_idx_.back(), res, insert_idx, 
            logi1a,logi1b,logi2a,logi2b);
    }
    else if (is_user_study_start)
    {
        mesh_poly_.curve_attach_to_curve(seg, v_f, s_f, user_study_line_scalar_field, user_study_line_vector_field, 
            path_project_idx, path_project_idx_.back(), res, insert_idx, 
            logi1a, logi1b, logi2a, logi2b);
    }
    path_res.attachCurve(MST_curve, insert_idx, feature_);

    if (is_user_algo_start)
    {
        mesh_poly_.BackProject2Mesh(path_res.curve, error_mag, is_bridge, res_idx, true);
    }
    else if (is_user_study_start)
    {
        mesh_poly_.BackProject2Mesh(path_res.curve, error_mag, user_study_line_scalar_field, path_project_idx);
    }

    callClearUserInput();
    ui.MainWidget->path_res = &path_res;
    callClearBridgeApts();
    ui.MainWidget->update();
    recordAttractCurveDone();
    ui.MainWidget->user_study_start_pt_idx_i = -1;
    ui.MainWidget->user_study_start_pt_idx_j = -1;
}

void WireCreater::callMoveCurve()
{   
    //std::cout << "here1" <<std::endl;
    /*
    if (vec_4_path_res.empty())
    {
        if (user_study_path.empty())
        {
            return;
        }
        callClearRedoStack();
        const double error_mag = tabCurveParam->getVariantProperty("Curve.ErrorMagnitude")->value().toDouble();
        mesh_poly_.BackProject2Mesh(path_res.curve, path_project_idx, error_mag);
    }
    else
    {
        bool is_bridge; int res_idx;
        selectRes(is_bridge, res_idx);
        callClearRedoStack();

        const double error_mag = tabCurveParam->getVariantProperty("Curve.ErrorMagnitude")->value().toDouble();
        mesh_poly_.BackProject2Mesh(path_res.curve, error_mag, is_bridge, res_idx, true);
    }
    */
    recordMoveCtrlPointsDone();
    //std::cout << "move done" << std::endl;
}

void WireCreater::callMoveCurveStateChange()
{   
    if (need_modify_ctrl_pts_draw)
    {
        auto prop = tabDrawOpt->getVariantProperty("Display.CtrlPts");
        prop->setValue(true);
    }
    ui.MainWidget->user_study_start_pt_idx_i = -1;
    ui.MainWidget->user_study_start_pt_idx_j = -1;
    recordMoveCtrlPoints();
}

void WireCreater::callModifyCurve()
{   
    if (select_rect_paths.empty())
    {
        return;
    }

    bool is_bridge; int res_idx;
    if (is_user_algo_start)
    {
        selectRes(is_bridge, res_idx);
    }
    callClearRedoStack();
    std::cout << "AAAAAA" << std::endl;
    const double error_mag = tabCurveParam->getVariantProperty("Curve.ErrorMagnitude")->value().toDouble();
    const int segment_times = tabCurveParam->getVariantProperty("Curve.LineSegment")->value().toInt();
    std::vector<int>nn_path_idx;
    std::vector<std::vector<int>>path_res_idx;
    ui.MainWidget->cutPartFromMesh(nn_path_idx, is_bridge, res_idx, true);
    int lower_bound=(path_res.curve[nn_path_idx[0]].size() - 1)/10;
    int upper_bound=(path_res.curve[nn_path_idx[0]].size() - 1) / 10*9;
    std::cout << "BBBBBBBB" << std::endl;
    for (int i = 0; i < nn_path_idx.size(); ++i)
    {
        std::cout << nn_path_idx[i] << std::endl;
    }
    if (nn_path_idx[1] <= lower_bound)
    {   
        nn_path_idx[1] = 0;
        path_res.modifyCurve(nn_path_idx, feature_);
        if (is_user_algo_start)
        {
            mesh_poly_.BackProject2Mesh(path_res.curve, error_mag, is_bridge, res_idx, true);
        }
        else if (is_user_study_start)
        {
            mesh_poly_.BackProject2Mesh(path_res.curve, error_mag, user_study_line_scalar_field, path_project_idx);
        }
        ui.MainWidget->user_study_start_pt_idx_i = nn_path_idx[0];
        ui.MainWidget->user_study_start_pt_idx_j = 0;
    }
    else if (nn_path_idx[2] >= upper_bound)
    {   
        std::cout << "BBBBB" << std::endl;
        nn_path_idx[2] = path_res.curve[nn_path_idx[0]].size() - 1;
        path_res.modifyCurve(nn_path_idx, feature_);
        if (is_user_algo_start)
        {
            mesh_poly_.BackProject2Mesh(path_res.curve, error_mag, is_bridge, res_idx, true);
        }
        else if (is_user_study_start)
        {   
            mesh_poly_.BackProject2Mesh(path_res.curve, error_mag, user_study_line_scalar_field, path_project_idx);
        }
        ui.MainWidget->user_study_start_pt_idx_i = nn_path_idx[0];
        ui.MainWidget->user_study_start_pt_idx_j = path_res.curve[nn_path_idx[0]].size()-1;
    }

    ui.MainWidget->path_res = &path_res;
    callClearUserInput();
    ui.MainWidget->update();
    recordRemoveCurveDone();
}

void WireCreater::callSmoothPart()
{   
    if (select_rect_paths.empty())
    {
        return;
    }

    bool is_bridge; int res_idx;
    if (is_user_algo_start)
    {
        selectRes(is_bridge, res_idx);
    }
    /*
    stk_user_edit.push(path_res);
    stk_load_path_idx.push(load_path_idx);
    stk_algo_start_pt_idx_i.push(ui.MainWidget->user_study_start_pt_idx_i);
    stk_algo_end_pt_idx_i.push(ui.MainWidget->user_study_end_pt_idx_i);
    stk_algo_start_pt_idx_j.push(ui.MainWidget->user_study_start_pt_idx_j);
    stk_algo_end_pt_idx_j.push(ui.MainWidget->user_study_end_pt_idx_j);
    if (is_bridge)
    {
        stk_line_scalar_field.push(mesh_poly_.vec_4_scalar_field_bridge[res_idx]);
        stk_apts.push(mesh_poly_.vec_4_curve_apt_bridge[res_idx]);
        stk_paths.push(mesh_poly_.vec_4_paths_bridge[res_idx]);
    }
    else
    {
        stk_line_scalar_field.push(mesh_poly_.vec_4_scalar_field[res_idx]);
        stk_apts.push(mesh_poly_.vec_4_curve_apt[res_idx]);
        stk_paths.push(mesh_poly_.vec_4_paths[res_idx]);
    }
    while (!redo_stk_user_edit.empty())
    {
        redo_stk_user_edit.pop();
        redo_stk_load_path_idx.pop();
        redo_stk_line_scalar_field.pop();
        redo_stk_apts.pop();
        redo_stk_paths.pop();
        redo_stk_algo_start_pt_idx_i.pop();
        redo_stk_algo_end_pt_idx_i.pop();
        redo_stk_algo_start_pt_idx_j.pop();
        redo_stk_algo_end_pt_idx_j.pop();
    }
    */
    callClearRedoStack();

    std::vector<int>nn_path_idx;
    ui.MainWidget->cutPartFromMesh(nn_path_idx, is_bridge,res_idx,false);
    path_res.solve(feature_, nn_path_idx,false);
    const double error_mag = tabCurveParam->getVariantProperty("Curve.ErrorMagnitude")->value().toDouble();
    if (is_user_algo_start)
    {
        mesh_poly_.BackProject2Mesh(path_res.curve, error_mag, is_bridge, res_idx, true);
    }
    else if (is_user_study_start)
    {
        mesh_poly_.BackProject2Mesh(path_res.curve, error_mag, user_study_line_scalar_field, path_project_idx);
    }
    ui.MainWidget->update();
    select_rect_paths.clear();
    ui.MainWidget->repaint();
    recordSmoothCurveDone();
}

void WireCreater::callAddCurve()
{   
    //enter add mode?
    //then we should allow
    if (user_input.empty())
    {
        return;
    }

    bool is_bridge; int res_idx;
    selectRes(is_bridge, res_idx);

    /*
    stk_user_edit.push(path_res);
    stk_load_path_idx.push(load_path_idx);
    stk_algo_start_pt_idx_i.push(ui.MainWidget->user_study_start_pt_idx_i);
    stk_algo_end_pt_idx_i.push(ui.MainWidget->user_study_end_pt_idx_i);
    stk_algo_start_pt_idx_j.push(ui.MainWidget->user_study_start_pt_idx_j);
    stk_algo_end_pt_idx_j.push(ui.MainWidget->user_study_end_pt_idx_j);
    if (is_bridge)
    {
        stk_line_scalar_field.push(mesh_poly_.vec_4_scalar_field_bridge[res_idx]);
        stk_apts.push(mesh_poly_.vec_4_curve_apt_bridge[res_idx]);
        stk_paths.push(mesh_poly_.vec_4_paths_bridge[res_idx]);
    }
    else
    {
        stk_line_scalar_field.push(mesh_poly_.vec_4_scalar_field[res_idx]);
        stk_apts.push(mesh_poly_.vec_4_curve_apt[res_idx]);
        stk_paths.push(mesh_poly_.vec_4_paths[res_idx]);
    }
    while (!redo_stk_user_edit.empty())
    {
        redo_stk_user_edit.pop();
        redo_stk_load_path_idx.pop();
        redo_stk_line_scalar_field.pop();
        redo_stk_apts.pop();
        redo_stk_paths.pop();
        redo_stk_algo_start_pt_idx_i.pop();
        redo_stk_algo_end_pt_idx_i.pop();
        redo_stk_algo_start_pt_idx_j.pop();
        redo_stk_algo_end_pt_idx_j.pop();
    }
    */
    callClearRedoStack();
    std::vector<Eigen::Vector3d>curve_projected;
    //ui.MainWidget->backProject2Mesh();
    ui.MainWidget->backProject2Mesh(curve_projected);
    if (curve_projected.size() < 3)
    {
        callClearUserInput();
        ui.MainWidget->update();
        return;
    }
    std::vector<std::vector<int>>path_res_idx;
    std::vector<std::vector<int>>path_res_idx_;
    std::vector<std::pair<int, int>>overlap_pts;
    const double error_mag = tabCurveParam->getVariantProperty("Curve.ErrorMagnitude")->value().toDouble();
    const int segment_times = tabCurveParam->getVariantProperty("Curve.LineSegment")->value().toInt();
    const double min_radix_of_curvature= tabCurveParam->getVariantProperty("Curve.MinRadiusOfCurvature")->value().toDouble();
    {   
        Curve tmp_curve(curve_projected, segment_times, error_mag, mesh_poly_.get_avg_edge_len(), feature_, min_radix_of_curvature);
        mesh_poly_.BackProject2Mesh(tmp_curve.curve, path_res_idx, error_mag);
        mesh_poly_.add_curve(seg, v_f, s_f, is_bridge, res_idx, path_res_idx.back(), path_res_idx_, overlap_pts);
        std::vector<Eigen::Vector3d>res_path;
        for (int i = 0; i < path_res_idx_.back().size(); ++i)
        {
            auto pt = mesh_poly_.index_to_vertex_map[path_res_idx_.back()[i]]->point();
            res_path.push_back(Eigen::Vector3d(pt.x(), pt.y(), pt.z()));
        }
        Curve linked_curve(res_path, segment_times, error_mag, mesh_poly_.get_avg_edge_len(), feature_, min_radix_of_curvature);
        path_res.addCurve(linked_curve, tmp_curve, overlap_pts, feature_);
        mesh_poly_.BackProject2Mesh(path_res.curve, error_mag, is_bridge, res_idx, true);

    }
    ui.MainWidget->path_res = &path_res;
    callClearUserInput();
    ui.MainWidget->update();
    recordAddCurveDone();
}

void WireCreater::callCreateNewLine()
{   
    if (user_input.empty())
    {
        return;
    }
    const double error_mag = tabCurveParam->getVariantProperty("Curve.ErrorMagnitude")->value().toDouble();
    const int segment_times = tabCurveParam->getVariantProperty("Curve.LineSegment")->value().toInt();
    const double min_radix_of_curvature = tabCurveParam->getVariantProperty("Curve.MinRadiusOfCurvature")->value().toDouble();
    stk_user_study.push(path_res);
    stk_user_study_path.push(user_study_path);
    stk_path_project_idx.push(path_project_idx);
    stk_user_op_create_new_line.push(last_op_create_new_line);
    stk_user_start_pt_idx_i.push(ui.MainWidget->user_study_start_pt_idx_i);
    stk_user_end_pt_idx_i.push(ui.MainWidget->user_study_end_pt_idx_i);
    stk_user_start_pt_idx_j.push(ui.MainWidget->user_study_start_pt_idx_j);
    stk_user_end_pt_idx_j.push(ui.MainWidget->user_study_end_pt_idx_j);
    while (!redo_stk_user_study.empty())
    {
        redo_stk_user_study.pop();
        redo_stk_user_study_path.pop();
        redo_stk_path_project_idx.pop();
        redo_stk_user_op_create_new_line.pop();
        redo_stk_user_start_pt_idx_i.pop();
        redo_stk_user_end_pt_idx_i.pop();
        redo_stk_user_start_pt_idx_j.pop();
        redo_stk_user_end_pt_idx_j.pop();
    }
    std::vector<std::vector<int>>path_res_idx;
    std::vector<int>insert_idx;
    std::vector<int>res;
    ui.MainWidget->backProject2Mesh();
    std::vector<Eigen::Vector3d>curve_projected;
    //ui.MainWidget->backProject2Mesh();
    ui.MainWidget->backProject2Mesh(curve_projected);
    if (curve_projected.size() < 3)
    {
        callClearUserInput();
        ui.MainWidget->update();
        return;
    }

    Curve MST_curve(curve_projected, segment_times,
        error_mag, mesh_poly_.get_avg_edge_len(), feature_, min_radix_of_curvature);
    path_res = MST_curve;

    recordCreateNewLine();
    ui.MainWidget->path_res = &path_res;
    callClearUserInput();
    ui.MainWidget->update();
    //mesh_poly_.BackProject2Mesh(path_res.curve, path_project_idx, error_mag);
    mesh_poly_.BackProject2Mesh(path_res.curve, error_mag, user_study_line_scalar_field, path_project_idx);
    update();
    last_op_create_new_line = false;
    //recordLinkToLastLine();

    ui.MainWidget->user_study_start_pt_idx_i = 0;
    ui.MainWidget->user_study_start_pt_idx_j = path_res.ctrl_pts.back().size() - 1;

    callLinkToLastLineStateChange();
}

void WireCreater::callLinkToLastLine()
{   
    if ((!is_user_study_start) && (!is_user_algo_start))
    {
        return;
    }
    if (user_input.empty())
    {
        return;
    }
    const double error_mag = tabCurveParam->getVariantProperty("Curve.ErrorMagnitude")->value().toDouble();
    const int segment_times = tabCurveParam->getVariantProperty("Curve.LineSegment")->value().toInt();
    const double min_radix_of_curvature = tabCurveParam->getVariantProperty("Curve.MinRadiusOfCurvature")->value().toDouble();
    callClearRedoStack();
    std::vector<int>res_idx;
    std::vector<Eigen::Vector3d>curve_projected;
    //ui.MainWidget->backProject2Mesh();
    ui.MainWidget->backProject2Mesh(curve_projected);
    ui.MainWidget->backProject2Mesh();
    if (curve_projected.size() < 3 || user_input_MST.size() < 3)
    {
        callClearUserInput();
        ui.MainWidget->update();
        return;
    }

    if (ui.MainWidget->user_study_start_pt_idx_i == -1)
    {
        Curve MST_curve(curve_projected, segment_times,
            error_mag, mesh_poly_.get_avg_edge_len(), feature_, min_radix_of_curvature);
        path_res = MST_curve;
        recordCreateNewLine();
        ui.MainWidget->path_res = &path_res;
        callClearUserInput();
        ui.MainWidget->update();
        //mesh_poly_.BackProject2Mesh(path_res.curve, path_project_idx, error_mag);
        if (is_user_study_start)
        {
            mesh_poly_.BackProject2Mesh(path_res.curve, error_mag, user_study_line_scalar_field, path_project_idx);
        }
        else if (is_user_algo_start)
        {
            bool is_bridge; int idx;
            selectRes(is_bridge, idx);
            mesh_poly_.BackProject2Mesh(path_res.curve, error_mag, is_bridge, idx, true);
        }
        update();
        last_op_create_new_line = false;
        //recordLinkToLastLine();
        ui.MainWidget->user_study_start_pt_idx_i = 0;
        ui.MainWidget->user_study_start_pt_idx_j = path_res.ctrl_pts.back().size() - 1;

        callLinkToLastLineStateChange();
    }
    else if (ui.MainWidget->user_study_start_pt_idx_j == -1)
    {
        return;
    }
    else
    {
        std::vector<std::pair<int, int>>overlap_pts;
        std::cout << "action 1" << std::endl;
        overlap_pts.push_back(std::pair<int, int>(ui.MainWidget->user_study_start_pt_idx_i,
            ui.MainWidget->user_study_start_pt_idx_j * (segment_times - 1)));
        std::cout << "action 1.5" << std::endl;
        if (is_user_study_start)
        {
            mesh_poly_.user_study_connect_path(path_project_idx, user_input_MST, res_idx, overlap_pts);
        }
        else if (is_user_algo_start)
        {
            bool is_bridge; int idx;
            selectRes(is_bridge, idx);
            mesh_poly_.user_study_connect_path(is_bridge?mesh_poly_.vec_4_paths_bridge[idx]: mesh_poly_.vec_4_paths[idx], 
                user_input_MST, res_idx, overlap_pts);
        }
        std::cout << "action 2" << std::endl;
        std::vector<Eigen::Vector3d>res_path;
        for (int i = 0; i < res_idx.size(); ++i)
        {
            auto pt = mesh_poly_.index_to_vertex_map[res_idx[i]]->point();
            res_path.push_back(Eigen::Vector3d(pt.x(), pt.y(), pt.z()));
        }

        std::cout << "action 3" << std::endl;
        Curve tmp_curve(res_path, segment_times, error_mag, mesh_poly_.get_avg_edge_len(), feature_, min_radix_of_curvature);

        if (ui.MainWidget->user_study_start_pt_idx_j == 0)
        {
            path_res.addCurve(tmp_curve, false, ui.MainWidget->user_study_start_pt_idx_i, feature_);
            ui.MainWidget->user_study_start_pt_idx_j = 0;
            std::cout << "connect 1" << std::endl;
            //ui.MainWidget->user_study_start_pt_idx_j = 0;
        }
        else if (ui.MainWidget->user_study_start_pt_idx_j == path_res.ctrl_pts[ui.MainWidget->user_study_start_pt_idx_i].size() - 1)
        {
            path_res.addCurve(tmp_curve, true, ui.MainWidget->user_study_start_pt_idx_i, feature_);
            ui.MainWidget->user_study_start_pt_idx_j = path_res.ctrl_pts[ui.MainWidget->user_study_start_pt_idx_i].size() - 1;
            std::cout << "connect 2" << std::endl;
        }
        else
        {
            std::vector<std::pair<int, int>>overlap_pts_idx;
            path_res.appendCurve(tmp_curve, std::pair<int, int>(ui.MainWidget->user_study_start_pt_idx_i, ui.MainWidget->user_study_start_pt_idx_j));
            ui.MainWidget->user_study_start_pt_idx_i = path_res.ctrl_pts.size() - 1;
            ui.MainWidget->user_study_start_pt_idx_j = path_res.ctrl_pts.back().size() - 1;
            std::cout << "connect 3" << std::endl;
        }

        ui.MainWidget->path_res = &path_res;
        callClearUserInput();
        ui.MainWidget->update();
        if (is_user_study_start)
        {
            mesh_poly_.BackProject2Mesh(path_res.curve, error_mag, user_study_line_scalar_field, path_project_idx);
        }
        else if (is_user_algo_start)
        {
            bool is_bridge; int idx;
            selectRes(is_bridge, idx);
            mesh_poly_.BackProject2Mesh(path_res.curve, error_mag, is_bridge, idx, true);
        }
        update();
        last_op_create_new_line = false;
        recordLinkToLastLine();

        callLinkToLastLineStateChange();
    }
}

void WireCreater::callAttachToNearestLine()
{   

}

void WireCreater::callLinkEndtoEnd()
{   
    if (user_study_path.empty())
    {
        return;
    }
    stk_user_study.push(path_res);
    stk_user_study_path.push(user_study_path);
    stk_path_project_idx.push(path_project_idx);
    stk_user_op_create_new_line.push(last_op_create_new_line);
    while (!redo_stk_user_study.empty())
    {
        redo_stk_user_study.pop();
        redo_stk_user_study_path.pop();
        redo_stk_path_project_idx.pop();
        redo_stk_user_op_create_new_line.pop();
    }
    std::vector<int>res_idx;
    mesh_poly_.user_study_link_ends(user_study_path.back(), res_idx);
    user_study_path.back() = res_idx;
    const double error_mag = tabCurveParam->getVariantProperty("Curve.ErrorMagnitude")->value().toDouble();
    const int segment_times = tabCurveParam->getVariantProperty("Curve.LineSegment")->value().toInt();
    const double min_radix_of_curvature = tabCurveParam->getVariantProperty("Curve.MinRadiusOfCurvature")->value().toDouble();
    path_res = Curve(user_study_path, selectPointsIndex, mesh_poly_, segment_times,
        error_mag, mesh_poly_.get_avg_edge_len(), feature_,false,min_radix_of_curvature);
    ui.MainWidget->path_res = &path_res;
    mesh_poly_.BackProject2Mesh(path_res.curve, path_project_idx, error_mag);
    update();
    last_op_create_new_line = false;
}

void WireCreater::callGetRes()
{
    auto paths_arg_sort = sort_indexes(feature_->multiple_assemble_paths_coveragence);
    auto bridges_arg_sort = sort_indexes(feature_->multiple_assemble_bridges_coveragence);
    std::cout << "get_res" << std::endl;
    for (int i = 0; i < paths_arg_sort.size(); ++i)
    {
        std::cout << feature_->multiple_assemble_paths_coveragence[paths_arg_sort[i]] << " ";
    }
    std::cout << std::endl;
    for (int i = 0; i < bridges_arg_sort.size(); ++i)
    {
        std::cout << feature_->multiple_assemble_bridges_coveragence[bridges_arg_sort[i]] << " ";
    }
    std::cout << std::endl;

    int cur_paths_idx = 0;
    int cur_bridges_idx = 0;
    const int subwindow_num = 9;
    while (true)
    {   
        std::cout << cur_paths_idx << " " << cur_bridges_idx << std::endl;
        if ((cur_paths_idx == feature_->multiple_assemble_paths.size()) &&
            (cur_bridges_idx == feature_->multiple_assemble_bridges.size()))
        {
            break;
        }
        if ((cur_paths_idx + cur_bridges_idx) == subwindow_num)
        {
            break;
        }
        vec_subviewer.push_back(new SubViewer());
        std::vector<std::vector<int>>path;
        if (cur_paths_idx < feature_->multiple_assemble_paths.size() &&
            cur_bridges_idx < feature_->multiple_assemble_bridges.size())
        {
            int idx1 = bridges_arg_sort[cur_bridges_idx];
            int idx2 = paths_arg_sort[cur_paths_idx];
            double cover1 = feature_->multiple_assemble_bridges_coveragence[idx1];
            double cover2 = feature_->multiple_assemble_paths_coveragence[idx2];
            if (cover1 < cover2)
            {
                path = feature_->multiple_assemble_bridges[idx1];
                vec_4_res_qstr.push_back(feature_->multiple_bridges_str[bridges_arg_sort[cur_bridges_idx]].c_str());
                cur_bridges_idx++;
            }
            else
            {
                path = feature_->multiple_assemble_paths[idx2];
                vec_4_res_qstr.push_back((std::string("c") + std::to_string(paths_arg_sort[cur_paths_idx])).c_str());
                cur_paths_idx++;
            }
        }
        else if (cur_paths_idx == feature_->multiple_assemble_paths.size())
        {
            int idx1 = bridges_arg_sort[cur_bridges_idx];
            path = feature_->multiple_assemble_bridges[idx1];
            vec_4_res_qstr.push_back(feature_->multiple_bridges_str[bridges_arg_sort[cur_bridges_idx]].c_str());
            cur_bridges_idx++;
        }
        else if (cur_bridges_idx == feature_->multiple_assemble_bridges.size())
        {
            int idx2 = paths_arg_sort[cur_paths_idx];
            path = feature_->multiple_assemble_paths[idx2];
            vec_4_res_qstr.push_back((std::string("c") + std::to_string(paths_arg_sort[cur_paths_idx])).c_str());
            cur_paths_idx++;
        }
        Curve curve;
        smoothResult(path, curve);
        //vec_subviewer.back()->readCurveGroup(path_pts, ctrl_pts,path_pts_);
        vec_subviewer.back()->readCurveGroup(curve);
        vec_subviewer.back()->setFrame(ui.MainWidget->getFrame());
        connect(ui.MainWidget, SIGNAL(Viewer_Frame(qglviewer::ManipulatedCameraFrame*)),
            vec_subviewer.back(), SLOT(updateFrame(qglviewer::ManipulatedCameraFrame*)));
        vec_widget.push_back(new QWidget());
        sublayout->addWidget(vec_widget.back(),
            (cur_paths_idx + cur_bridges_idx - 1) / 3,
            (cur_paths_idx + cur_bridges_idx - 1) % 3);
        vec_subviewer_layout.push_back(new QVBoxLayout(vec_widget.back()));
        vec_subviewer_button.push_back(new QRadioButton());
        vec_subviewer_layout.back()->addWidget(vec_subviewer_button.back());
        vec_subviewer_layout.back()->addWidget(vec_subviewer.back());
        vec_4_path_res.push_back(curve);
        std::cout << "here3" << std::endl;
    }
    bg_subviewer = new QButtonGroup();
    for (int i = 0; i < vec_subviewer_button.size(); ++i)
    {
        bg_subviewer->addButton(vec_subviewer_button[i], i);
    }
    for (int i = vec_subviewer.size(); i < 9; ++i)
    {
        sublayout->addWidget(new QWidget(), i / 3, i % 3);
    }
    mesh_poly_.ComputeBridgeRes(feature_->multiple_assemble_bridges, selectPointsIndex);
    vec_subviewer_button.front()->setChecked(true);
}

void WireCreater::callLoadRes()
{   
    const double error_mag = tabCurveParam->getVariantProperty("Curve.ErrorMagnitude")->value().toDouble();
    bool is_bridge; int res_idx;
    load_path_idx = bg_subviewer->checkedId();
    selectRes(is_bridge, res_idx);
    std::cout << is_bridge << res_idx << std::endl;
    mesh_poly_.BackProject2Mesh(vec_4_path_res[load_path_idx].curve, error_mag, is_bridge, res_idx, true);
    path_res = vec_4_path_res[load_path_idx];
    ui.MainWidget->path_res = &path_res;
    ui.MainWidget->res_got = true;
    //path_res.setA_x(feature_, std::vector<int>());
    //ui.MainWidget->setField(is_bridge,res_idx);
    ui.MainWidget->is_bridge_poly = is_bridge;
    ui.MainWidget->res_idx_poly = res_idx;
    ui.MainWidget->update();
    std::vector<std::vector<int>>origin_path_res;
    if (is_bridge)
    {
        origin_path_res = mesh_poly_.vec_4_paths_bridge[res_idx];
    }
    else
    {
        origin_path_res = mesh_poly_.vec_4_paths[res_idx];
    }
}

void WireCreater::smoothResult(std::vector<std::vector<int>>& paths, Curve& curve)
{   
    const double error_mag = tabCurveParam->getVariantProperty("Curve.ErrorMagnitude")->value().toDouble();
    const int segment_times = tabCurveParam->getVariantProperty("Curve.LineSegment")->value().toInt();
    const double min_radix_of_curvature = tabCurveParam->getVariantProperty("Curve.MinRadiusOfCurvature")->value().toDouble();
    curve = Curve(paths, selectPointsIndex, mesh_poly_, segment_times,
        error_mag, mesh_poly_.get_avg_edge_len(), NULL, false, min_radix_of_curvature);
}

void WireCreater::callRevokeUserStudy()
{
    if (!stk_user_edit.empty())
    {
        redo_stk_user_edit.push(path_res);
        redo_stk_user_study_path.push(user_study_path);
        redo_stk_path_project_idx.push(path_project_idx);
        redo_stk_user_op_create_new_line.push(last_op_create_new_line);
        redo_stk_user_start_pt_idx_i.push(ui.MainWidget->user_study_start_pt_idx_i);
        redo_stk_user_end_pt_idx_i.push(ui.MainWidget->user_study_end_pt_idx_i);
        redo_stk_user_start_pt_idx_j.push(ui.MainWidget->user_study_start_pt_idx_j);
        redo_stk_user_end_pt_idx_j.push(ui.MainWidget->user_study_end_pt_idx_j);


        last_op_create_new_line = stk_user_op_create_new_line.top();
        path_res = stk_user_edit.top();
        user_study_path = stk_user_study_path.top();
        path_project_idx = stk_path_project_idx.top();
        stk_user_op_create_new_line.pop();
        stk_user_edit.pop();
        stk_user_study_path.pop();
        stk_path_project_idx.pop();
        ui.MainWidget->user_study_start_pt_idx_i = stk_user_start_pt_idx_i.top();
        stk_user_start_pt_idx_i.pop();
        ui.MainWidget->user_study_start_pt_idx_j = stk_user_start_pt_idx_j.top();
        stk_user_start_pt_idx_j.pop();
        ui.MainWidget->user_study_end_pt_idx_i = stk_user_end_pt_idx_i.top();
        stk_user_end_pt_idx_i.pop();
        ui.MainWidget->user_study_end_pt_idx_j = stk_user_end_pt_idx_j.top();
        stk_user_end_pt_idx_j.pop();
        ui.MainWidget->path_res = &path_res;
    }
    //add some fla
    ui.MainWidget->update();
}

void WireCreater::callRedoUserStudy()
{
    if (!redo_stk_user_edit.empty())
    {
        //stk_user_study.push(path_res);
        stk_user_edit.push(path_res);
        stk_user_study_path.push(user_study_path);
        stk_path_project_idx.push(path_project_idx);
        stk_user_op_create_new_line.push(last_op_create_new_line);
        stk_user_start_pt_idx_i.push(ui.MainWidget->user_study_start_pt_idx_i);
        stk_user_end_pt_idx_i.push(ui.MainWidget->user_study_end_pt_idx_i);
        stk_user_start_pt_idx_j.push(ui.MainWidget->user_study_start_pt_idx_j);
        stk_user_end_pt_idx_j.push(ui.MainWidget->user_study_end_pt_idx_j);

        last_op_create_new_line = redo_stk_user_op_create_new_line.top();
        path_res = redo_stk_user_edit.top();
        user_study_path = redo_stk_user_study_path.top();
        path_project_idx = redo_stk_path_project_idx.top();
        redo_stk_user_op_create_new_line.pop();

        redo_stk_user_edit.pop();
        redo_stk_user_study_path.pop();
        redo_stk_path_project_idx.pop();
        ui.MainWidget->user_study_start_pt_idx_i = redo_stk_user_start_pt_idx_i.top();
        redo_stk_user_start_pt_idx_i.pop();
        ui.MainWidget->user_study_start_pt_idx_j = redo_stk_user_start_pt_idx_j.top();
        redo_stk_user_start_pt_idx_j.pop();
        ui.MainWidget->user_study_end_pt_idx_i = redo_stk_user_end_pt_idx_i.top();
        redo_stk_user_end_pt_idx_i.pop();
        ui.MainWidget->user_study_end_pt_idx_j = redo_stk_user_end_pt_idx_j.top();
        redo_stk_user_end_pt_idx_j.pop();


        ui.MainWidget->path_res = &path_res;
    }
    ui.MainWidget->update();
}

void WireCreater::callModifyRevoke()
{
    if (!stk_user_edit.empty())
    {
        redo_stk_user_edit.push(path_res);
        redo_stk_load_path_idx.push(load_path_idx);
        redo_stk_user_op_create_new_line.push(last_op_create_new_line);
        redo_stk_user_start_pt_idx_i.push(ui.MainWidget->user_study_start_pt_idx_i);
        redo_stk_user_end_pt_idx_i.push(ui.MainWidget->user_study_end_pt_idx_i);
        redo_stk_user_start_pt_idx_j.push(ui.MainWidget->user_study_start_pt_idx_j);
        redo_stk_user_end_pt_idx_j.push(ui.MainWidget->user_study_end_pt_idx_j);

        path_res = stk_user_edit.top();
        stk_user_edit.pop();

        load_path_idx = stk_load_path_idx.top();
        stk_load_path_idx.pop();

        last_op_create_new_line = stk_user_op_create_new_line.top();
        stk_user_op_create_new_line.pop();

        ui.MainWidget->user_study_start_pt_idx_i = stk_user_start_pt_idx_i.top();
        stk_user_start_pt_idx_i.pop();
        ui.MainWidget->user_study_start_pt_idx_j = stk_user_start_pt_idx_j.top();
        stk_user_start_pt_idx_j.pop();
        ui.MainWidget->user_study_end_pt_idx_i = stk_user_end_pt_idx_i.top();
        stk_user_end_pt_idx_i.pop();
        ui.MainWidget->user_study_end_pt_idx_j = stk_user_end_pt_idx_j.top();
        stk_user_end_pt_idx_j.pop();
        ui.MainWidget->path_res = &path_res;
        bool is_bridge; int res_idx;
        selectRes(is_bridge, res_idx);
        if (is_bridge)
        {
            redo_stk_line_scalar_field.push(mesh_poly_.vec_4_scalar_field_bridge[res_idx]);
            redo_stk_apts.push(mesh_poly_.vec_4_curve_apt_bridge[res_idx]);
            redo_stk_paths.push(mesh_poly_.vec_4_paths_bridge[res_idx]);

            mesh_poly_.vec_4_scalar_field_bridge[res_idx] = stk_line_scalar_field.top();
            stk_line_scalar_field.pop();
            mesh_poly_.vec_4_curve_apt_bridge[res_idx] = stk_apts.top();
            stk_apts.pop();
            mesh_poly_.vec_4_paths_bridge[res_idx] = stk_paths.top();
            stk_paths.pop();
        }
        else
        {
            redo_stk_line_scalar_field.push(mesh_poly_.vec_4_scalar_field[res_idx]);
            redo_stk_apts.push(mesh_poly_.vec_4_curve_apt[res_idx]);
            redo_stk_paths.push(mesh_poly_.vec_4_paths[res_idx]);

            mesh_poly_.vec_4_scalar_field[res_idx] = stk_line_scalar_field.top();
            stk_line_scalar_field.pop();
            mesh_poly_.vec_4_curve_apt[res_idx] = stk_apts.top();
            stk_apts.pop();
            mesh_poly_.vec_4_paths[res_idx] = stk_paths.top();
            stk_paths.pop();
        }
    }
    ui.MainWidget->update();
}

void WireCreater::callModifyRedo()
{
    if (!redo_stk_user_edit.empty())
    {
        stk_user_edit.push(path_res);
        stk_load_path_idx.push(load_path_idx);
        stk_user_op_create_new_line.push(last_op_create_new_line);
        stk_user_start_pt_idx_i.push(ui.MainWidget->user_study_start_pt_idx_i);
        stk_user_end_pt_idx_i.push(ui.MainWidget->user_study_end_pt_idx_i);
        stk_user_start_pt_idx_j.push(ui.MainWidget->user_study_start_pt_idx_j);
        stk_user_end_pt_idx_j.push(ui.MainWidget->user_study_end_pt_idx_j);

        path_res = redo_stk_user_edit.top();
        redo_stk_user_edit.pop();

        load_path_idx = redo_stk_load_path_idx.top();
        redo_stk_load_path_idx.pop();

        last_op_create_new_line = redo_stk_user_op_create_new_line.top();
        redo_stk_user_op_create_new_line.pop();

        ui.MainWidget->user_study_start_pt_idx_i = redo_stk_user_start_pt_idx_i.top();
        redo_stk_user_start_pt_idx_i.pop();
        ui.MainWidget->user_study_start_pt_idx_j = redo_stk_user_start_pt_idx_j.top();
        redo_stk_user_start_pt_idx_j.pop();
        ui.MainWidget->user_study_end_pt_idx_i = redo_stk_user_end_pt_idx_i.top();
        redo_stk_user_end_pt_idx_i.pop();
        ui.MainWidget->user_study_end_pt_idx_j = redo_stk_user_end_pt_idx_j.top();
        redo_stk_user_end_pt_idx_j.pop();
        ui.MainWidget->path_res = &path_res;

        bool is_bridge; int res_idx;
        selectRes(is_bridge, res_idx);
        if (is_bridge)
        {
            stk_line_scalar_field.push(mesh_poly_.vec_4_scalar_field_bridge[res_idx]);
            stk_apts.push(mesh_poly_.vec_4_curve_apt_bridge[res_idx]);
            stk_paths.push(mesh_poly_.vec_4_paths_bridge[res_idx]);

            mesh_poly_.vec_4_scalar_field_bridge[res_idx] = redo_stk_line_scalar_field.top();
            redo_stk_line_scalar_field.pop();
            mesh_poly_.vec_4_curve_apt_bridge[res_idx] = redo_stk_apts.top();
            redo_stk_apts.pop();
            mesh_poly_.vec_4_paths_bridge[res_idx] = redo_stk_paths.top();
            redo_stk_paths.pop();
        }
        else
        {
            stk_line_scalar_field.push(mesh_poly_.vec_4_scalar_field[res_idx]);
            stk_apts.push(mesh_poly_.vec_4_curve_apt[res_idx]);
            stk_paths.push(mesh_poly_.vec_4_paths[res_idx]);

            mesh_poly_.vec_4_scalar_field[res_idx] = redo_stk_line_scalar_field.top();
            redo_stk_line_scalar_field.pop();
            mesh_poly_.vec_4_curve_apt[res_idx] = redo_stk_apts.top();
            redo_stk_apts.pop();
            mesh_poly_.vec_4_paths[res_idx] = redo_stk_paths.top();
            redo_stk_paths.pop();
        }
    }
    ui.MainWidget->update();
}

void WireCreater::callPrelocatePathsStateChange()
{
    ui.MainWidget->cur_mouse = kMouse::DRAW_USER_INPUT;
    ui.MainWidget->cur_edit = kEdit::ANCHOR_PATH;
    //ag_mouseAction->actions()[2]->setChecked(true);
    ui.MainWidget->mouseChanged();
    select_move_pt_idx_i = -1;
    select_move_pt_idx_j = -1;
    ui.MainWidget->update();
}

void WireCreater::callAddCurveStateChange()
{   
    if (!is_user_algo_start)
    {
        return;
    }
    if (!need_modify_ctrl_pts_draw)
    {
        auto prop = tabDrawOpt->getVariantProperty("Display.CtrlPts");
        prop->setValue(false);
    }
    recordAddCurve();
    ui.MainWidget->cur_mouse = kMouse::DRAW_USER_INPUT;
    ui.MainWidget->cur_edit = kEdit::ADD_CURVE;
    //ag_mouseAction->actions()[2]->setChecked(true);
    select_move_pt_idx_i = -1;
    select_move_pt_idx_j = -1;
    ui.MainWidget->update();
}

void WireCreater::callAttachToCurveStateChange()
{   
    if ((!is_user_algo_start) && (!is_user_study_start))
    {
        return;
    }
    if (!need_modify_ctrl_pts_draw)
    {
        auto prop = tabDrawOpt->getVariantProperty("Display.CtrlPts");
        prop->setValue(false);
    }
    ui.MainWidget->cur_mouse = kMouse::DRAW_USER_INPUT;
    ui.MainWidget->cur_edit = kEdit::ATTACH_TO_CURVE;
    //ag_mouseAction->actions()[3]->setChecked(true);
    select_move_pt_idx_i = -1;
    select_move_pt_idx_j = -1;
    ui.MainWidget->update();
    recordAttractCurve();
}

void WireCreater::callModifyCurveStateChange()
{   
    if ((!is_user_algo_start)&&(!is_user_study_start))
    {
        return;
    }
    if (!need_modify_ctrl_pts_draw)
    {
        auto prop = tabDrawOpt->getVariantProperty("Display.CtrlPts");
        prop->setValue(false);
    }
    ui.MainWidget->cur_mouse = kMouse::DRAW_USEE_INPUT_PATH;
    ui.MainWidget->cur_edit = kEdit::MODIFY_CURVE;
    //ag_mouseAction->actions()[4]->setChecked(true);
    select_move_pt_idx_i = -1;
    select_move_pt_idx_j = -1;
    ui.MainWidget->update();
    recordRemoveCurve();
}

void WireCreater::callSmoothPartStateChange()
{   
    if ((!is_user_algo_start) && (!is_user_study_start))
    {
        return;
    }
    if (!need_modify_ctrl_pts_draw)
    {
        auto prop = tabDrawOpt->getVariantProperty("Display.CtrlPts");
        prop->setValue(false);
    }
    setMouseTracking(false);
    std::cout << "state change" << std::endl;
    ui.MainWidget->cur_mouse = kMouse::DRAW_USEE_INPUT_PATH;
    ui.MainWidget->cur_edit = kEdit::SMOOTH_PART;
    //ag_mouseAction->actions()[3]->setChecked(true);
    select_move_pt_idx_i = -1;
    select_move_pt_idx_j = -1;
    ui.MainWidget->update();
    recordSmoothCurve();
}

void WireCreater::callCreateNewLineStateChange()
{   
    if (!is_user_study_start)
    {
        return;
    }
    if (!need_modify_ctrl_pts_draw)
    {
        auto prop = tabDrawOpt->getVariantProperty("Display.CtrlPts");
        prop->setValue(false);
    }
    setMouseTracking(false);
    ag_userStudyMouseAction->actions()[4]->setChecked(true);
    ui.MainWidget->cur_mouse = kMouse::DRAW_USER_INPUT;
    //ui.MainWidget->cur_mouse = kMouse::CHOOSE_MODEL_PT;
    ui.MainWidget->cur_edit = kEdit::USER_STUDY_CREATE;
    last_op_create_new_line = true;

    /*
    ui.MainWidget->user_study_start_pt_idx_i = -1;
    ui.MainWidget->user_study_end_pt_idx_i = -1;
    ui.MainWidget->user_study_start_pt_idx_j = -1;
    ui.MainWidget->user_study_end_pt_idx_j = -1;
    */
}

void WireCreater::callUserFormLines()
{   
    if (!(is_user_study_start) && (!is_user_algo_start))
    {
        return;
    }
    if (ui.MainWidget->user_study_start_pt_idx_i == -1)
    {   
        if (is_user_algo_start)
        {   
            return;
        }
        if (is_user_study_start)
        {   
            if (ui.MainWidget->user_study_start_pt_idx_j == -1)
            {   
                return;
            }
            if (ui.MainWidget->user_study_end_pt_idx_j == -1)
            {   
                return;
            }
        }
        callClearRedoStack();

        bool is_bridge; int idx;
        if (is_user_algo_start)
        {
            selectRes(is_bridge, idx);
        }
        std::vector<int>res_idx;
        const double error_mag = tabCurveParam->getVariantProperty("Curve.ErrorMagnitude")->value().toDouble();
        const int segment_times = tabCurveParam->getVariantProperty("Curve.LineSegment")->value().toInt();
        const double min_radix_of_curvature = tabCurveParam->getVariantProperty("Curve.MinRadiusOfCurvature")->value().toDouble();

        const double logi1a = tabCurveParam->getVariantProperty("Curve.Logi1a")->value().toDouble();
        const double logi1b = tabCurveParam->getVariantProperty("Curve.Logi1b")->value().toDouble();
        const double logi2a = tabCurveParam->getVariantProperty("Curve.Logi2a")->value().toDouble();
        const double logi2b = tabCurveParam->getVariantProperty("Curve.Logi2b")->value().toDouble();
        if (v_f.empty())
        {
            if (!load_from_cfg)
            {
                stripsMerge();
            }
            computeField();
            for (auto i : feature_->features_draw_option_)
            {
                if (i.second == kDrawingOption::DRAW_SAVED_RES|| i.second == kDrawingOption::DRAW_SAVED_RES_NOTHING)
                {
                    v_f.push_back(feature_->feature_vector_field[i.first]);
                    s_f.push_back(feature_->feature_scalar_field[i.first]);
                }
            }
            if (feature_->user_input_feature.size() > 0)
            {
                mesh_poly_.compute_optimal_orien(feature_->user_input_feature, feature_->user_input_vector_field);
                mesh_poly_.compute_heat_val(feature_->user_input_feature, feature_->user_input_scalar_field);
                v_f.push_back(feature_->user_input_vector_field);
                s_f.push_back(feature_->user_input_scalar_field);
            }
        }
        if (is_user_study_start)
        {   
            std::cout << "a" << std::endl;
            mesh_poly_.append_curve_part(seg, v_f, s_f, user_study_line_scalar_field, user_study_line_vector_field,
                ui.MainWidget->user_study_start_pt_idx_j, ui.MainWidget->user_study_end_pt_idx_j, res_idx,logi1a,logi1b,logi2a,logi2b);
            std::cout << "a" << std::endl;
        }
        else if (is_user_algo_start)
        {   
            if (is_bridge)
            {
                mesh_poly_.append_curve_part(seg, v_f, s_f, mesh_poly_.vec_4_scalar_field_bridge[idx], std::vector<Eigen::RowVector3d>(),
                    ui.MainWidget->user_study_start_pt_idx_j, ui.MainWidget->user_study_end_pt_idx_j, res_idx,logi1a,logi1b,logi2a,logi2b);
            }
            else
            {
                mesh_poly_.append_curve_part(seg, v_f, s_f, mesh_poly_.vec_4_scalar_field[idx], std::vector<Eigen::RowVector3d>(),
                    ui.MainWidget->user_study_start_pt_idx_j, ui.MainWidget->user_study_end_pt_idx_j, res_idx,logi1a,logi1b,logi2a,logi2b);
            }
        }
        std::vector<Eigen::Vector3d>res_path;
        for (int i = 0; i < res_idx.size(); ++i)
        {
            auto pt = mesh_poly_.index_to_vertex_map[res_idx[i]]->point();
            res_path.push_back(Eigen::Vector3d(pt.x(), pt.y(), pt.z()));
        }
        std::cout << "bbbb" << std::endl;
        path_res=Curve(res_path, segment_times, error_mag, mesh_poly_.get_avg_edge_len(), feature_, min_radix_of_curvature);
        //path_res.appendCurve(tmp_curve, feature_);
        ui.MainWidget->user_study_start_pt_idx_i = 0;
        ui.MainWidget->user_study_start_pt_idx_j = path_res.ctrl_pts.back().size() - 1;
        ui.MainWidget->path_res = &path_res;
        callClearUserInput();
        update();
        ui.MainWidget->update();
        if (is_user_algo_start)
        {
            mesh_poly_.BackProject2Mesh(path_res.curve, error_mag, is_bridge, idx, true);
        }
        else if (is_user_study_start)
        {   
            std::cout << "cccc" << std::endl;
            mesh_poly_.BackProject2Mesh(path_res.curve, error_mag, user_study_line_scalar_field, path_project_idx);
        }
        //callLinkToLastLineStateChange();
        callSelectNextPointStateChange();
        last_op_create_new_line = false;
        recordCreateNewLineDone();
    }
    else
    {   
        if (is_user_algo_start)
        {
            if (ui.MainWidget->user_study_end_pt_idx_j == -1)
            {
                return;
            }
        }
        if (is_user_study_start)
        {
            if (ui.MainWidget->user_study_start_pt_idx_j == -1)
            {
                return;
            }
            if (ui.MainWidget->user_study_end_pt_idx_j == -1)
            {
                return;
            }
        }
        const double error_mag = tabCurveParam->getVariantProperty("Curve.ErrorMagnitude")->value().toDouble();
        const int segment_times = tabCurveParam->getVariantProperty("Curve.LineSegment")->value().toInt();
        const double min_radix_of_curvature = tabCurveParam->getVariantProperty("Curve.MinRadiusOfCurvature")->value().toDouble();
        const double logi1a = tabCurveParam->getVariantProperty("Curve.Logi1a")->value().toDouble();
        const double logi1b = tabCurveParam->getVariantProperty("Curve.Logi1b")->value().toDouble();
        const double logi2a = tabCurveParam->getVariantProperty("Curve.Logi2a")->value().toDouble();
        const double logi2b = tabCurveParam->getVariantProperty("Curve.Logi2b")->value().toDouble();
        if (v_f.empty())
        {
            if (!load_from_cfg)
            {
                stripsMerge();
            }
            computeField();
            for (auto i : feature_->features_draw_option_)
            {
                if (i.second == kDrawingOption::DRAW_SAVED_RES)
                {
                    v_f.push_back(feature_->feature_vector_field[i.first]);
                    s_f.push_back(feature_->feature_scalar_field[i.first]);
                }
            }
            if (feature_->user_input_feature.size() > 0)
            {
                mesh_poly_.compute_optimal_orien(feature_->user_input_feature, feature_->user_input_vector_field);
                mesh_poly_.compute_heat_val(feature_->user_input_feature, feature_->user_input_scalar_field);
                v_f.push_back(feature_->user_input_vector_field);
                s_f.push_back(feature_->user_input_scalar_field);
            }
        }

        callClearRedoStack();
        bool is_bridge; int idx;
        if (is_user_algo_start)
        {
            selectRes(is_bridge, idx);
        }
        std::vector<int>res_idx;
        std::cout << ui.MainWidget->user_study_start_pt_idx_j << std::endl;
        std::cout << path_project_idx[ui.MainWidget->user_study_start_pt_idx_i].size() << std::endl;
        int start_pt_idx = path_project_idx[ui.MainWidget->user_study_start_pt_idx_i][ui.MainWidget->user_study_start_pt_idx_j * (segment_times - 1)];
        mesh_poly_.append_curve_part(seg, v_f, s_f, user_study_line_scalar_field, user_study_line_vector_field,
            start_pt_idx, ui.MainWidget->user_study_end_pt_idx_j, res_idx,
            logi1a,logi1b,logi2a,logi2b);
        std::vector<Eigen::Vector3d>res_path;
        for (int i = 0; i < res_idx.size(); ++i)
        {
            auto pt = mesh_poly_.index_to_vertex_map[res_idx[i]]->point();
            res_path.push_back(Eigen::Vector3d(pt.x(), pt.y(), pt.z()));
        }
        Curve tmp_curve(res_path, segment_times, error_mag, mesh_poly_.get_avg_edge_len(), feature_, min_radix_of_curvature);
        //path_res.appendCurve(tmp_curve, feature_);
        if (ui.MainWidget->user_study_start_pt_idx_j == 0)
        {
            path_res.addCurve(tmp_curve, false, ui.MainWidget->user_study_start_pt_idx_i, feature_);
            ui.MainWidget->user_study_start_pt_idx_j = 0;
        }
        else if (ui.MainWidget->user_study_start_pt_idx_j == path_res.ctrl_pts[ui.MainWidget->user_study_start_pt_idx_i].size() - 1)
        {   
            path_res.addCurve(tmp_curve, true, ui.MainWidget->user_study_start_pt_idx_i,feature_);
            ui.MainWidget->user_study_start_pt_idx_j = path_res.ctrl_pts[ui.MainWidget->user_study_start_pt_idx_i].size() - 1;
        }
        else
        {
            std::vector<std::pair<int, int>>overlap_pts_idx;
            path_res.appendCurve(tmp_curve, std::pair<int, int>(ui.MainWidget->user_study_start_pt_idx_i, ui.MainWidget->user_study_start_pt_idx_j));
            ui.MainWidget->user_study_start_pt_idx_i = path_res.ctrl_pts.size() - 1;
            ui.MainWidget->user_study_start_pt_idx_j = path_res.ctrl_pts.back().size() - 1;
        }
        ui.MainWidget->path_res = &path_res;
        callClearUserInput();
        ui.MainWidget->update();
        if (is_user_algo_start)
        {
            mesh_poly_.BackProject2Mesh(path_res.curve, error_mag, is_bridge, idx, true);
        }
        else if (is_user_study_start)
        {
            mesh_poly_.BackProject2Mesh(path_res.curve, error_mag, user_study_line_scalar_field, path_project_idx);
        }
        update();
        last_op_create_new_line = false;
        callSelectNextPointStateChange();
        recordLinkToLastLineDone();
    }
}

void WireCreater::callLinkToLastLineStateChange()
{   
    if ((!is_user_study_start)&& (!is_user_algo_start))
    {
        return;
    }
    if (!need_modify_ctrl_pts_draw)
    {
        auto prop = tabDrawOpt->getVariantProperty("Display.CtrlPts");
        prop->setValue(false);
    }
    ag_mouseAction->actions()[6]->setChecked(true);
    ui.MainWidget->cur_mouse = kMouse::DRAW_USER_INPUT;
    //ui.MainWidget->cur_mouse = kMouse::CHOOSE_MODEL_PT;
    ui.MainWidget->cur_edit = kEdit::USER_STUDY_LINK;
    ui.actionLink_to_Last_Line->setChecked(true);
    if (ui.MainWidget->user_study_start_pt_idx_i == -1)
    {
        recordCreateNewLine();
    }
    else
    {
        recordLinkToLastLine();
    }
    //ui.MainWidget->user_study_start_pt_idx = ui.MainWidget->user_study_end_pt_idx;
    //ui.MainWidget->user_study_end_pt_idx = -1;
    //ag_mouseAction->actions()[2]->setChecked(true);
    ui.MainWidget->update();
    ui.MainWidget->mouseChanged();
}

void WireCreater::callStartUserAlgo()
{   
    bool ok;
    QString text = QInputDialog::getText(this, tr("QInputDialog::getText()"),
        tr("User name:"), QLineEdit::Normal,
        QDir::home().dirName(), &ok);
    if (ok && !text.isEmpty())
    {
        user_name = text;
    }
    start = clock();
    is_user_algo_start = true;
    for (int i = 0; i < ag_mouseAction->actions().size(); ++i)
    {
        if (i != 5)
        {
            ag_mouseAction->actions()[i]->setCheckable(true);
        }
    }
    ui.MainWidget->draw_extend_pt = true;
}

void WireCreater::callEndUserAlgo()
{
    end = clock();
    is_user_algo_start = false;
    for (int i = 0; i < ag_mouseAction->actions().size(); ++i)
    {
        if (i != 5)
        {
            ag_mouseAction->actions()[i]->setChecked(false);
            ag_mouseAction->actions()[i]->setCheckable(false);
        }
    }
    ui.actionCamera_Mode->setChecked(true);
    callCameraMode();
    double endtime = (double)(end - start) / CLOCKS_PER_SEC;
    std::fstream File_output;
    File_output.open("./" + model_name.toStdString() + "_" + user_name.toStdString() + "_algo.rcd", std::fstream::out);
    std::string text = "Hello World\n";

    File_output << "Total time spent:" << endtime << " seconds" << std::endl;
    File_output << "Total Edit time spent:" << user_edit_cost_time << " seconds" << std::endl;
    File_output << "Total Edit operation times:" << user_edit_times << std::endl;
    File_output << "Total Camera Operation times:" << camera_operation_times << std::endl;
    File_output << "Algo form lines time spent:" << form_line_cost_time << std::endl;
    File_output << "Undo times:" << undo_times << std::endl;
    for (auto i : record_operation_num)
    {
        File_output << i.first << ": " << i.second << " times" << std::endl;
    }
    for (auto i : record_operation)
    {
        File_output << "Oparation: " << i.first << "  Occur Time: " << (double)(i.second - start) / CLOCKS_PER_SEC << std::endl;
    }

    File_output.close();
    ui.MainWidget->draw_extend_pt = false;
    ui.MainWidget->user_study_start_pt_idx_i = -1;
    ui.MainWidget->user_study_start_pt_idx_j = -1;
    ui.MainWidget->user_study_end_pt_idx_i = -1;
    ui.MainWidget->user_study_end_pt_idx_j = -1;
}

void WireCreater::callStartUserStudy()
{   
    user_study_line_scalar_field = std::vector<double>(mesh_poly_.size_of_vertices(), 1);
    user_study_line_vector_field = std::vector<Eigen::RowVector3d>(mesh_poly_.size_of_vertices(), Eigen::RowVector3d(1,1,1));
    start = clock();
    is_user_study_start = true;

    bool ok;
    QString text = QInputDialog::getText(this, tr("QInputDialog::getText()"),
        tr("User name:"), QLineEdit::Normal,
        QDir::home().dirName(), &ok);
    if (ok && !text.isEmpty())
    {
        user_name = text;
    }
    /*
    for (int i = 0; i < ag_userStudyMouseAction->actions().size(); ++i)
    {   
        if (i != 3)
        {
            ag_userStudyMouseAction->actions()[i]->setCheckable(true);
        }
    }
    */
    for (int i = 0; i < ag_mouseAction->actions().size(); ++i)
    {
        if (i != 5)
        {
            ag_mouseAction->actions()[i]->setCheckable(true);
        }
    }
    ui.MainWidget->draw_extend_pt = true;
}

void WireCreater::callEndUserStudy()
{   
    end = clock();
    is_user_study_start = false;
    for (int i = 0; i < ag_mouseAction->actions().size(); ++i)
    {
        if (i != 5)
        {
            ag_mouseAction->actions()[i]->setChecked(false);
            ag_mouseAction->actions()[i]->setCheckable(false);
        }
    }
    ui.actionCamera_Mode->setChecked(true);
    callCameraMode();
    //here to write file.
    double endtime = (double)(end - start) / CLOCKS_PER_SEC;
    std::fstream File_output;
    File_output.open("./" + model_name.toStdString() + "_"+user_name.toStdString()+".rcd", std::fstream::out);
    std::string text = "Hello World\n";

    File_output << "Total time spent:" << endtime << " seconds" << std::endl;
    File_output << "Total Edit time spent:" << user_edit_cost_time << " seconds" << std::endl;
    File_output << "Total Edit operation times:" << user_edit_times << std::endl;
    File_output << "Total Camera Operation times:" << camera_operation_times << std::endl;
    File_output << "Algo form lines time spent:" << form_line_cost_time << std::endl;
    File_output << "Undo times:" << undo_times << std::endl;
    for (auto i : record_operation_num)
    {
        File_output << i.first << ": " << i.second <<" times"<< std::endl;
    }
    for (auto i : record_operation)
    {
        File_output << "Oparation: "<< i.first << "  Occur Time: " << (double)(i.second - start) / CLOCKS_PER_SEC <<std::endl;
    }

    File_output.close();
    ui.MainWidget->draw_extend_pt = false;
    ui.MainWidget->user_study_start_pt_idx_i = -1;
    ui.MainWidget->user_study_start_pt_idx_j = -1;
    ui.MainWidget->user_study_end_pt_idx_i = -1;
    ui.MainWidget->user_study_end_pt_idx_j = -1;
}

void WireCreater::callRedo()
{
    if (is_user_study_start)
    {
        callRedoUserStudy();
    }
    else
    {
        callModifyRedo();
    }
}

void WireCreater::callRevoke()
{
    if (is_user_study_start)
    {
        callRevokeUserStudy();
    }
    else
    {
        callModifyRevoke();
    }
    undo_times++;
}

void WireCreater::callCameraMode()
{
    if (is_user_study_start)
    {
        for (int i = 0; i < ag_userStudyMouseAction->actions().size(); ++i)
        {
            ag_userStudyMouseAction->actions()[i]->setChecked(false);
        }
    }
    else
    {
        for (int i = 0; i < ag_mouseAction->actions().size(); ++i)
        {
            ag_mouseAction->actions()[i]->setChecked(false);
        }
    }
    if (!need_modify_ctrl_pts_draw)
    {
        auto prop = tabDrawOpt->getVariantProperty("Display.CtrlPts");
        prop->setValue(false);
    }
    ui.MainWidget->cur_mouse = kMouse::DEFAULT;
    ui.MainWidget->cur_edit = kEdit::NONE;
    ui.MainWidget->mouseChanged();
    select_move_pt_idx_i = -1;
    select_move_pt_idx_j = -1;
    ui.MainWidget->update();
}

void WireCreater::callSelectModelPtStateChange()
{   
    if (is_user_study_start)
    {
        return;
    }
    if (!is_user_algo_start)
    {
        return;
    }
    if (!need_modify_ctrl_pts_draw)
    {
        auto prop = tabDrawOpt->getVariantProperty("Display.CtrlPts");
        prop->setValue(false);
    }
    ui.MainWidget->cur_mouse = kMouse::SELECT_MODEL_PT;
    ui.MainWidget->cur_edit = kEdit::NONE;
    //ag_mouseAction->actions()[2]->setChecked(true);
    select_move_pt_idx_i = -1;
    select_move_pt_idx_j = -1;
    ui.MainWidget->update();
    ui.MainWidget->mouseChanged();
}


void WireCreater::callSaveCurOriginPath()
{   
    bool is_bridge;
    int res_idx;
    selectRes(is_bridge, res_idx);
    std::vector<std::vector<int>>path_idx;
    if (is_bridge)
    {
        path_idx = mesh_poly_.vec_4_paths_bridge_origin[res_idx];
    }
    else
    {
        path_idx = mesh_poly_.vec_4_paths_origin[res_idx];
    }
    QString filename = QFileDialog::getSaveFileName(NULL, "save path", ".", ".pth");
    std::ofstream f(filename.toStdString(), std::ios::out | std::ios::trunc);
    for (auto i : path_idx)
    {
        f << i.size() << std::endl;
        for (auto j : i)
        {
            f << j << std::endl;
        }
    }
}

void WireCreater::callLoadPathCurve()
{   
    std::string filename_;
    QString filename_q = QFileDialog::getOpenFileName(NULL, "curve result select", ".", "*.cve");
    std::ifstream input(filename_q.toStdString());
    size_t ctrl_pts_group_num;
    input >> ctrl_pts_group_num;
    std::cout << ctrl_pts_group_num << std::endl;
    std::vector<std::vector<Eigen::Vector3d>>ctrl_pts;
    while (ctrl_pts_group_num--)
    {   
        size_t ctrl_pts_num;
        input >> ctrl_pts_num;
        std::cout << ctrl_pts_num << std::endl;
        ctrl_pts.push_back(std::vector<Eigen::Vector3d>());
        while (ctrl_pts_num--)
        {   
            double x, y, z;
            Eigen::Vector3d pt;
            input >> x >> y >>z;
            std::cout << x << std::endl;
            std::cout << y << std::endl;
            std::cout << z << std::endl;
            std::cout << ctrl_pts_num << std::endl;
            ctrl_pts.back().push_back(Eigen::Vector3d(x,y,z));
        }
    }
    size_t overlap_pts_group_num;
    std::vector<std::vector<std::pair<int, double>>>overlap_pts_vec;
    input >> overlap_pts_group_num;
    while (overlap_pts_group_num--)
    {   
        int idx;
        double weight;
        overlap_pts_vec.push_back(std::vector<std::pair<int, double>>());
        input >> idx;
        input >> weight;
        overlap_pts_vec.back().push_back(std::pair<int, double>(idx, weight));
        input >> idx;
        input >> weight;
        overlap_pts_vec.back().push_back(std::pair<int, double>(idx, weight));
    }
    input.close(); 
    const double error_mag = tabCurveParam->getVariantProperty("Curve.ErrorMagnitude")->value().toDouble();
    const int segment_times = tabCurveParam->getVariantProperty("Curve.LineSegment")->value().toInt();
    const double min_radix_of_curvature = tabCurveParam->getVariantProperty("Curve.MinRadiusOfCurvature")->value().toDouble();

    ui.MainWidget->select_ctrl_pt_vec = &select_ctrl_pt_vec;//
    ui.MainWidget->select_move_pt_idx_i = &select_move_pt_idx_i;
    ui.MainWidget->select_move_pt_idx_j = &select_move_pt_idx_j;

    path_res = Curve(ctrl_pts, overlap_pts_vec,segment_times,error_mag);
    ui.MainWidget->path_res = &path_res;
    ui.MainWidget->update();
    
}

void WireCreater::callSavePathCurve()
{   
    QString filename = QFileDialog::getSaveFileName(NULL, "save curve", ".", ".cve");
    std::ofstream f(filename.toStdString(), std::ios::out | std::ios::trunc);
    f << path_res.ctrl_pts.size() << std::endl;
    for (auto i : path_res.ctrl_pts)
    {
        f << i.size() << std::endl;
        for (auto j : i)
        {
            f << j.x() << std::endl;
            f << j.y() << std::endl;
            f << j.z() << std::endl;
        }
    }
    f << path_res.overlap_pts_vec.size() << std::endl;
    for (auto i : path_res.overlap_pts_vec)
    {   
        for (auto j : i)
        {
            f << j.first << std::endl;
            f << j.second << std::endl;
        }
    }
    f.close();
}

void WireCreater::callSaveCurveMesh()
{
    QString filename = QFileDialog::getSaveFileName(NULL, "save mesh", ".", ".obj");
    path_res.outputObj(filename.toStdString());
    /*
    if (path_res.pipes.size() == 1)
    {
        path_res.pipes.front().outputObj(filename.toStdString());
    }
    else
    {
        for (int i = 0; i < path_res.pipes.size(); ++i)
        {
            QString filename_ = filename+QString(i)+".obj";
            path_res.pipes.front().outputObj(filename_.toStdString());
        }
    }
    */
}

void WireCreater::callBindCurves()
{
    int select_seg1, select_seg2;
    std::vector<std::vector<std::pair<int, int>>>ctrl_pts_cross_seg;
    std::vector<std::vector<std::pair<int, int>>>seg_crossed;
    std::set<int>seg_neibour1;
    std::set<int>seg_neibour2;
    for (int i = 0; i < seg_crossed.size(); ++i)
    {
        for (int j = 0; j < seg_crossed[i].size(); ++j)
        {
            if (seg_crossed[i][j].first == select_seg1)
            {
                seg_neibour1.insert(seg_crossed[i][j].second);
            }
            if (seg_crossed[i][j].second == select_seg1)
            {
                seg_neibour1.insert(seg_crossed[i][j].first);
            }

            if (seg_crossed[i][j].first == select_seg2)
            {
                seg_neibour2.insert(seg_crossed[i][j].second);
            }
            if (seg_crossed[i][j].second == select_seg2)
            {
                seg_neibour2.insert(seg_crossed[i][j].first);
            }
        }
        std::vector<int>intersection;
        std::set_intersection(seg_neibour1.begin(), seg_neibour1.end(),
            seg_neibour2.begin(), seg_neibour2.end(), std::back_inserter(intersection));
        if (intersection.size() == 1)
        {   
            //expotion 
            std::vector<std::pair<int, int>>seg1_curve_parts;
            std::vector<std::pair<int, int>>seg2_curve_parts;
            int seg_intersection = intersection.front();
            for (int j = 0; j < seg_crossed[i].size(); ++j)
            {
                if ((seg_crossed[i][j].first == select_seg1) &&
                    (seg_crossed[i][j].second == seg_intersection))
                {
                    seg1_curve_parts.push_back(seg_crossed[i][j]);
                }
                if ((seg_crossed[i][j].second == select_seg1) &&
                    (seg_crossed[i][j].first == seg_intersection))
                {
                    seg1_curve_parts.push_back(seg_crossed[i][j]);
                }

                if ((seg_crossed[i][j].first == select_seg2) &&
                    (seg_crossed[i][j].second == seg_intersection))
                {
                    seg2_curve_parts.push_back(seg_crossed[i][j]);
                }
                if ((seg_crossed[i][j].second == select_seg2) &&
                    (seg_crossed[i][j].first == seg_intersection))
                {
                    seg2_curve_parts.push_back(seg_crossed[i][j]);
                }
            }
            if (seg1_curve_parts.size() != 2 || seg2_curve_parts.size() != 2)
            {
                std::cout << "wrong seg info" << std::endl;
            }
            else
            {
                if (seg1_curve_parts.front().first > seg1_curve_parts.back().first)
                {
                    auto t = seg1_curve_parts.front();
                    seg1_curve_parts.front() = seg1_curve_parts.back();
                    seg1_curve_parts.back() = t;
                }
                if (seg2_curve_parts.front().first > seg2_curve_parts.back().first)
                {
                    auto t = seg2_curve_parts.front();
                    seg2_curve_parts.front() = seg2_curve_parts.back();
                    seg2_curve_parts.back() = t;
                }
            }
        }
    }
}

void WireCreater::callSelectStartPointStateChange()
{
    if (!is_user_study_start)
    {
        return;
    }
    setMouseTracking(true);
    //ui.MainWidget->cur_mouse = kMouse::DRAW_USER_INPUT;
    recordSelectStartPointStateChange();
    ui.MainWidget->cur_mouse = kMouse::CHOOSE_MODEL_PT;
    ui.MainWidget->cur_edit = kEdit::USER_STUDY_CREATE;
    last_op_create_new_line = true;
    ui.MainWidget->user_study_start_pt_idx_i = -1;
    ui.MainWidget->user_study_end_pt_idx_i = -1;
    ui.MainWidget->user_study_start_pt_idx_j = -1;
    ui.MainWidget->user_study_end_pt_idx_j = -1;
    ui.MainWidget->mouseChanged();
}

void WireCreater::callSelectLastPointStateChange()
{
    if ((!is_user_study_start)&& (!is_user_algo_start))
    {
        return;
    }
    if (need_modify_ctrl_pts_draw)
    {
        auto prop = tabDrawOpt->getVariantProperty("Display.CtrlPts");
        prop->setValue(true);
    }
    setMouseTracking(false);
    //ui.MainWidget->cur_mouse = kMouse::DRAW_USER_INPUT;
    ui.MainWidget->cur_mouse = kMouse::CHOOSE_CURVE_PT;
    ui.MainWidget->cur_edit = kEdit::USER_STUDY_CREATE;
    //last_op_create_new_line = true;
    select_move_pt_idx_i = -1;
    select_move_pt_idx_j = -1;
    ui.MainWidget->user_study_start_pt_idx_i = -1;
    ui.MainWidget->user_study_start_pt_idx_j = -1;
    ui.MainWidget->mouseChanged();
    ui.MainWidget->update();
    recordSelectLastPointStateChange();
}

void WireCreater::callSelectNextPointStateChange()
{
    if ((!is_user_study_start) && (!is_user_algo_start))
    {
        return;
    }
    setMouseTracking(true);
    //ui.MainWidget->cur_mouse = kMouse::DRAW_USER_INPUT;
    ui.MainWidget->cur_mouse = kMouse::CHOOSE_MODEL_PT;
    ui.MainWidget->cur_edit = kEdit::USER_STUDY_CREATE;
    //last_op_create_new_line = true;
    ui.MainWidget->user_study_end_pt_idx_i = -1;
    ui.MainWidget->user_study_end_pt_idx_j = -1;
    ui.actionSelect_Next_Point->setChecked(true);
    ui.MainWidget->mouseChanged();
    if (ui.MainWidget->user_study_start_pt_idx_i == -1)
    {
        recordSelectNextPointStateChange();
    }
    else
    {
        recordSelectStartPointStateChange();
    }
}

void WireCreater::callAlgoSelectLastPointStateChange()
{
    if (!is_user_algo_start)
    {
        return;
    }
    setMouseTracking(false);
    recordSelectLastPointStateChange();
    //ui.MainWidget->cur_mouse = kMouse::DRAW_USER_INPUT;
    ui.MainWidget->cur_mouse = kMouse::CHOOSE_CURVE_PT;
    ui.MainWidget->cur_edit = kEdit::USER_STUDY_CREATE;
    //last_op_create_new_line = true;
    ui.MainWidget->user_study_start_pt_idx_i = -1;
    ui.MainWidget->user_study_start_pt_idx_j = -1;
    ui.MainWidget->mouseChanged();
}

void WireCreater::callAlgoSelectNextPointStateChange()
{
    if (!is_user_algo_start)
    {
        return;
    }
    setMouseTracking(true);
    recordSelectNextPointStateChange();
    //ui.MainWidget->cur_mouse = kMouse::DRAW_USER_INPUT;
    ui.MainWidget->cur_mouse = kMouse::CHOOSE_MODEL_PT;
    ui.MainWidget->cur_edit = kEdit::USER_STUDY_CREATE;
    //last_op_create_new_line = true;
    ui.MainWidget->user_study_end_pt_idx_i = -1;
    ui.MainWidget->user_study_end_pt_idx_j = -1;
    ui.actionSelect_Next_Point->setChecked(true);
    ui.MainWidget->mouseChanged();
}

void WireCreater::callAlgoFormLines()
{
    if (ui.MainWidget->user_study_start_pt_idx_i == -1)
    {
        return;
    }
    else if (ui.MainWidget->user_study_end_pt_idx_j == -1)
    {
        return;
    }
    else
    {
        if (ui.MainWidget->user_study_end_pt_idx_j == -1)
        {
            return;
        }
        const double error_mag = tabCurveParam->getVariantProperty("Curve.ErrorMagnitude")->value().toDouble();
        const int segment_times = tabCurveParam->getVariantProperty("Curve.LineSegment")->value().toInt();
        const double min_radix_of_curvature = tabCurveParam->getVariantProperty("Curve.MinRadiusOfCurvature")->value().toDouble();
        const double logi1a = tabCurveParam->getVariantProperty("Curve.Logi1a")->value().toDouble();
        const double logi1b = tabCurveParam->getVariantProperty("Curve.Logi1b")->value().toDouble();
        const double logi2a = tabCurveParam->getVariantProperty("Curve.Logi2a")->value().toDouble();
        const double logi2b = tabCurveParam->getVariantProperty("Curve.Logi2b")->value().toDouble();
        if (v_f.empty())
        {
            if (!load_from_cfg)
            {
                stripsMerge();
            }
            computeField();
            for (auto i : feature_->features_draw_option_)
            {
                if (i.second == kDrawingOption::DRAW_SAVED_RES)
                {
                    v_f.push_back(feature_->feature_vector_field[i.first]);
                    s_f.push_back(feature_->feature_scalar_field[i.first]);
                }
            }
            if (feature_->user_input_feature.size() > 0)
            {
                mesh_poly_.compute_optimal_orien(feature_->user_input_feature, feature_->user_input_vector_field);
                mesh_poly_.compute_heat_val(feature_->user_input_feature, feature_->user_input_scalar_field);
                v_f.push_back(feature_->user_input_vector_field);
                s_f.push_back(feature_->user_input_scalar_field);
            }
        }
        stk_user_study.push(path_res);
        stk_user_study_path.push(user_study_path);
        stk_path_project_idx.push(path_project_idx);
        stk_user_op_create_new_line.push(last_op_create_new_line);
        stk_user_start_pt_idx_i.push(ui.MainWidget->user_study_start_pt_idx_i);
        stk_user_end_pt_idx_i.push(ui.MainWidget->user_study_end_pt_idx_i);
        stk_user_start_pt_idx_j.push(ui.MainWidget->user_study_start_pt_idx_j);
        stk_user_end_pt_idx_j.push(ui.MainWidget->user_study_end_pt_idx_j);

        while (!redo_stk_user_study.empty())
        {
            redo_stk_user_study.pop();
            redo_stk_user_study_path.pop();
            redo_stk_path_project_idx.pop();
            redo_stk_user_op_create_new_line.pop();
            redo_stk_user_start_pt_idx_i.pop();
            redo_stk_user_end_pt_idx_i.pop();
            redo_stk_user_start_pt_idx_j.pop();
            redo_stk_user_end_pt_idx_j.pop();
        }
        bool is_bridge; int idx;
        selectRes(is_bridge, idx);

        std::vector<int>res_idx;
        std::cout << ui.MainWidget->user_study_start_pt_idx_j << std::endl;
        std::cout << path_project_idx[ui.MainWidget->user_study_start_pt_idx_i].size() << std::endl;
        int start_pt_idx = path_project_idx[ui.MainWidget->user_study_start_pt_idx_i][ui.MainWidget->user_study_start_pt_idx_j * (segment_times - 1)];
        mesh_poly_.append_curve_part(seg, v_f, s_f, user_study_line_scalar_field, user_study_line_vector_field,
            start_pt_idx, ui.MainWidget->user_study_end_pt_idx_j, res_idx,
            logi1a,logi1b,logi2a,logi2b);
        std::vector<Eigen::Vector3d>res_path;
        for (int i = 0; i < res_idx.size(); ++i)
        {
            auto pt = mesh_poly_.index_to_vertex_map[res_idx[i]]->point();
            res_path.push_back(Eigen::Vector3d(pt.x(), pt.y(), pt.z()));
        }
        Curve tmp_curve(res_path, segment_times, error_mag, mesh_poly_.get_avg_edge_len(), feature_, min_radix_of_curvature);
        //path_res.appendCurve(tmp_curve, feature_);
        if (ui.MainWidget->user_study_start_pt_idx_j == 0)
        {
            path_res.addCurve(tmp_curve, false, ui.MainWidget->user_study_start_pt_idx_i, feature_);
            ui.MainWidget->user_study_start_pt_idx_j = 0;
        }
        else if (ui.MainWidget->user_study_start_pt_idx_j == path_res.ctrl_pts[ui.MainWidget->user_study_start_pt_idx_i].size() - 1)
        {
            path_res.addCurve(tmp_curve, true, ui.MainWidget->user_study_start_pt_idx_i, feature_);
            ui.MainWidget->user_study_start_pt_idx_j = path_res.ctrl_pts[ui.MainWidget->user_study_start_pt_idx_i].size() - 1;
        }
        else
        {
            std::vector<std::pair<int, int>>overlap_pts_idx;
            path_res.appendCurve(tmp_curve, std::pair<int, int>(ui.MainWidget->user_study_start_pt_idx_i, ui.MainWidget->user_study_start_pt_idx_j));
            ui.MainWidget->user_study_start_pt_idx_i = path_res.ctrl_pts.size() - 1;
            ui.MainWidget->user_study_start_pt_idx_j = path_res.ctrl_pts.back().size() - 1;
        }
        ui.MainWidget->path_res = &path_res;
        callClearUserInput();
        ui.MainWidget->update();
        //mesh_poly_.BackProject2Mesh(path_res.curve, error_mag, user_study_line_scalar_field, path_project_idx);
        mesh_poly_.BackProject2Mesh(path_res.curve, error_mag, is_bridge, idx, true);
        update();
        last_op_create_new_line = false;
        callSelectNextPointStateChange();
        recordLinkToLastLine();
    }
}

void WireCreater::callAlgoLinkToLinesStateChange()
{
    if (!is_user_algo_start)
    {
        return;
    }
    if (!need_modify_ctrl_pts_draw)
    {
        auto prop = tabDrawOpt->getVariantProperty("Display.CtrlPts");
        prop->setValue(false);
    }
    ag_mouseAction->actions()[5]->setChecked(true);
    ui.MainWidget->cur_mouse = kMouse::DRAW_USER_INPUT;
    //ui.MainWidget->cur_mouse = kMouse::CHOOSE_MODEL_PT;
    ui.MainWidget->cur_edit = kEdit::USER_STUDY_LINK;
    ui.actionLink_to_Last_Line->setChecked(true);
    //ui.MainWidget->user_study_start_pt_idx = ui.MainWidget->user_study_end_pt_idx;
    //ui.MainWidget->user_study_end_pt_idx = -1;
    //ag_mouseAction->actions()[2]->setChecked(true);
    ui.MainWidget->update();
    ui.MainWidget->mouseChanged();
}

void WireCreater::callAlgoLinkToLines()
{
    if (user_input.empty())
    {
        return;
    }
    const double error_mag = tabCurveParam->getVariantProperty("Curve.ErrorMagnitude")->value().toDouble();
    const int segment_times = tabCurveParam->getVariantProperty("Curve.LineSegment")->value().toInt();
    const double min_radix_of_curvature = tabCurveParam->getVariantProperty("Curve.MinRadiusOfCurvature")->value().toDouble();
    stk_user_study.push(path_res);
    stk_user_study_path.push(user_study_path);
    stk_path_project_idx.push(path_project_idx);
    stk_user_op_create_new_line.push(last_op_create_new_line);
    stk_user_start_pt_idx_i.push(ui.MainWidget->user_study_start_pt_idx_i);
    stk_user_end_pt_idx_i.push(ui.MainWidget->user_study_end_pt_idx_i);
    stk_user_start_pt_idx_j.push(ui.MainWidget->user_study_start_pt_idx_j);
    stk_user_end_pt_idx_j.push(ui.MainWidget->user_study_end_pt_idx_j);
    while (!redo_stk_user_study.empty())
    {
        redo_stk_user_study.pop();
        redo_stk_user_study_path.pop();
        redo_stk_path_project_idx.pop();
        redo_stk_user_op_create_new_line.pop();
        redo_stk_user_start_pt_idx_i.pop();
        redo_stk_user_end_pt_idx_i.pop();
        redo_stk_user_start_pt_idx_j.pop();
        redo_stk_user_end_pt_idx_j.pop();
    }

    bool is_bridge; int idx;
    selectRes(is_bridge, idx);


    std::vector<int>res_idx;
    std::vector<Eigen::Vector3d>curve_projected;
    //ui.MainWidget->backProject2Mesh();
    ui.MainWidget->backProject2Mesh(curve_projected);
    ui.MainWidget->backProject2Mesh();
    if (curve_projected.size() < 3 || user_input_MST.size() < 3)
    {
        callClearUserInput();
        ui.MainWidget->update();
        return;
    }

    if (ui.MainWidget->user_study_start_pt_idx_i == -1)
    {
        return;
    }
    else if (ui.MainWidget->user_study_start_pt_idx_j == -1)
    {
        return;
    }
    else
    {
        std::vector<std::pair<int, int>>overlap_pts;
        overlap_pts.push_back(std::pair<int, int>(ui.MainWidget->user_study_start_pt_idx_i,
            ui.MainWidget->user_study_start_pt_idx_j * (segment_times - 1)));
        mesh_poly_.user_study_connect_path(path_project_idx, user_input_MST, res_idx, overlap_pts);
        std::cout << "action 2" << std::endl;
        std::vector<Eigen::Vector3d>res_path;
        for (int i = 0; i < res_idx.size(); ++i)
        {
            auto pt = mesh_poly_.index_to_vertex_map[res_idx[i]]->point();
            res_path.push_back(Eigen::Vector3d(pt.x(), pt.y(), pt.z()));
        }

        std::cout << "action 3" << std::endl;
        Curve tmp_curve(res_path, segment_times, error_mag, mesh_poly_.get_avg_edge_len(), feature_, min_radix_of_curvature);

        if (ui.MainWidget->user_study_start_pt_idx_j == 0)
        {
            path_res.addCurve(tmp_curve, false, ui.MainWidget->user_study_start_pt_idx_i, feature_);
            ui.MainWidget->user_study_start_pt_idx_j = 0;
        }
        else if (ui.MainWidget->user_study_start_pt_idx_j == path_res.ctrl_pts[ui.MainWidget->user_study_start_pt_idx_i].size() - 1)
        {
            path_res.addCurve(tmp_curve, true, ui.MainWidget->user_study_start_pt_idx_i, feature_);
            ui.MainWidget->user_study_start_pt_idx_j = path_res.ctrl_pts[ui.MainWidget->user_study_start_pt_idx_i].size() - 1;
        }
        else
        {
            std::vector<std::pair<int, int>>overlap_pts_idx;
            path_res.appendCurve(tmp_curve, std::pair<int, int>(ui.MainWidget->user_study_start_pt_idx_i, ui.MainWidget->user_study_start_pt_idx_j));
            ui.MainWidget->user_study_start_pt_idx_i = path_res.ctrl_pts.size() - 1;
            ui.MainWidget->user_study_start_pt_idx_j = path_res.ctrl_pts.back().size() - 1;
        }

        ui.MainWidget->path_res = &path_res;
        callClearUserInput();
        ui.MainWidget->update();
        mesh_poly_.BackProject2Mesh(path_res.curve, error_mag, is_bridge, idx, true);
        update();
        last_op_create_new_line = false;
        recordLinkToLastLine();

        ui.MainWidget->user_study_start_pt_idx_i = path_res.ctrl_pts.size() - 1;
        ui.MainWidget->user_study_start_pt_idx_j = path_res.ctrl_pts.back().size() - 1;
        callAlgoLinkToLinesStateChange();
    }
}

void WireCreater::callClearRedoStack()
{
    if (is_user_study_start)
    {
        stk_user_study_path.push(user_study_path);
        stk_path_project_idx.push(path_project_idx);
        while (!redo_stk_user_study_path.empty())
        {
            redo_stk_user_study_path.pop();
            redo_stk_path_project_idx.pop();
        }
    }
    else if (is_user_algo_start)
    {   
        bool is_bridge; int res_idx;
        selectRes(is_bridge, res_idx);
        stk_load_path_idx.push(load_path_idx);
        if (is_bridge)
        {
            stk_line_scalar_field.push(mesh_poly_.vec_4_scalar_field_bridge[res_idx]);
            stk_apts.push(mesh_poly_.vec_4_curve_apt_bridge[res_idx]);
            stk_paths.push(mesh_poly_.vec_4_paths_bridge[res_idx]);
        }
        else
        {
            stk_line_scalar_field.push(mesh_poly_.vec_4_scalar_field[res_idx]);
            stk_apts.push(mesh_poly_.vec_4_curve_apt[res_idx]);
            stk_paths.push(mesh_poly_.vec_4_paths[res_idx]);
        }
        while (!redo_stk_load_path_idx.empty())
        {
            redo_stk_load_path_idx.pop();
            redo_stk_line_scalar_field.pop();
            redo_stk_apts.pop();
            redo_stk_paths.pop();
        }
    }
    stk_user_edit.push(path_res);
    stk_user_start_pt_idx_i.push(ui.MainWidget->user_study_start_pt_idx_i);
    stk_user_end_pt_idx_i.push(ui.MainWidget->user_study_end_pt_idx_i);
    stk_user_start_pt_idx_j.push(ui.MainWidget->user_study_start_pt_idx_j);
    stk_user_end_pt_idx_j.push(ui.MainWidget->user_study_end_pt_idx_j);
    stk_user_op_create_new_line.push(last_op_create_new_line);
    while (!redo_stk_user_edit.empty())
    {
        redo_stk_user_edit.pop();
        redo_stk_user_op_create_new_line.pop();
        redo_stk_user_start_pt_idx_i.pop();
        redo_stk_user_end_pt_idx_i.pop();
        redo_stk_user_start_pt_idx_j.pop();
        redo_stk_user_end_pt_idx_j.pop();
    }
}

void WireCreater::callPrelocatePaths()
{
    if (user_input.empty())
    {
        return;
    }
    const double error_mag = tabCurveParam->getVariantProperty("Curve.ErrorMagnitude")->value().toDouble();
    const int segment_times = tabCurveParam->getVariantProperty("Curve.LineSegment")->value().toInt();
    const double min_radix_of_curvature = tabCurveParam->getVariantProperty("Curve.MinRadiusOfCurvature")->value().toDouble();
    std::vector<int>res_idx;
    std::vector<Eigen::Vector3d>curve_projected;
    ui.MainWidget->backProject2Mesh(curve_projected);
    ui.MainWidget->backProject2Mesh();
    if (curve_projected.size() < 3 || user_input_MST.size() < 3)
    {
        callClearUserInput();
        ui.MainWidget->update();
        return;
    }
    pre_anchor_paths.push_back(user_input_MST);

    Curve MST_curve(curve_projected, segment_times,
        error_mag, mesh_poly_.get_avg_edge_len(), feature_, min_radix_of_curvature);
    path_res.addCurve(MST_curve);
    ui.MainWidget->path_res = &path_res;
    callClearUserInput();
    ui.MainWidget->update();
}

void WireCreater::callAutoSelectLandmarks()
{
    mesh_poly_.getExtremePts(seg, selectPointsIndex);
    for (int i = 0; i < selectPointsIndex.size(); ++i)
    {
        is_pt_selected[selectPointsIndex[i]] = true;
    }
    ui.MainWidget->update();
}