#pragma once
#include <ctime>
#include <string>
#include <stack>
#include <map>
#include <QtWidgets/QMainWindow>
#include <qfiledialog.h>
#include <qstringliteral.h>
#include <qradiobutton.h>
#include <qbuttongroup.h>
#include <qprogressdialog.h>
#include <qstatusbar.h>
#include <qlabel.h>
#include <qinputdialog.h>
#include "subviewer.h"
#include "PropertyBrowser.h"
#include "ui_WireCreater.h"

class WireCreater : public QMainWindow
{
    Q_OBJECT

public:
    WireCreater(QWidget *parent = Q_NULLPTR);

private:
    Ui::WireCreaterClass ui;
    QActionGroup* ag_mouseAction;
    QActionGroup* ag_userStudyMouseAction;
    QActionGroup* ag_feature_silhouette;
    QActionGroup* ag_feature_topolines;
    QActionGroup* ag_feature_miscK;
    QActionGroup* ag_feature_miscH;
    QActionGroup* ag_feature_miscDwKr;
    QActionGroup* ag_feature_ridges;
    QActionGroup* ag_feature_valleys;
    QActionGroup* ag_feature_sh;
    QActionGroup* ag_feature_sc;
    QActionGroup* ag_feature_contours;
    CPropertyBrowser* tabCurveParam;
    CPropertyBrowser* tabDrawOpt;

    QProgressDialog* progressDialog;
    //QStatusBar* statusBar;
    QLabel* statusLabel;
    bool is_user_study_start;
    bool is_user_algo_start;
    clock_t start, end;

    int camera_operation_times;
    int user_edit_times;
    int redo_times;
    int undo_times;

    double camera_operation_cost_time;
    double user_edit_cost_time;
    double form_line_cost_time;

    QString user_name;
    QString model_name;
    std::vector<std::pair<std::string, double>>record_operation;
    std::map<std::string, int>record_operation_num;
    
    int segment_iter_times;
    double error_magnitude;
    int smooth_iter_times;
    int max_line_num;
    double bridge_density;

    Enriched_polyhedron<Kernel, Enriched_items> mesh_poly_;
    Feature *feature_;
    bool load_from_cfg;
    segIO seg;
    int bridge_pt;
    int select_move_pt_idx_i;
    int select_move_pt_idx_j;
    int load_path_idx;
    std::vector<std::vector<Eigen::RowVector3d>>v_f;
    std::vector<std::vector<double>>s_f;
    std::vector<QRect>selectRects;
    std::vector<std::vector<QRect>> select_ctrl_pt_vec;
    std::vector<int>selectPointsIndex;
    std::vector<bool>is_pt_selected;
    std::vector<QString>vec_4_res_qstr;

    std::vector<QPoint>user_input;
    std::vector<QRect>select_rect_paths;
    std::vector<int>user_input_MST;

    std::vector<std::vector<int>>user_study_path;
    std::vector<std::vector<Eigen::Vector3d>>user_study_ctrl_pts;
    std::vector<std::vector<Eigen::Vector3d>>user_study_path_res;

    std::vector<SubViewer*>vec_subviewer;
    std::vector<QWidget*>vec_widget;
    QGridLayout *sublayout;
    std::vector<QVBoxLayout*>vec_subviewer_layout;
    std::vector<QRadioButton*>vec_subviewer_button;
    QButtonGroup *bg_subviewer;

    std::vector<std::vector<int>>path_project_idx;
    Curve path_res;
    std::vector<Curve>vec_4_path_res;

    std::vector<double>user_study_line_scalar_field;
    std::vector<Eigen::RowVector3d>user_study_line_vector_field;

    std::stack<Curve>stk_user_study;
    std::stack<std::vector<std::vector<int>>>stk_user_study_path;
    std::stack<std::vector<std::vector<int>>>stk_path_project_idx;
    std::stack<bool>stk_user_op_create_new_line;
    std::stack<int>stk_user_start_pt_idx_i;
    std::stack<int>stk_user_end_pt_idx_i;
    std::stack<int>stk_user_start_pt_idx_j;
    std::stack<int>stk_user_end_pt_idx_j;

    std::stack<Curve>redo_stk_user_study;
    std::stack<std::vector<std::vector<int>>>redo_stk_user_study_path;
    std::stack<std::vector<std::vector<int>>>redo_stk_path_project_idx;
    std::stack<bool>redo_stk_user_op_create_new_line;//preserved
    std::stack<int>redo_stk_user_start_pt_idx_i;
    std::stack<int>redo_stk_user_end_pt_idx_i;
    std::stack<int>redo_stk_user_start_pt_idx_j;
    std::stack<int>redo_stk_user_end_pt_idx_j;

    std::stack<Curve>stk_user_edit;//preserved
    std::stack<std::vector<double>>stk_line_scalar_field;
    std::stack<std::vector<std::vector<int>>>stk_apts;
    std::stack<std::vector<std::vector<int>>>stk_paths;
    std::stack<int>stk_load_path_idx;//preserved

    std::stack<Curve>redo_stk_user_edit;
    std::stack<std::vector<double>>redo_stk_line_scalar_field;
    std::stack<std::vector<std::vector<int>>>redo_stk_apts;
    std::stack<std::vector<std::vector<int>>>redo_stk_paths;
    std::stack<int>redo_stk_load_path_idx;
    std::stack<int>redo_stk_algo_start_pt_idx_i;
    std::stack<int>redo_stk_algo_end_pt_idx_i;
    std::stack<int>redo_stk_algo_start_pt_idx_j;
    std::stack<int>redo_stk_algo_end_pt_idx_j;

    std::vector<std::vector<int>>pre_anchor_paths;

    bool need_modify_ctrl_pts_draw;
    bool last_op_create_new_line;
    void setMouseAction();
    void setFeatureOpt();
    void createPropertyBrowser();
    void setconnection();
    void selectRes(bool& is_bridge, int& res_idx);

    void stripsMerge();
    void computeField();
    void computeFieldAssemble(std::vector<std::vector<std::vector<int>>>& feature_paths);
    
    void loadModel(std::string filename);
    void loadSegment(std::string filename);
    void loadFeature(std::string filename);
    void loadApt(std::string filename);
    void saveApt(std::string filename);
    void loadCurveParam(std::string filename);

    void smoothResult(std::vector<std::vector<int>>& paths, Curve& curve);
    void callGetRes();
    void initUserRecord()
    {
        record_operation_num["MOVE_CAMERA"] = 0;
        record_operation_num["MOVE_CAMERA_DONE"] = 0;
        record_operation_num["ROTATE_CAMERA"] = 0;
        record_operation_num["ROTATE_CAMERA_DONE"] = 0;
        record_operation_num["SCALE_CAMERA"] = 0;
        record_operation_num["SCALE_CAMERA_DONE"] = 0;
        
        record_operation_num["FORM_LINES_ALGO"] = 0;
        record_operation_num["FORM_LINES_ALGO_DONE"] = 0;

        record_operation_num["ADD_CURVE"] = 0;
        record_operation_num["ADD_CURVE_DONE"] = 0;
        record_operation_num["REMOVE_CURVE"] = 0;
        record_operation_num["REMOVE_CURVE_DONE"] = 0;
        record_operation_num["ATTRACT_CURVE"] = 0;
        record_operation_num["ATTRACT_CURVE_DONE"] = 0;
        record_operation_num["SMOOTH_CURVE"] = 0;
        record_operation_num["SMOOTH_CURVE_DONE"] = 0;

        record_operation_num["CREATE_NEW_LINE"] = 0;
        record_operation_num["CREATE_NEW_LINE_DONE"] = 0;
        record_operation_num["LINK_TO_LAST_LINE"] = 0;
        record_operation_num["LINK_TO_LAST_LINE_DONE"] = 0;
        record_operation_num["CHOOSE_MODEL_POINT"] = 0;
        record_operation_num["CHOOSE_CURVE_POINT"] = 0;

        record_operation_num["MOVE_CTRL_POINTS"] = 0;
        record_operation_num["MOVE_CTRL_POINTS_DONE"] = 0;
    }
    void recordAddCurve() { record_operation_num["ADD_CURVE"]++; end = clock(); record_operation.emplace(record_operation.end(), "ADD_CURVE", end); }
    void recordAddCurveDone()
    { 
        record_operation_num["ADD_CURVE_DONE"]++; end = clock(); 
        user_edit_times += 1;
        user_edit_cost_time += (end - record_operation.back().second) / CLOCKS_PER_SEC;
        record_operation.emplace(record_operation.end(), "ADD_CURVE_DONE", end); 
    }
    void recordRemoveCurve() { record_operation_num["REMOVE_CURVE"]++; end = clock(); record_operation.emplace(record_operation.end(), "REMOVE_CURVE", end); }
    void recordRemoveCurveDone() 
    { 
        record_operation_num["REMOVE_CURVE_DONE"]++; end = clock(); 
        user_edit_times += 1;
        user_edit_cost_time += (end - record_operation.back().second) / CLOCKS_PER_SEC;
        record_operation.emplace(record_operation.end(), "REMOVE_CURVE_DONE", end); 
    }
    void recordAttractCurve() { record_operation_num["ATTRACT_CURVE"]++; end = clock(); record_operation.emplace(record_operation.end(), "ATTRACT_CURVE", end); }
    void recordAttractCurveDone() 
    { 
        record_operation_num["ATTRACT_CURVE_DONE"]++; end = clock(); 
        user_edit_times += 1;
        user_edit_cost_time += (end - record_operation.back().second) / CLOCKS_PER_SEC;
        record_operation.emplace(record_operation.end(), "ATTRACT_CURVE_DONE", end); 
    }
    void recordSmoothCurve() { record_operation_num["SMOOTH_CURVE"]++; end = clock(); record_operation.emplace(record_operation.end(), "SMOOTH_CURVE", end); }
    void recordSmoothCurveDone() 
    { 
        record_operation_num["SMOOTH_CURVE_DONE"]++; end = clock(); 
        user_edit_times += 1;
        user_edit_cost_time += (end - record_operation.back().second) / CLOCKS_PER_SEC;
        record_operation.emplace(record_operation.end(), "SMOOTH_CURVE_DONE", end); 
    }
    void recordCreateNewLine() { record_operation_num["CREATE_NEW_LINE"]++; end = clock(); record_operation.emplace(record_operation.end(), "CREATE_NEW_LINE", end); }
    void recordCreateNewLineDone() 
    { 
        record_operation_num["CREATE_NEW_LINE_DONE"]++; end = clock(); 
        user_edit_times += 1;
        user_edit_cost_time += (end - record_operation.back().second) / CLOCKS_PER_SEC;
        record_operation.emplace(record_operation.end(), "CREATE_NEW_LINE_DONE", end); 
    }
    void recordLinkToLastLine() { record_operation_num["LINK_TO_LAST_LINE"]++; end = clock(); record_operation.emplace(record_operation.end(), "LINK_TO_LAST_LINE", end); }
    void recordLinkToLastLineDone()
    {
        record_operation_num["LINK_TO_LAST_LINE_DONE"]++; end = clock();
        user_edit_times += 1;
        user_edit_cost_time += (end - record_operation.back().second) / CLOCKS_PER_SEC;
        record_operation.emplace(record_operation.end(), "LINK_TO_LAST_LINE_DONE", end);
    }
    void recordSelectLastPointStateChange() { record_operation_num["CHOOSE_CURVE_POINT"]++; end = clock(); record_operation.emplace(record_operation.end(), "CHOOSE_CURVE_POINT", end); }
    void recordSelectNextPointStateChange() { record_operation_num["CHOOSE_MODEL_POINT"]++; end = clock(); record_operation.emplace(record_operation.end(), "CHOOSE_MODEL_POINT", end); }
    void recordSelectStartPointStateChange() { record_operation_num["CHOOSE_MODEL_POINT"]+=2; end = clock(); record_operation.emplace(record_operation.end(), "CHOOSE_MODEL_POINT", end); 
        end = clock(); record_operation.emplace(record_operation.end(), "CHOOSE_MODEL_POINT", end);}
    void recordAttachToNearestLine() { record_operation_num["ATTACH_TO_NEAREST_LINE"]++; end = clock(); record_operation.emplace(record_operation.end(), "ATTACH_TO_NEAREST_LINE", end); }
    void recordMoveCtrlPoints(){ record_operation_num["MOVE_CTRL_POINTS"]++; end = clock(); record_operation.emplace(record_operation.end(), "MOVE_CTRL_POINTS", end); }
    void recordMoveCtrlPointsDone() 
    { 
        record_operation_num["MOVE_CTRL_POINTS_DONE"]++; end = clock(); 
        user_edit_times += 1;
        user_edit_cost_time += (end - record_operation.back().second) / CLOCKS_PER_SEC;
        record_operation.emplace(record_operation.end(), "MOVE_CTRL_POINTS_DONE", end); 
    }
    void recordAlgoFormLines() { record_operation_num["FORM_LINES_ALGO"]++; end = clock(); record_operation.emplace(record_operation.end(), "FORM_LINES_ALGO", end); }
    void recordAlgoFormLinesDone() 
    { 
        record_operation_num["FORM_LINES_ALGO_DONE"]++; end = clock(); 
        form_line_cost_time= (end - record_operation.back().second) / CLOCKS_PER_SEC;
        record_operation.emplace(record_operation.end(), "FORM_LINES_ALGO_DONE", end); 
    }
private slots:
    void drawOptChanged(QtProperty* prop, const QVariant& value);
    void curveParamsChanged(QtProperty* prop, const QVariant& value);

    void setDrawFeatureOption();
    /*
    */
    void callLoadModel();
    void callLoadApt();
    void callLoadSegment();
    void callLoadFeature();
    void callSaveApt();
    void callSaveFeature();
    void callSaveCurveParam();
    void callSaveCurOriginPath();
    void callSaveField();
    void callFormLines();
    void callFormLinesAlter();
    void callFormLinesAssemble();

    void callAttachToPt();
    void callAttachToCurve();
    void callAttachToCurveStateChange();

    void callModifyCurve();
    void callModifyCurveStateChange();
    void callSmoothPart();
    void callSmoothPartStateChange();
    void callAddCurve();
    void callMoveCurve();
    void callMoveCurveStateChange();
    void callAddCurveStateChange();

    void callAlgoSelectLastPointStateChange();
    void callAlgoSelectNextPointStateChange();
    void callAlgoFormLines();
    void callAlgoLinkToLinesStateChange();
    void callAlgoLinkToLines();

    void callModifyRevoke();
    void callModifyRedo();
    void callClearRedoStack();

    void callSelectModelPtStateChange();

    void callChangeMouse();

    void callClearBridgeApts();
    void callClearUserInput();

    void callUserFormLines();
    void callCreateNewLine();
    void callCreateNewLineStateChange();
    void callLinkToLastLine();
    void callLinkToLastLineStateChange();
    void callSelectStartPointStateChange();
    void callSelectLastPointStateChange();
    void callSelectNextPointStateChange();
    void callAttachToNearestLine();
    void callLinkEndtoEnd();
    void callRevokeUserStudy();
    void callRedoUserStudy();

    void callLoadRes();

    void callStartUserStudy();
    void callEndUserStudy();
    void callStartUserAlgo();
    void callEndUserAlgo();

    void callRevoke();
    void callRedo();
    void callCameraMode();
    void callUserStudyChangeMouse();

    void callBindCurves();

    void callLoadPathCurve();
    void callSavePathCurve();
    void callSaveCurveMesh();

    void callPrelocatePaths();
    void callPrelocatePathsStateChange();


    void recordMoveCamera() { record_operation_num["MOVE_CAMERA"]++; end = clock(); record_operation.emplace(record_operation.end(), "MOVE_CAMERA", end); }
    void recordMoveCameraDone() 
    {
        record_operation_num["MOVE_CAMERA_DONE"]++; end = clock();
        camera_operation_times += 1;
        camera_operation_cost_time += (end - record_operation.back().second) / CLOCKS_PER_SEC;
        record_operation.emplace(record_operation.end(), "MOVE_CAMERA_DONE", end);
    }
    void recordRotateCamera() { record_operation_num["ROTATE_CAMERA"]++; end = clock(); record_operation.emplace(record_operation.end(), "ROTATE_CAMERA", end); }
    void recordRotateCameraDone() 
    { 
        record_operation_num["ROTATE_CAMERA_DONE"]++; end = clock(); 
        camera_operation_times += 1;
        camera_operation_cost_time += (end - record_operation.back().second) / CLOCKS_PER_SEC;
        record_operation.emplace(record_operation.end(), "ROTATE_CAMERA_DONE", end); 
    }
    void recordScaleCamera() { record_operation_num["SCALE_CAMERA"]++; end = clock(); record_operation.emplace(record_operation.end(), "SCALE_CAMERA", end); }
    void recordScaleCameraDone() 
    { 
        record_operation_num["SCALE_CAMERA_DONE"]++; end = clock(); 
        camera_operation_times += 1;
        camera_operation_cost_time += (end - record_operation.back().second) / CLOCKS_PER_SEC;
        record_operation.emplace(record_operation.end(), "SCALE_CAMERA_DONE", end); 
    }

    void callAutoSelectLandmarks();
};
