#pragma once
#include<vector>
#include"helper_algo.h"
#include <Eigen/Core>
#include <Eigen/Geometry> 
//for 3d mainly,in 2d case,set the 3rd dimention of points to 0.

enum kCURVE { BEZIER, CIRCUILAR, ELLIPTICAL,HYBRID};

class Ecllipse
{
public:
	Eigen::Vector3d center;
	Eigen::Vector3d axis1;
	Eigen::Vector3d axis2;
	Eigen::Vector3d limits;
	Ecllipse(Eigen::Vector3d c, Eigen::Vector3d a1, Eigen::Vector3d a2, Eigen::Vector3d l)
	{
		center = c;
		axis1 = a1;
		axis2 = a2;
		limits = l;
	}
};
class c2line
{
private:
	std::vector<Eigen::Vector3d>points;

	std::vector<std::vector<Eigen::Vector3d>>curve_path;
	std::vector<Ecllipse>ecllipse_path;
	std::vector<kCURVE>curve_type;
	bool is_loop;

	void get_hybrid()
	{
		int vec_size = is_loop ? (points.size() - 1) : (points.size() - 2);
		ecllipse_path.clear();
		for (int i = 1; i < vec_size; ++i)
		{
			ecllipse_path.push_back(get_circular(i));
		}
	}

	Ecllipse get_hybrid(int i)
	{
		Ecllipse c = get_circular(i);
		double lim0 = c.limits.x();
		double lim2 = c.limits.z();
		if (lim2 < lim0) { double l = lim0; lim0 = lim2; lim2 = l; }
		if (lim0 < -ML_PI_2 || lim2 > ML_PI_2) c = get_ellipse(i);
		return c;
	}

	void get_circular()
	{
		int vec_size = is_loop ? (points.size() - 1) : (points.size() - 2);
		ecllipse_path.clear();
		for (int i = 1; i < vec_size; ++i)
		{
			ecllipse_path.push_back(get_circular(i));
		}
	}

	Ecllipse get_circular(int i)
	{
		int j = (i - 1 + points.size()) % points.size();
		int k = (i + 1) % points.size();

		Eigen::Vector3d vec1 = points[i] - points[j];
		Eigen::Vector3d mid1 = points[j] + (vec1 / 2);
		Eigen::Vector3d vec2 = points[k] - points[i];
		Eigen::Vector3d mid2 = points[i] + (vec2 / 2);

		Eigen::Vector3d normal_vec = vec1.cross(vec2);
		Eigen::Vector3d dir1 = normal_vec.cross(vec1);
		Eigen::Vector3d dir2 = normal_vec.cross(vec2);
		Eigen::Vector3d det = dir1.cross(dir2);
		if (det.norm() / (dir1.norm() * dir2.norm()) < 0.001)
		{
			if (vec1.dot(vec2) > 0 || points.size() <= 2)
			{	
				double s = std::sin(0.01);
				auto l1 = vec1.norm();
				auto l2 = vec2.norm();
				return Ecllipse(points[i],
					Eigen::Vector3d(0, 0, 0),
					vec2 / s,
					Eigen::Vector3d(-0.01 * l1 / l2, 0, 0.01));
			}
			else
			{
				det = Eigen::Vector3d::Zero().array() + 0.001;
			}
		}
		auto s = dir2.cross(mid1-mid2).norm()/det.norm();
		Eigen::Vector3d center = mid1 + s * dir1;
		Eigen::Vector3d axis1 = points[i] - center;
		Eigen::Vector3d axis2 = axis1.cross(normal_vec);
		auto len2 = std::pow(axis1.norm(), 2);
		Eigen::Vector3d toPt2 = points[k] - center;
		double limit2 = std::atan2(axis2.dot(toPt2), axis1.dot(toPt2));
		Eigen::Vector3d toPt1 = points[j] - center;
		double limit1 = std::atan2(axis2.dot(toPt1), axis1.dot(toPt1));
		if (limit1 * limit2 > 0)
		{
			if (std::abs(limit1) < std::abs(limit2))
			{
				limit2 += (limit2 > 0) ? (-ML_2_PI) : ML_2_PI;
			}
			if (std::abs(limit1) > std::abs(limit2))
			{
				limit1 += (limit1 > 0) ? (-ML_2_PI) : ML_2_PI;
			}
		}
		return Ecllipse(center,
			axis1, axis2,
			Eigen::Vector3d(limit1, 0, limit2));
	}

	void get_ellipse()
	{
		int vec_size = is_loop ? (points.size() - 1) : (points.size() - 2);
		ecllipse_path.clear();
		for (int i = 1; i < vec_size; ++i)
		{
			ecllipse_path.push_back(get_ellipse(i));
		}
	}

	Ecllipse get_ellipse(int i)
	{
		const int numIter = 16;
		int j = (i - 1 + points.size()) % points.size();
		int k = (i + 1) % points.size();

		Eigen::Vector3d vec1 = points[i] - points[j];
		Eigen::Vector3d vec2 = points[k] - points[i];
		if (points.size() <= 2)
		{
			//small edge
			double s = std::sin(0.01);
			return Ecllipse(points[i],
				Eigen::Vector3d(0, 0, 0),
				vec2 / s,
				Eigen::Vector3d(-0.01, 0, 0.01));
		}
		double len1 = vec1.norm();
		double len2 = vec2.norm();
		double cosa = vec1.dot(vec2) / (len1 * len2);
		double maxA = std::acos(cosa);
		double ang = maxA * 0.5;
		double incA = maxA * 0.25;
		double l1 = std::max(len1, len2);
		double l2 = std::min(len1, len2);
		double a, b, c, d;
		for (int i = 0; i < numIter; ++i)
		{
			double theta = ang * 0.5;
			a = l1 * std::sin(theta);
			b = l1 * std::cos(theta);
			double beta = maxA - theta;
			c = l2 * std::sin(theta);
			d = l2 * std::cos(theta);
			double v = (1 - d / b) * (1 - d / b) + (c * c) / (a * a);
			ang += (v > 1) ? incA : -incA;
			incA *= 0.5;
		}
		Eigen::Vector3d vec, pt2;
		double len;
		if(len1 < len2)
		{
			vec = vec2;
			len = len2;
			pt2 = points[k];
		}
		else
		{
			vec = vec1;
			len = len1;
			pt2 = points[j];
		}
		Eigen::Vector3d dir = vec / len;
		Eigen::Vector3d perp = vec1.cross(vec2).cross(dir).normalized();
		double cross = vec1.cross(vec2).norm();
		if ((len1 < len2 && cross>0) || (len1 < len2 && cross < 0))
		{
			perp = -perp;
		}
		double v = b * b / len;
		double h = b * a / len;
		Eigen::Vector3d axis1 = -v * dir - h * perp;
		Eigen::Vector3d center = points[i] - axis1;
		Eigen::Vector3d axis2 = pt2 - center;
		double beta = std::asin(std::min(c / a, 1.0));
		return Ecllipse(center,
			axis1,
			(len1 < len2) ? axis2 : (-axis2),
			(len1 < len2) ? Eigen::Vector3d(-beta, 0, ML_PI_2) : Eigen::Vector3d(-ML_PI_2, 0, beta));
	}

	void get_Bezier()
	{	
		int vec_size = is_loop ? (points.size()-1) : (points.size() - 1);
		curve_path.clear();
		curve_type.clear();
		for (int i = 1; i < vec_size; ++i)
		{
			get_Bezier(i);
		}
	}

	void get_Bezier(int i)
	{	
		int j = (i - 1 + points.size()) % points.size();
		int k = (i + 1) % points.size();
		
		Eigen::Vector3d v0 = points[j] - points[i];
		Eigen::Vector3d v2 = points[k] - points[i];
		auto a = sqrt_t(v0.dot(v0));
		auto b = sqrt_t(v2.dot(v2));
		auto c = sqrt_t(a * b);

		auto t = maxCurvatureT(points[j], points[i], points[k]);

		curve_path.push_back(std::vector<Eigen::Vector3d>());
		curve_path.back().push_back(points[j]);
		Eigen::Vector3d mid_pt = (points[i] - ((1 - t) * (1 - t) * points[j] + t * t * points[k])) / (2 * t * (1 - t));
		curve_path.back().push_back(mid_pt);
		curve_path.back().push_back(points[k]);
		curve_path.back().push_back(Eigen::Vector3d(t, t, t));
		curve_type.push_back(kCURVE::BEZIER);
	}
	double maxCurvatureT(Eigen::Vector3d p0, Eigen::Vector3d pin, Eigen::Vector3d p1)
	{
		Eigen::Vector3d v0 = p0 - pin;
		Eigen::Vector3d v2 = p1 - pin;
		auto c=v0.dot(v2);
		return cubicRoot(-v0.dot(v0), -c / 3, c / 3, v2.dot(v2));
	}
	double cubicRoot(double d, double c, double b,double a)
	{	
		return 0.5;
		/*
		double value = (d + 3 * c + 3 * b + a) / 8;
		if (value >= 0.000001) return cubicRoot(d, (d + c) / 2, (d + 2 * c + b) / 4, value) / 2;
		if (value <= -0.000001) return 0.5 + cubicRoot(value, (c + 2 * b + a) / 4, (b + a) / 2, a) / 2;
		return 0.5;
		*/
	}
public:
	c2line(std::vector<Eigen::Vector3d>pts,bool lop)
	{
		points = pts;
		is_loop = lop;
	}
	c2line(std::vector<Eigen::RowVector3d>pts, bool lop)
	{
		for (int i = 0; i < pts.size(); ++i)
		{
			points.push_back(pts[i]);
		}
		is_loop = lop;
	}
	std::vector<std::vector<Eigen::Vector3d>>smooth_path()
	{
		//get_hybrid();
		get_Bezier();
		//return ecllipse_path;
		return curve_path;
	}
};