#include"curve.h"


Curve::Curve(
    std::vector<std::vector<int>>& paths,
    std::vector<int>& selectPointsIndex,
    Enriched_polyhedron<Kernel, Enriched_items>& mesh_poly_,
    int segment_iter_times_, double error_magitude_,
    double avg_edge_len_, Feature* feature_,
    bool interpolate,double min_radix_curvature)
{   

    segment_iter_times = segment_iter_times_;
    error_magitude = error_magitude_;
    avg_edge_len = avg_edge_len_;

    const int NN_num = 4;
    const double normal_force_weight = 0.1;
    const double subnormal_force_weight = 0.01;
    const double feature_force_weight = 0;
    const double max_dist_amplify = 2;

    std::vector<std::vector<Eigen::Vector3d>>interpolate_paths;
    std::vector<std::vector<int>>interpolate_paths_idx;

    std::vector<std::vector<std::vector<Eigen::Vector3d>>>path;
    std::vector<std::vector<std::vector<double>>>path_length;
    std::vector<std::vector<std::vector<int>>>path_idx;
    std::vector<std::vector<int>>path_beizer_seg;

    std::vector<std::pair<int, int>>path_overlap_pts;
    for (int j = 0; j < paths.size(); ++j)
    {   
        for (int k = 0; k < paths.size(); ++k)
        {   
            if (k == j)continue;
            //maybe more attention.this is not stable?
            auto find_iter = std::find(paths[k].begin(),
                paths[k].end(), paths[j].front());
            if (find_iter != paths[k].end())
            {
                auto dis = std::distance(paths[k].begin(), find_iter);
                path_overlap_pts.push_back(std::pair<int, int>(j, 0));
                path_overlap_pts.push_back(std::pair<int, int>(k, dis));
                overlap_pts_idx.push_back(std::vector<std::pair<int, int>>());
                overlap_pts_idx.back().push_back(std::pair<int, int>(j, 0));
                overlap_pts_idx.back().push_back(std::pair<int, int>(k, dis));
                break;
            }
        }
        for (int k = 0; k < paths.size(); ++k)
        {   
            if (k == j)continue;
            auto find_iter = std::find(paths[k].begin(),
                paths[k].end(), paths[j].back());
            if (find_iter != paths[k].end())
            {
                auto dis = std::distance(paths[k].begin(), find_iter);
                path_overlap_pts.push_back(std::pair<int, int>(j, paths[j].size() - 1));
                path_overlap_pts.push_back(std::pair<int, int>(k, dis));
                overlap_pts_idx.push_back(std::vector<std::pair<int, int>>());
                overlap_pts_idx.back().push_back(std::pair<int, int>(j, paths[j].size() - 1));
                overlap_pts_idx.back().push_back(std::pair<int, int>(k, dis));
                break;
            }
        }
        if (paths[j].front() == paths[j].back())
        {   
            path_overlap_pts.push_back(std::pair<int, int>(j, 0));
            path_overlap_pts.push_back(std::pair<int, int>(j, paths[j].size() - 1));
            overlap_pts_idx.push_back(std::vector<std::pair<int, int>>());
            overlap_pts_idx.back().push_back(std::pair<int, int>(j, 0));
            overlap_pts_idx.back().push_back(std::pair<int, int>(j, paths[j].size() - 1));
        }
    }

    double sampleDist = 0.3 * avg_edge_len_;//0.1*avg_len;
    std::vector<std::vector<Eigen::Vector3d>>samplePaths;
    std::vector<std::vector<std::pair<int, int>>>overlap_pts_idx_tmp;
    for (int i = 0; i < overlap_pts_idx.size(); ++i)
    {
        overlap_pts_idx_tmp.push_back(std::vector<std::pair<int, int>>());
        overlap_pts_idx_tmp.back().push_back(std::pair<int, int>(overlap_pts_idx[i].front().first,-1));
        overlap_pts_idx_tmp.back().push_back(std::pair<int, int>(overlap_pts_idx[i].back().first, -1));
    }
    for (int i = 0; i < paths.size(); ++i)
    {   
        samplePaths.push_back(std::vector<Eigen::Vector3d>());
        for (int j = 1; j < paths[i].size(); ++j)
        {   

            int prevj = j - 1;
            auto pt_cur = mesh_poly_.index_to_vertex_map[paths[i][j]]->point();
            auto pt_prev = mesh_poly_.index_to_vertex_map[paths[i][prevj]]->point();
            samplePaths[i].push_back(Eigen::Vector3d(pt_prev.x(), pt_prev.y(), pt_prev.z()));
            for (int k = 0; k < overlap_pts_idx.size(); ++k)
            {
                if (overlap_pts_idx[k].front().first == i)
                {
                    if (overlap_pts_idx[k].front().second == prevj)
                    {
                        overlap_pts_idx_tmp[k].front().second = samplePaths[i].size() - 1;
                        break;
                    }
                }
                if (overlap_pts_idx[k].back().first == i)
                {
                    if (overlap_pts_idx[k].back().second == prevj)
                    {
                        overlap_pts_idx_tmp[k].back().second = samplePaths[i].size() - 1;
                        break;
                    }
                }
            }



            Eigen::Vector3d pt_cur_e = Eigen::Vector3d(pt_cur.x(), pt_cur.y(), pt_cur.z());
            Eigen::Vector3d pt_prev_e = Eigen::Vector3d(pt_prev.x(), pt_prev.y(), pt_prev.z());
            Eigen::Vector3d thisVec = pt_cur_e - pt_prev_e;
            double thisL = sqrt(thisVec.dot(thisVec));
            int thisN = (int)(thisL / sampleDist);
            /*
            if (thisL < sampleDist)
            {
                thisN = 0;
            }
            else
            {
                for (int k = 1; k < thisN; ++k)
                {
                    Eigen::Vector3d thisSamplePt;
                    thisSamplePt = pt_prev_e + thisVec * (double)k/ thisN;
                    samplePaths[i].push_back(thisSamplePt);
                }
            }
            */
        }
        auto pt_end = mesh_poly_.index_to_vertex_map[paths[i].back()]->point();

        samplePaths[i].push_back(Eigen::Vector3d(pt_end.x(), pt_end.y(), pt_end.z()));
        for (int k = 0; k < overlap_pts_idx.size(); ++k)
        {
            if (overlap_pts_idx[k].front().first == i)
            {
                if (overlap_pts_idx[k].front().second == paths[i].size()-1)
                {
                    overlap_pts_idx_tmp[k].front().second = samplePaths[i].size() - 1;
                    break;
                }
            }
            if (overlap_pts_idx[k].back().first == i)
            {
                if (overlap_pts_idx[k].back().second == paths[i].size() - 1)
                {
                    overlap_pts_idx_tmp[k].back().second = samplePaths[i].size() - 1;
                    break;
                }
            }
        }
    }
    overlap_pts_idx = overlap_pts_idx_tmp;

    if (min_radix_curvature == 0)
    {
        this->curve = samplePaths;
        pipes = std::vector<Utils::Pipe>(ctrl_pts.size());
        for (int i = 0; i < this->curve.size(); ++i)
        {
            generateCylinder(i);
        }
        return;
    }
    int numIteration = 10;
    std::vector<std::vector<Eigen::Vector3d>>samplePaths_smooth;

    for (unsigned int count = 0; count < numIteration; ++count)
    {
        samplePaths_smooth.clear();
        for (int i = 0; i < samplePaths.size(); ++i)
        {
            samplePaths_smooth.push_back(std::vector<Eigen::Vector3d>());
            samplePaths_smooth.back().push_back(samplePaths[i].front());
            for (int j = 1; j < samplePaths[i].size()-1; ++j)
            {
                Eigen::Vector3d p0 = samplePaths[i][j - 1];
                Eigen::Vector3d p1 = samplePaths[i][j];
                Eigen::Vector3d p2 = samplePaths[i][j + 1];
                Eigen::Vector3d thisPt = p0 * 0.125 + p1 * 0.75 + p2 * 0.125;
                samplePaths_smooth.back().push_back(thisPt);
            }
            samplePaths_smooth.back().push_back(samplePaths[i].back());
        }

        samplePaths = samplePaths_smooth;
        for (int i = 0; i < overlap_pts_idx.size(); ++i)
        {
            auto mid_pt = (samplePaths[overlap_pts_idx[i].front().first][overlap_pts_idx[i].front().second] +
                samplePaths[overlap_pts_idx[i].back().first][overlap_pts_idx[i].back().second]) / 2;
            samplePaths[overlap_pts_idx[i].front().first][overlap_pts_idx[i].front().second]=mid_pt;
            samplePaths[overlap_pts_idx[i].back().first][overlap_pts_idx[i].back().second] = mid_pt;
        }
    }

    if (min_radix_curvature == 0)
    {
        this->curve = samplePaths;
        pipes = std::vector<Utils::Pipe>(ctrl_pts.size());
        for (int i = 0; i < this->curve.size(); ++i)
        {
            generateCylinder(i);
        }
        return;
    }

    std::vector<std::vector<double>>curvature;
    std::vector<std::vector<Eigen::Vector3d>>finite_diff_vec;
    std::vector<std::vector<Eigen::Vector3d>>finite_diff2_vec;
    for (int j = 0; j < samplePaths.size(); ++j)
    {
        finite_diff_vec.push_back(std::vector<Eigen::Vector3d>());
        finite_diff_vec.back().push_back(samplePaths[j][1] - samplePaths[j][0]);
        for (int k = 1; k < samplePaths[j].size() - 1; ++k)
        {
            finite_diff_vec.back().push_back((samplePaths[j][k - 1] - samplePaths[j][k + 1]));
        }
        finite_diff_vec.back().push_back(samplePaths[j].back() - *(samplePaths[j].end()-2));

        finite_diff2_vec.push_back(std::vector<Eigen::Vector3d>());
        finite_diff2_vec.back().push_back(finite_diff_vec[j][1] - finite_diff_vec[j][0]);
        for (int k = 1; k < finite_diff_vec[j].size() - 1; ++k)
        {
            finite_diff2_vec.back().push_back((finite_diff_vec[j][k - 1] - finite_diff_vec[j][k + 1]));
        }
        finite_diff2_vec.back().push_back(finite_diff_vec[j].back() - *(finite_diff_vec[j].end() - 2));

        curvature.push_back(std::vector<double>());
        for (int k = 0; k < finite_diff2_vec[j].size(); ++k)
        {   
            double c = sqrt(std::abs(
                (pow(finite_diff2_vec[j][k].z() * finite_diff_vec[j][k].y() - finite_diff2_vec[j][k].y() * finite_diff_vec[j][k].z(), 2.0f) +
                    pow(finite_diff2_vec[j][k].x() * finite_diff_vec[j][k].z() - finite_diff2_vec[j][k].z() * finite_diff_vec[j][k].x(), 2.0f) +
                    pow(finite_diff2_vec[j][k].y() * finite_diff_vec[j][k].x() - finite_diff2_vec[j][k].x() * finite_diff_vec[j][k].y(), 2.0f)) /
                pow(finite_diff2_vec[j][k].x() + finite_diff2_vec[j][k].x() + finite_diff2_vec[j][k].x(), 3.0f)));
            curvature.back().push_back(c);
        }
    }

    for (int j = 0; j < samplePaths.size(); ++j)
    {
        interpolate_paths.push_back(std::vector<Eigen::Vector3d>());
        interpolate_paths[j].push_back(samplePaths[j].front());
        path_beizer_seg.push_back(std::vector<int>());
        path_beizer_seg[j].push_back(0);


        for (int k = 3; k < curvature[j].size()-3; ++k)
        {   
            if (curvature[j][k]<(1/(min_radix_curvature *avg_edge_len)))
            {   
                continue;
            }
            bool local_maximum = true;
            for (int k1 = 1; k1 <= 3; ++k1)
            {   
                if (curvature[j][k] < curvature[j][k+k1] || curvature[j][k] < curvature[j][k - k1])
                {
                    local_maximum = false;
                }
            }
            if (local_maximum)
            {   
                int vec_back = path_beizer_seg[j].back();
                int idx_diff = k - path_beizer_seg[j].back();
                int insert_num = (idx_diff) / 5;
                if (insert_num != 0)
                {   
                    int step = idx_diff / insert_num;
                    if (idx_diff > step)
                    {   
                        std::cout << path_beizer_seg[j].back() << " " << idx_diff << std::endl;
                        std::cout << insert_num << std::endl;
                        std::cout << step << std::endl;
                        for (int step_i = step; step_i < idx_diff - step; step_i += step)
                        {
                            int idx = vec_back + step_i;
                            interpolate_paths[j].push_back(samplePaths[j][idx]);
                            path_beizer_seg[j].push_back(idx);
                        }
                    }
                }
                interpolate_paths[j].push_back(samplePaths[j][k]);
                path_beizer_seg[j].push_back(k);
            }
        }
        int vec_back = path_beizer_seg[j].back();
        int idx_diff = (samplePaths[j].size() - 1) - path_beizer_seg[j].back();
        int insert_num = (idx_diff) / 5;
        if (insert_num != 0)
        {
            int step = idx_diff / insert_num;
            if (idx_diff > step)
            {
                std::cout << path_beizer_seg[j].back() << " " << idx_diff << std::endl;
                std::cout << insert_num << std::endl;
                std::cout << step << std::endl;
                for (int step_i = step; step_i < idx_diff - step; step_i += step)
                {
                    int idx = vec_back + step_i;
                    interpolate_paths[j].push_back(samplePaths[j][idx]);
                    path_beizer_seg[j].push_back(idx);
                }
            }
        }
        interpolate_paths[j].push_back(samplePaths[j].back());
        path_beizer_seg[j].push_back(samplePaths[j].size()-1);
    }
    for (int j = 0; j < overlap_pts_idx.size(); ++j)
    {
        int c_idx1 = overlap_pts_idx[j].front().first;
        int c_idx2 = overlap_pts_idx[j].back().first;
        auto find_iter1 = std::find(path_beizer_seg[c_idx1].begin(), path_beizer_seg[c_idx1].end(), overlap_pts_idx[j].front().second);
        auto find_iter2 = std::find(path_beizer_seg[c_idx2].begin(), path_beizer_seg[c_idx2].end(), overlap_pts_idx[j].back().second);
        if (find_iter1 == path_beizer_seg[c_idx1].end())
        {
            auto insert_idx = std::distance(path_beizer_seg[c_idx1].begin(),
                std::upper_bound(path_beizer_seg[c_idx1].begin(), path_beizer_seg[c_idx1].end(), overlap_pts_idx[j].front().second));

            int k = overlap_pts_idx[j].front().second;
            //int k_ = paths[c_idx1][k];
            auto pt = samplePaths[c_idx1][k];
            interpolate_paths[c_idx1].insert(interpolate_paths[c_idx1].begin() + insert_idx, Eigen::Vector3d(pt.x(), pt.y(), pt.z()));
            //interpolate_paths_idx[c_idx1].insert(interpolate_paths_idx[c_idx1].begin() + insert_idx, k_);
            path_beizer_seg[c_idx1].insert(path_beizer_seg[c_idx1].begin() + insert_idx, k);
        }
        if (find_iter2 == path_beizer_seg[c_idx2].end())
        {
            auto insert_idx = std::distance(path_beizer_seg[c_idx2].begin(),
                std::upper_bound(path_beizer_seg[c_idx2].begin(), path_beizer_seg[c_idx2].end(), overlap_pts_idx[j].back().second));

            int k = overlap_pts_idx[j].back().second;
            //int k_ = paths[c_idx2][k];
            auto pt = samplePaths[c_idx2][k];
            interpolate_paths[c_idx2].insert(interpolate_paths[c_idx2].begin() + insert_idx, Eigen::Vector3d(pt.x(), pt.y(), pt.z()));
            //interpolate_paths_idx[c_idx2].insert(interpolate_paths_idx[c_idx2].begin() + insert_idx, k_);
            path_beizer_seg[c_idx2].insert(path_beizer_seg[c_idx2].begin() + insert_idx, k);
        }
    }
    ctrl_pts = interpolate_paths;
    pipes = std::vector<Utils::Pipe>(ctrl_pts.size());
    //setA_x(feature_, std::vector<int>());
    form_curve(false);
    form_curve(true);

    std::vector<std::vector<Eigen::Vector3d>>ctrl_pts_tmp(ctrl_pts.size());
    if (interpolate)
    {
        for (int i = 0; i < ctrl_pts.size(); ++i)
        {
            for (int j = 0; j < ctrl_pts[i].size() - 1; ++j)
            {
                ctrl_pts_tmp[i].push_back(ctrl_pts[i][j]);
                ctrl_pts_tmp[i].push_back(curve[i][j * (segment_iter_times - 1) + (segment_iter_times - 1) / 2]);
            }
            ctrl_pts_tmp[i].push_back(ctrl_pts[i].back());
        }
    }

    for (int i = 0; i < path_overlap_pts.size(); i += 2)
    {
        int curve_idx_1 = path_overlap_pts[i].first;
        int curve_ctrl_pt_idx_1 = path_overlap_pts[i].second;

        int curve_idx_2 = path_overlap_pts[i + 1].first;
        int curve_ctrl_pt_idx_2 = path_overlap_pts[i + 1].second;
        int curve_ctrl_pt_idx_2_copy = curve_ctrl_pt_idx_2;
        int vec_i = 0;
        int long_vec_idx = 0;
        for (int k = 0; k < curve_idx_1; ++k)
        {
            long_vec_idx += interpolate ? (ctrl_pts[k].size() * 2 - 1) : ctrl_pts[k].size();
        }
        overlap_pts_vec.push_back(std::vector<std::pair<int, double>>());
        curve_ctrl_pt_idx_1 = std::distance(path_beizer_seg[curve_idx_1].begin(),
            std::find(path_beizer_seg[curve_idx_1].begin(),
                path_beizer_seg[curve_idx_1].end(), curve_ctrl_pt_idx_1));
        overlap_pts_vec.back().push_back(std::pair<int, double>(long_vec_idx + curve_ctrl_pt_idx_1, 1));

        long_vec_idx = 0;
        for (int k = 0; k < curve_idx_2; ++k)
        {
            long_vec_idx += interpolate ? (ctrl_pts[k].size() * 2 - 1) : ctrl_pts[k].size();
        }
        curve_ctrl_pt_idx_2 = std::distance(path_beizer_seg[curve_idx_2].begin(),
            std::find(path_beizer_seg[curve_idx_2].begin(),
                path_beizer_seg[curve_idx_2].end(), curve_ctrl_pt_idx_2));
        overlap_pts_vec.back().push_back(std::pair<int, double>(long_vec_idx + curve_ctrl_pt_idx_2, 1));
    }
    if (interpolate)
    {
        ctrl_pts = ctrl_pts_tmp;
    }
    if (feature_ != NULL)
    {
        setA_x(feature_, std::vector<int>());
    }
    pipes = std::vector<Utils::Pipe>(ctrl_pts.size());
    form_curve(false);
    form_curve(true);
}

Curve::Curve(std::vector<Eigen::Vector3d>& paths, int segment_iter_times_, double error_magitude_, double avg_edge_len_ ,Feature* feature_,double min_radix_curvature)
{
    segment_iter_times = segment_iter_times_;
    error_magitude = error_magitude_;
    avg_edge_len = avg_edge_len_;

    const int NN_num = 4;
    const double normal_force_weight = 0.1;
    const double subnormal_force_weight = 0.01;
    const double feature_force_weight = 0;
    const double max_dist_amplify = 2;

    std::vector<Eigen::Vector3d>interpolate_paths;
    std::cout << "step 1" << std::endl;
    std::vector<std::vector<Eigen::Vector3d>>path;
    std::vector<std::vector<double>>path_length;
    std::vector<std::vector<int>>path_idx;
    std::vector<int>path_beizer_seg;

    std::cout << "step 2" << std::endl;
    double sampleDist = 0.1 * avg_edge_len_;//0.1*avg_len;
    std::vector<Eigen::Vector3d>samplePaths;
    double accumulate_path_length = 0;
    samplePaths.push_back(paths.front());
    for (int j = 1; j < paths.size(); ++j)
    {
        int prevj = j - 1;
        auto pt_cur = paths[j];
        auto pt_prev = paths[prevj];

        Eigen::Vector3d pt_cur_e = Eigen::Vector3d(pt_cur.x(), pt_cur.y(), pt_cur.z());
        Eigen::Vector3d pt_prev_e = Eigen::Vector3d(pt_prev.x(), pt_prev.y(), pt_prev.z());
        Eigen::Vector3d thisVec = pt_cur - pt_prev;
        accumulate_path_length += thisVec.norm();
        if (accumulate_path_length > (0.3 * avg_edge_len_))
        {
            samplePaths.push_back(pt_cur);
            accumulate_path_length = 0;
        }
    }
    /*
    for (int j = 1; j < paths.size(); ++j)
    {
        int prevj = j - 1;
        auto pt_cur = paths[j];
        auto pt_prev = paths[prevj];

        Eigen::Vector3d pt_cur_e = Eigen::Vector3d(pt_cur.x(), pt_cur.y(), pt_cur.z());
        Eigen::Vector3d pt_prev_e = Eigen::Vector3d(pt_prev.x(), pt_prev.y(), pt_prev.z());
        Eigen::Vector3d thisVec = pt_cur - pt_prev;
        if (accumulate_path_length + thisVec.norm() < (0.3*avg_edge_len_))
        {
            accumulate_path_length += thisVec.norm();
        }
        else if (accumulate_path_length == 0)
        {
            double times = thisVec.norm() / (0.3*avg_edge_len_);
            for (int iter = 1; iter < (int)times -1; ++iter)
            {   
                Eigen::Vector3d thisSamplePt;
                thisSamplePt = pt_prev_e + thisVec * (double)iter / times;
                samplePaths.push_back(thisSamplePt);
            }
            samplePaths.push_back(pt_cur);
        }
        else
        {
            samplePaths.push_back(pt_cur);
            accumulate_path_length = 0;
        }
        double thisL = sqrt(thisVec.dot(thisVec));
        int thisN = (int)(thisL / sampleDist);
    }
    */
    //samplePaths.push_back(paths.back());
    int numIteration = 10;
    std::vector<Eigen::Vector3d>samplePaths_smooth;

    for (unsigned int count = 0; count < numIteration; ++count)
    {
        samplePaths_smooth.clear();
        samplePaths_smooth.push_back(samplePaths.front());
        for (int j = 1; j < samplePaths.size()-1; ++j)
        {
            Eigen::Vector3d p0 = samplePaths[j - 1];
            Eigen::Vector3d p1 = samplePaths[j];
            Eigen::Vector3d p2 = samplePaths[j + 1];
            Eigen::Vector3d thisPt = p0 * 0.125 + p1 * 0.75 + p2 * 0.125;
           samplePaths_smooth.push_back(thisPt);
        }
        samplePaths_smooth.push_back(samplePaths.back());
        samplePaths = samplePaths_smooth;
    }
    std::cout << "step 3" << std::endl;
    std::vector<double>curvature;
    std::vector<Eigen::Vector3d>finite_diff_vec;
    std::vector<Eigen::Vector3d>finite_diff2_vec;
    finite_diff_vec.push_back(samplePaths[1] - samplePaths[0]);
    for (int k = 1; k < samplePaths.size() - 1; ++k)
    {
        finite_diff_vec.push_back((samplePaths[k - 1] - samplePaths[k + 1]));
    }
    finite_diff_vec.push_back(samplePaths.back() - *(samplePaths.end() - 2));

    finite_diff2_vec.push_back(finite_diff_vec[1] - finite_diff_vec[0]);
    for (int k = 1; k < finite_diff_vec.size() - 1; ++k)
    {
        finite_diff2_vec.push_back((finite_diff_vec[k - 1] - finite_diff_vec[k + 1]));
    }
    finite_diff2_vec.push_back(finite_diff_vec.back() - *(finite_diff_vec.end() - 2));

    for (int k = 0; k < finite_diff2_vec.size(); ++k)
    {
        double c = sqrt(std::abs(
            (pow(finite_diff2_vec[k].z() * finite_diff_vec[k].y() - finite_diff2_vec[k].y() * finite_diff_vec[k].z(), 2.0f) +
                pow(finite_diff2_vec[k].x() * finite_diff_vec[k].z() - finite_diff2_vec[k].z() * finite_diff_vec[k].x(), 2.0f) +
                pow(finite_diff2_vec[k].y() * finite_diff_vec[k].x() - finite_diff2_vec[k].x() * finite_diff_vec[k].y(), 2.0f)) /
            pow(finite_diff2_vec[k].x() + finite_diff2_vec[k].x() + finite_diff2_vec[k].x(), 3.0f)));
        curvature.push_back(c);
    }

    std::cout << "step 4" << std::endl;
    interpolate_paths.push_back(samplePaths.front());
    path_beizer_seg.push_back(0);

    for (int k = 2; k < curvature.size() - 2; ++k)
    {
        if (curvature[k] < (1 / (min_radix_curvature * avg_edge_len)))
        {
            continue;
        }
        bool local_maximum = true;
        for (int k1 = 1; k1 <= 2; ++k1)
        {
            if (curvature[k] < curvature[k + k1] || curvature[k] < curvature[k - k1])
            {
                local_maximum = false;
            }
        }
        if (local_maximum)
        {
            int vec_back = path_beizer_seg.back();
            int idx_diff = k - path_beizer_seg.back();
            int insert_num = (idx_diff) / 5;
            if (insert_num != 0)
            {
                    int step = idx_diff / insert_num;
                    if (idx_diff > step)
                    {
                        for (int step_i = step; step_i < idx_diff - step; step_i += step)
                        {
                            int idx = vec_back + step_i;
                            interpolate_paths.push_back(samplePaths[idx]);
                            path_beizer_seg.push_back(idx);
                            std::cout << "a:" << idx << std::endl;
                        }
                    }
            }
            interpolate_paths.push_back(samplePaths[k]);
            path_beizer_seg.push_back(k);
        }
    }
    {
        std::cout << "step 5" << std::endl;
        int vec_back = path_beizer_seg.back();
        int idx_diff = (samplePaths.size() - 1) - path_beizer_seg.back();
        int insert_num = (idx_diff) / 5;
        if (insert_num != 0)
        {
            int step = idx_diff / insert_num;
            if (idx_diff > step)
            {
                for (int step_i = step; step_i < idx_diff - step; step_i += step)
                {
                    int idx = vec_back + step_i;
                    interpolate_paths.push_back(samplePaths[idx]);
                    path_beizer_seg.push_back(idx);
                    std::cout << "b:" << idx << std::endl;
                }
            }
        }
        /*
        interpolate_paths.push_back(samplePaths.back());
        path_beizer_seg.push_back(samplePaths.size() - 1);
        */
    }

    interpolate_paths.push_back(samplePaths.back());
    path_beizer_seg.push_back(samplePaths.size() - 1);

    if (interpolate_paths.size() < 3)
    {
        interpolate_paths.insert(interpolate_paths.begin() + 1, samplePaths[path_beizer_seg.back() / 2]);
    }
    std::vector<std::vector<Eigen::Vector3d>>vec_interpolate_paths;
    vec_interpolate_paths.push_back(interpolate_paths);
    std::cout << "step 6" << std::endl;

    ctrl_pts = vec_interpolate_paths;
    pipes = std::vector<Utils::Pipe>(ctrl_pts.size());
    //setA_x(feature_, std::vector<int>());
    std::cout << ctrl_pts.back().size() << std::endl;
    form_curve(false);
    std::cout << ctrl_pts.back().size() << std::endl;
    std::cout << "step 6.5" << std::endl;
    //form_curve(true);
    std::cout << "step 7" << std::endl;
}

Curve::Curve(std::vector<std::vector<Eigen::Vector3d >>& ctrl_pts_vec, std::vector<std::vector<std::pair<int, double>>>& overlap_pts_vec,
    int segment_iter_times_, double error_magitude_)
{   
    segment_iter_times = segment_iter_times_;
    error_magitude = error_magitude_;
    //avg_edge_len = avg_edge_len_;

    this->ctrl_pts = ctrl_pts_vec;

    this->overlap_pts_vec = overlap_pts_vec;
    
    std::vector<Eigen::Vector3d>vec_ctrl_pts;
    for (int i = 0; i < ctrl_pts.size(); ++i)
    {
        for (int j = 0; j < ctrl_pts[i].size(); ++j)
        {
            vec_ctrl_pts.push_back(ctrl_pts[i][j]);
        }
    }
    for (int i = 0; i < this->overlap_pts_vec.size(); ++i)
    {
        int idx1 = overlap_pts_vec[i].front().first;
        //double move_to_x = 0, move_to_y = 0, move_to_z = 0;
        Eigen::Vector3d move_to = Eigen::Vector3d::Zero();
        for (int j = 1; j < this->overlap_pts_vec[i].size(); ++j)
        {
            int idx2 = this->overlap_pts_vec[i][j].first;
            double w = this->overlap_pts_vec[i][j].second;
            move_to += w * vec_ctrl_pts[idx2];
        }
        vec_ctrl_pts[idx1] = move_to;
    }
    int col_idx = 0;
    for (int i = 0; i < ctrl_pts.size(); ++i)
    {
        for (int j = 0; j < ctrl_pts[i].size(); ++j)
        {
            ctrl_pts[i][j] = vec_ctrl_pts[col_idx];
            col_idx++;
        }
    }
    pipes = std::vector<Utils::Pipe>(ctrl_pts.size());
    form_curve(false);
    generateCylinder();
}


void Curve::solve(Feature* feature_, std::vector<int>&nn_curve_idx, bool soft_drag)
{   
    for (int i = 0; i < nn_curve_idx.size(); i+=2)
    {   
        int curve_idx = nn_curve_idx[i];
        int pt_idx = nn_curve_idx[i + 1];
        int quotient = pt_idx / (segment_iter_times - 1);
        if (quotient == 0)
        {
            Eigen::Vector3d p0 = ctrl_pts[curve_idx][0];
            Eigen::Vector3d p1 = ctrl_pts[curve_idx][1];
            Eigen::Vector3d p2 = ctrl_pts[curve_idx][2];
            Eigen::Vector3d thisPt = p0 * 0.125 + p1 * 0.75 + p2 * 0.125;
            ctrl_pts[curve_idx][1] = thisPt;
        }
        else if (quotient == ctrl_pts[pt_idx].size() - 2)
        {
            Eigen::Vector3d p0 = ctrl_pts[curve_idx][ctrl_pts[curve_idx].size() - 1];
            Eigen::Vector3d p1 = ctrl_pts[curve_idx][ctrl_pts[curve_idx].size() - 2];
            Eigen::Vector3d p2 = ctrl_pts[curve_idx][ctrl_pts[curve_idx].size() - 3];
            Eigen::Vector3d thisPt = p0 * 0.125 + p1 * 0.75 + p2 * 0.125;
            ctrl_pts[curve_idx][ctrl_pts[curve_idx].size() - 2] = thisPt;
        }
        else
        {
            Eigen::Vector3d p0 = ctrl_pts[curve_idx][quotient - 1];
            Eigen::Vector3d p1 = ctrl_pts[curve_idx][quotient];
            Eigen::Vector3d p2 = ctrl_pts[curve_idx][quotient + 1];
            Eigen::Vector3d p3 = ctrl_pts[curve_idx][quotient + 2];
            Eigen::Vector3d thisPt0 = p0 * 0.125 + p1 * 0.75 + p2 * 0.125;
            Eigen::Vector3d thisPt1 = p1 * 0.125 + p2 * 0.75 + p3 * 0.125;
            ctrl_pts[curve_idx][quotient] = thisPt0;
            ctrl_pts[curve_idx][quotient + 1] = thisPt1;
        }
    }
    form_curve(false);
}

void Curve::solve(Feature* feature_, int j,std::vector<int>&nn_curve_idx)
{
    //setA_x(feature_, j, j0, j1);
    setA_x(feature_, j, nn_curve_idx);
    auto A_x = vec_A_x[j];
    Eigen::VectorXd x_x = A_x.bdcSvd(Eigen::ComputeThinU | Eigen::ComputeThinV).solve(vec_b_x[j]);
    Eigen::VectorXd x_y = A_x.bdcSvd(Eigen::ComputeThinU | Eigen::ComputeThinV).solve(vec_b_y[j]);
    Eigen::VectorXd x_z = A_x.bdcSvd(Eigen::ComputeThinU | Eigen::ComputeThinV).solve(vec_b_z[j]);
    for (int k = 1; k < ctrl_pts[j].size() - 1; k++)
    {
        ctrl_pts[j][k] = Eigen::Vector3d(x_x(k), x_y(k), x_z(k));
    }
    form_curve(j, false);
    //setA_x(feature_, j, -1, -1);
    setA_x(feature_, j, nn_curve_idx);
}


void Curve::setA_x(Feature* feature_, std::vector<int>& nn_curve_idx)
{
    vec_A_x = std::vector<Eigen::MatrixXd>(ctrl_pts.size());
    vec_b_x = std::vector<Eigen::VectorXd>(ctrl_pts.size());
    vec_b_y = std::vector<Eigen::VectorXd>(ctrl_pts.size());
    vec_b_z = std::vector<Eigen::VectorXd>(ctrl_pts.size());
    for (int i = 0; i < ctrl_pts.size(); ++i)
    {
        setA_x(feature_, i,nn_curve_idx);
    }
}


void Curve::setA_x(Feature* feature_, int j,std::vector<int>&nn_curve_idx)
{
    //for (int j = 0; j < ctrl_pts.size(); ++j)
    c2line spline(ctrl_pts[j], true);
    std::vector<std::vector<Eigen::Vector3d>>smooth_res = spline.smooth_path();
    std::vector<Eigen::Vector3d>smooth_curve;
    //iterpolation
    std::vector<std::vector<Eigen::Vector3d>>beizer_interpolation;
    std::vector<double>pts_dist;
    feature_->curve_attach_2_feature(ctrl_pts[j], pts_dist);
    for (int k = 0; k < pts_dist.size(); ++k)
    {
        pts_dist[k] /= avg_edge_len;
    }
    for (int k = 0; k < pts_dist.size(); ++k)
    {
        pts_dist[k] = 2 * guassian(0.05 * pts_dist[k])*10;
    }
    Eigen::MatrixXd A_x(ctrl_pts[j].size(), ctrl_pts[j].size());
    Eigen::VectorXd b_x(A_x.rows());
    Eigen::VectorXd b_y(A_x.rows());
    Eigen::VectorXd b_z(A_x.rows());
    A_x.setZero();
    b_x.setZero();
    b_y.setZero();
    b_z.setZero();
    //int row_id=0;
    int row_id = 0;
    for (int k = 0; k < segment_iter_times; ++k)
    {
        double modifier = 1;
        bool is_onpath = false;
        for (int vec_i = 0; vec_i < nn_curve_idx.size(); vec_i+=2)
        {
            if (j == nn_curve_idx[vec_i] && (nn_curve_idx[vec_i + 1] == row_id))
            {
                is_onpath = true;
                break;
            }
        }
        if (is_onpath)
        {   
            modifier = 0;
            row_id++;
            continue;
        }
        double tt = (static_cast<double>(k) / (segment_iter_times-1)) * smooth_res[0][3].x();
        double b0 = (1 - tt) * (1 - tt);
        double b1 = 2 * tt * (1 - tt);
        double b2 = (tt * tt);
        auto pt = (smooth_res[0][0] * (1 - tt) * (1 - tt)
            + smooth_res[0][1] * 2 * tt * (1 - tt) + smooth_res[0][2] * tt * tt);
        smooth_curve.push_back(pt);
        b_x(0) += (b0 - b1 / 2) * pt.x() * pts_dist[0];
        b_y(0) += (b0 - b1 / 2) * pt.y() * pts_dist[0];
        b_z(0) += (b0 - b1 / 2) * pt.z() * pts_dist[0];

        A_x(0, 0) += (b0 - b1 / 2) * (b0 - b1 / 2) * pts_dist[0];
        A_x(0, 1) += 2 * b1 * (b0 - b1 / 2) * pts_dist[0];
        A_x(0, 2) += (b2 - b1 / 2) * (b0 - b1 / 2) * pts_dist[0];

        b_x(1) += 2 * b1 * pt.x() * pts_dist[1];
        b_y(1) += 2 * b1 * pt.y() * pts_dist[1];
        b_z(1) += 2 * b1 * pt.z() * pts_dist[1];

        A_x(1, 0) += (b0 - b1 / 2) * 2 * b1 * pts_dist[1];
        A_x(1, 1) += 2 * b1 * 2 * b1 * pts_dist[1];
        A_x(1, 2) += (b2 - b1 / 2) * 2 * b1 * pts_dist[1];

        b_x(2) += (b2 - b1 / 2) * pt.x() * pts_dist[2];
        b_y(2) += (b2 - b1 / 2) * pt.y() * pts_dist[2];
        b_z(2) += (b2 - b1 / 2) * pt.z() * pts_dist[2];

        A_x(2, 0) += (b0 - b1 / 2) * (b2 - b1 / 2) * pts_dist[2];
        A_x(2, 1) += 2 * b1 * (b2 - b1 / 2) * pts_dist[2];
        A_x(2, 2) += (b2 - b1 / 2) * (b2 - b1 / 2) * pts_dist[2];

        row_id++;
    }
    beizer_interpolation.push_back(smooth_curve);
    smooth_curve.clear();
    for (int k = 1; k < smooth_res.size(); ++k)
    {
        for (int k1 = 1; k1 < segment_iter_times; ++k1)
        {
            double modifier = 1;
            bool is_onpath = false;
            for (int vec_i = 0; vec_i < nn_curve_idx.size(); vec_i += 2)
            {
                if (j == nn_curve_idx[vec_i] && (nn_curve_idx[vec_i + 1] == row_id))
                {
                    is_onpath = true;
                    break;
                }
            }
            if (is_onpath)
            {
                modifier = 0;
                row_id++;
                continue;
            }
            double tt_1 = (static_cast<double>(k1) / (segment_iter_times-1)) * smooth_res[k][3].x();
            Eigen::Vector3d pt1 = (smooth_res[k][0] * (1 - tt_1) * (1 - tt_1)
                + smooth_res[k][1] * 2 * tt_1 * (1 - tt_1) + smooth_res[k][2] * tt_1 * tt_1);

            double tt_2 = (static_cast<double>(k1) / (segment_iter_times-1)) * (1 - smooth_res[k - 1][3].x()) + smooth_res[k - 1][3].x();
            Eigen::Vector3d pt2 = (smooth_res[k - 1][0] * (1 - tt_2) * (1 - tt_2)
                + smooth_res[k - 1][1] * 2 * tt_2 * (1 - tt_2) + smooth_res[k - 1][2] * tt_2 * tt_2);

            double theta = (static_cast<double>(k1) / (segment_iter_times-1)) * ML_PI_2;
            Eigen::Vector3d pt = std::pow(std::cos(theta), 2) * pt2 + std::pow(std::sin(theta), 2) * pt1;
            smooth_curve.push_back(pt);


            double b0_2 = (1 - tt_1) * (1 - tt_1);
            double b1_2 = 2 * tt_1 * (1 - tt_1);
            double b2_2 = (tt_1 * tt_1);

            double b0_1 = (1 - tt_2) * (1 - tt_2);
            double b1_1 = 2 * tt_2 * (1 - tt_2);
            double b2_1 = (tt_2 * tt_2);

            b_x(k - 1) += (std::pow(std::cos(theta), 2) * ((b0_1 - b1_1 / 2))) * pt.x() * pts_dist[k - 1];
            b_y(k - 1) += (std::pow(std::cos(theta), 2) * ((b0_1 - b1_1 / 2))) * pt.y() * pts_dist[k - 1];
            b_z(k - 1) += (std::pow(std::cos(theta), 2) * ((b0_1 - b1_1 / 2))) * pt.z() * pts_dist[k - 1];

            A_x(k - 1, k - 1) += (std::pow(std::cos(theta), 2) * ((b0_1 - b1_1 / 2))) *
                (std::pow(std::cos(theta), 2) * ((b0_1 - b1_1 / 2))) * pts_dist[k - 1];
            A_x(k - 1, k) += (std::pow(std::cos(theta), 2) * ((b0_1 - b1_1 / 2))) *
                (std::pow(std::cos(theta), 2) * (2 * b1_1) +
                    std::pow(std::sin(theta), 2) * (b0_2 - b1_2 / 2)) * pts_dist[k - 1];
            A_x(k - 1, k + 1) += (std::pow(std::cos(theta), 2) * ((b0_1 - b1_1 / 2))) *
                (std::pow(std::cos(theta), 2) * (b2_1 - b1_1 / 2) +
                    std::pow(std::sin(theta), 2) * (2 * b1_2)) * pts_dist[k - 1];
            A_x(k - 1, k + 2) += (std::pow(std::cos(theta), 2) * ((b0_1 - b1_1 / 2))) *
                (std::pow(std::sin(theta), 2) * (b2_2 - b1_2 / 2)) * pts_dist[k - 1];

            b_x(k) += (std::pow(std::cos(theta), 2) * 2 * b1_1 +
                std::pow(std::sin(theta), 2) * (b0_2 - b1_2 / 2)) * pt.x() * pts_dist[k];
            b_y(k) += (std::pow(std::cos(theta), 2) * 2 * b1_1 +
                std::pow(std::sin(theta), 2) * (b0_2 - b1_2 / 2)) * pt.y() * pts_dist[k];
            b_z(k) += (std::pow(std::cos(theta), 2) * 2 * b1_1 +
                std::pow(std::sin(theta), 2) * (b0_2 - b1_2 / 2)) * pt.z() * pts_dist[k];

            A_x(k, k - 1) += (std::pow(std::cos(theta), 2) * 2 * b1_1 +
                std::pow(std::sin(theta), 2) * (b0_2 - b1_2 / 2)) *
                (std::pow(std::cos(theta), 2) * ((b0_1 - b1_1 / 2))) * pts_dist[k];
            A_x(k, k) += (std::pow(std::cos(theta), 2) * 2 * b1_1 +
                std::pow(std::sin(theta), 2) * (b0_2 - b1_2 / 2)) *
                (std::pow(std::cos(theta), 2) * (2 * b1_1) +
                    std::pow(std::sin(theta), 2) * (b0_2 - b1_2 / 2)) * pts_dist[k];
            A_x(k, k + 1) += (std::pow(std::cos(theta), 2) * 2 * b1_1 +
                std::pow(std::sin(theta), 2) * (b0_2 - b1_2 / 2)) *
                (std::pow(std::cos(theta), 2) * (b2_1 - b1_1 / 2) +
                    std::pow(std::sin(theta), 2) * (2 * b1_2)) * pts_dist[k];
            A_x(k, k + 2) += (std::pow(std::cos(theta), 2) * 2 * b1_1 +
                std::pow(std::sin(theta), 2) * (b0_2 - b1_2 / 2)) *
                (std::pow(std::sin(theta), 2) * (b2_2 - b1_2 / 2)) * pts_dist[k];

            b_x(k + 1) += (std::pow(std::cos(theta), 2) * (b2_1 - b1_1 / 2) +
                std::pow(std::sin(theta), 2) * (2 * b1_2)) * pt.x() * pts_dist[k + 1];
            b_y(k + 1) += (std::pow(std::cos(theta), 2) * (b2_1 - b1_1 / 2) +
                std::pow(std::sin(theta), 2) * (2 * b1_2)) * pt.y() * pts_dist[k + 1];
            b_z(k + 1) += (std::pow(std::cos(theta), 2) * (b2_1 - b1_1 / 2) +
                std::pow(std::sin(theta), 2) * (2 * b1_2)) * pt.z() * pts_dist[k + 1];

            A_x(k + 1, k - 1) += (std::pow(std::cos(theta), 2) * (b2_1 - b1_1 / 2) +
                std::pow(std::sin(theta), 2) * (2 * b1_2)) *
                (std::pow(std::cos(theta), 2) * ((b0_1 - b1_1 / 2))) * pts_dist[k + 1];
            A_x(k + 1, k) += (std::pow(std::cos(theta), 2) * (b2_1 - b1_1 / 2) +
                std::pow(std::sin(theta), 2) * (2 * b1_2)) *
                (std::pow(std::cos(theta), 2) * (2 * b1_1) +
                    std::pow(std::sin(theta), 2) * (b0_2 - b1_2 / 2)) * pts_dist[k + 1];
            A_x(k + 1, k + 1) += (std::pow(std::cos(theta), 2) * (b2_1 - b1_1 / 2) +
                std::pow(std::sin(theta), 2) * (2 * b1_2)) *
                (std::pow(std::cos(theta), 2) * (b2_1 - b1_1 / 2) +
                    std::pow(std::sin(theta), 2) * (2 * b1_2)) * pts_dist[k + 1];
            A_x(k + 1, k + 2) += (std::pow(std::cos(theta), 2) * (b2_1 - b1_1 / 2) +
                std::pow(std::sin(theta), 2) * (2 * b1_2)) *
                (std::pow(std::sin(theta), 2) * (b2_2 - b1_2 / 2)) * pts_dist[k + 1];

            b_x(k + 2) += (std::pow(std::sin(theta), 2) * (b2_2 - b1_2 / 2)) * pt.x() * pts_dist[k + 2];
            b_y(k + 2) += (std::pow(std::sin(theta), 2) * (b2_2 - b1_2 / 2)) * pt.y() * pts_dist[k + 2];
            b_z(k + 2) += (std::pow(std::sin(theta), 2) * (b2_2 - b1_2 / 2)) * pt.z() * pts_dist[k + 2];

            A_x(k + 2, k - 1) += (std::pow(std::sin(theta), 2) * (b2_2 - b1_2 / 2)) *
                (std::pow(std::cos(theta), 2) * ((b0_1 - b1_1 / 2))) * pts_dist[k + 2];
            A_x(k + 2, k) += (std::pow(std::sin(theta), 2) * (b2_2 - b1_2 / 2)) *
                (std::pow(std::cos(theta), 2) * (2 * b1_1) +
                    std::pow(std::sin(theta), 2) * (b0_2 - b1_2 / 2)) * pts_dist[k + 2];
            A_x(k + 2, k + 1) += (std::pow(std::sin(theta), 2) * (b2_2 - b1_2 / 2)) *
                (std::pow(std::cos(theta), 2) * (b2_1 - b1_1 / 2) +
                    std::pow(std::sin(theta), 2) * (2 * b1_2)) * pts_dist[k + 2];
            A_x(k + 2, k + 2) += (std::pow(std::sin(theta), 2) * (b2_2 - b1_2 / 2)) *
                (std::pow(std::sin(theta), 2) * (b2_2 - b1_2 / 2)) * pts_dist[k + 2];

            row_id++;
        }
        beizer_interpolation.push_back(smooth_curve);
        smooth_curve.clear();
    }
    for (int k = 1; k < segment_iter_times; ++k)
    {
        double modifier = 1;
        bool is_onpath = false;
        for (int vec_i = 0; vec_i < nn_curve_idx.size(); vec_i += 2)
        {
            if (j == nn_curve_idx[vec_i] && (nn_curve_idx[vec_i + 1] == row_id))
            {
                is_onpath = true;
                break;
            }
        }
        if (is_onpath)
        {
            modifier = 0;
            row_id++;
            continue;
        }

        double tt = (static_cast<double>(k) / (segment_iter_times-1)) * (1 - smooth_res.back()[3].x()) + smooth_res.back()[3].x();
        auto pt = (smooth_res.back()[0] * (1 - tt) * (1 - tt)
            + smooth_res.back()[1] * 2 * tt * (1 - tt) + smooth_res.back()[2] * tt * tt);
        smooth_curve.push_back(pt);

        double b0 = (1 - tt) * (1 - tt);
        double b1 = 2 * tt * (1 - tt);
        double b2 = (tt * tt);
        b_x(b_x.size() - 3) += (b0 - b1 / 2) * pt.x() * pts_dist[A_x.cols() - 3];
        b_y(b_x.size() - 3) += (b0 - b1 / 2) * pt.y() * pts_dist[A_x.cols() - 3];
        b_z(b_x.size() - 3) += (b0 - b1 / 2) * pt.z() * pts_dist[A_x.cols() - 3];

        A_x(A_x.rows() - 3, A_x.cols() - 3) += (b0 - b1 / 2) * (b0 - b1 / 2) * pts_dist[A_x.cols() - 3];
        A_x(A_x.rows() - 3, A_x.cols() - 2) += 2 * b1 * (b0 - b1 / 2) * pts_dist[A_x.cols() - 3];
        A_x(A_x.rows() - 3, A_x.cols() - 1) += (b2 - b1 / 2) * (b0 - b1 / 2) * pts_dist[A_x.cols() - 3];

        b_x(b_x.size() - 2) += 2 * b1 * pt.x() * pts_dist[A_x.cols() - 2];
        b_y(b_x.size() - 2) += 2 * b1 * pt.y() * pts_dist[A_x.cols() - 2];
        b_z(b_x.size() - 2) += 2 * b1 * pt.z() * pts_dist[A_x.cols() - 2];

        A_x(A_x.rows() - 2, A_x.cols() - 3) += (b0 - b1 / 2) * 2 * b1 * pts_dist[A_x.cols() - 2];
        A_x(A_x.rows() - 2, A_x.cols() - 2) += 2 * b1 * 2 * b1 * pts_dist[A_x.cols() - 2];
        A_x(A_x.rows() - 2, A_x.cols() - 1) += (b2 - b1 / 2) * 2 * b1 * pts_dist[A_x.cols() - 2];

        b_x(b_x.size() - 1) += (b2 - b1 / 2) * pt.x() * pts_dist[A_x.cols() - 1];
        b_y(b_x.size() - 1) += (b2 - b1 / 2) * pt.y() * pts_dist[A_x.cols() - 1];
        b_z(b_x.size() - 1) += (b2 - b1 / 2) * pt.z() * pts_dist[A_x.cols() - 1];

        A_x(A_x.rows() - 1, A_x.cols() - 3) += (b0 - b1 / 2) * (b2 - b1 / 2) * pts_dist[A_x.cols() - 1];
        A_x(A_x.rows() - 1, A_x.cols() - 2) += 2 * b1 * (b2 - b1 / 2) * pts_dist[A_x.cols() - 1];
        A_x(A_x.rows() - 1, A_x.cols() - 1) += (b2 - b1 / 2) * (b2 - b1 / 2) * pts_dist[A_x.cols() - 1];
        row_id++;
    }
    beizer_interpolation.push_back(smooth_curve);
    smooth_curve.clear();
    std::vector<std::vector<double>>beizer_interpolation_arclen(beizer_interpolation.size());
    for (int k = 0; k < beizer_interpolation_arclen.size(); ++k)
    {
        beizer_interpolation_arclen[k].push_back(0);
        for (int k1 = 1; k1 < beizer_interpolation[k].size(); ++k1)
        {
            beizer_interpolation_arclen[k].push_back(beizer_interpolation_arclen[k].back() +
                (beizer_interpolation[k][k1] - beizer_interpolation[k][k1 - 1]).norm());
        }
    }

    row_id = 0;
    Eigen::MatrixXd A_x_((ctrl_pts[j].size() - 1) * (segment_iter_times - 1) + 1, ctrl_pts[j].size());
    A_x_.setZero();
    for (int k = 0; k < segment_iter_times; ++k)
    {
        double tt = (static_cast<double>(k) / (segment_iter_times-1)) * smooth_res[0][3].x();
        double b0 = (1 - tt) * (1 - tt);
        double b1 = 2 * tt * (1 - tt);
        double b2 = (tt * tt);

        A_x_(row_id, 0) += (b0 - b1 / 2);
        A_x_(row_id, 1) += 2 * b1;
        A_x_(row_id, 2) += (b2 - b1 / 2);
        row_id++;
    }
    for (int k = 1; k < smooth_res.size(); ++k)
    {
        for (int k1 = 1; k1 < segment_iter_times; ++k1)
        {

            double tt_1 = (static_cast<double>(k1) / (segment_iter_times-1)) * smooth_res[k][3].x();
            Eigen::Vector3d pt1 = (smooth_res[k][0] * (1 - tt_1) * (1 - tt_1)
                + smooth_res[k][1] * 2 * tt_1 * (1 - tt_1) + smooth_res[k][2] * tt_1 * tt_1);

            double tt_2 = (static_cast<double>(k1) / (segment_iter_times-1)) * (1 - smooth_res[k - 1][3].x()) + smooth_res[k - 1][3].x();
            Eigen::Vector3d pt2 = (smooth_res[k - 1][0] * (1 - tt_2) * (1 - tt_2)
                + smooth_res[k - 1][1] * 2 * tt_2 * (1 - tt_2) + smooth_res[k - 1][2] * tt_2 * tt_2);

            double theta = (static_cast<double>(k1) / (segment_iter_times-1)) * ML_PI_2;
            Eigen::Vector3d pt = std::pow(std::cos(theta), 2) * pt2 + std::pow(std::sin(theta), 2) * pt1;

            double b0_2 = (1 - tt_1) * (1 - tt_1);
            double b1_2 = 2 * tt_1 * (1 - tt_1);
            double b2_2 = (tt_1 * tt_1);

            double b0_1 = (1 - tt_2) * (1 - tt_2);
            double b1_1 = 2 * tt_2 * (1 - tt_2);
            double b2_1 = (tt_2 * tt_2);

            A_x_(row_id, k - 1) += (std::pow(std::cos(theta), 2) * ((b0_1 - b1_1 / 2)));
            A_x_(row_id, k) += (std::pow(std::cos(theta), 2) * (2 * b1_1) +
                std::pow(std::sin(theta), 2) * (b0_2 - b1_2 / 2));
            A_x_(row_id, k + 1) += (std::pow(std::cos(theta), 2) * (b2_1 - b1_1 / 2) +
                std::pow(std::sin(theta), 2) * (2 * b1_2));
            A_x_(row_id, k + 2) += (std::pow(std::sin(theta), 2) * (b2_2 - b1_2 / 2));

            row_id++;
        }
    }
    for (int k = 1; k < segment_iter_times; ++k)
    {
        double tt = (static_cast<double>(k) / (segment_iter_times-1)) * (1 - smooth_res.back()[3].x()) + smooth_res.back()[3].x();
        auto pt = (smooth_res.back()[0] * (1 - tt) * (1 - tt)
            + smooth_res.back()[1] * 2 * tt * (1 - tt) + smooth_res.back()[2] * tt * tt);
        smooth_curve.push_back(pt);

        double b0 = (1 - tt) * (1 - tt);
        double b1 = 2 * tt * (1 - tt);
        double b2 = (tt * tt);


        A_x_(row_id, A_x.cols() - 3) += (b0 - b1 / 2);
        A_x_(row_id, A_x.cols() - 2) += 2 * b1;
        A_x_(row_id, A_x.cols() - 1) += (b2 - b1 / 2);
        row_id++;
    }
    for (int k = 0; k < A_x_.rows(); ++k)
    {
        A_x.conservativeResize(A_x.rows() + 1, A_x.cols());
        b_x.conservativeResize(b_x.size() + 1, 1);
        b_y.conservativeResize(b_y.size() + 1, 1);
        b_z.conservativeResize(b_z.size() + 1, 1);

        A_x.row(A_x.rows() - 1).setZero();
        b_x(A_x.rows() - 1) = 0;
        b_y(A_x.rows() - 1) = 0;
        b_z(A_x.rows() - 1) = 0;

        for (int k1 = 1; k1 <= std::min(k, 5); k1++)
        {
            double modifier = 22 - k1 * 4;
            A_x.row(A_x.rows() - 1) -= modifier * A_x_.row(k - k1);
            A_x.row(A_x.rows() - 1) += modifier * A_x_.row(k);
        }
        for (int k1 = 1; k1 <= std::min(int(A_x_.rows() - 1 - k), 5); k1++)
        {
            double modifier = 22 - k1 * 4;
            A_x.row(A_x.rows() - 1) -= modifier * A_x_.row(k + k1);
            A_x.row(A_x.rows() - 1) += modifier * A_x_.row(k);
        }
    }
    vec_A_x[j] = A_x;
    vec_b_x[j] = b_x;
    vec_b_y[j] = b_y;
    vec_b_z[j] = b_z;
}


void Curve::form_curve(bool is_compute_arclen = false)
{
    curve = std::vector<std::vector<Eigen::Vector3d>>(ctrl_pts.size());
    if (is_compute_arclen)
    {
        beizer_interpolation = std::vector<std::vector<std::vector<Eigen::Vector3d>>>(ctrl_pts.size());
        beizer_interpolation_arclen = std::vector<std::vector<std::vector<double>>>(ctrl_pts.size());
    }
    for (int i = 0; i < ctrl_pts.size(); ++i)
    {
        form_curve(i, is_compute_arclen);
    }
    //form_curve(idx, bool is_compute_arclen = false)
}

void Curve::form_curve(int j,bool is_compute_arclen=false)
{   
    c2line spline(ctrl_pts[j], true);
    std::vector<std::vector<Eigen::Vector3d>>smooth_res = spline.smooth_path();
    std::vector<Eigen::Vector3d>smooth_curve;
    curve[j].clear();
    for (int k = 0; k < segment_iter_times; ++k)
    {   
        double tt = (static_cast<double>(k) / (segment_iter_times-1)) * smooth_res[0][3].x();
        curve[j].push_back(smooth_res[0][0] * (1 - tt) * (1 - tt)
            + smooth_res[0][1] * 2 * tt * (1 - tt) + smooth_res[0][2] * tt * tt);
        smooth_curve.push_back(curve[j].back());
    }
    if (is_compute_arclen)
    {   
        beizer_interpolation[j].clear();
        beizer_interpolation[j].push_back(smooth_curve);
        smooth_curve.clear();
    }
    for (int k = 1; k < smooth_res.size(); ++k)
    {
        for (int k1 = 1; k1 < segment_iter_times; ++k1)
        {
            double tt = (static_cast<double>(k1) / (segment_iter_times-1)) * smooth_res[k][3].x();
            Eigen::Vector3d pt1 = (smooth_res[k][0] * (1 - tt) * (1 - tt)
                + smooth_res[k][1] * 2 * tt * (1 - tt) + smooth_res[k][2] * tt * tt);

            tt = (static_cast<double>(k1) / (segment_iter_times-1)) * (1 - smooth_res[k - 1][3].x()) + smooth_res[k - 1][3].x();
            Eigen::Vector3d pt2 = (smooth_res[k - 1][0] * (1 - tt) * (1 - tt)
                + smooth_res[k - 1][1] * 2 * tt * (1 - tt) + smooth_res[k - 1][2] * tt * tt);

            double theta = (static_cast<double>(k1) / (segment_iter_times-1)) * ML_PI_2;
            Eigen::Vector3d pt = std::pow(std::cos(theta), 2) * pt2 + std::pow(std::sin(theta), 2) * pt1;
            curve[j].push_back(pt);
            smooth_curve.push_back(curve[j].back());
        }
        if (is_compute_arclen)
        {
            beizer_interpolation[j].push_back(smooth_curve);
            smooth_curve.clear();
        }
    }
    for (int k = 1; k < segment_iter_times; ++k)
    {
        double tt = (static_cast<double>(k) / (segment_iter_times-1)) * (1 - smooth_res.back()[3].x()) + smooth_res.back()[3].x();
        curve[j].push_back(smooth_res.back()[0] * (1 - tt) * (1 - tt)
            + smooth_res.back()[1] * 2 * tt * (1 - tt) + smooth_res.back()[2] * tt * tt);
        smooth_curve.push_back(curve[j].back());
    }
    if (is_compute_arclen)
    {
        beizer_interpolation[j].push_back(smooth_curve);
        smooth_curve.clear();
        beizer_interpolation_arclen[j].clear();
        for (int k = 0; k < beizer_interpolation[j].size(); ++k)
        {
            //beizer_interpolation_arclen[j][k].push_back(0);
            beizer_interpolation_arclen[j].push_back(std::vector<double>());
            beizer_interpolation_arclen[j][k].push_back(0);
            for (int k1 = 1; k1 < beizer_interpolation[j][k].size(); ++k1)
            {
                beizer_interpolation_arclen[j][k].push_back(beizer_interpolation_arclen[j][k].back() +
                    (beizer_interpolation[j][k][k1] - beizer_interpolation[j][k][k1 - 1]).norm());
            }
        }
    }
    else
    {   
        generateCylinder(j);
    }
}

void Curve::generateCylinder()
{
    //cylinder_pts = std::vector<std::vector<Eigen::Vector3d>>(ctrl_pts.size());
    pipes = std::vector<Utils::Pipe>(ctrl_pts.size());
    for (int i = 0; i < pipes.size(); ++i)
    {
        generateCylinder(i);
    }
}

void Curve::generateCylinder(int i)
{   
    std::vector<trimesh::vec>curve_pts;
    /*
    for (int j = 0; j < curve[i].size(); ++j)
    {
        curve_pts.push_back(trimesh::vec(curve[i][j].x(), curve[i][j].y(), curve[i][j].z()));
    }
    */
    curve_pts.push_back(trimesh::vec(curve[i].front().x(), curve[i].front().y(), curve[i].front().z()));
    double accumulate_length=0;
    const double upper_bound = 0.01;
    for (int j = 1; j < curve[i].size(); ++j)
    {
        accumulate_length += (curve[i][j] - curve[i][j - 1]).norm();
        if (accumulate_length >= upper_bound)
        {
            accumulate_length = 0;
            curve_pts.push_back(trimesh::vec(curve[i][j].x(), curve[i][j].y(), curve[i][j].z()));
        }
    }
    auto circle = Utils::buildCircle(0.005f, 48);
    pipes[i]= Utils::Pipe(curve_pts, circle);
}

void Curve::draw(bool draw_path, bool draw_cylinder, bool draw_ctrl_pt, int ctrl_pt_i, int ctrl_pt_j,QColor curve_Color)
{   
    glLineWidth(2);
    glEnable(GL_POINT_SMOOTH);
    glEnable(GL_LINE_SMOOTH);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glShadeModel(GL_SMOOTH);
    if (draw_path)
    {
        for (int i = 0; i < curve.size(); ++i)
        {
            glBegin(GL_LINE_STRIP);
            glColor3d(curve_Color.redF(), curve_Color.greenF(), curve_Color.blueF());
            for (auto j : curve[i])
            {
                glVertex3d(j.x(), j.y(), j.z());
            }
            glEnd();
        }
    }
    if (ctrl_pt_i > -1 && ctrl_pt_j > -1)
    {
        glPointSize(10);
        glBegin(GL_POINTS);
        glColor3d(1, 1, 0);
        auto pt = ctrl_pts[ctrl_pt_i][ctrl_pt_j];
        glVertex3d(pt.x(), pt.y(), pt.z());
        glEnd();
    }
    if (draw_ctrl_pt)
    {
        for (int i = 0; i < ctrl_pts.size(); ++i)
        {
            glPointSize(10);
            glBegin(GL_POINTS);
            glColor3ub(58, 59, 123);
            for (int j = 0; j < ctrl_pts[i].size(); ++j)
            {
                if ((i == ctrl_pt_i) && (j == ctrl_pt_j))
                {
                    continue;
                }
                auto pt = ctrl_pts[i][j];
                glVertex3d(pt.x(), pt.y(), pt.z());
            }
            glEnd();
        }
    }
    if (draw_cylinder)
    {   
        glColor3d(0.529, 0.333, 0.3);
        //glColor4ub(150, 255, 224, 255);
        for (int i = 0; i < pipes.size(); ++i)
        {   
            int count = pipes[i].getContourCount();
            for (int j = 0; j < count - 1; ++j)
            {
                auto c1 = pipes[i].getContour(j);
                auto c2 = pipes[i].getContour(j + 1);
                auto n1 = pipes[i].getNormal(j);
                auto n2 = pipes[i].getNormal(j + 1);
                glBegin(GL_TRIANGLE_STRIP);
                for (int k = 0; k < (int)c2.size(); ++k) {
                    glNormal3f(n2[k][0], n2[k][1], n2[k][2]);
                    glVertex3f(c2[k][0], c2[k][1], c2[k][2]);
                    glNormal3f(n1[k][0], n1[k][1], n1[k][2]);
                    glVertex3f(c1[k][0], c1[k][1], c1[k][2]);
                }
                glEnd();
            }
        }
    }
    glDisable(GL_POINT_SMOOTH);
    glDisable(GL_LINE_SMOOTH);
    glDisable(GL_LINE_SMOOTH);
    glDisable(GL_POINT_SMOOTH);
    glDisable(GL_BLEND);
    glDepthMask(GL_TRUE);
    glDisable(GL_POLYGON_SMOOTH);
}
void Curve::modify(Feature* feature_, int ctrl_pt_i, int ctrl_pt_j, Eigen::Vector3d move_pt)
{   
    int cur_ctrl_pt_i = ctrl_pt_i, cur_ctrl_pt_j = ctrl_pt_j;
    for (int i = 0; i < overlap_pts_idx.size(); ++i)
    {
        if ((ctrl_pt_i == overlap_pts_idx[i].front().first) &&
            (ctrl_pt_j == overlap_pts_idx[i].front().second))
        {
            if (overlap_pts_idx[i].size() == 1)
            {
                return;
            }
            else
            {
                cur_ctrl_pt_i = overlap_pts_idx[i].back().first;
                cur_ctrl_pt_j = overlap_pts_idx[i].back().second;
            }
        }
    }

    ctrl_pts[cur_ctrl_pt_i][cur_ctrl_pt_j] = move_pt;
    std::vector<Eigen::Vector3d>vec_ctrl_pts;
    for (int i = 0; i < ctrl_pts.size(); ++i)
    {
        for (int j = 0; j < ctrl_pts[i].size(); ++j)
        {   
            vec_ctrl_pts.push_back(ctrl_pts[i][j]);
        }
    }

    for (int i = 0; i < overlap_pts_vec.size(); ++i)
    {
        int idx1 = overlap_pts_vec[i].front().first;
        //double move_to_x = 0, move_to_y = 0, move_to_z = 0;
        Eigen::Vector3d move_to = Eigen::Vector3d::Zero();
        for (int j = 1; j < overlap_pts_vec[i].size(); ++j)
        {
            int idx2 = overlap_pts_vec[i][j].first;
            double w = overlap_pts_vec[i][j].second;
            move_to += w * vec_ctrl_pts[idx2];
        }
        vec_ctrl_pts[idx1] = move_to;
    }
    int col_idx = 0;
    for (int i = 0; i < ctrl_pts.size(); ++i)
    {
        for (int j = 0; j < ctrl_pts[i].size(); ++j)
        {
            ctrl_pts[i][j]=vec_ctrl_pts[col_idx];
            col_idx++;
        }
    }
    form_curve(false);
    generateCylinder();
}



void Curve::addCurve(Curve& add_path, Curve& geodesic_path, kLineLink link)
{   
    //////std::cout << "size 1" << add_path.ctrl_pts.back().size() << std::endl;
    //////std::cout << "size 2" << geodesic_path.ctrl_pts.back().size() << std::endl;
    std::vector<Eigen::Vector3d>cur_path = this->ctrl_pts.back();
    if (link == kLineLink::RADDPATH_RGEODESICPATH_CURPATH)
    {
        cur_path.insert(cur_path.begin(), geodesic_path.ctrl_pts.back().begin()+1, geodesic_path.ctrl_pts.back().end()-1);
        cur_path.insert(cur_path.begin(), add_path.ctrl_pts.back().rbegin(), add_path.ctrl_pts.back().rend());
    }
    if (link == kLineLink::CURPATH_GEODESICPATH_ADDPATH)
    {
        cur_path.insert(cur_path.end(), geodesic_path.ctrl_pts.back().begin()+1, geodesic_path.ctrl_pts.back().end()-1);
        cur_path.insert(cur_path.end(), add_path.ctrl_pts.back().begin(), add_path.ctrl_pts.back().end());
    }
    if (link == kLineLink::ADDPATH_RGEODESICPATH_CURPATH)
    {
        cur_path.insert(cur_path.begin(), geodesic_path.ctrl_pts.back().begin()+1, geodesic_path.ctrl_pts.back().end()-1);
        cur_path.insert(cur_path.begin(), add_path.ctrl_pts.back().begin(), add_path.ctrl_pts.back().end());
    }
    if (link == kLineLink::CURPATH_GEODESICPATH_RADDPATH)
    {
        cur_path.insert(cur_path.end(), geodesic_path.ctrl_pts.back().begin()+1, geodesic_path.ctrl_pts.back().end()-1);
        cur_path.insert(cur_path.end(), add_path.ctrl_pts.back().rbegin(), add_path.ctrl_pts.back().rend());
    }
    this->ctrl_pts.back() = cur_path;
    
    pipes = std::vector<Utils::Pipe>(ctrl_pts.size());
    form_curve(false);
    form_curve(true);
}

void Curve::addCurve(Curve& rhs)
{
    this->ctrl_pts.push_back(rhs.ctrl_pts.back());
    pipes = std::vector<Utils::Pipe>(ctrl_pts.size());
    form_curve(false);
    form_curve(true);
}

void Curve::addCurve(Curve& rhs, bool insert_end, Feature* feature_)
{
    std::vector<Eigen::Vector3d>cur_path = this->ctrl_pts.back();
    if (insert_end)
    {
        cur_path.insert(cur_path.end(), rhs.ctrl_pts.back().begin() + 1, rhs.ctrl_pts.back().end());
    }
    else
    {
        cur_path.insert(cur_path.begin(), rhs.ctrl_pts.back().rbegin(), rhs.ctrl_pts.back().rend()-1);
        auto size = rhs.ctrl_pts.back().size() - 1;
        for (int i = 0; i < overlap_pts_idx.size(); ++i)
        {
            if (overlap_pts_idx[i].front().first == this->ctrl_pts.size()-1)
            {
                //overlap_pts_idx[i].front().second++;
                overlap_pts_idx[i].front().second += size;
            }
            if (overlap_pts_idx[i].back().first == this->ctrl_pts.size() - 1)
            {
                //overlap_pts_idx[i].back().second++;
                overlap_pts_idx[i].back().second += size;
            }
        }
    }
    this->ctrl_pts.back() = cur_path;
    //overlap pts ctrl;
    pipes = std::vector<Utils::Pipe>(ctrl_pts.size());
    form_curve(false);
    form_curve(true);
}

void Curve::addCurve(Curve& rhs, bool insert_end, int insert_idx,Feature* feature_)
{
    std::vector<Eigen::Vector3d>cur_path = this->ctrl_pts[insert_idx];
    if (insert_end)
    {
        cur_path.insert(cur_path.end(), rhs.ctrl_pts.back().begin() + 1, rhs.ctrl_pts.back().end());
        auto size = rhs.ctrl_pts.back().size() - 1;
        for (int i = 0; i < overlap_pts_idx.size(); ++i)
        {
            if (overlap_pts_idx[i].front().first > insert_idx)
            {
                //overlap_pts_idx[i].front().second++;
                overlap_pts_idx[i].front().second += size;
            }
            if (overlap_pts_idx[i].back().first > insert_idx)
            {
                //overlap_pts_idx[i].back().second++;
                overlap_pts_idx[i].back().second += size;
            }
        }
    }
    else
    {
        cur_path.insert(cur_path.begin(), rhs.ctrl_pts.back().rbegin(), rhs.ctrl_pts.back().rend() - 1);
        auto size = rhs.ctrl_pts.back().size() - 1;
        for (int i = 0; i < overlap_pts_idx.size(); ++i)
        {
            if (overlap_pts_idx[i].front().first >= insert_idx)
            {
                //overlap_pts_idx[i].front().second++;
                overlap_pts_idx[i].front().second += size;
            }
            if (overlap_pts_idx[i].back().first >= insert_idx)
            {
                //overlap_pts_idx[i].back().second++;
                overlap_pts_idx[i].back().second += size;
            }
        }
    }
    this->ctrl_pts[insert_idx] = cur_path;
    //overlap pts ctrl;
    pipes = std::vector<Utils::Pipe>(ctrl_pts.size());
    form_curve(false);
    form_curve(true);
}

void Curve::addCurve(Curve& rhs, std::vector<std::vector<int>>&smooth_project_idx,std::vector<std::pair<int,int>>overlap_pts , Feature* feature_)
{   
    ctrl_pts.push_back(rhs.ctrl_pts.front());

    //insert here
    int long_vec_idx = 0;
    for (int i = 0; i < ctrl_pts.size()-1; ++i)
    {
        long_vec_idx += ctrl_pts[i].size();
    }

    Eigen::Vector3d insert_ctrl_pt;
    long_vec_idx = 0;
    for (int i = 0; i < overlap_pts.front().first; ++i)
    {
        long_vec_idx += ctrl_pts[i].size();
    }

    int vec_i_remainder = overlap_pts.front().second % (this->segment_iter_times - 1);
    int vec_i_quotient= overlap_pts.front().second / (this->segment_iter_times - 1);
    if (vec_i_quotient == 0)
    {
        double tt = (static_cast<double>(vec_i_remainder) / (segment_iter_times - 1)) * 0.5;
        double b0 = (1 - tt) * (1 - tt);
        double b1 = 2 * tt * (1 - tt);
        double b2 = (tt * tt);

        insert_ctrl_pt = (b0 - b1 / 2) * ctrl_pts[overlap_pts.front().first][0]
            + 2 * b1 * ctrl_pts[overlap_pts.front().first][1]
            + (b2 - b1 / 2) * ctrl_pts[overlap_pts.front().first][2];
    }
    else if (vec_i_quotient >= ctrl_pts[overlap_pts.front().first].size()-2)
    {
        double tt = (static_cast<double>(vec_i_remainder + 1) / (segment_iter_times - 1)) * 0.5 + 0.5;
        double b0 = (1 - tt) * (1 - tt);
        double b1 = 2 * tt * (1 - tt);
        double b2 = (tt * tt);

        insert_ctrl_pt = (b0 - b1 / 2) * ctrl_pts[overlap_pts.front().first][ctrl_pts[overlap_pts.front().first].size() - 3]
            + 2 * b1 * ctrl_pts[overlap_pts.front().first][ctrl_pts[overlap_pts.front().first].size() - 2]
            + (b2 - b1 / 2) * ctrl_pts[overlap_pts.front().first][ctrl_pts[overlap_pts.front().first].size() - 1];
    }
    else
    {
        double tt_1 = (static_cast<double>(vec_i_remainder + 1) / (segment_iter_times - 1)) * 0.5;
        double tt_2 = (static_cast<double>(vec_i_remainder + 1) / (segment_iter_times - 1)) * 0.5 + 0.5;

        double theta = (static_cast<double>(vec_i_remainder + 1) / (segment_iter_times - 1)) * ML_PI_2;

        double b0_2 = (1 - tt_1) * (1 - tt_1);
        double b1_2 = 2 * tt_1 * (1 - tt_1);
        double b2_2 = (tt_1 * tt_1);

        double b0_1 = (1 - tt_2) * (1 - tt_2);
        double b1_1 = 2 * tt_2 * (1 - tt_2);
        double b2_1 = (tt_2 * tt_2);

        double w1 = (std::pow(std::cos(theta), 2) * ((b0_1 - b1_1 / 2)));
        double w2 = (std::pow(std::cos(theta), 2) * (2 * b1_1) +
            std::pow(std::sin(theta), 2) * (b0_2 - b1_2 / 2));
        double w3 = (std::pow(std::cos(theta), 2) * (b2_1 - b1_1 / 2) +
            std::pow(std::sin(theta), 2) * (2 * b1_2));
        double w4 = (std::pow(std::sin(theta), 2) * (b2_2 - b1_2 / 2));


        insert_ctrl_pt = w1 * ctrl_pts[overlap_pts.front().first][vec_i_quotient - 1]
            + w2 * ctrl_pts[overlap_pts.front().first][vec_i_quotient]
            + w3 * ctrl_pts[overlap_pts.front().first][vec_i_quotient + 1]
            + w4 * ctrl_pts[overlap_pts.front().first][vec_i_quotient + 2];
    }

    //insert
    ctrl_pts[overlap_pts.front().first].insert(ctrl_pts[overlap_pts.front().first].begin() +
        vec_i_quotient+1, insert_ctrl_pt);
    for (int i = 0; i < overlap_pts_idx.size(); ++i)
    {
        if (overlap_pts_idx[i].front().first == overlap_pts.front().first &&
            overlap_pts_idx[i].front().second > vec_i_quotient)
        {
            overlap_pts_idx[i].front().second++;
        }
        if (overlap_pts_idx[i].back().first == overlap_pts.front().first &&
            overlap_pts_idx[i].back().second > vec_i_quotient)
        {
            overlap_pts_idx[i].back().second++;
        }
    }
    overlap_pts_idx.push_back(std::vector<std::pair<int, int>>());
    overlap_pts_idx.back().push_back(std::pair<int, int>(ctrl_pts.size() - 1, 0));
    overlap_pts_idx.back().push_back(std::pair<int, int>(overlap_pts.front().first, vec_i_quotient + 1));

    overlap_pts_vec.clear();

    for (int i = 0; i < overlap_pts_idx.size(); ++i)
    {
        int curve_idx_1 = overlap_pts_idx[i].front().first;
        int curve_ctrl_pt_idx_1 = overlap_pts_idx[i].front().second;

        int curve_idx_2 = overlap_pts_idx[i].back().first;
        int curve_ctrl_pt_idx_2 = overlap_pts_idx[i].back().second;

        int long_vec_idx = 0;
        for (int k = 0; k < curve_idx_1; ++k)
        {
            long_vec_idx += ctrl_pts[k].size();
        }

        overlap_pts_vec.push_back(std::vector<std::pair<int, double>>());
        overlap_pts_vec.back().push_back(std::pair<int, double>(long_vec_idx + curve_ctrl_pt_idx_1, 1));

        long_vec_idx = 0;
        for (int k = 0; k < curve_idx_2; ++k)
        {
            long_vec_idx += ctrl_pts[k].size();
        }

        overlap_pts_vec.back().push_back(std::pair<int, double>(long_vec_idx + curve_ctrl_pt_idx_2, 1));
    }


    

    std::vector<Eigen::Vector3d>vec_ctrl_pts;
    for (int i = 0; i < ctrl_pts.size(); ++i)
    {
        for (int j = 0; j < ctrl_pts[i].size(); ++j)
        {
            vec_ctrl_pts.push_back(ctrl_pts[i][j]);
        }
    }

    for (int i = 0; i < overlap_pts_vec.size(); ++i)
    {
        int idx1 = overlap_pts_vec[i].front().first;
        //double move_to_x = 0, move_to_y = 0, move_to_z = 0;
        Eigen::Vector3d move_to = Eigen::Vector3d::Zero();
        for (int j = 1; j < overlap_pts_vec[i].size(); ++j)
        {
            int idx2 = overlap_pts_vec[i][j].first;
            double w = overlap_pts_vec[i][j].second;
            move_to += w * vec_ctrl_pts[idx2];
        }
        vec_ctrl_pts[idx1] = move_to;
    }
    int col_idx = 0;
    for (int i = 0; i < ctrl_pts.size(); ++i)
    {
        for (int j = 0; j < ctrl_pts[i].size(); ++j)
        {
            ctrl_pts[i][j] = vec_ctrl_pts[col_idx];
            col_idx++;
        }
    }

    //this->setA_x(feature_, std::vector<int>());
    pipes = std::vector<Utils::Pipe>(ctrl_pts.size());
    form_curve(false);
    form_curve(true);
}

void Curve::addCurve(Curve& rhs, std::vector<std::pair<int, int>>overlap_pts, Feature* feature_)
{
    ctrl_pts.push_back(rhs.ctrl_pts.front());
    //insert here
    int long_vec_idx = 0;
    for (int i = 0; i < ctrl_pts.size() - 1; ++i)
    {
        long_vec_idx += ctrl_pts[i].size();
    }

    Eigen::Vector3d insert_ctrl_pt;
    long_vec_idx = 0;
    for (int i = 0; i < overlap_pts.front().first; ++i)
    {
        long_vec_idx += ctrl_pts[i].size();
    }

    overlap_pts_idx.push_back(std::vector<std::pair<int, int>>());
    overlap_pts_idx.back().push_back(std::pair<int, int>(ctrl_pts.size() - 1, 0));
    //overlap_pts_idx.back().push_back(std::pair<int, int>(ctrl_pts.size() - 1, 0));
    overlap_pts_idx.back().push_back(std::pair<int, int>(overlap_pts.front().first, overlap_pts.front().second/(segment_iter_times-1)));

    overlap_pts_vec.clear();

    for (int i = 0; i < overlap_pts_idx.size(); ++i)
    {
        int curve_idx_1 = overlap_pts_idx[i].front().first;
        int curve_ctrl_pt_idx_1 = overlap_pts_idx[i].front().second;

        int curve_idx_2 = overlap_pts_idx[i].back().first;
        int curve_ctrl_pt_idx_2 = overlap_pts_idx[i].back().second;

        int long_vec_idx = 0;
        for (int k = 0; k < curve_idx_1; ++k)
        {
            long_vec_idx += ctrl_pts[k].size();
        }

        overlap_pts_vec.push_back(std::vector<std::pair<int, double>>());
        overlap_pts_vec.back().push_back(std::pair<int, double>(long_vec_idx + curve_ctrl_pt_idx_1, 1));

        long_vec_idx = 0;
        for (int k = 0; k < curve_idx_2; ++k)
        {
            long_vec_idx += ctrl_pts[k].size();
        }

        overlap_pts_vec.back().push_back(std::pair<int, double>(long_vec_idx + curve_ctrl_pt_idx_2, 1));
    }

    std::vector<Eigen::Vector3d>vec_ctrl_pts;
    for (int i = 0; i < ctrl_pts.size(); ++i)
    {
        for (int j = 0; j < ctrl_pts[i].size(); ++j)
        {
            vec_ctrl_pts.push_back(ctrl_pts[i][j]);
        }
    }

    for (int i = 0; i < overlap_pts_vec.size(); ++i)
    {
        int idx1 = overlap_pts_vec[i].front().first;
        //double move_to_x = 0, move_to_y = 0, move_to_z = 0;
        Eigen::Vector3d move_to = Eigen::Vector3d::Zero();
        for (int j = 1; j < overlap_pts_vec[i].size(); ++j)
        {
            int idx2 = overlap_pts_vec[i][j].first;
            double w = overlap_pts_vec[i][j].second;
            move_to += w * vec_ctrl_pts[idx2];
        }
        vec_ctrl_pts[idx1] = move_to;
    }
    int col_idx = 0;
    for (int i = 0; i < ctrl_pts.size(); ++i)
    {
        for (int j = 0; j < ctrl_pts[i].size(); ++j)
        {
            ctrl_pts[i][j] = vec_ctrl_pts[col_idx];
            col_idx++;
        }
    }

    //this->setA_x(feature_, std::vector<int>());
    pipes = std::vector<Utils::Pipe>(ctrl_pts.size());
    form_curve(false);
    form_curve(true);
}

void Curve::addCurve(Curve& mhs, Curve& rhs, std::vector<std::pair<int, int>>overlap_pts, Feature* feature_)
{   
    std::cout << "add 1" << std::endl;
    ctrl_pts.push_back(rhs.ctrl_pts.front());
    if (overlap_pts.back().second == 0)
    {
        ctrl_pts.back().insert(ctrl_pts.back().begin(), mhs.ctrl_pts.back().begin(), mhs.ctrl_pts.back().end() - 1);
    }
    else
    {
        ctrl_pts.back().insert(ctrl_pts.back().end(), mhs.ctrl_pts.back().rbegin() + 1, mhs.ctrl_pts.back().rend());
    }
    std::cout << "add 2" << std::endl;
    overlap_pts_idx.push_back(std::vector<std::pair<int, int>>());
    if (overlap_pts.back().second == 0)
    {
        overlap_pts_idx.back().push_back(std::pair<int, int>(ctrl_pts.size() - 1, 0));
    }
    else
    {
        overlap_pts_idx.back().push_back(std::pair<int, int>(ctrl_pts.size() - 1, ctrl_pts.back().size() - 1));
    }
    std::cout << "add 3" << std::endl;
    //overlap_pts_idx.back().push_back(std::pair<int, int>(ctrl_pts.size() - 1, 0));
    overlap_pts_idx.back().push_back(std::pair<int, int>(overlap_pts.front().first, (overlap_pts.front().second+ (segment_iter_times - 1)/2) /(segment_iter_times-1)));

    overlap_pts_vec.clear();

    for (int i = 0; i < overlap_pts_idx.size(); ++i)
    {
        int curve_idx_1 = overlap_pts_idx[i].front().first;
        int curve_ctrl_pt_idx_1 = overlap_pts_idx[i].front().second;

        int curve_idx_2 = overlap_pts_idx[i].back().first;
        int curve_ctrl_pt_idx_2 = overlap_pts_idx[i].back().second;

        int long_vec_idx = 0;
        for (int k = 0; k < curve_idx_1; ++k)
        {
            long_vec_idx += ctrl_pts[k].size();
        }

        overlap_pts_vec.push_back(std::vector<std::pair<int, double>>());
        overlap_pts_vec.back().push_back(std::pair<int, double>(long_vec_idx + curve_ctrl_pt_idx_1, 1));

        long_vec_idx = 0;
        for (int k = 0; k < curve_idx_2; ++k)
        {
            long_vec_idx += ctrl_pts[k].size();
        }

        overlap_pts_vec.back().push_back(std::pair<int, double>(long_vec_idx + curve_ctrl_pt_idx_2, 1));
    }
    std::cout << "add 4" << std::endl;
    std::vector<Eigen::Vector3d>vec_ctrl_pts;
    for (int i = 0; i < ctrl_pts.size(); ++i)
    {
        for (int j = 0; j < ctrl_pts[i].size(); ++j)
        {
            vec_ctrl_pts.push_back(ctrl_pts[i][j]);
        }
    }

    for (int i = 0; i < overlap_pts_vec.size(); ++i)
    {
        int idx1 = overlap_pts_vec[i].front().first;
        //double move_to_x = 0, move_to_y = 0, move_to_z = 0;
        Eigen::Vector3d move_to = Eigen::Vector3d::Zero();
        for (int j = 1; j < overlap_pts_vec[i].size(); ++j)
        {
            int idx2 = overlap_pts_vec[i][j].first;
            double w = overlap_pts_vec[i][j].second;
            move_to += w * vec_ctrl_pts[idx2];
        }
        vec_ctrl_pts[idx1] = move_to;
    }
    int col_idx = 0;
    for (int i = 0; i < ctrl_pts.size(); ++i)
    {
        for (int j = 0; j < ctrl_pts[i].size(); ++j)
        {
            ctrl_pts[i][j] = vec_ctrl_pts[col_idx];
            col_idx++;
        }
    }

    //this->setA_x(feature_, std::vector<int>());
    std::cout << "add 5" << std::endl;
    pipes = std::vector<Utils::Pipe>(ctrl_pts.size());
    form_curve(false);
    form_curve(true);
}

void Curve::appendCurve(Curve& rhs, std::pair<int, int>overlap_pts)
{
    this->ctrl_pts.push_back(rhs.ctrl_pts.back());
    overlap_pts_idx.push_back(std::vector<std::pair<int, int>>());
    overlap_pts_idx.back().push_back(std::pair<int, int>(ctrl_pts.size() - 1, 0));
    overlap_pts_idx.back().push_back(std::pair<int, int>(overlap_pts.first, overlap_pts.second));
    //overlap_pts_vec.clear();
    overlap_pts_vec.clear();

    for (int i = 0; i < overlap_pts_idx.size(); ++i)
    {   
        int curve_idx_1 = overlap_pts_idx[i].front().first;
        int curve_ctrl_pt_idx_1 = overlap_pts_idx[i].front().second;

        int curve_idx_2 = overlap_pts_idx[i].back().first;
        int curve_ctrl_pt_idx_2 = overlap_pts_idx[i].back().second;

        int long_vec_idx = 0;
        for (int k = 0; k < curve_idx_1; ++k)
        {
            long_vec_idx += ctrl_pts[k].size();
        }
        overlap_pts_vec.push_back(std::vector<std::pair<int, double>>());
        overlap_pts_vec.back().push_back(std::pair<int, double>(long_vec_idx + curve_ctrl_pt_idx_1, 1));

        long_vec_idx = 0;
        for (int k = 0; k < curve_idx_2; ++k)
        {
            long_vec_idx += ctrl_pts[k].size();
        }
        overlap_pts_vec.back().push_back(std::pair<int, double>(long_vec_idx + curve_ctrl_pt_idx_2, 1));
    }
    std::vector<Eigen::Vector3d>vec_ctrl_pts;
    for (int i = 0; i < ctrl_pts.size(); ++i)
    {
        for (int j = 0; j < ctrl_pts[i].size(); ++j)
        {
            vec_ctrl_pts.push_back(ctrl_pts[i][j]);
        }
    }

    for (int i = 0; i < overlap_pts_vec.size(); ++i)
    {
        int idx1 = overlap_pts_vec[i].front().first;
        //double move_to_x = 0, move_to_y = 0, move_to_z = 0;
        Eigen::Vector3d move_to = Eigen::Vector3d::Zero();
        for (int j = 1; j < overlap_pts_vec[i].size(); ++j)
        {
            int idx2 = overlap_pts_vec[i][j].first;
            double w = overlap_pts_vec[i][j].second;
            move_to += w * vec_ctrl_pts[idx2];
        }
        vec_ctrl_pts[idx1] = move_to;
    }

    int col_idx = 0;
    for (int i = 0; i < ctrl_pts.size(); ++i)
    {
        for (int j = 0; j < ctrl_pts[i].size(); ++j)
        {
            ctrl_pts[i][j] = vec_ctrl_pts[col_idx];
            col_idx++;
        }
    }

    pipes = std::vector<Utils::Pipe>(ctrl_pts.size());
    form_curve(false);
}

void Curve::modifyCurve(std::vector<int>& curve_modify_part, Feature* feature_)
{   
    //case of erase all.
    int curve_idx = curve_modify_part.front();
    int curve_start = curve_modify_part[1];
    int curve_end = curve_modify_part[2];

    int erase_ctrl_pts_start;
    {
        int vec_i_remainder = curve_start % (this->segment_iter_times - 1);
        int vec_i_quotient = curve_start / (this->segment_iter_times - 1);
        if (vec_i_quotient == 0)
        {
            erase_ctrl_pts_start = 0;
        }
        else if (vec_i_quotient >= ctrl_pts[curve_idx].size() - 2)
        {
            erase_ctrl_pts_start = vec_i_quotient;
        }
        else
        {
            erase_ctrl_pts_start = vec_i_quotient;
        }
    }
    int erase_ctrl_pts_end;
    {
        int vec_i_remainder = curve_end % (this->segment_iter_times - 1);
        int vec_i_quotient = curve_end / (this->segment_iter_times - 1);
        if (vec_i_quotient == 0)
        {
            erase_ctrl_pts_end = 1;
        }
        else if (vec_i_quotient >= ctrl_pts[curve_idx].size() - 2)
        {
            erase_ctrl_pts_end = vec_i_quotient+1;
        }
        else
        {
            erase_ctrl_pts_end = vec_i_quotient+1;
        }
    }
    Eigen::Vector3d insert_pt1, insert_pt2;
    Eigen::Vector3d insert_pt3 = Eigen::Vector3d::Zero();
    if (erase_ctrl_pts_start == 0)
    {   //swap?
        int idx = (curve[curve_idx].size() - curve_end) / 2 + curve_end;
        insert_pt1 = this->curve[curve_idx][curve_end];
        insert_pt2 = this->curve[curve_idx][idx];
        //idx = curve_end + segment_iter_times;
        idx = erase_ctrl_pts_end * (this->segment_iter_times - 1) + segment_iter_times / 2;
        if (idx < curve[curve_idx].size())
        {
            insert_pt3 = this->curve[curve_idx][idx];
        }
    }
    else
    {   
        int idx = curve_start / 2;
        insert_pt1 = this->curve[curve_idx][curve_start];
        insert_pt2 = this->curve[curve_idx][idx];
        //idx = curve_start - segment_iter_times;
        idx=(erase_ctrl_pts_start-1) * (this->segment_iter_times - 1) + segment_iter_times / 2;
        if (idx > -1)
        {
            insert_pt3 = this->curve[curve_idx][idx];
        }
    }
    ctrl_pts[curve_idx].erase(ctrl_pts[curve_idx].begin() + erase_ctrl_pts_start,
        ctrl_pts[curve_idx].begin() + erase_ctrl_pts_end);
    //some constrain
    if (erase_ctrl_pts_start == 0)
    {
        ctrl_pts[curve_idx].insert(ctrl_pts[curve_idx].begin(), insert_pt1);
        if (insert_pt3 != Eigen::Vector3d::Zero())
        {
            ctrl_pts[curve_idx].insert(ctrl_pts[curve_idx].begin() + 2, insert_pt3);
        }
    }
    else
    {   
        ctrl_pts[curve_idx].push_back(insert_pt1);
        if (insert_pt3 != Eigen::Vector3d::Zero())
        {
            //ctrl_pts[curve_idx].push_back(insert_pt3);
            ctrl_pts[curve_idx].insert(ctrl_pts[curve_idx].end()-1,insert_pt3);
        }
    }
    if (ctrl_pts[curve_idx].size() == 2)
    {
        ctrl_pts[curve_idx].insert(ctrl_pts[curve_idx].begin() + 1, insert_pt2);
    }
    //this->setA_x(feature_, std::vector<int>());
    pipes = std::vector<Utils::Pipe>(ctrl_pts.size());
    form_curve(false);
    form_curve(true);
}

void Curve::modifyCurve(Curve& rhs, std::vector<int>& curve_modify_part, Feature* feature_)
{
    int curve_idx = curve_modify_part.front();
    int curve_start = curve_modify_part[1];
    int curve_end = curve_modify_part[2];

    int erase_ctrl_pts_start;
    {
        int vec_i_remainder = curve_start % (this->segment_iter_times - 1);
        int vec_i_quotient = curve_start / (this->segment_iter_times - 1);
        erase_ctrl_pts_start = vec_i_quotient;
    }
    int erase_ctrl_pts_end;
    {
        int vec_i_remainder = curve_end % (this->segment_iter_times - 1);
        int vec_i_quotient = curve_end / (this->segment_iter_times - 1);
        erase_ctrl_pts_end = vec_i_quotient + 1;
    }
    ctrl_pts[curve_idx].erase(ctrl_pts[curve_idx].begin() + erase_ctrl_pts_start,
        ctrl_pts[curve_idx].begin() + erase_ctrl_pts_end);
    if (curve_modify_part[1] < curve_modify_part[2])
    {
        ctrl_pts[curve_idx].insert(ctrl_pts[curve_idx].begin() + erase_ctrl_pts_start,
            rhs.ctrl_pts.front().begin(), rhs.ctrl_pts.front().end());
    }
    else
    {
        ctrl_pts[curve_idx].insert(ctrl_pts[curve_idx].begin() + erase_ctrl_pts_start,
            rhs.ctrl_pts.front().rbegin(), rhs.ctrl_pts.front().rend());
    }
    //some question.
    //this->setA_x(feature_, std::vector<int>());
    pipes = std::vector<Utils::Pipe>(ctrl_pts.size());
    form_curve(false);
    form_curve(true);
}

void Curve::attachCurve(Curve& rhs, std::vector<int>& curve_modify_part, Feature* feature_)
{
    int curve_idx = curve_modify_part.front();
    int curve_start = std::min(curve_modify_part[1], curve_modify_part[2]);
    int curve_end = std::max(curve_modify_part[1], curve_modify_part[2]);

    int erase_ctrl_pts_start;
    {
        int vec_i_quotient = (curve_start+ (this->segment_iter_times - 1)/2) / (this->segment_iter_times - 1);
        //int vec_i_quotient = curve_start / (this->segment_iter_times - 1);
        erase_ctrl_pts_start = vec_i_quotient;
    }
    int erase_ctrl_pts_end;
    {
        int vec_i_quotient = (curve_end + (this->segment_iter_times - 1) / 2) / (this->segment_iter_times - 1);
        //int vec_i_quotient = curve_end / (this->segment_iter_times - 1);
        erase_ctrl_pts_end = vec_i_quotient + 1;
    }
    std::vector<Eigen::Vector3d>insert_ctrl_pts = rhs.ctrl_pts.front();
    if (curve_modify_part[1] < curve_modify_part[2])
    {
        insert_ctrl_pts.insert(insert_ctrl_pts.begin(), curve[curve_modify_part[0]][curve_modify_part[1]]);
        insert_ctrl_pts.push_back(curve[curve_modify_part[0]][curve_modify_part[2]]);
    }
    else
    {
        insert_ctrl_pts.insert(insert_ctrl_pts.begin(), curve[curve_modify_part[0]][curve_modify_part[2]]);
        insert_ctrl_pts.push_back(curve[curve_modify_part[0]][curve_modify_part[1]]);
    }
    ctrl_pts[curve_idx].erase(ctrl_pts[curve_idx].begin() + erase_ctrl_pts_start + 1,
        ctrl_pts[curve_idx].begin() + erase_ctrl_pts_end);

    const int num_of_iteration = 5;
    if (curve_modify_part[1] < curve_modify_part[2])
    {
        ctrl_pts[curve_idx].insert(ctrl_pts[curve_idx].begin() + erase_ctrl_pts_start + 1 ,
            rhs.ctrl_pts.front().begin(), rhs.ctrl_pts.front().end());
    }
    else
    {
        ctrl_pts[curve_idx].insert(ctrl_pts[curve_idx].begin() + erase_ctrl_pts_start + 1,
            rhs.ctrl_pts.front().rbegin(), rhs.ctrl_pts.front().rend());
    }
    
    for (int i = 0; i < num_of_iteration; ++i)
    {   
        auto p0 = ctrl_pts[curve_idx][erase_ctrl_pts_start - 1];
        auto p1 = ctrl_pts[curve_idx][erase_ctrl_pts_start];
        auto p2 = ctrl_pts[curve_idx][erase_ctrl_pts_start + 1];
        auto p3 = ctrl_pts[curve_idx][erase_ctrl_pts_start + 2];

        auto p4 = ctrl_pts[curve_idx][erase_ctrl_pts_start + rhs.ctrl_pts.front().size() - 1];
        auto p5 = ctrl_pts[curve_idx][erase_ctrl_pts_start + rhs.ctrl_pts.front().size()];
        auto p6 = ctrl_pts[curve_idx][erase_ctrl_pts_start + rhs.ctrl_pts.front().size() + 1];
        auto p7 = ctrl_pts[curve_idx][erase_ctrl_pts_start + rhs.ctrl_pts.front().size() + 2];

        Eigen::Vector3d thisPt0 = p0 * 0.125 + p1 * 0.75 + p2 * 0.125;
        Eigen::Vector3d thisPt1 = p1 * 0.125 + p2 * 0.75 + p3 * 0.125;
        Eigen::Vector3d thisPt2 = p4 * 0.125 + p5 * 0.75 + p6 * 0.125;
        Eigen::Vector3d thisPt3 = p5 * 0.125 + p6 * 0.75 + p7 * 0.125;
        ctrl_pts[curve_idx][erase_ctrl_pts_start] = thisPt0;
        ctrl_pts[curve_idx][erase_ctrl_pts_start + 1] = thisPt1;
        ctrl_pts[curve_idx][erase_ctrl_pts_start + rhs.ctrl_pts.front().size()] = thisPt2;
        ctrl_pts[curve_idx][erase_ctrl_pts_start + rhs.ctrl_pts.front().size() + 1] = thisPt3;
    }

    //this->setA_x(feature_, std::vector<int>());
    pipes = std::vector<Utils::Pipe>(ctrl_pts.size());
    form_curve(false);
    form_curve(true);
}

void Curve::attachNNCurve(Curve& rhs, std::vector<std::pair<int, int>>& overlap_pts,Feature* feature_)
{   
    if (overlap_pts.back().second == 0)
    {
        this->ctrl_pts.back().insert(this->ctrl_pts.back().begin(), rhs.ctrl_pts.front().begin(), rhs.ctrl_pts.front().end()-1);
    }
    else
    {
        this->ctrl_pts.back().insert(this->ctrl_pts.back().end(), rhs.ctrl_pts.front().rbegin(), rhs.ctrl_pts.front().rend()-1);
    }


    Eigen::Vector3d insert_ctrl_pt;
    int long_vec_idx = 0;
    for (int i = 0; i < overlap_pts.front().first; ++i)
    {
        long_vec_idx += ctrl_pts[i].size();
    }

    int vec_i_remainder = overlap_pts.front().second % (this->segment_iter_times - 1);
    int vec_i_quotient = overlap_pts.front().second / (this->segment_iter_times - 1);
    if (vec_i_quotient == 0)
    {
        double tt = (static_cast<double>(vec_i_remainder) / (segment_iter_times - 1)) * 0.5;
        double b0 = (1 - tt) * (1 - tt);
        double b1 = 2 * tt * (1 - tt);
        double b2 = (tt * tt);

        insert_ctrl_pt = (b0 - b1 / 2) * ctrl_pts[overlap_pts.front().first][0]
            + 2 * b1 * ctrl_pts[overlap_pts.front().first][1]
            + (b2 - b1 / 2) * ctrl_pts[overlap_pts.front().first][2];
    }
    else if (vec_i_quotient >= ctrl_pts[overlap_pts.front().first].size() - 2)
    {
        double tt = (static_cast<double>(vec_i_remainder + 1) / (segment_iter_times - 1)) * 0.5 + 0.5;
        double b0 = (1 - tt) * (1 - tt);
        double b1 = 2 * tt * (1 - tt);
        double b2 = (tt * tt);

        insert_ctrl_pt = (b0 - b1 / 2) * ctrl_pts[overlap_pts.front().first][ctrl_pts[overlap_pts.front().first].size() - 3]
            + 2 * b1 * ctrl_pts[overlap_pts.front().first][ctrl_pts[overlap_pts.front().first].size() - 2]
            + (b2 - b1 / 2) * ctrl_pts[overlap_pts.front().first][ctrl_pts[overlap_pts.front().first].size() - 1];
    }
    else
    {
        double tt_1 = (static_cast<double>(vec_i_remainder + 1) / (segment_iter_times - 1)) * 0.5;
        double tt_2 = (static_cast<double>(vec_i_remainder + 1) / (segment_iter_times - 1)) * 0.5 + 0.5;

        double theta = (static_cast<double>(vec_i_remainder + 1) / (segment_iter_times - 1)) * ML_PI_2;

        double b0_2 = (1 - tt_1) * (1 - tt_1);
        double b1_2 = 2 * tt_1 * (1 - tt_1);
        double b2_2 = (tt_1 * tt_1);

        double b0_1 = (1 - tt_2) * (1 - tt_2);
        double b1_1 = 2 * tt_2 * (1 - tt_2);
        double b2_1 = (tt_2 * tt_2);

        double w1 = (std::pow(std::cos(theta), 2) * ((b0_1 - b1_1 / 2)));
        double w2 = (std::pow(std::cos(theta), 2) * (2 * b1_1) +
            std::pow(std::sin(theta), 2) * (b0_2 - b1_2 / 2));
        double w3 = (std::pow(std::cos(theta), 2) * (b2_1 - b1_1 / 2) +
            std::pow(std::sin(theta), 2) * (2 * b1_2));
        double w4 = (std::pow(std::sin(theta), 2) * (b2_2 - b1_2 / 2));


        insert_ctrl_pt = w1 * ctrl_pts[overlap_pts.front().first][vec_i_quotient - 1]
            + w2 * ctrl_pts[overlap_pts.front().first][vec_i_quotient]
            + w3 * ctrl_pts[overlap_pts.front().first][vec_i_quotient + 1]
            + w4 * ctrl_pts[overlap_pts.front().first][vec_i_quotient + 2];
    }

    ctrl_pts[overlap_pts.front().first].insert(ctrl_pts[overlap_pts.front().first].begin() +
        vec_i_quotient + 1, insert_ctrl_pt);

    for (int i = 0; i < overlap_pts_idx.size(); ++i)
    {
        if (overlap_pts_idx[i].front().first == overlap_pts.front().first &&
            overlap_pts_idx[i].front().second > vec_i_quotient)
        {
            overlap_pts_idx[i].front().second++;
        }
        if (overlap_pts_idx[i].back().first == overlap_pts.front().first &&
            overlap_pts_idx[i].back().second > vec_i_quotient)
        {
            overlap_pts_idx[i].back().second++;
        }
    }
    overlap_pts_idx.push_back(std::vector<std::pair<int, int>>());
    overlap_pts_idx.back().push_back(std::pair<int, int>(ctrl_pts.size() - 1, (overlap_pts.back().second==0)?0: ctrl_pts.back().size() - 1));
    overlap_pts_idx.back().push_back(std::pair<int, int>(overlap_pts.front().first, vec_i_quotient + 1));

    overlap_pts_vec.clear();

    for (int i = 0; i < overlap_pts_idx.size(); ++i)
    {
        int curve_idx_1 = overlap_pts_idx[i].front().first;
        int curve_ctrl_pt_idx_1 = overlap_pts_idx[i].front().second;

        int curve_idx_2 = overlap_pts_idx[i].back().first;
        int curve_ctrl_pt_idx_2 = overlap_pts_idx[i].back().second;

        int long_vec_idx = 0;
        for (int k = 0; k < curve_idx_1; ++k)
        {
            long_vec_idx += ctrl_pts[k].size();
        }

        overlap_pts_vec.push_back(std::vector<std::pair<int, double>>());
        overlap_pts_vec.back().push_back(std::pair<int, double>(long_vec_idx + curve_ctrl_pt_idx_1, 1));

        long_vec_idx = 0;
        for (int k = 0; k < curve_idx_2; ++k)
        {
            long_vec_idx += ctrl_pts[k].size();
        }

        overlap_pts_vec.back().push_back(std::pair<int, double>(long_vec_idx + curve_ctrl_pt_idx_2, 1));
    }




    std::vector<Eigen::Vector3d>vec_ctrl_pts;
    for (int i = 0; i < ctrl_pts.size(); ++i)
    {
        for (int j = 0; j < ctrl_pts[i].size(); ++j)
        {
            vec_ctrl_pts.push_back(ctrl_pts[i][j]);
        }
    }

    for (int i = 0; i < overlap_pts_vec.size(); ++i)
    {
        int idx1 = overlap_pts_vec[i].front().first;
        //double move_to_x = 0, move_to_y = 0, move_to_z = 0;
        Eigen::Vector3d move_to = Eigen::Vector3d::Zero();
        for (int j = 1; j < overlap_pts_vec[i].size(); ++j)
        {
            int idx2 = overlap_pts_vec[i][j].first;
            double w = overlap_pts_vec[i][j].second;
            move_to += w * vec_ctrl_pts[idx2];
        }
        vec_ctrl_pts[idx1] = move_to;
    }
    int col_idx = 0;
    for (int i = 0; i < ctrl_pts.size(); ++i)
    {
        for (int j = 0; j < ctrl_pts[i].size(); ++j)
        {
            ctrl_pts[i][j] = vec_ctrl_pts[col_idx];
            col_idx++;
        }
    }

    //this->setA_x(feature_, std::vector<int>());
    pipes = std::vector<Utils::Pipe>(ctrl_pts.size());
    form_curve(false);
    form_curve(true);
}

void Curve::appendCurve(Curve& rhs, Feature* feature_)
{   
    ctrl_pts.push_back(rhs.ctrl_pts.back());
    //this->setA_x(feature_, std::vector<int>());
    pipes = std::vector<Utils::Pipe>(ctrl_pts.size());
    form_curve(false);
    form_curve(true);
}

/*
void Curve::modify(Feature* feature_,int ctrl_pt_i, int ctrl_pt_j, Eigen::Vector3d move_pt)
{
    ctrl_pts[ctrl_pt_i][ctrl_pt_j] = move_pt;
    setA_x(feature_);
    form_curve(false);
    generateCylinder();
}
*/
void Curve::piecewisePlanerazation(double weight)
{   
    std::vector<std::vector<std::vector<Eigen::Vector3d>>>forming_candidates_current;
    for (int i = 0; i < curve.size(); ++i)
    {   
        forming_candidates_current.push_back(std::vector<std::vector<Eigen::Vector3d>>());
        for (int j = 1; j < curve[i].size(); ++j)
        {   
            forming_candidates_current.back().push_back(std::vector<Eigen::Vector3d>());
            forming_candidates_current.back().back().push_back(curve[i][j - 1]);
            forming_candidates_current.back().back().push_back(curve[i][j]);
        }
    }
    int origin_curve_segment_num = 0;
    for (int i = 0; i < forming_candidates_current.size(); ++i)
    {
        std::cout << "size beform merge:" << forming_candidates_current[i].size() << std::endl;
        origin_curve_segment_num += forming_candidates_current[i].size();
    }
    std::vector<std::vector<std::vector<Eigen::Vector3d>>>forming_candidates_best;
    double current_mark = compute_planes_mark(forming_candidates_current, origin_curve_segment_num,weight);
    double best_mark = current_mark;
    double Temp = 100000;

    double pre_score_4_segment = 1;
    int reduced_count = 0;
    for (double T = Temp; T > 0.01; T *= 0.5) 
    {   
        std::cout << "mark:"<<current_mark << std::endl;
        for (int i = 0; i < forming_candidates_current.size(); ++i)
        {
            std::cout << "size beform merge:" << forming_candidates_current[i].size() << std::endl;
        }
        for (int i = 0; i < 1000; i++) 
        {   
            int candidates_sum = 0;
            for (int k1 = 0; k1 < forming_candidates_current.size(); ++k1)
            {   
                candidates_sum += forming_candidates_current[k1].size();
            }
            int random_candidate = static_cast<int>(rand_uniform(0, candidates_sum));
            while (random_candidate == candidates_sum)
            {
                random_candidate = static_cast<int>(rand_uniform(0, candidates_sum));
            }
            int random_candidate_i, random_candidate_j;
            for (int k1 = 0; k1 < forming_candidates_current.size(); ++k1)
            {   
                if (random_candidate >= forming_candidates_current[k1].size())
                {
                    random_candidate -= forming_candidates_current[k1].size();
                }
                else
                {   
                    random_candidate_i = k1;
                    random_candidate_j = random_candidate;
                    break;
                }
            }
            //nibble or Swallow
            bool is_swallow = rand_uniform(0, 1) > 0.9;

            {   
                std::vector<std::vector<std::vector<Eigen::Vector3d>>>forming_candidates_copy= forming_candidates_current;
                if (forming_candidates_copy[random_candidate_i].size() == 1)
                {   
                    //reduced_count = 0;
                    continue;
                }
                else if (random_candidate_j == 0)
                {   
                    if (is_swallow)
                    {
                        forming_candidates_copy[random_candidate_i][random_candidate_j].insert(
                            forming_candidates_copy[random_candidate_i][random_candidate_j].end(), 
                            forming_candidates_copy[random_candidate_i][random_candidate_j + 1].begin()+1,
                            forming_candidates_copy[random_candidate_i][random_candidate_j + 1].end());
                        //reduced_count = forming_candidates_copy[random_candidate_i][random_candidate_j + 1].size();
                        forming_candidates_copy[random_candidate_i].erase(forming_candidates_copy[random_candidate_i].begin() + random_candidate_j + 1);
                    }
                    else
                    {
                        forming_candidates_copy[random_candidate_i][random_candidate_j].push_back(
                            forming_candidates_copy[random_candidate_i][random_candidate_j + 1][1]);
                        if (forming_candidates_copy[random_candidate_i][random_candidate_j + 1].size() == 2)
                        {
                            forming_candidates_copy[random_candidate_i].erase(forming_candidates_copy[random_candidate_i].begin() + random_candidate_j + 1);
                            //reduced_count = 1;
                        }
                        else
                        {
                            forming_candidates_copy[random_candidate_i][random_candidate_j + 1].erase(forming_candidates_copy[random_candidate_i][random_candidate_j + 1].begin());
                            //reduced_count = 0;
                        }
                    }
                }
                else if (random_candidate_j == forming_candidates_copy[random_candidate_i].size()-1)
                {   
                    if (is_swallow)
                    {
                        forming_candidates_copy[random_candidate_i][random_candidate_j].insert(
                            forming_candidates_copy[random_candidate_i][random_candidate_j].begin(),
                            forming_candidates_copy[random_candidate_i][random_candidate_j - 1].begin(),
                            forming_candidates_copy[random_candidate_i][random_candidate_j - 1].end() - 1);
                        //reduced_count = forming_candidates_copy[random_candidate_i][random_candidate_j - 1].size();
                        forming_candidates_copy[random_candidate_i].erase(forming_candidates_copy[random_candidate_i].begin() + random_candidate_j - 1);
                    }
                    else
                    {
                        forming_candidates_copy[random_candidate_i][random_candidate_j].insert(
                            forming_candidates_copy[random_candidate_i][random_candidate_j].begin(),
                            *(forming_candidates_copy[random_candidate_i][random_candidate_j - 1].end() - 2));
                        if (forming_candidates_copy[random_candidate_i][random_candidate_j - 1].size() == 2)
                        {
                            forming_candidates_copy[random_candidate_i].erase(forming_candidates_copy[random_candidate_i].begin() + random_candidate_j - 1);
                            //reduced_count = 1;
                        }
                        else
                        {
                            forming_candidates_copy[random_candidate_i][random_candidate_j - 1].erase(forming_candidates_copy[random_candidate_i][random_candidate_j - 1].end() - 1);
                            //reduced_count = 0;
                        }
                    }
                }
                else
                {
                    if (rand_uniform(0, 1) > 0.5)
                    {
                        if (is_swallow)
                        {
                            forming_candidates_copy[random_candidate_i][random_candidate_j].insert(
                                forming_candidates_copy[random_candidate_i][random_candidate_j].end(),
                                forming_candidates_copy[random_candidate_i][random_candidate_j + 1].begin() + 1,
                                forming_candidates_copy[random_candidate_i][random_candidate_j + 1].end());
                            //reduced_count = forming_candidates_copy[random_candidate_i][random_candidate_j + 1].size();
                            forming_candidates_copy[random_candidate_i].erase(forming_candidates_copy[random_candidate_i].begin() + random_candidate_j + 1);
                        }
                        else
                        {
                            forming_candidates_copy[random_candidate_i][random_candidate_j].push_back(
                                forming_candidates_copy[random_candidate_i][random_candidate_j + 1][1]);
                            if (forming_candidates_copy[random_candidate_i][random_candidate_j + 1].size() == 2)
                            {
                                forming_candidates_copy[random_candidate_i].erase(forming_candidates_copy[random_candidate_i].begin() + random_candidate_j + 1);
                                //reduced_count = 1;
                            }
                            else
                            {
                                forming_candidates_copy[random_candidate_i][random_candidate_j + 1].erase(forming_candidates_copy[random_candidate_i][random_candidate_j + 1].begin());
                                //reduced_count = 0;
                            }
                        }
                    }
                    else
                    {
                        if (is_swallow)
                        {
                            forming_candidates_copy[random_candidate_i][random_candidate_j].insert(
                                forming_candidates_copy[random_candidate_i][random_candidate_j].begin(),
                                forming_candidates_copy[random_candidate_i][random_candidate_j - 1].begin(),
                                forming_candidates_copy[random_candidate_i][random_candidate_j - 1].end() - 1);
                            //reduced_count = forming_candidates_copy[random_candidate_i][random_candidate_j - 1].size();
                            forming_candidates_copy[random_candidate_i].erase(forming_candidates_copy[random_candidate_i].begin() + random_candidate_j - 1);
                        }
                        else
                        {
                            forming_candidates_copy[random_candidate_i][random_candidate_j].insert(
                                forming_candidates_copy[random_candidate_i][random_candidate_j].begin(),
                                *(forming_candidates_copy[random_candidate_i][random_candidate_j - 1].end() - 2));
                            if (forming_candidates_copy[random_candidate_i][random_candidate_j - 1].size() == 2)
                            {
                                forming_candidates_copy[random_candidate_i].erase(forming_candidates_copy[random_candidate_i].begin() + random_candidate_j - 1);
                                //reduced_count = 1;
                            }
                            else
                            {
                                forming_candidates_copy[random_candidate_i][random_candidate_j - 1].erase(forming_candidates_copy[random_candidate_i][random_candidate_j - 1].end() - 1);
                                //reduced_count = 0;
                            }
                        }
                    }
                }
                double pre_score_4_segment_copy = pre_score_4_segment;
                double copy_mark = compute_planes_mark(forming_candidates_copy, origin_curve_segment_num, weight);
                double deltaE = current_mark - copy_mark;
                deltaE /= 0.01;
                double p =exp(deltaE);
                double expP = rand_uniform(0, 1);
                if (expP < p)
                { // move
                    forming_candidates_current = forming_candidates_copy;
                    current_mark = copy_mark;
                    //std::cout << current_mark << std::endl;
                    if (copy_mark < best_mark)
                    {
                        best_mark = copy_mark;
                        forming_candidates_best = forming_candidates_copy;
                    }
                }
            }
        }
    }
    for (int i = 0; i < forming_candidates_best.size(); ++i)
    {
        std::cout << "size after merge:" << forming_candidates_best[i].size() << std::endl;
        for (int j = 0; j < forming_candidates_best[i].size(); ++j)
        {
            std::cout << forming_candidates_best[i][j].size() << std::endl;
        }
    }
    planer_curve = forming_candidates_best;

    for (int i = 0; i < planer_curve.size(); ++i)
    {
        for (int j = 0; j < planer_curve[i].size(); ++j)
        {
            //get the most propriate point
            auto plane_param = bestPlaneFromPoints(planer_curve[i][j]);
            //
            plane_param.first = (planer_curve[i][j].front() + planer_curve[i][j].back()) / 2;
            auto vec=(planer_curve[i][j].front() - planer_curve[i][j].back()).normalized();
            auto perpendicular_vec=vec.cross(plane_param.second);
            plane_param.second = perpendicular_vec.cross(vec);

            for (int k = 0; k < planer_curve[i][j].size(); ++k)
            {
                planer_curve[i][j][k] = planer_curve[i][j][k] -
                    (planer_curve[i][j][k] - plane_param.first).dot(plane_param.second) * plane_param.second;
            }
        }
    }
}

void Curve::bindParts(int idx_curve, std::vector<std::pair<int, int>>seg1_curve_parts, std::vector<std::pair<int, int>>seg2_curve_parts)
{   
    //maybe curve order needed to be caution.
    auto vec_ctrl_pts = this->ctrl_pts[idx_curve];
    auto center_pt = (vec_ctrl_pts[seg1_curve_parts.front().first] + vec_ctrl_pts[seg1_curve_parts.back().second] +
        vec_ctrl_pts[seg2_curve_parts.front().first] + vec_ctrl_pts[seg2_curve_parts.front().first]) / 4;

    int middle_start = std::min(seg1_curve_parts.back().second, seg2_curve_parts.back().second);
    int middle_end = std::max(seg1_curve_parts.front().second, seg2_curve_parts.front().second);
    for (int i = middle_start; i <= middle_end; ++i)
    {
        vec_ctrl_pts[i] = center_pt;
    }
    vec_ctrl_pts[seg1_curve_parts.front().second] = vec_ctrl_pts[seg1_curve_parts.front().first];
    vec_ctrl_pts[seg1_curve_parts.back().first] = vec_ctrl_pts[seg1_curve_parts.back().second];
    vec_ctrl_pts[seg2_curve_parts.front().second] = vec_ctrl_pts[seg2_curve_parts.front().first];
    vec_ctrl_pts[seg2_curve_parts.back().first] = vec_ctrl_pts[seg2_curve_parts.back().second];

    vec_ctrl_pts[seg1_curve_parts.front().first] = center_pt;
    vec_ctrl_pts[seg1_curve_parts.back().second] = center_pt;
    vec_ctrl_pts[seg2_curve_parts.front().first] = center_pt;
    vec_ctrl_pts[seg2_curve_parts.back().second] = center_pt;
    this->ctrl_pts[idx_curve];
    //over lap_pts
    form_curve(false);
}

void Curve::outputObj(std::string filename)
{   
    if (this->curve.size() == 1)
    {   
        std::ofstream of(filename, std::ofstream::out);
        if (of.fail()) {
            std::cout << "open file error!\n";
            return;
        }
        std::vector<Eigen::Vector3d>vt;
        for (int i = 0; i < this->curve.front().size(); ++i)
        {
            vt.push_back(this->curve.front()[i]);
        }
        for (auto v : vt)
        {
            of << "v " << v.x() << " " << v.y() << " " << v.z() << std::endl;
        }
        of << "g " << "curve" << std::endl;
        of << "l";
        //for (auto idx : vIndices)
        for (int idx = 0; idx < vt.size(); ++idx)
        {
            of << " " << idx + 1;
        }
        of << std::endl;
        of.close();
    }
    else
    {
        for (int iter = 0; iter < this->curve.size(); ++iter)
        {
            std::string filename_ = filename + std::to_string(iter) + ".obj";

            std::ofstream of(filename_, std::ofstream::out);
            if (of.fail()) {
                std::cout << "open file error!\n";
                return;
            }
            std::vector<Eigen::Vector3d>vt;
            for (int i = 0; i < this->curve[iter].size(); ++i)
            {
                vt.push_back(this->curve[iter][i]);
            }
            for (auto v : vt)
            {
                of << "v " << v.x() << " " << v.y() << " " << v.z() << std::endl;
            }
            of << "g " << "curve" << std::endl;
            of << "l";
            //for (auto idx : vIndices)
            for (int idx = 0; idx < vt.size(); ++idx)
            {
                of << " " << idx + 1;
            }
            of << std::endl;
            of.close();


        }
    }
}