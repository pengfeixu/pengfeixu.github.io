#pragma once
#include <vector>
#include <Eigen/Core>
#include <Eigen/Geometry>
#include "polygon.h"
#include "c2spline.h"
#include "feature.h"
#include "helper_algo.h"
#include "curvecylinder.h"
#include <QGLViewer/qglviewer.h>
class Curve
{
public:
	std::vector<std::vector<Eigen::Vector3d>>ctrl_pts;
	std::vector<std::vector<Eigen::Vector3d>>curve;
	std::vector<std::vector<std::vector<Eigen::Vector3d>>>beizer_interpolation;
	std::vector<std::vector<std::vector<double>>>beizer_interpolation_arclen;
	std::vector<Eigen::MatrixXd> vec_A_x;
	std::vector<Eigen::MatrixXd> vec_A_x_copy;
	std::vector<Eigen::VectorXd> vec_b_x, vec_b_y, vec_b_z;
	//std::vector<std::vector<Eigen::Vector3d>>cylinder_pts;
	std::vector<Utils::Pipe>pipes;
	std::vector<std::vector<std::pair<int,double>>>overlap_pts_vec;
	std::vector<std::vector<std::pair<int, int>>>overlap_pts_idx;

	std::vector<std::vector<std::vector<Eigen::Vector3d>>> planer_curve;
	void setA_x(Feature* feature_, std::vector<int>& nn_curve_idx);
	void setA_x(Feature* feature_, int j, std::vector<int>& nn_curve_idx);
	void form_curve(bool is_compute_arclen);
	void form_curve(int j, bool is_compute_arclen);
	void solve(Feature* feature_, std::vector<int>&nn_curve_idx, bool soft_drag);
	void solve(Feature* feature_, int j, std::vector<int>& nn_curve_idx);
	void generateCylinder();
	void generateCylinder(int i);
	void transformFirstContour(std::vector<Eigen::Vector3d>& path, std::vector<std::vector<Eigen::Vector3d>>& contour);

	void draw(bool draw_path, bool draw_cylinder, bool draw_ctrl_pt, int ctrl_pt_i, int ctrl_pt_j, QColor curve_Color = QColor(0, 0, 0));
	int segment_iter_times;
	double error_magitude;
	double avg_edge_len;
	int ndivs;
	Curve(std::vector<std::vector<int>>& paths,
		std::vector<int>& selectPointsIndex,
		Enriched_polyhedron<Kernel, Enriched_items>& mesh_poly_,
		int segment_iter_times_, double error_magitude_,
		double avg_edge_len_, Feature* feature_,bool interpolate,double min_radix_curvatur);
	Curve(std::vector<Eigen::Vector3d>&paths,int segment_iter_times,double error_magitude_,double avg_edge_len_ ,Feature* feature_, double min_radix_curvatur);
	Curve(std::vector<std::vector<Eigen::Vector3d >> & vec_ctrl_pts, std::vector<std::vector<std::pair<int, double>>>& overlap_pts_vec,
		int segment_iter_times,double error_magitude_);
	Curve() {};
	void outputObj(std::string filename);
	void modify(Feature* feature_, int ctrl_pt_i, int ctrl_pt_j, Eigen::Vector3d move_pt);
	void addCurve(Curve& rhs);
	void addCurve(Curve& mhs, Curve& rhs, std::vector<std::pair<int, int>>overlap_pts, Feature* feature_);
	void addCurve(Curve& mhs, Curve& rhs, kLineLink link);
	void addCurve(Curve& rhs, std::vector<std::vector<int>>& smooth_project_idx, std::vector<std::pair<int, int>>overlap_pts, Feature* feature_);
	void addCurve(Curve& rhs, bool insert_end, Feature* feature_);
	void addCurve(Curve& rhs, std::vector<std::pair<int, int>>overlap_pts, Feature* feature_);
	void addCurve(Curve& rhs, bool insert_end, int insert_idx, Feature* feature_);
	void appendCurve(Curve& rhs, std::pair<int, int>overlap_pts);
	void modifyCurve(Curve& rhs, std::vector<int>&curve_modify_part, Feature* feature_);
	void modifyCurve(std::vector<int>& curve_modify_part, Feature* feature_);
	void appendCurve(Curve& rhs, Feature* feature_);
	void attachCurve(Curve& rhs, std::vector<int>& curve_modify_part, Feature* feature_);
	void attachNNCurve(Curve& rhs, std::vector<std::pair<int, int>>&overlap_pts,Feature* feature_);
	void bindParts(int idx_curve, std::vector<std::pair<int, int>>seg1_curve_parts, std::vector<std::pair<int, int>>seg2_curve_parts);

	void piecewisePlanerazation(double weight);
	double compute_planes_mark(std::vector<std::vector<std::vector<Eigen::Vector3d>>>& forming_candidates,int origin_curve_segment_num,double weight )
	{	
		int cur_curve_segment_num = 0;
		double accumulated_error=0;
		const double tor = this->avg_edge_len;
		double acuumulated_segment_score = 0;
		for (int i = 0; i < forming_candidates.size(); ++i)
		{
			cur_curve_segment_num += forming_candidates[i].size();
			for (int j = 0; j < forming_candidates[i].size(); ++j)
			{
				if (forming_candidates[i][j].size()==2)
				{	
					accumulated_error += tor/(std::log(2));
					//accumulated_error += 0.5 * std::log2(tor / tor + 1);
					acuumulated_segment_score += std::log2(2)/(origin_curve_segment_num* std::log2(2));
					continue;//1/2 for front and 1/2 for back respectively
					//accumulated_error += 1;
				}
				auto plane_param = bestPlaneFromPoints(forming_candidates[i][j]);
				for (int k = 1; k < forming_candidates[i][j].size() - 1; ++k)
				{
					accumulated_error += (std::exp(std::abs(plane_param.second.dot(forming_candidates[i][j][k] - plane_param.first)) / tor) - 1) / (std::log2(forming_candidates[i][j].size()));
					//accumulated_error += std::log2(std::abs(plane_param.second.dot(forming_candidates[i][j][k] - plane_param.first)) / tor + 1);
					//accumulated_error += std::abs(plane_param.second.dot(forming_candidates[i][j][k] - plane_param.first))/(std::log2(forming_candidates[i][j].size()));
				}
				accumulated_error += (0.5 * std::exp(std::abs(plane_param.second.dot(forming_candidates[i][j].front() - plane_param.first)) / tor) - 1) / (std::log2(forming_candidates[i][j].size()));
				accumulated_error += (0.5 * std::exp(std::abs(plane_param.second.dot(forming_candidates[i][j].back() - plane_param.first)) / tor) - 1) / (std::log2(forming_candidates[i][j].size()));
				//accumulated_error += 0.5*std::abs(plane_param.second.dot(forming_candidates[i][j].front() - plane_param.first)) / (std::log2(forming_candidates[i][j].size()));
				//accumulated_error += 0.5 * std::abs(plane_param.second.dot(forming_candidates[i][j].back() - plane_param.first)) / (std::log2(forming_candidates[i][j].size()));
				acuumulated_segment_score += std::log2(forming_candidates[i][j].size()) / (origin_curve_segment_num * std::log2(2));
			}
		}
		//return acuumulated_segment_score + accumulated_error / (origin_curve_segment_num * tor);
		return acuumulated_segment_score + weight*accumulated_error / (origin_curve_segment_num);
	}
	std::pair<Eigen::Vector3d,Eigen::Vector3d>bestPlaneFromPoints(const std::vector<Eigen::Vector3d>& c)
	{
		// copy coordinates to  matrix in Eigen format
		size_t num_atoms = c.size();
		Eigen::Matrix<Eigen::Vector3d::Scalar, Eigen::Dynamic, Eigen::Dynamic > coord(3, num_atoms);
		for (size_t i = 0; i < num_atoms; ++i) coord.col(i) = c[i];

		// calculate centroid
		Eigen::Vector3d centroid(coord.row(0).mean(), coord.row(1).mean(), coord.row(2).mean());

		// subtract centroid
		coord.row(0).array() -= centroid(0); coord.row(1).array() -= centroid(1); coord.row(2).array() -= centroid(2);

		auto svd = coord.jacobiSvd(Eigen::ComputeThinU | Eigen::ComputeThinV);
		Eigen::Vector3d plane_normal = svd.matrixU().rightCols<1>();
		return std::make_pair(centroid, plane_normal.normalized());
	}
};