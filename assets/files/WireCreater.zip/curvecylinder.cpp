#include <Eigen/Dense>
#include <iostream>
#include "curvecylinder.h"

namespace Utils {
	std::vector<trimesh::vec> buildSpiralPath(float r1, float r2, float h1, float h2, float turns, int points) {
		using trimesh::vec;
		const float PI = acos(-1);
		std::vector<vec> vertices;
		vec vertex;
		float r = r1;
		float rStep = (r2 - r1) / (points - 1);
		float y = h1;
		float yStep = (h2 - h1) / (points - 1);
		float a = 0;
		float aStep = (turns * 2 * PI) / (points - 1);
		for (int i = 0; i < points; ++i) {
			vertex[0] = r * cos(a);
			vertex[1] = y;
			vertex[2] = r * sin(a);
			vertices.push_back(vertex * 0.1);

			r += rStep;
			y += yStep;
			a += aStep;
		}
		return vertices;
	};

	std::vector<trimesh::vec> buildCircle(float radius, int steps) {
		using trimesh::vec;
		std::vector<vec> points;
		if (steps < 2) return std::vector<vec>();
		const float PI2 = acos(-1) * 2.0f;
		float x, y, a;
		for (int i = 0; i <= steps; ++i) {
			a = PI2 / steps * i;
			x = radius * cosf(a);
			y = radius * sinf(a);
			points.push_back(vec(x, y, 0));
		}
		return points;
	}

	Pipe::Pipe() {}

	Pipe::Pipe(const std::vector<trimesh::vec>& pathPoints, const std::vector<trimesh::vec>& contourPoints) :path(pathPoints), contour(contourPoints) {
		//for (int i = 0; i < contourPoints.size(); ++i)

		std::vector<std::vector<trimesh::vec>>().swap(contours);
		std::vector<std::vector<trimesh::vec>>().swap(normals);

		transformFirstContour();

		auto computeContourNormal = [&](int pathIndex)->std::vector<trimesh::vec> {
			auto& contour = contours[pathIndex];
			auto center = path[pathIndex];

			std::vector<trimesh::vec> contourNormal;
			trimesh::vec normal;
			for (int i = 0; i < (int)contour.size(); ++i) {
				normal = trimesh::normalized(contour[i] - center);
				contourNormal.push_back(normal);
			}
			return contourNormal;
		};

		auto projectContour = [&](int fromIndex, int toIndex)->std::vector<trimesh::vec> {
			using trimesh::vec;
			vec dir1, dir2, normal;
			Line line;

			dir1 = path[toIndex] - path[fromIndex];
			if (toIndex == (int)path.size() - 1)
				dir2 = dir1;
			else
				dir2 = path[toIndex + 1] - path[toIndex];
			normal = dir1 + dir2;
			Plane plane(normal, path[toIndex]);

			std::vector<vec>& fromContour = contours[fromIndex];
			std::vector<vec> toContour;
			int count = (int)fromContour.size();
			for (int i = 0; i < count; ++i) {
				line.set(dir1, fromContour[i]);
				toContour.push_back(plane.intersect(line));
			}
			return toContour;
		};

		contours.push_back(this->contour);
		normals.push_back(computeContourNormal(0));

		int count = (int)path.size();
		for (int i = 1; i < count; ++i) {
			contours.push_back(projectContour(i - 1, i));
			normals.push_back(computeContourNormal(i));
		}
	}

	void Pipe::transformFirstContour() {
		using Eigen::Vector3f;
		using Eigen::Affine3f;
		using Eigen::Matrix4f;
		int pathCount = (int)path.size();
		int vertexCount = (int)contour.size();

		Affine3f matrix = Affine3f::Identity();

		auto lookAt = [&](Vector3f target) {
			Vector3f forward = target;
			forward.normalize();
			Vector3f up, left;
			if (fabs(forward(0)) < std::numeric_limits<float>::epsilon() && fabs(forward(2)) < std::numeric_limits<float>::epsilon()) {
				if (forward(1) > 0) up << 0.f, 0.f, -1.f;
				else up << 0.f, 0.f, 1.f;
			}
			else {
				up << 0.f, 1.f, 0.f;
			}

			left = up.cross(forward);
			left.normalize();

			up = forward.cross(left);

			Matrix4f& m = matrix.matrix();
			m.col(0) << left, 0;
			m.col(1) << up, 0;
			m.col(2) << forward, 0;
		};
		auto target = path[1] - path[0];
		matrix.translate(Vector3f(path[0][0], path[0][1], path[0][2]));
		lookAt(Vector3f(target[0], target[1], target[2]));
		//matrix.translate(Vector3f(path[0][0], path[0][1], path[0][2]));

		for (int i = 0; i < vertexCount; ++i) {
			Vector3f p;
			p << contour[i][0], contour[i][1], contour[i][2];
			auto tmp = matrix * p;
			contour[i] = trimesh::vec(tmp(0), tmp(1), tmp(2));
		}
	}


	void Pipe::outputObj(std::string file) {
		std::ofstream of(file, std::ofstream::out);
		if (of.fail()) {
			std::cout << "open file error!\n";
			return;
		}

		int count = getContourCount();
		std::vector<int> vIndices;
		std::vector<trimesh::vec> vertices;
		std::vector<trimesh::vec> normals;
		for (int i = 0; i < count; ++i) {
			auto& c1 = getContour(i);
			auto& n1 = getNormal(i);
			for (int j = 0; j < c1.size(); ++j) {
				vertices.push_back(c1[j]);
				normals.push_back(n1[j]);
			}
		}
		int contourSize = getContour(0).size();
		/*
		for (int i = 0; i < count - 1; ++i) {
			for (int j = 0; j < contourSize - 1; ++j) {
				vIndices.push_back((i + 1) * contourSize + j);
				vIndices.push_back(i * contourSize + j + 1);
				vIndices.push_back((i + 1) * contourSize + j + 1);

				vIndices.push_back((i + 1) * contourSize + j);
				vIndices.push_back(i * contourSize + j);
				vIndices.push_back(i * contourSize + j + 1);
			}
		}
		*/
		for (int i = 0; i < count; ++i)
		{
			vIndices.push_back(i * contourSize);
		}
		for (auto v : vIndices)
		{
			of << "v " << vertices[v][0] << " " << vertices[v][1] << " " << vertices[v][2] << std::endl;
		}
		/*
		for (auto& v : vertices) {
			of << "v " << v[0] << " " << v[1] << " " << v[2] << "\n";
		}
		*/
		/*
		for (auto& n : normals) {
			of << "vn " << n[0] << " " << n[1] << " " << n[2] << "\n";
		}
		*/
		/*
		count = 0;
		for (auto& idx : vIndices) {
			if (count == 0) of << "f";
			of << " " << idx + 1 << "//" << idx + 1;
			if (count == 2) {
				of << "\n";
				count = 0;
			}
			else count++;
		}
		*/
		//of << "g " << "curve" << std::endl;
		of << "l";
		//for (auto idx : vIndices)
		for(int idx=0;idx< vIndices.size();++idx)
		{
			of << " "<<idx+1;
		}
		of << std::endl;
		of.close();
	}


	void Line::set(const trimesh::vec& v, const trimesh::vec& p) {
		this->dir = v;
		this->point = p;
	}

	Plane::Plane() {}

	Plane::Plane(trimesh::vec& normal, trimesh::vec& point) {
		this->normal = normal;
		normalLength = trimesh::length(normal);
		d = -normal.dot(point); // -(a*x0+b*y0+c*z0)
		distance = -d / normalLength;
	}

	trimesh::vec Plane::intersect(const Line& line) const {
		using trimesh::vec;

		vec p = line.getPoint();
		vec v = line.getDirection();

		float dot1 = normal.dot(p);
		float dot2 = normal.dot(v);

		if (dot2 == 0)
			return trimesh::vec(0, 0, 0);

		float t = -(dot1 + d) / dot2;

		return p + (v * t);
	}
}