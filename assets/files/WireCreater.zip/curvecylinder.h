#pragma once

#include <TriMesh.h>
#include <vector>

namespace Utils {
    std::vector<trimesh::vec> buildSpiralPath(float r1, float r2, float h1, float h2, float turns, int points);

    std::vector<trimesh::vec> buildCircle(float radius, int steps);

    class Pipe {
    public:
        Pipe();
        Pipe(const std::vector<trimesh::vec>& pathPoints, const std::vector<trimesh::vec>& contourPoints);
        void transformFirstContour();
        int getContourCount() const { return (int)contours.size(); }
        const std::vector<trimesh::vec>& getContour(int index) const { return contours.at(index); }
        const std::vector<trimesh::vec>& getNormal(int index) const { return normals.at(index); }
        void outputObj(std::string file);
        std::vector< std::vector<trimesh::vec>> contours;
    private:
        std::vector<trimesh::vec> path;
        std::vector<trimesh::vec> contour;
        //std::vector< std::vector<trimesh::vec>> contours;
        std::vector< std::vector<trimesh::vec>> normals;
    };

    class Line {
    public:
        Line() : dir(0., 0., 0.), point(0., 0., 0.) {}

        void set(const trimesh::vec&, const trimesh::vec&);
        const trimesh::vec& getPoint() const { return point; }
        const trimesh::vec& getDirection() const { return dir; }
    private:
        trimesh::vec dir;
        trimesh::vec point;
    };

    class Plane {
    public:
        Plane();
        Plane(trimesh::vec&, trimesh::vec&);

        trimesh::vec intersect(const Line& line) const;
    private:
        trimesh::vec normal;
        float d;
        float normalLength;
        float distance;
    };
}