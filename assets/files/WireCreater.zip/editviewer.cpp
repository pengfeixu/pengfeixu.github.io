#include "editviewer.h"

using namespace std;

EditViewer::EditViewer(QWidget* parent = 0):QGLViewer(parent)
{

}

// Draws a spiral
void EditViewer::draw() {
    //setDrawFeatureOption();
    glClearColor(backgroundColor().redF(), backgroundColor().greenF(), backgroundColor().blueF(), 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);
    drawMesh();
    drawSegment();
    drawFeature();
    drawPaths();
    //drawFields();
}

void EditViewer::init() 
{
    mesh_poly_ = NULL;
    seg = NULL;
    feature_ = NULL;
    path_res = NULL;
    select_ctrl_pt_vec = NULL;
    face_color = QColor(164, 164, 164);
    line_color = QColor(67, 255, 163);
    vertex_color = QColor(255, 0, 255);
    this->setBackgroundColor(QColor(255, 255, 255));
    is_drag = false;
    res_got = false;
    glDisable(GL_LIGHTING);

    user_study_start_pt_idx_i = -1;
    user_study_start_pt_idx_j = -1;
    user_study_end_pt_idx_i = -1;
    user_study_end_pt_idx_j = -1;

    bind_face1 = -1;
    bind_face2 = -2;
}

void EditViewer::drawMesh()
{
    if (mesh_poly_ == NULL)
    {
        return;
    }
    if (draw_face)
    {   
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glColor3ub(face_color.red(), face_color.green(), face_color.blue());
        glShadeModel(GL_SMOOTH);
        glEnable(GL_LIGHTING);
        glEnable(GL_AUTO_NORMAL);
        const qglviewer::Vec cameraPos = camera()->position();
        const GLfloat pos[4] = { (float)cameraPos[0], (float)cameraPos[1],
                                (float)cameraPos[2], 1.0f };
        glLightfv(GL_LIGHT1, GL_POSITION, pos);

        glLightfv(GL_LIGHT1, GL_SPOT_DIRECTION, camera()->viewDirection());


        glEnable(GL_POLYGON_OFFSET_FILL);
        glPolygonOffset(1, 1);
        glColor4f(face_color.redF(), face_color.greenF(), face_color.blueF(),draw_face_alpha);
        glDepthMask(false);
        glBegin(GL_TRIANGLES);
        for (unsigned int i = 0; i < feature_->themesh->faces.size(); i++)
        {   
            if (i == bind_face1 || i == bind_face2)
            {
                continue;
            }
            trimesh::TriMesh::Face* thisFace;
            thisFace = &(feature_->themesh->faces[i]);

            trimesh::vec& n0 = feature_->themesh->normals[(*thisFace)[0]];
            trimesh::vec& v0 = feature_->themesh->vertices[(*thisFace)[0]];
            if (draw_field&&res_got)
            {
                int v_i = (*thisFace)[0];
                glColor4f(field_color[v_i].x(), field_color[v_i].y(), field_color[v_i].z(), draw_face_alpha);
            }
            glNormal3d(n0[0], n0[1], n0[2]);
            glVertex3f(v0[0], v0[1], v0[2]);

            trimesh::vec& n1 = feature_->themesh->normals[(*thisFace)[1]];
            trimesh::vec& v1 = feature_->themesh->vertices[(*thisFace)[1]];
            if (draw_field&&res_got)
            {
                int v_i = (*thisFace)[1];
                glColor4f(field_color[v_i].x(), field_color[v_i].y(), field_color[v_i].z(), draw_face_alpha);
            }
            glNormal3d(n1[0], n1[1], n1[2]);
            glVertex3f(v1[0], v1[1], v1[2]);

            trimesh::vec& n2 = feature_->themesh->normals[(*thisFace)[2]];
            trimesh::vec& v2 = feature_->themesh->vertices[(*thisFace)[2]];
            if (draw_field&&res_got)
            {
                int v_i = (*thisFace)[2];
                glColor4f(field_color[v_i].x(), field_color[v_i].y(), field_color[v_i].z(), draw_face_alpha);
            }
            glNormal3d(n2[0], n2[1], n2[2]);
            glVertex3f(v2[0], v2[1], v2[2]);
        }

        if (bind_face1 > -1)
        {   
            glColor4f(1.0f, 0, 0, draw_face_alpha);
            trimesh::TriMesh::Face* thisFace;
            thisFace = &(feature_->themesh->faces[bind_face1]);

            trimesh::vec& n0 = feature_->themesh->normals[(*thisFace)[0]];
            trimesh::vec& v0 = feature_->themesh->vertices[(*thisFace)[0]];
            glNormal3d(n0[0], n0[1], n0[2]);
            glVertex3f(v0[0], v0[1], v0[2]);

            trimesh::vec& n1 = feature_->themesh->normals[(*thisFace)[1]];
            trimesh::vec& v1 = feature_->themesh->vertices[(*thisFace)[1]];
            glNormal3d(n1[0], n1[1], n1[2]);
            glVertex3f(v1[0], v1[1], v1[2]);

            trimesh::vec& n2 = feature_->themesh->normals[(*thisFace)[2]];
            trimesh::vec& v2 = feature_->themesh->vertices[(*thisFace)[2]];
            glNormal3d(n2[0], n2[1], n2[2]);
            glVertex3f(v2[0], v2[1], v2[2]);
        }

        if (bind_face2 > -1)
        {
            glColor4f(1.0f, 0, 0, draw_face_alpha);
            trimesh::TriMesh::Face* thisFace;
            thisFace = &(feature_->themesh->faces[bind_face2]);

            trimesh::vec& n0 = feature_->themesh->normals[(*thisFace)[0]];
            trimesh::vec& v0 = feature_->themesh->vertices[(*thisFace)[0]];
            glNormal3d(n0[0], n0[1], n0[2]);
            glVertex3f(v0[0], v0[1], v0[2]);

            trimesh::vec& n1 = feature_->themesh->normals[(*thisFace)[1]];
            trimesh::vec& v1 = feature_->themesh->vertices[(*thisFace)[1]];
            glNormal3d(n1[0], n1[1], n1[2]);
            glVertex3f(v1[0], v1[1], v1[2]);

            trimesh::vec& n2 = feature_->themesh->normals[(*thisFace)[2]];
            trimesh::vec& v2 = feature_->themesh->vertices[(*thisFace)[2]];
            glNormal3d(n2[0], n2[1], n2[2]);
            glVertex3f(v2[0], v2[1], v2[2]);
        }

        glEnd();
        glDepthMask(true);
        glDisable(GL_POLYGON_OFFSET_FILL);
        //glPopMatrix();
        glDisable(GL_BLEND);
        glDisable(GL_LIGHTING);
        glDisable(GL_AUTO_NORMAL);
        //glDisable(GL_ALPHA_TEST);
        //glDepthMask(GL_TRUE);
    }
    if (draw_line)
    {
        glLineWidth(line_width);
        glColor3f(line_color.redF(), line_color.greenF(), line_color.blueF());
        glBegin(GL_LINES);
        for (auto e = mesh_poly_->edges_begin(); e != mesh_poly_->edges_end(); ++e)
        {
            auto pt1 = e->vertex()->point();
            auto pt2 = e->opposite()->vertex()->point();
            glVertex3d(pt1.x(), pt1.y(), pt1.z());
            glVertex3d(pt2.x(), pt2.y(), pt2.z());
        }
        glEnd();
    }
    if (draw_anchor_vertex)
    {   
        glColor3ub(255, 0, 0);
        glBegin(GL_QUADS);
        for (auto pt = mesh_poly_->vertices_begin(); pt != mesh_poly_->vertices_end(); ++pt)
        {
            if (!(*is_pt_selected)[pt->id()])continue;
            //if (pt->id() == cur_mouse_near_pt_idx)continue;
            if (pt->id() == *bridge_pt)continue;
            //glVertex3d(pt->point().x(), pt->point().y(), pt->point().z());
            if (cur_mouse_near_pt_idx == pt->id())
            {
                glColor3f(0, 1.0f, 0);
            }
            else
            {
                glColor3f(1.0f, 0, 0);
            }
            drawSphere(pt->point().x(), pt->point().y(), pt->point().z(), mesh_poly_->get_avg_edge_len());
        }
        glEnd();
    }
    if (draw_vertex)
    {
        glEnable(GL_POLYGON_OFFSET_POINT);
        glPolygonOffset(-2, -2);
        glPointSize(vertex_size);
        glColor3f(vertex_color.redF(), vertex_color.greenF(), vertex_color.blueF());
        glColor3ub(160, 85, 34);
        glBegin(GL_POINTS);
        for (auto pt = mesh_poly_->vertices_begin(); pt != mesh_poly_->vertices_end(); ++pt)
        {
            auto projectedVertex = this->camera()->projectedCoordinatesOf(qglviewer::Vec(pt->point().x(), pt->point().y(), pt->point().z()));
            (*selectRects)[pt->id()] = QRect(projectedVertex.x - 4, projectedVertex.y - 4, 8, 8);
        }
        for (auto pt = mesh_poly_->vertices_begin(); pt != mesh_poly_->vertices_end(); ++pt)
        {
            if ((*is_pt_selected)[pt->id()])continue;
            if (pt->id() == cur_mouse_near_pt_idx)continue;
            if (pt->id() == *bridge_pt)continue;
            auto v_n = mesh_poly_->index_to_vertex_map[pt->id()]->normal();
            qglviewer::Vec v_normal(v_n.x(), v_n.y(), v_n.z());
            bool is_vis = (v_normal * camera()->viewDirection()) > 0 ? 0 : 1;
            if (is_vis)
            {
                glVertex3d(pt->point().x(), pt->point().y(), pt->point().z());
            }
        }

        glColor3ub(160, 85, 34);
        glColor3f(vertex_color.redF(), vertex_color.greenF(), vertex_color.blueF());
        //////std::cout << selectPointsIndex.size() << std::endl;
        glEnd();

        glBegin(GL_POINTS);
        if (cur_mouse_near_pt_idx > -1)
        {
            auto pt = mesh_poly_->index_to_vertex_map[cur_mouse_near_pt_idx]->point();
            glColor3f(0, 1.0f, 0);
            glVertex3d(pt.x(), pt.y(), pt.z());
        }
        if (*bridge_pt > -1)
        {
            auto pt = mesh_poly_->index_to_vertex_map[*bridge_pt]->point();
            glColor3f(0, 0, 1.0f);
            glVertex3d(pt.x(), pt.y(), pt.z());
        }
        glEnd();

        glEnd();
        glDisable(GL_POLYGON_OFFSET_POINT);
    }
    if (draw_extend_pt)
    {
        if (user_study_start_pt_idx_i == -1)
        {
            if (user_study_start_pt_idx_j > -1)
            {
                auto vt = mesh_poly_->index_to_vertex_map[user_study_start_pt_idx_j]->point();
                if (cur_mouse_near_pt_idx == user_study_start_pt_idx_j)
                {
                    glColor3f(0, 1.0f, 0);
                }
                else
                {
                    glColor3f(1.0f, 0, 0);
                }
                drawSphere(vt.x(), vt.y(), vt.z(), mesh_poly_->get_avg_edge_len());
            }
        }
        if (user_study_end_pt_idx_i == -1)
        {
            if (user_study_end_pt_idx_j > -1)
            {   
                auto vt = mesh_poly_->index_to_vertex_map[user_study_end_pt_idx_j]->point();
                if (cur_mouse_near_pt_idx == user_study_end_pt_idx_j)
                {
                    glColor3f(0, 1.0f, 0);
                }
                else
                {
                    glColor3f(1.0f, 0, 0);
                }
                drawSphere(vt.x(), vt.y(), vt.z(), mesh_poly_->get_avg_edge_len());
            }
        }
    }
}

void EditViewer::drawSegment()
{   
    if (seg == NULL) { return; }
    if (seg->empty()||(!(draw_segment)))return;
    glEnable(GL_POLYGON_OFFSET_FILL);
    glPolygonOffset(1, 1);
    glBegin(GL_TRIANGLES);
    for (auto f = mesh_poly_->facets_begin(); f != mesh_poly_->facets_end(); ++f)
    {
        auto pt1 = f->facet_begin()->vertex()->point();
        auto pt2 = f->facet_begin()->next()->vertex()->point();
        auto pt3 = f->facet_begin()->next()->next()->vertex()->point();
        glColor3d(seg->color((*seg)[f->id()]).redF(), seg->color((*seg)[f->id()]).greenF(), seg->color((*seg)[f->id()]).blueF());
        glVertex3d(pt1.x(), pt1.y(), pt1.z());
        glVertex3d(pt2.x(), pt2.y(), pt2.z());
        glVertex3d(pt3.x(), pt3.y(), pt3.z());
    }
    glEnd();
    glDisable(GL_POLYGON_OFFSET_FILL);
}

void EditViewer::drawPaths()
{   
    if (path_res == NULL) { return; }
    if (select_ctrl_pt_vec == NULL) { return; }

    glEnable(GL_SMOOTH);
    glEnable(GL_MULTISAMPLE);
    glDisable(GL_LIGHTING);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_COLOR, GL_SRC_COLOR);
    if (*select_move_pt_idx_i < 0)
    {
        path_res->draw(draw_curve, draw_curvecyliner, draw_ctrlpts, user_study_start_pt_idx_i, user_study_start_pt_idx_j);
    }
    else
    {
        path_res->draw(draw_curve, draw_curvecyliner, draw_ctrlpts, *select_move_pt_idx_i, *select_move_pt_idx_j);
    }
    //path_res->draw(draw_curve, draw_curvecyliner, draw_ctrlpts||draw_extend_pt, *select_move_pt_idx_i, *select_move_pt_idx_j);
    //glDisable(GL_MULTISAMPLE);
    glDisable(GL_SMOOTH);
    glDisable(GL_BLEND);
    glEnable(GL_LIGHTING);
    (*select_ctrl_pt_vec) = std::vector<std::vector<QRect>>(path_res->ctrl_pts.size());
    for (int i = 0; i < path_res->ctrl_pts.size(); ++i)
    {
        for (auto j : path_res->ctrl_pts[i])
        {
            auto pt = this->camera()->projectedCoordinatesOf(qglviewer::Vec(j.x(), j.y(), j.z()));
            (*select_ctrl_pt_vec)[i].push_back(QRect(pt.x - 5, pt.y - 5, 10, 10));
        }
    }
    if ((*select_move_pt_idx_i > -1) && (*select_move_pt_idx_j > -1))
    {
        user_select_ctrl_pt_rect = (*select_ctrl_pt_vec)[*select_move_pt_idx_i][*select_move_pt_idx_j];
    }
    if ((user_study_end_pt_idx_i > -1) && (user_study_end_pt_idx_j > -1))
    {
        user_select_ctrl_pt_rect = (*select_ctrl_pt_vec)[user_study_end_pt_idx_i][user_study_end_pt_idx_j];
    }
}

void EditViewer::drawUserInput(QPainter* painter)
{
    if (cur_mouse == kMouse::DRAW_USER_INPUT)
    {   
        if (user_input == NULL) { return; }
        if (user_input->empty())
        {
            return;
        }
        QBrush thisBrush(QColor(255, 0, 0, 125));
        double strokeWidth;
        strokeWidth = 4;
        QPen thisPen(thisBrush, strokeWidth, Qt::SolidLine, Qt::RoundCap);
        thisPen.setJoinStyle(Qt::RoundJoin);
        painter->save();

        painter->setPen(thisPen);

        QPainterPath thisPath;
        thisPath.moveTo(user_input->front());
        for (int i = 1; i < user_input->size(); ++i)
        {
            thisPath.lineTo((*user_input)[i]);
        }

        painter->setRenderHint(QPainter::Antialiasing);
        painter->drawPath(thisPath);
        painter->restore();
    }
    else if (cur_mouse == kMouse::DRAW_USEE_INPUT_PATH)
    {   
        if (select_rect_paths == NULL) { return; }
        if (select_rect_paths->empty())
        {
            return;
        }
        QBrush thisBrush(QColor(255, 255, 0, 100));

        double strokeWidth;
        strokeWidth = 5 * 2 *2;
        QPen thisPen(thisBrush, strokeWidth, Qt::SolidLine, Qt::RoundCap);
        thisPen.setJoinStyle(Qt::RoundJoin);
        painter->save();

        painter->setPen(thisPen);

        QPainterPath thisPath;
        thisPath.moveTo(select_rect_paths->front().center());
        for (int i = 1; i < select_rect_paths->size(); ++i)
        {
            thisPath.lineTo((*select_rect_paths)[i].center());
        }

        painter->setRenderHint(QPainter::Antialiasing);
        painter->drawPath(thisPath);
        painter->restore();
    }
}

void EditViewer::drawFeature()
{   
    glDisable(GL_LIGHTING);
    glLineWidth(2);
    glEnable(GL_POINT_SMOOTH);
    glEnable(GL_LINE_SMOOTH);
    glEnable(GL_BLEND);
    if (feature_ == NULL) { return; }
    Eigen::Matrix4f view; GLfloat 	m[16];
    camera()->getModelViewProjectionMatrix(m);
    view << m[0], m[4], m[8], m[12],
        m[1], m[5], m[9], m[13],
        m[2], m[6], m[10], m[14],
        m[3], m[7], m[11], m[15];
    feature_->feature_update(view);
    for (auto i : feature_->features_draw_option_)
    {
        if (i.second == kDrawingOption::DRAW_IMMEDIATELY ||
            i.second == kDrawingOption::DRAW_SAVED_RES)
        {
            if (!(feature_->features_[i.first].empty()))
            {
                glBegin(GL_LINES);
                for (int j = 0; j < (feature_->features_[i.first].size() / 5); ++j)
                {
                    glColor3dv(feature_->features_[i.first][j * 5].data());
                    glVertex3dv(feature_->features_[i.first][j * 5 + 1].data());
                    glColor3dv(feature_->features_[i.first][j * 5 + 2].data());
                    glVertex3dv(feature_->features_[i.first][j * 5 + 3].data());
                }
                glEnd();
            }
            else
            {
                for (int j = 0; j < feature_->feature_lines[i.first].size(); ++j)
                {
                    glBegin(GL_LINE_STRIP);
                    glColor3d(0, 0, 0);
                    for (int k = 0; k < feature_->feature_lines[i.first][j].size(); ++k)
                    {
                        glVertex3dv(feature_->feature_lines[i.first][j][k].data());
                    }
                    glEnd();
                }
            }
        }
    }
    glDisable(GL_LINE_SMOOTH);
    glDisable(GL_POINT_SMOOTH);
    glDisable(GL_BLEND);
    glEnable(GL_LIGHTING);
}

void EditViewer::drawArrows(QPainter* painter)
{   
    if (select_move_pt_idx_i == NULL || select_move_pt_idx_j == NULL)
    {
        return;
    }
    if (path_res == NULL)
    {
        return;
    }
    if ((*select_move_pt_idx_i < 0) || (*select_move_pt_idx_j < 0))
    {
        return;
    }
    auto move_pt = path_res->ctrl_pts[*select_move_pt_idx_i][*select_move_pt_idx_j];
    auto project_pt = this->camera()->projectedCoordinatesOf(qglviewer::Vec(move_pt.x(), move_pt.y(), move_pt.z()));
    QPoint project_pt_ = QPoint(project_pt.x, project_pt.y);
    painter->setPen(Qt::red);
    drawArrows(project_pt_, project_pt_ + QPoint(40, 0), painter);
    painter->setPen(Qt::green);
    drawArrows(project_pt_, project_pt_ + QPoint(0, 40), painter);
}

void EditViewer::drawArrows(QPoint start_pt, QPoint end_pt, QPainter* painter)
{
    const int arrow_size = 20;
    QLineF line(start_pt, end_pt);
    painter->drawLine(start_pt, end_pt);
    QPoint dir = end_pt - start_pt;
    double len = std::abs(dir.x() + dir.y());
    double angle = std::acos((dir.x()) * 1.0 / len);
    if (dir.y() >= 0)
    {
        angle = M_2PI - angle;
    }
    QPoint destArrowP1 = end_pt + QPoint(std::sin(angle - M_PI / 3) * arrow_size,
        std::cos(angle - M_PI / 3) * arrow_size);
    QPoint destArrowP2 = end_pt + QPoint(std::sin(angle - M_PI + M_PI / 3) * arrow_size,
        std::cos(angle - M_PI + M_PI / 3) * arrow_size);
    painter->drawLine(destArrowP1, end_pt);
    painter->drawLine(destArrowP2, end_pt);
}

void EditViewer::paintEvent(QPaintEvent* event) {
    Q_UNUSED(event)
        QPainter painter;
    painter.begin(this);
    painter.setRenderHint(QPainter::Antialiasing);

    // Save current OpenGL state
    glPushAttrib(GL_ALL_ATTRIB_BITS);
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();

    // Reset OpenGL parameters
    glShadeModel(GL_SMOOTH);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);
    //glEnable(GL_LIGHTING);
    //glEnable(GL_LIGHT0);
    glEnable(GL_MULTISAMPLE);
    //static GLfloat lightPosition[4] = { 1.0, 5.0, 5.0, 1.0 };
    //glLightfv(GL_LIGHT0, GL_POSITION, lightPosition);
    glClearColor(backgroundColor().redF(), backgroundColor().greenF(),
        backgroundColor().blueF(), backgroundColor().alphaF());

    preDraw();
    draw();
    postDraw();
    // Restore OpenGL state
    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glPopAttrib();
    drawUserInput(&painter);
    drawArrows(&painter);

    painter.end();
}

void EditViewer::keyPressEvent(QKeyEvent* e)
{   
    QGLViewer::keyPressEvent(e);
    if (e->key() == Qt::Key_Left ||
        e->key() == Qt::Key_Right ||
        e->key() == Qt::Key_Up ||
        e->key() == Qt::Key_Down)
    {
        emit Viewer_MoveCamera();
    }
}

void EditViewer::wheelEvent(QWheelEvent* e)
{   
    emit Viewer_ScaleCamera();
    QGLViewer::wheelEvent(e);
    emit Viewer_Frame(camera()->frame());
    emit Viewer_ScaleCameraDone();
}

void EditViewer::mousePressEvent(QMouseEvent* e)
{
    int pos_x = e->x();
    int pos_y = e->y();
    if (cur_mouse == kMouse::DEFAULT)
    {
        QGLViewer::mousePressEvent(e);
        update();
        //
        if (e->button() == Qt::LeftButton)
        {
            emit Viewer_RotateCamera();
        }
        if (e->button() == Qt::RightButton)
        {
            emit Viewer_MoveCamera();
        }
        return;
    }
    else if ((cur_mouse == kMouse::MOVE_CTRL_PT) ||
        (cur_mouse == kMouse::MOVE_CTRL_PT_SOFT))
    {
        //std::cout << select_ctrl_pt_vec->size() << std::endl;
        for (int i = 0; i < select_ctrl_pt_vec->size(); i++)
        {   
            //std::cout << select_ctrl_pt_vec->at(i).size() << std::endl;
            for (int j = 0; j < (*select_ctrl_pt_vec)[i].size(); ++j)
            {   
                if ((*select_ctrl_pt_vec)[i][j].contains(pos_x, pos_y))
                {   
                    //std::cout << "contain:" << i << " " << j << std::endl;
                    *select_move_pt_idx_i = i;
                    *select_move_pt_idx_j = j;
                    break;
                }
            }
        }
        update();
        if ((*select_move_pt_idx_i > -1) && (*select_move_pt_idx_j > -1))
        {
            user_select_ctrl_pt_rect = (*select_ctrl_pt_vec)[*select_move_pt_idx_i][*select_move_pt_idx_j];
            if (user_select_ctrl_pt_rect.contains(pos_x, pos_y))
            {
                is_drag = true;
                return;
            }
        }
        update();
        return;
    }
    //else if (cbx_select_attach_pt->isChecked())
    else if (cur_mouse == kMouse::SELECT_ATTACH_PT)
    {
        for (int i = 0; i < selectRects->size(); i++)
        {
            if ((*selectRects)[i].contains(pos_x, pos_y))
            {
                //////std::cout << "in" << std::endl;
                auto v_n = mesh_poly_->index_to_vertex_map[i]->normal();
                //Polyhedron::Traits::Vector_3 v_n=CGAL::Polygon_mesh_processing::compute_vertex_normal(v_it,mesh_poly);
                qglviewer::Vec v_normal(v_n.x(), v_n.y(), v_n.z());
                bool is_vis = (v_normal * camera()->viewDirection()) > 0 ? 0 : 1;
                if (is_vis)
                {
                    *bridge_pt = i;
                    break;
                }
            }
        }
        update();
        return;
    }
    else if (cur_mouse == kMouse::SELECT_MODEL_PT)
    {   
        for (int i = 0; i < selectRects->size(); i++)
        {
            if ((*selectRects)[i].contains(pos_x, pos_y))
            {
                auto find_iter = std::find(selectPointsIndex->begin(), selectPointsIndex->end(), i);
                auto v_n = mesh_poly_->index_to_vertex_map[i]->normal();
                qglviewer::Vec v_normal(v_n.x(), v_n.y(), v_n.z());
                bool is_vis = (v_normal * camera()->viewDirection()) > 0 ? 0 : 1;
                if (find_iter == selectPointsIndex->end() && is_vis)
                {
                    selectPointsIndex->push_back(i);
                    (*is_pt_selected)[i] = true;
                    return;
                }
                else if (find_iter != selectPointsIndex->end() && is_vis)
                {
                    selectPointsIndex->erase(find_iter);
                    (*is_pt_selected)[i] = false;
                    return;
                }
                break;
            }
        }
    }
    else if (cur_mouse == kMouse::CHOOSE_MODEL_PT)
    {   
        Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic> mat(mesh_poly_->size_of_vertices(), 2);
        for (int i = 0; i < mesh_poly_->size_of_vertices(); ++i)
        {   
            auto pt = mesh_poly_->index_to_vertex_map[i];
            auto projectedVertex = this->camera()->projectedCoordinatesOf(qglviewer::Vec(pt->point().x(), pt->point().y(), pt->point().z()));
            mat.row(i) = Eigen::Vector2d(projectedVertex.x, projectedVertex.y);
        }
        my_kd_tree_t mat_index(2, mat, 10);
        mat_index.index->buildIndex();

        const std::size_t num_results = mesh_poly_->size_of_vertices();
        std::vector<size_t>ret_idx_(num_results);
        std::vector<double>out_dists_sqr_(num_results);
        nanoflann::KNNResultSet<double>resultSet(num_results);
        resultSet.init(ret_idx_.data(), out_dists_sqr_.data());
        mat_index.index->findNeighbors(resultSet, Eigen::Vector2d(e->x(),e->y()).data(), nanoflann::SearchParams(128));

        for (int i = 0; i < ret_idx_.size(); ++i)
        {
            auto v_n = mesh_poly_->index_to_vertex_map[ret_idx_[i]]->normal();
            qglviewer::Vec v_normal(v_n.x(), v_n.y(), v_n.z());
            bool is_vis = (v_normal * camera()->viewDirection()) > 0 ? 0 : 1;
            if (is_vis)
            {
                if (user_study_start_pt_idx_i == -1)
                {
                    if (user_study_start_pt_idx_j == -1)
                    {
                        user_study_start_pt_idx_j = ret_idx_[i];
                        break;
                    }
                    else if (user_study_start_pt_idx_j == ret_idx_[i])
                    {
                        user_study_start_pt_idx_j = -1;
                        break;
                    }
                    else if (user_study_end_pt_idx_j == -1)
                    {
                        user_study_end_pt_idx_j = ret_idx_[i];
                        break;
                    }
                    else if (user_study_end_pt_idx_j == ret_idx_[i])
                    {
                        user_study_end_pt_idx_j = -1;
                        break;
                    }
                }
                else
                {
                    if (user_study_end_pt_idx_j == -1)
                    {   
                        std::cout << "aaaa" << std::endl;
                        user_study_end_pt_idx_j = ret_idx_[i];
                        break;
                    }
                    else if (user_study_end_pt_idx_j == ret_idx_[i])
                    {   
                        std::cout << "bbb" << std::endl;
                        user_study_end_pt_idx_j = -1;
                        break;
                    }
                }
            }
        }
        update();
    }
    else if (cur_mouse == kMouse::CHOOSE_MODEL_FACE)
    {
        for (int i = 0; i < feature_->themesh->faces.size(); ++i)
        {
            auto face = feature_->themesh->faces[i];
            auto v_n1 = mesh_poly_->index_to_vertex_map[face[0]]->normal();
            auto v_n2 = mesh_poly_->index_to_vertex_map[face[1]]->normal();
            auto v_n3 = mesh_poly_->index_to_vertex_map[face[2]]->normal();
            qglviewer::Vec v_normal1(v_n1.x(), v_n1.y(), v_n1.z());
            qglviewer::Vec v_normal2(v_n2.x(), v_n2.y(), v_n2.z());
            qglviewer::Vec v_normal3(v_n3.x(), v_n3.y(), v_n3.z());
            bool is_vis = (v_normal1 * camera()->viewDirection()) > 0 ? 0 : 1;
            is_vis = is_vis && ((v_normal2 * camera()->viewDirection()) > 0 ? 0 : 1);
            is_vis = is_vis && ((v_normal3 * camera()->viewDirection()) > 0 ? 0 : 1);

            if (is_vis)
            {
                auto face_pt0 = feature_->themesh->vertices[face[0]];
                auto face_pt1 = feature_->themesh->vertices[face[1]];
                auto face_pt2 = feature_->themesh->vertices[face[2]];
                qglviewer::Vec project_pt0 = this->camera()->projectedCoordinatesOf(qglviewer::Vec(face_pt0.x, face_pt0.y, face_pt0.z));
                qglviewer::Vec project_pt1 = this->camera()->projectedCoordinatesOf(qglviewer::Vec(face_pt1.x, face_pt1.y, face_pt1.z));
                qglviewer::Vec project_pt2 = this->camera()->projectedCoordinatesOf(qglviewer::Vec(face_pt2.x, face_pt2.y, face_pt2.z));
                qglviewer::Vec input_pt(e->x(), e->y(), 0);
                if (PointInTriangle(project_pt0, project_pt1, project_pt2, input_pt))
                {
                    if (bind_face1 == -1)
                    {
                        bind_face1 = i;
                        break;
                    }
                    else if (bind_face1 == i)
                    {
                        bind_face1 = -1;
                        break;
                    }
                    else if (bind_face2 == -1)
                    {
                        bind_face2 = i;
                        break;
                    }
                    else if (bind_face2 == i)
                    {
                        bind_face2 = -1;
                        break;
                    }
                }
            }
        }
    }
    else if (cur_mouse == kMouse::CHOOSE_CURVE_PT)
    {
        for (int i = 0; i < select_ctrl_pt_vec->size(); i++)
        {
            for (int j = 0; j < (*select_ctrl_pt_vec)[i].size(); ++j)
            {
                if ((*select_ctrl_pt_vec)[i][j].contains(pos_x, pos_y))
                {
                    user_study_start_pt_idx_i = i;
                    user_study_start_pt_idx_j = j;
                    break;
                }
            }
        }
        update();
        return;
    }
    else if (cur_mouse == kMouse::DRAW_USER_INPUT)
    {
        user_input->clear();
        user_input->push_back(e->pos());
        repaint();
        return;
    }
    else if (cur_mouse == kMouse::DRAW_USEE_INPUT_PATH)
    {
        select_rect_paths->clear();
        int x = e->x(), y = e->y();
        select_rect_paths->push_back(QRect(x - 10, y - 10, 20, 20));
        repaint();
        return;
    }
}

void EditViewer::mouseMoveEvent(QMouseEvent* e)
{
    if (cur_mouse == kMouse::DEFAULT)
    {
        QGLViewer::mouseMoveEvent(e);
        emit Viewer_Frame(camera()->frame());
        update();
        repaint();

        if (e->button() == Qt::LeftButton)
        {
            emit Viewer_RotateCameraDone();
        }
        if (e->button() == Qt::RightButton)
        {
            emit Viewer_MoveCameraDone();
        }
        return;
    }
    else if (cur_mouse == kMouse::MOVE_CTRL_PT)
    {
        if (is_drag)
        {
            if ((*select_move_pt_idx_i > -1) && (*select_move_pt_idx_j > -1))
            {
                Eigen::Vector3d move_pt = path_res->ctrl_pts[*select_move_pt_idx_i][*select_move_pt_idx_j];
                auto move_pt_project = this->camera()->projectedCoordinatesOf(qglviewer::Vec(move_pt.x(), move_pt.y(), move_pt.z()));
                double x_pos = e->x();
                double y_pos = e->y();
                auto move_res = this->camera()->unprojectedCoordinatesOf(qglviewer::Vec(x_pos, y_pos, move_pt_project.z));
                Eigen::Vector3d move_res_e = Eigen::Vector3d(move_res.x, move_res.y, move_res.z);
                path_res->modify(feature_, *select_move_pt_idx_i, *select_move_pt_idx_j, move_res_e);
                //callSmoothResult(path_res_ctrl_pts, path_res);
            }
            update();
            return;
        }
    }
    else if (cur_mouse == kMouse::MOVE_CTRL_PT_SOFT)
    {
        if (is_drag)
        {
            if ((*select_move_pt_idx_i > -1) && (*select_move_pt_idx_j > -1))
            {
                Eigen::Vector3d move_pt = path_res->ctrl_pts[*select_move_pt_idx_i][*select_move_pt_idx_j];
                double min_dist = std::numeric_limits<double>::max();
                int nn_idx = -1;
                auto move_pt_project = this->camera()->projectedCoordinatesOf(qglviewer::Vec(move_pt.x(), move_pt.y(), move_pt.z()));
                Eigen::Vector2d move_pt_project_e(move_pt_project.x, move_pt_project.y);
                Eigen::Vector2d n_pt_project;
                for (int i = 0; i < selectRects->size(); ++i)
                {
                    auto v_n = mesh_poly_->index_to_vertex_map[i]->normal();
                    qglviewer::Vec v_normal(v_n.x(), v_n.y(), v_n.z());
                    bool is_vis = (v_normal * camera()->viewDirection()) > 0 ? 0 : 1;
                    if (is_vis)
                    {
                        Eigen::Vector2d pt((*selectRects)[i].center().x(), (*selectRects)[i].center().y());
                        double dis = (pt - move_pt_project_e).norm();
                        if (dis < min_dist)
                        {
                            nn_idx = i;
                            min_dist = dis;
                            n_pt_project = pt;
                        }
                    }
                }
                double max_dist_pro = 0;
                for (int i = 0; i < selectRects->size(); ++i)
                {   
                    auto v_it = mesh_poly_->index_to_vertex_map[i];
                    auto pt1 = v_it->point();
                    auto pt1_pro = this->camera()->projectedCoordinatesOf(qglviewer::Vec(pt1.x(), pt1.y(), pt1.z()));
                    auto v_i = v_it->vertex_begin();
                    for (int j = 0; j < v_it->vertex_degree(); j++)
                    {
                        auto pt2 = v_i->opposite()->vertex()->point();
                        auto pt2_pro = this->camera()->projectedCoordinatesOf(qglviewer::Vec(pt2.x(), pt2.y(), pt2.z()));
                        max_dist_pro = std::max(max_dist_pro, (pt1_pro - pt2_pro).norm());
                    }
                }
                ////std::cout << min_dist << std::endl;
                if ((min_dist > 0.5*max_dist_pro) && ((move_pt_project_e - n_pt_project).dot(
                    Eigen::Vector2d(e->x(), e->y()) - move_pt_project_e) > 0))
                {
                    update();
                    return;
                }

                auto nn_pt = mesh_poly_->index_to_vertex_map[nn_idx]->point();
                double dist = (move_pt - Eigen::Vector3d(nn_pt.x(), nn_pt.y(), nn_pt.z())).norm();
                auto nn_pt_project = this->camera()->projectedCoordinatesOf(qglviewer::Vec(nn_pt.x(), nn_pt.y(), nn_pt.z()));

                double x_pos = e->x();
                double y_pos = e->y();
                auto move_res = this->camera()->unprojectedCoordinatesOf(qglviewer::Vec(x_pos, y_pos, nn_pt_project.z));
                Eigen::Vector3d move_res_e = Eigen::Vector3d(move_res.x, move_res.y, move_res.z);
                path_res->modify(feature_, *select_move_pt_idx_i, *select_move_pt_idx_j, move_res_e);
            }
            update();
            return;
        }
    }
    else if (cur_mouse == kMouse::DRAW_USER_INPUT)
    {
        user_input->push_back(e->pos());
        //drawUserInput();
        repaint();
        return;
    }
    else if (cur_mouse == kMouse::DRAW_USEE_INPUT_PATH)
    {
        int x = e->x(), y = e->y();
        select_rect_paths->push_back(QRect(x - 10, y - 10, 20, 20));
        //drawUserInput();
        //drawUserInput();
        repaint();
        return;
    }
    else if ((cur_mouse == kMouse::SELECT_MODEL_PT) ||
        (cur_mouse == kMouse::SELECT_ATTACH_PT)||
        (cur_mouse == kMouse::CHOOSE_MODEL_PT))
    {
        int pos_x = e->x();
        int pos_y = e->y();
        for (int i = 0; i < selectRects->size(); i++)
        {
            if ((*selectRects)[i].contains(pos_x, pos_y))
            {
                auto v_n = mesh_poly_->index_to_vertex_map[i]->normal();
                qglviewer::Vec v_normal(v_n.x(), v_n.y(), v_n.z());
                bool is_vis = (v_normal * camera()->viewDirection()) > 0 ? 0 : 1;
                if (is_vis)
                {
                    cur_mouse_near_pt_idx = i;
                    update();
                    repaint();
                    return;
                }
            }
        }
        cur_mouse_near_pt_idx = -1;
        update();
        repaint();
    }
}

void EditViewer::mouseReleaseEvent(QMouseEvent* e)
{
    if (cur_mouse == kMouse::DEFAULT)
    {
        QGLViewer::mouseReleaseEvent(e);
        emit Viewer_Frame(camera()->frame());
        update();
        repaint();
        return;
    }
    else if ((cur_mouse == kMouse::MOVE_CTRL_PT) ||
        (cur_mouse == kMouse::MOVE_CTRL_PT_SOFT))
    {   
        if (is_drag)
        {
            emit Viewer_MoveCurveDone();
        }
        is_drag = false;
        return;
    }
    else if (cur_mouse == kMouse::DRAW_USEE_INPUT_PATH)
    {
        if (cur_edit == kEdit::MODIFY_CURVE)
        {
            emit Viewer_ModifyCurve();
        }
        else if (cur_edit == kEdit::SMOOTH_PART)
        {
            emit Viewer_SmoothPart();
        }
        return;
    }
    else if (cur_mouse == kMouse::DRAW_USER_INPUT)
    {
        if (cur_edit == kEdit::ATTACH_TO_CURVE)
        {   
            emit Viewer_AttachToCurve();
        }
        else if (cur_edit == kEdit::ADD_CURVE)
        {
            emit Viewer_AddCurve();
        }
        else if (cur_edit == kEdit::USER_STUDY_CREATE)
        {
            emit Viewer_UserStudyCreateNewLine();
        }
        else if (cur_edit == kEdit::USER_STUDY_LINK)
        {
            emit Viewer_UserStudyLineToLastLine();
        }
        else if (cur_edit == kEdit::ANCHOR_PATH)
        {
            emit Viewer_AnchorPathDone();
        }
    }
}

void EditViewer::mouseDoubleClickEvent(QMouseEvent* e){}

void EditViewer::backProject2Mesh(std::vector<Eigen::Vector3d>& curve_projected)
{   
    curve_projected.clear();
    std::vector<int>front_pt_idx;
    std::vector<Eigen::Vector2d>front_pts;
    std::vector<Eigen::Vector2d>user_input_;

    for (int i = 0; i < mesh_poly_->size_of_vertices(); ++i)
    {
        auto v_n = mesh_poly_->index_to_vertex_map[i]->normal();

        qglviewer::Vec v_normal(v_n.x(), v_n.y(), v_n.z());
        bool is_vis = (v_normal * camera()->viewDirection()) > 0 ? 0 : 1;
        if (is_vis)
        {
            front_pt_idx.push_back(i);
            auto pt = mesh_poly_->index_to_vertex_map[i]->point();
            qglviewer::Vec project_pt = this->camera()->projectedCoordinatesOf(qglviewer::Vec(pt.x(), pt.y(), pt.z()));
            front_pts.push_back(Eigen::Vector2d(project_pt.x, project_pt.y));
        }
    }
    resample_input();
    for (auto i : *user_input)
    {
        user_input_.push_back(Eigen::Vector2d(i.x(), i.y()));
    }
    feature_->user_input_attach(front_pt_idx, front_pts, user_input_);
    for (int i = 0; i < feature_->user_input_feature.back().size(); ++i)
    {
        auto facets = feature_->themesh->adjacentfaces[feature_->user_input_feature.back()[i]];
        for (auto facet : facets)
        {
            auto face_pt0 = feature_->themesh->vertices[feature_->themesh->faces[facet][0]];
            auto face_pt1 = feature_->themesh->vertices[feature_->themesh->faces[facet][1]];
            auto face_pt2 = feature_->themesh->vertices[feature_->themesh->faces[facet][2]];
            qglviewer::Vec project_pt0 = this->camera()->projectedCoordinatesOf(qglviewer::Vec(face_pt0.x, face_pt0.y, face_pt0.z));
            qglviewer::Vec project_pt1 = this->camera()->projectedCoordinatesOf(qglviewer::Vec(face_pt1.x, face_pt1.y, face_pt1.z));
            qglviewer::Vec project_pt2 = this->camera()->projectedCoordinatesOf(qglviewer::Vec(face_pt2.x, face_pt2.y, face_pt2.z));
            qglviewer::Vec input_pt(user_input_[i].x(), user_input_[i].y(), 0);
            if (PointInTriangle(project_pt0, project_pt1, project_pt2, input_pt))
            {
                auto nn_pt = feature_->themesh->vertices[feature_->user_input_feature.back()[i]];
                qglviewer::Vec nearest_project = this->camera()->projectedCoordinatesOf(qglviewer::Vec(nn_pt.x, nn_pt.y, nn_pt.z));
                qglviewer::Vec res= this->camera()->unprojectedCoordinatesOf(qglviewer::Vec(input_pt.x, input_pt.y, nearest_project.z));
                curve_projected.push_back(Eigen::Vector3d(res.x, res.y, res.z));
            }
        }
    }
}

void EditViewer::backProject2Mesh(bool need_resample)
{   
    //std::cout << "step A" << std::endl;
    std::vector<int>front_pt_idx;
    std::vector<Eigen::Vector2d>front_pts;
    std::vector<Eigen::Vector2d>user_input_;
    for (int i = 0; i < mesh_poly_->size_of_vertices(); ++i)
    {
        auto v_n = mesh_poly_->index_to_vertex_map[i]->normal();
        //Polyhedron::Traits::Vector_3 v_n=CGAL::Polygon_mesh_processing::compute_vertex_normal(v_it,mesh_poly);
        qglviewer::Vec v_normal(v_n.x(), v_n.y(), v_n.z());
        bool is_vis = (v_normal * camera()->viewDirection()) > 0 ? 0 : 1;
        if (is_vis)
        {
            front_pt_idx.push_back(i);
            auto pt = mesh_poly_->index_to_vertex_map[i]->point();
            qglviewer::Vec project_pt = this->camera()->projectedCoordinatesOf(qglviewer::Vec(pt.x(), pt.y(), pt.z()));
            front_pts.push_back(Eigen::Vector2d(project_pt.x, project_pt.y));
        }
    }
    if(need_resample)resample_input();
    for (auto i : *user_input)
    {
        user_input_.push_back(Eigen::Vector2d(i.x(), i.y()));
    }
    //std::cout << "step B" << std::endl;
    feature_->user_input_attach(front_pt_idx, front_pts, user_input_);
    std::set<int>MST_node(feature_->user_input_feature.back().begin(),
        feature_->user_input_feature.back().end());
    std::vector<int>MST_node_vec(MST_node.begin(), MST_node.end());
    std::vector<double>edge_len_array;
    typedef std::pair< int, int > E;
    std::vector<E>edge_array;

    for (int i = 0; i < MST_node_vec.size(); ++i)
    {
        auto v_it = mesh_poly_->index_to_vertex_map[MST_node_vec[i]];
        auto pt1 = v_it->point();
        auto v_i = v_it->vertex_begin();
        for (int j = 0; j < v_it->vertex_degree(); ++j)
        {
            if (v_i->opposite()->vertex()->id() > v_it->id())
            {
                v_i++;
                continue;
            }
            auto find_iter = std::find(MST_node_vec.begin(), MST_node_vec.end(), v_i->opposite()->vertex()->id());
            if (find_iter != MST_node_vec.end())
            {
                auto pt2 = v_i->opposite()->vertex()->point();
                double d = std::sqrt((pt1 - pt2).squared_length());
                int i_i = std::distance(MST_node_vec.begin(), find_iter);
                int min_idx = std::min(i, i_i);
                int max_idx = std::max(i, i_i);
                edge_array.push_back(std::pair<int, int>(min_idx, max_idx));
                edge_len_array.push_back(d);
            }
            v_i++;
        }
    }
    //std::cout << "step C" << std::endl;
    //std::cout << edge_array.size() << std::endl;
    //std::cout << MST_node_vec.size() << std::endl;
    if (MST_node_vec.empty())
    {
        return;
    }
    if (edge_array.empty())
    {   
        return;
    }
    typedef boost::adjacency_list< boost::vecS, boost::vecS, boost::undirectedS,
        boost::property< boost::vertex_distance_t, int >, boost::property< boost::edge_weight_t, double > >
        Graph_MST;
    Graph_MST g(edge_array.data(), edge_array.data() + edge_array.size(), edge_len_array.data(), MST_node_vec.size());
    std::vector<boost::graph_traits<Graph_MST>::vertex_descriptor>p(boost::num_vertices(g));
    boost::prim_minimum_spanning_tree(g, p.data());
    std::vector<E>MST_edge_vec;
    for (int i = 0; i < p.size(); ++i)
    {
        if (p[i] != i)
        {
            int min_edge_idx = std::min(i, int(p[i]));
            int max_edge_idx = std::max(i, int(p[i]));
            MST_edge_vec.push_back(std::pair<int, int>(min_edge_idx, max_edge_idx));
        }
    }
    //std::cout << "step D" << std::endl;
    double max_dist = 0;
    std::vector<int>MST_path;
    for (int i = 0; i < MST_node_vec.size(); ++i)
    {
        std::vector<double>dis(MST_node_vec.size(), -1);
        std::queue<int>q;
        q.push(i);
        dis[i] = 0;
        while (!q.empty())
        {
            int candidate = q.front();
            q.pop();
            auto v_it = mesh_poly_->index_to_vertex_map[MST_node_vec[candidate]];
            auto v_i = v_it->vertex_begin();
            auto pt1 = v_it->point();
            for (int j = 0; j < v_it->vertex_degree(); ++j)
            {
                auto find_iter = std::find(MST_node_vec.begin(), MST_node_vec.end(), v_i->opposite()->vertex()->id());
                if (find_iter != MST_node_vec.end())
                {
                    int i_i = std::distance(MST_node_vec.begin(), find_iter);
                    int min_edge_idx = std::min(candidate, i_i);
                    int max_edge_idx = std::max(candidate, i_i);
                    auto pt2 = v_i->opposite()->vertex()->point();
                    double d = std::sqrt((pt1 - pt2).squared_length());
                    std::pair<int, int>e(min_edge_idx, max_edge_idx);
                    auto find_iter_ = std::find(MST_edge_vec.begin(), MST_edge_vec.end(), e);
                    if (find_iter_ != MST_edge_vec.end())
                    {
                        if (dis[i_i] == -1)
                        {
                            q.push(i_i);
                            dis[i_i] = dis[candidate] + d;
                        }
                    }
                }
                v_i++;
            }
        }
        auto max_dist_iter = std::max_element(dis.begin(), dis.end());
        if ((*max_dist_iter) > max_dist)
        {
            max_dist = (*max_dist_iter);
            MST_path.clear();
            int idx = i;
            while (idx != p[idx])
            {
                MST_path.push_back(idx);
                idx = p[idx];
            }
            MST_path.push_back(idx);
            std::vector<int>path_insert;
            idx = std::distance(dis.begin(), max_dist_iter);
            auto find_iiter = std::find(MST_path.begin(), MST_path.end(), idx);
            while (find_iiter == MST_path.end())
            {
                path_insert.push_back(idx);
                idx = p[idx];
                find_iiter = std::find(MST_path.begin(), MST_path.end(), idx);
            }
            //MST_path.erase(MST_path.begin(), find_iiter);
            MST_path.erase(find_iiter + 1, MST_path.end());
            MST_path.insert(MST_path.end(), path_insert.rbegin(), path_insert.rend());
        }
    }
    //std::cout << "step E" << std::endl;
    user_input_MST->clear();
    for (int i = 0; i < MST_path.size(); ++i)
    {
        user_input_MST->push_back(MST_node_vec[MST_path[i]]);
    }
}

void EditViewer::cutPartFromMesh(std::vector<int>& nn_path_idx, bool is_bridge, int res_idx, bool Project2mesh = true)
{   
    std::vector<std::vector<Eigen::Vector2d>>curve_project(path_res->curve.size());
    for (int i = 0; i < path_res->curve.size(); ++i)
    {
        for (int j = 0; j < path_res->curve[i].size(); ++j)
        {
            auto pt = this->camera()->projectedCoordinatesOf(qglviewer::Vec(path_res->curve[i][j].x(), path_res->curve[i][j].y(), path_res->curve[i][j].z()));
            curve_project[i].push_back(Eigen::Vector2d(pt.x, pt.y));
        }
    }
    int i0 = -1, j0 = std::numeric_limits<int>::max(), i1 = -1, j1 = -1;
    resample_input();
    int vec_front_idx = 0, vec_back_idx = select_rect_paths->size() - 1;
    while (i0 == -1)
    {
        for (int i = 0; i < curve_project.size(); ++i)
        {
            for (int j = 0; j < curve_project[i].size(); ++j)
            {
                if ((*select_rect_paths)[vec_front_idx].contains(curve_project[i][j].x(), curve_project[i][j].y()))
                {
                    if (j < j0)
                    {
                        j0 = j;
                        i0 = i;
                    }
                }
            }
        }
        vec_front_idx++;
    }
    while (i1 == -1)
    {
        for (int i = 0; i < curve_project.size(); ++i)
        {
            for (int j = 0; j < curve_project[i].size(); ++j)
            {
                if ((*select_rect_paths)[vec_back_idx].contains(curve_project[i][j].x(), curve_project[i][j].y()))
                {
                    if (j > j1)
                    {
                        j1 = j;
                        i1 = i;
                    }
                }
            }
        }
        vec_back_idx--;
    }
    if (i1 != i0)
    {
        return;
    }
    if (!Project2mesh)
    {   
        bool is_oncurve = false;
        std::vector<int>tmp_on_curve;
        std::vector<std::set<int>>pts_selected(curve_project.size());
        for (int i = 0; i < select_rect_paths->size(); ++i)
        {
            for (int j = 0; j < curve_project.size(); ++j)
            {
                for (int k = 0; k < curve_project[j].size(); ++k)
                {
                    if ((*select_rect_paths)[i].contains(curve_project[j][k].x(), curve_project[j][k].y()))
                    {   
                        pts_selected[j].insert(k);
                        /*
                        if (!is_oncurve)
                        {
                            nn_path_idx.push_back(j);
                            nn_path_idx.push_back(k);
                            is_oncurve = true;
                        }
                        else
                        {
                            tmp_on_curve.push_back(k);
                        }
                        */
                    }
                    else
                    {   
                        /*
                        if (is_oncurve)
                        {
                            if (tmp_on_curve.empty())
                            {
                                nn_path_idx.push_back(nn_path_idx.back());
                            }
                            else
                            {   
                                int back1 = nn_path_idx.back();
                                nn_path_idx.pop_back();
                                int back2 = tmp_on_curve.back();
                                if (back1 > back2)
                                {
                                    std::swap(back1, back2);
                                }
                                nn_path_idx.push_back(back1);
                                nn_path_idx.push_back(back2);
                            }
                            tmp_on_curve.clear();
                            is_oncurve = false;
                        }
                        */
                    }
                }
            }
        }
        for (int i = 0; i < pts_selected.size(); ++i)
        {   
            for (auto j : pts_selected[i])
            {
                nn_path_idx.push_back(i);
                nn_path_idx.push_back(j);
            }
        }
    }
    else
    {   
        std::vector<Eigen::Vector3d>curve_ends;
        curve_ends.push_back(path_res->curve[i0][j0]);
        curve_ends.push_back(path_res->curve[i0][j1]);
        nn_path_idx.push_back(i0);
        nn_path_idx.push_back(std::min(j0,j1));
        nn_path_idx.push_back(std::max(j0,j1));
    }
}

void EditViewer::mouseChanged()
{
    if (cur_mouse == kMouse::DEFAULT)
    {   
        setMouseTracking(false);
    }
    else if (cur_mouse == kMouse::DRAW_USER_INPUT || cur_mouse == kMouse::DRAW_USEE_INPUT_PATH)
    {
        setMouseTracking(false);
    }
    else if (cur_mouse == kMouse::SELECT_MODEL_PT || cur_mouse == kMouse::SELECT_ATTACH_PT||cur_mouse == kMouse::CHOOSE_MODEL_PT)
    {
        setMouseTracking(true);
    }
    else if (cur_mouse == kMouse::MOVE_CTRL_PT || cur_mouse == kMouse::MOVE_CTRL_PT_SOFT|| cur_mouse == kMouse::CHOOSE_CURVE_PT)
    {
        setMouseTracking(false);
    }
}

void EditViewer::resample_input()
{   
    const int iter_times = 3;
    std::vector<QPoint>resample;
    for (int i = 1; i < user_input->size(); ++i)
    {   
        auto pt1 = user_input->at(i - 1);
        double pt1_x = pt1.x();
        double pt1_y = pt1.y();
        auto pt2 = user_input->at(i);
        double pt2_x = pt2.x();
        double pt2_y = pt2.y();
        for (int j = 0; j < iter_times; ++j)
        {
            double inter_x = pt1_x + ((j * 1.0) / iter_times) * (pt2_x - pt1_x);
            double inter_y = pt1_y + ((j * 1.0) / iter_times) * (pt2_y - pt1_y);
            resample.push_back(QPoint(inter_x, inter_y));
        }
    }
    user_input->clear();
    for (int i = 0; i < resample.size(); ++i)
    {
        user_input->push_back(resample[i]);
    }
}

void EditViewer::resample_rect()
{
    const int iter_times = 20;
    std::vector<QRect>resample;
    for (int i = 1; i < select_rect_paths->size(); ++i)
    {
        auto pt1 = select_rect_paths->at(i - 1);
        double pt1_x = pt1.center().x();
        double pt1_y = pt1.center().y();
        auto pt2 = select_rect_paths->at(i);
        double pt2_x = pt2.center().x();
        double pt2_y = pt2.center().y();
        for (int j = 0; j < iter_times; ++j)
        {
            double inter_x = pt1_x + ((j * 1.0) / iter_times) * (pt2_x - pt1_x);
            double inter_y = pt1_y + ((j * 1.0) / iter_times) * (pt2_y - pt1_y);
            resample.push_back(QRect(inter_x-5, inter_y-5,10,10));
        }
    }
    select_rect_paths->clear();
    for (int i = 0; i < resample.size(); ++i)
    {
        select_rect_paths->push_back(resample[i]);
    }
}

void EditViewer::setField(bool is_bridge, int res_idx)
{
    std::vector<double>feature_field_val(mesh_poly_->size_of_vertices(), std::numeric_limits<double>::max());
    for (auto i : feature_->features_draw_option_)
    {
        if (i.second == kDrawingOption::DRAW_SAVED_RES_NOTHING ||
            i.second == kDrawingOption::DRAW_SAVED_RES)
        {
            for (int j = 0; j < feature_->feature_scalar_field[i.first].size(); ++j)
            {
                feature_field_val[j] = std::min(feature_field_val[j],
                    feature_->feature_scalar_field[i.first][j]);
            }
        }
    }
    for (int i = 0; i < feature_field_val.size(); ++i)
    {
        feature_field_val[i] = logistic_1(feature_field_val[i]);
    }
    std::vector<double>line_field_val;
    if (is_bridge)
    {   
        line_field_val = mesh_poly_->vec_4_scalar_field_bridge[res_idx];
        sigma_field = mesh_poly_->sigma_field_bridges[res_idx];
        feature_field = mesh_poly_->feature_field_bridges[res_idx];
        //uncut_line_field = mesh_poly_->uncut_line_field_bridges[res_idx];
    }
    else
    {   
        line_field_val = mesh_poly_->vec_4_scalar_field[res_idx];
        sigma_field = mesh_poly_->sigma_field_paths[res_idx];
        feature_field = mesh_poly_->feature_field_paths[res_idx];
        //uncut_line_field = mesh_poly_->uncut_line_field_paths[res_idx];
    }
    for (int i = 0; i < line_field_val.size(); ++i)
    {
        line_field_val[i] = logistic_2(line_field_val[i]);
    }
    std::vector<double>field_val(line_field_val.size(), 0);
    for (int i = 0; i < line_field_val.size(); ++i)
    {
        field_val[i] = feature_field_val[i] / line_field_val[i];
    }
    double max_val = *(std::max_element(field_val.begin(), field_val.end()));
    double min_val = *(std::min_element(field_val.begin(), field_val.end()));

    for (int i = 0; i < field_val.size(); ++i)
    {
        field_val[i] = (max_val - field_val[i]) / (max_val - min_val);
        field_val[i] *= field_val[i];
    }
    field_color= std::vector<Eigen::Vector3d>(field_val.size());
    const Eigen::Vector3d up_val_color(247.0 / 255.0, 0, 0);
    const Eigen::Vector3d low_val_color(54.0 / 255.0, 43.0 / 255.0, 136.0 / 255.0);
    for (int i = 0; i < field_color.size(); ++i)
    {
        field_color[i] = field_val[i] * (up_val_color - low_val_color) + low_val_color;
    }

    {   
        sigma_field_color = std::vector<Eigen::Vector3d>(sigma_field.size());
        double max_val = 1;
        double min_val = 0;
        for (int i = 0; i < sigma_field.size(); ++i)
        {
            sigma_field_color[i] = std::min(1.0, sigma_field[i]) * (up_val_color - low_val_color) + low_val_color;
        }
    }
    {   
        feature_field_color = std::vector<Eigen::Vector3d>(feature_field.size());
        double max_val = *std::max_element(feature_field.begin(), feature_field.end());
        double min_val = *std::min_element(feature_field.begin(), feature_field.end());
        for (int i = 0; i < feature_field.size(); ++i)
        {
            feature_field_color[i] = std::min(1.0, std::abs(sigma_field[i]- uncut_line_field[i])) * (up_val_color - low_val_color) + low_val_color;
            
        }
        std::cout << "max_val" << std::endl;
        std::cout << *std::max_element(sigma_field.begin(), sigma_field.end()) << std::endl;;
    }
    {   
        uncut_line_field_color = std::vector<Eigen::Vector3d>(uncut_line_field.size());
        double max_val = *std::max_element(uncut_line_field.begin(), uncut_line_field.end());
        double min_val = *std::min_element(uncut_line_field.begin(), uncut_line_field.end());
        for (int i = 0; i < uncut_line_field.size(); ++i)
        {
            uncut_line_field_color[i] = std::min(1.0,uncut_line_field[i]) * (up_val_color - low_val_color) + low_val_color;
        }
    }
}

void EditViewer::drawSphere(double xc, double yc, double zc, double r)
{   
    int lats = 20; int longs = 20;
    int i, j;
    for (i = 0; i <= lats; i++) {
        double lat0 = M_PI * (-0.5 + (double)(i - 1) / lats);
        double z0 = sin(lat0);
        double zr0 = cos(lat0);

        double lat1 = M_PI * (-0.5 + (double)i / lats);
        double z1 = sin(lat1);
        double zr1 = cos(lat1);

        glBegin(GL_QUAD_STRIP);
        for (j = 0; j <= longs; j++) {
            double lng = 2 * M_PI * (double)(j - 1) / longs;
            double x = cos(lng);
            double y = sin(lng);

            glNormal3f(x * zr0, y * zr0, z0);
            glVertex3f(xc+r * x * zr0, yc+r * y * zr0, zc+r * z0);
            glNormal3f(x * zr1, y * zr1, z1);
            glVertex3f(xc+r * x * zr1, yc+r * y * zr1, zc+r * z1);
        }
        glEnd();
    }
}

void EditViewer::drawFields()
{       
    if (mesh_poly_ == NULL)
    {
        return;
    }
        glColor3ub(face_color.red(), face_color.green(), face_color.blue());
        glShadeModel(GL_SMOOTH);
        glEnable(GL_LIGHTING);
        glEnable(GL_AUTO_NORMAL);
        const qglviewer::Vec cameraPos = camera()->position();
        const GLfloat pos[4] = { (float)cameraPos[0], (float)cameraPos[1],
                                (float)cameraPos[2], 1.0f };
        glLightfv(GL_LIGHT1, GL_POSITION, pos);

        glLightfv(GL_LIGHT1, GL_SPOT_DIRECTION, camera()->viewDirection());


        glEnable(GL_POLYGON_OFFSET_FILL);
        glPolygonOffset(1, 1);
        glColor4f(face_color.redF(), face_color.greenF(), face_color.blueF(), draw_face_alpha);
        glBegin(GL_TRIANGLES);
        for (unsigned int i = 0; i < feature_->themesh->faces.size(); i++)
        {
            trimesh::TriMesh::Face* thisFace;
            thisFace = &(feature_->themesh->faces[i]);

            trimesh::vec& n0 = feature_->themesh->normals[(*thisFace)[0]];
            trimesh::vec& v0 = feature_->themesh->vertices[(*thisFace)[0]];
            {
                int v_i = (*thisFace)[0];
                if (draw_sigma_field)
                {
                    glColor3f(sigma_field_color[v_i].x(), sigma_field_color[v_i].y(), sigma_field_color[v_i].z());
                }
                if (draw_feature_field)
                {
                    glColor3f(feature_field_color[v_i].x(), feature_field_color[v_i].y(), feature_field_color[v_i].z());
                }
                if (draw_uncut_line_field)
                {
                    glColor3f(uncut_line_field_color[v_i].x(), uncut_line_field_color[v_i].y(), uncut_line_field_color[v_i].z());
                }
            }
            glNormal3d(n0[0], n0[1], n0[2]);
            glVertex3f(v0[0], v0[1], v0[2]);

            trimesh::vec& n1 = feature_->themesh->normals[(*thisFace)[1]];
            trimesh::vec& v1 = feature_->themesh->vertices[(*thisFace)[1]];
            {
                int v_i = (*thisFace)[1];
                if (draw_sigma_field)
                {
                    glColor3f(sigma_field_color[v_i].x(), sigma_field_color[v_i].y(), sigma_field_color[v_i].z());
                }
                if (draw_feature_field)
                {
                    glColor3f(feature_field_color[v_i].x(), feature_field_color[v_i].y(), feature_field_color[v_i].z());
                }
                if (draw_uncut_line_field)
                {
                    glColor3f(uncut_line_field_color[v_i].x(), uncut_line_field_color[v_i].y(), uncut_line_field_color[v_i].z());
                }
            }
                
            glNormal3d(n1[0], n1[1], n1[2]);
            glVertex3f(v1[0], v1[1], v1[2]);

            trimesh::vec& n2 = feature_->themesh->normals[(*thisFace)[2]];
            trimesh::vec& v2 = feature_->themesh->vertices[(*thisFace)[2]];
            {
                int v_i = (*thisFace)[2];
                if (draw_sigma_field)
                {
                    glColor3f(sigma_field_color[v_i].x(), sigma_field_color[v_i].y(), sigma_field_color[v_i].z());
                }
                if (draw_feature_field)
                {
                    glColor3f(feature_field_color[v_i].x(), feature_field_color[v_i].y(), feature_field_color[v_i].z());
                }
                if (draw_uncut_line_field)
                {
                    glColor3f(uncut_line_field_color[v_i].x(), uncut_line_field_color[v_i].y(), uncut_line_field_color[v_i].z());
                }
            }
            glNormal3d(n2[0], n2[1], n2[2]);
            glVertex3f(v2[0], v2[1], v2[2]);
        }

        glEnd();
        glDisable(GL_POLYGON_OFFSET_FILL);
        //glPopMatrix();
        glDisable(GL_LIGHTING);
        glDisable(GL_AUTO_NORMAL);
        //glDisable(GL_ALPHA_TEST);
        //glDepthMask(GL_TRUE);
}