#pragma once
#include <QGLViewer/qglviewer.h>
#include <CGAL/Polyhedron_3.h>
#include <CGAL/Polyhedron_items_with_id_3.h>
#include <CGAL/Exact_predicates_inexact_constructions_kernel.h>
#include "polygon.h"
#include "curve.h"

enum kMouse{DEFAULT,DRAW_USER_INPUT,DRAW_USEE_INPUT_PATH,SELECT_MODEL_PT,
    SELECT_ATTACH_PT,MOVE_CTRL_PT,MOVE_CTRL_PT_SOFT,CHOOSE_CURVE_PT,CHOOSE_MODEL_PT,CHOOSE_MODEL_FACE};
enum kEdit{NONE,ADD_CURVE,ATTACH_TO_CURVE,MODIFY_CURVE,SMOOTH_PART,USER_STUDY_CREATE,USER_STUDY_LINK, ANCHOR_PATH};
typedef CGAL::Exact_predicates_inexact_constructions_kernel Kernel;
typedef Kernel::Plane_3 Plane;
typedef Kernel::Line_3 Line;
typedef CGAL::Polyhedron_3<Kernel, CGAL::Polyhedron_items_with_id_3> Polyhedron;
#ifdef CGAL_USE_GMP
#include <CGAL/Gmpzf.h>
typedef CGAL::Gmpzf ET;
#else
#include <CGAL/MP_Float.h>
typedef CGAL::MP_Float ET;
#endif
class EditViewer : public QGLViewer {
    Q_OBJECT
signals:
    void Viewer_Sender();
    void Viewer_Frame(qglviewer::ManipulatedCameraFrame* _t1) ;

    void Viewer_AddCurve();
    void Viewer_AttachToCurve();
    void Viewer_ModifyCurve();
    void Viewer_SmoothPart();
    void Viewer_UserStudyCreateNewLine();
    void Viewer_UserStudyLineToLastLine();
    void Viewer_MoveCurveDone();

    void Viewer_AnchorPath();
    void Viewer_AnchorPathDone();

    void Viewer_MoveCamera();
    void Viewer_MoveCameraDone();
    void Viewer_RotateCamera();
    void Viewer_RotateCameraDone();
    void Viewer_ScaleCamera();
    void Viewer_ScaleCameraDone();
public:
    EditViewer(QWidget* parent);
    bool draw_face;
    bool draw_line;
    bool draw_vertex;
    bool draw_anchor_vertex;
    bool draw_segment;

    bool draw_field;
    bool res_got;
    int vertex_size;
    int line_width;
    bool draw_curve;
    bool draw_ctrlpts;
    bool draw_curvecyliner;
    bool draw_extend_pt;
    double draw_face_alpha;


    int cur_mouse;
    int cur_edit;

    Enriched_polyhedron<Kernel, Enriched_items>* mesh_poly_;
    Feature* feature_;
    QColor line_color;
    QColor vertex_color;
    QColor face_color;
    int *bridge_pt;
    int cur_mouse_near_pt_idx;
    std::vector<int>* selectPointsIndex;
    std::vector<bool>* is_pt_selected;
    std::vector<QRect>* selectRects;
    std::vector<QPoint>* user_input;
    std::vector<QRect>* select_rect_paths;
    segIO* seg;
    Curve* path_res;
    int *select_move_pt_idx_i;
    int *select_move_pt_idx_j;
    std::vector<std::vector<QRect>>* select_ctrl_pt_vec;
    QRect user_select_ctrl_pt_rect;
    bool is_drag;
    std::vector<int>* user_input_MST;
    
    //i -1 for model points
    int user_study_start_pt_idx_i;
    int user_study_start_pt_idx_j;
    int user_study_end_pt_idx_i;
    int user_study_end_pt_idx_j;

    int bind_face1;
    int bind_face2;


    std::vector<double>sigma_field;
    std::vector<double>feature_field;
    std::vector<double>uncut_line_field;

    std::vector<Eigen::Vector3d>sigma_field_color;
    std::vector<Eigen::Vector3d>feature_field_color;
    std::vector<Eigen::Vector3d>uncut_line_field_color;

    bool draw_sigma_field;
    bool draw_feature_field;
    bool draw_uncut_line_field;



    bool is_bridge_poly;
    int res_idx_poly;

    void updateMesh(Enriched_polyhedron<Kernel, Enriched_items>* mesh) { this->mesh_poly_ = mesh; };
    void backProject2Mesh(bool need_resample=false);
    void backProject2Mesh(std::vector<Eigen::Vector3d>& curve_projected);
    void cutPartFromMesh(std::vector<int>& nn_path_idx, bool is_bridge, int res_idx,bool Project2mesh);
    qglviewer::ManipulatedCameraFrame* getFrame() { return camera()->frame(); }
    void mouseChanged();
    void resample_input();
    void resample_rect();

    void setField(bool is_bridge, int res_idx);
    void updateField();
protected:
    virtual void draw();
    virtual void init();
    //virtual void drawOverpaint(QPainter* painter);
    virtual void mousePressEvent(QMouseEvent* e);
    virtual void mouseMoveEvent(QMouseEvent* e);
    virtual void mouseReleaseEvent(QMouseEvent* e);
    virtual void mouseDoubleClickEvent(QMouseEvent* e);
    virtual void wheelEvent(QWheelEvent* e);
    virtual void paintEvent(QPaintEvent* event);
    virtual void keyPressEvent(QKeyEvent* e);
private:
    inline float sign(qglviewer::Vec p1, qglviewer::Vec p2, qglviewer::Vec p3)
    {
        return (p1.x - p3.x) * (p2.y - p3.y) - (p2.x - p3.x) * (p1.y - p3.y);
    }

    inline bool PointInTriangle(qglviewer::Vec pt, qglviewer::Vec v1, qglviewer::Vec v2, qglviewer::Vec v3)
    {
        float d1, d2, d3;
        bool has_neg, has_pos;

        d1 = sign(pt, v1, v2);
        d2 = sign(pt, v2, v3);
        d3 = sign(pt, v3, v1);

        has_neg = (d1 < 0) || (d2 < 0) || (d3 < 0);
        has_pos = (d1 > 0) || (d2 > 0) || (d3 > 0);

        return !(has_neg && has_pos);
    }

    inline qglviewer::Vec intersection_pt(qglviewer::Vec plane_pt0, qglviewer::Vec plane_pt1, qglviewer::Vec plane_pt2,
        qglviewer::Vec ray_pt0, qglviewer::Vec ray_pt1)
    {
        //qglviewer::Vec plane_normal = qglviewer::cross(plane_pt0 - plane_pt1, plane_pt0 - plane_pt2);
        qglviewer::Vec plane_normal = (plane_pt0 - plane_pt1)^ (plane_pt0 - plane_pt2);
        plane_normal.normalize();

        qglviewer::Vec ray_dir = ray_pt0 - ray_pt0;
        ray_dir.normalize();
        qglviewer::Vec diff = ray_pt0 - plane_pt0;
        double prod1 = diff * plane_normal;
        double prod2 = ray_dir * plane_normal;
        double prod3 = prod1 / prod2;
        return ray_pt0 - ray_dir * prod3;
    }
    
    void drawMesh();
    void drawSegment();
    void drawPaths();
    void drawFeature();
    void drawUserInput(QPainter* painter);
    void drawArrows(QPainter* painter);
    void drawArrows(QPoint start_pt, QPoint end_pt, QPainter* painter);
    void drawFields();
    void drawSphere(double x, double y, double z, double r);
    std::vector<Eigen::Vector3d>field_color;
};