#include "feature.h"
Feature::Feature(std::string filename)
{
	themesh = trimesh::TriMesh::read(filename.c_str());
	themesh->need_neighbors();
	themesh->need_tstrips();
	themesh->need_bsphere();
	themesh->need_normals();
	themesh->need_curvatures();
	themesh->need_dcurv();
	compute_feature_size();
	currsmooth = 0.5f * themesh->feature_size();
	/*
	for (int i = 0; i < 25; ++i)
	{	
		std::vector<trimesh::vec>normals(themesh->normals.size(),trimesh::vec(0,0,0));
		std::vector<float>curv1(themesh->normals.size(), 0);
		std::vector<trimesh::Vec<4, float>>dcurv(themesh->normals.size(), trimesh::Vec<4, float>(0, 0, 0, 0));
		for (int j = 0; j < themesh->normals.size(); ++j)
		{
			for (int k = 0; k < themesh->neighbors[j].size(); k++)
			{
				normals[j] += themesh->normals[themesh->neighbors[j][k]];
				curv1[j]+= themesh->curv1[themesh->neighbors[j][k]];
				dcurv[j] += themesh->dcurv[themesh->neighbors[j][k]];
			}
			normals[j] /= themesh->neighbors[j].size();
			curv1[j] /= themesh->neighbors[j].size();
			dcurv[j] /= themesh->neighbors[j].size();
		}
		themesh->normals = normals;
		themesh->curv1 = curv1;
		themesh->dcurv = dcurv;
	}
	*/
	//sug_thresh = 0.01f;
	//sug_thresh = 0.2f;
	sug_thresh = 0.01f;
	sh_thresh = 0.02f;
	ntopo = 10;
	topo_offset = 0.0f;
	test_rv = 1;
	rv_thresh = 0.1;

	currcolor = Eigen::Vector4f(0, 0, 0, 1);

	features_draw_option_["silhouette"] = kDrawingOption::DRAW_IMMEDIATELY_NOTHING;
	features_draw_option_["topolines"] = kDrawingOption::DRAW_IMMEDIATELY_NOTHING;
	features_draw_option_["misc_K"] = kDrawingOption::DRAW_IMMEDIATELY_NOTHING;
	features_draw_option_["misc_H"] = kDrawingOption::DRAW_IMMEDIATELY_NOTHING;
	features_draw_option_["misc_DwKr"] = kDrawingOption::DRAW_IMMEDIATELY_NOTHING;
	features_draw_option_["ridges"] = kDrawingOption::DRAW_IMMEDIATELY_NOTHING;
	features_draw_option_["valleys"] = kDrawingOption::DRAW_IMMEDIATELY_NOTHING;
	features_draw_option_["suggestive highlights"] = kDrawingOption::DRAW_IMMEDIATELY_NOTHING;
	features_draw_option_["suggestive contours"] = kDrawingOption::DRAW_IMMEDIATELY_NOTHING;
	features_draw_option_["contours"] = kDrawingOption::DRAW_IMMEDIATELY_NOTHING;

	feature_vector_field["silhouette"] = std::vector < Eigen::RowVector3d>();
	feature_vector_field["topolines"] = std::vector < Eigen::RowVector3d>();
	feature_vector_field["misc_K"] = std::vector < Eigen::RowVector3d>();
	feature_vector_field["misc_H"] = std::vector < Eigen::RowVector3d>();
	feature_vector_field["misc_DwKr"] = std::vector < Eigen::RowVector3d>();
	feature_vector_field["ridges"] = std::vector < Eigen::RowVector3d>();
	feature_vector_field["valleys"] = std::vector < Eigen::RowVector3d>();
	feature_vector_field["suggestive highlights"] = std::vector < Eigen::RowVector3d>();
	feature_vector_field["suggestive contours"] = std::vector < Eigen::RowVector3d>();
	feature_vector_field["contours"] = std::vector < Eigen::RowVector3d>();

	feature_scalar_field["silhouette"] = std::vector <double>();
	feature_scalar_field["topolines"] = std::vector <double>();
	feature_scalar_field["misc_K"] = std::vector <double>();
	feature_scalar_field["misc_H"] = std::vector <double>();
	feature_scalar_field["misc_DwKr"] = std::vector <double>();
	feature_scalar_field["ridges"] = std::vector <double>();
	feature_scalar_field["valleys"] = std::vector <double>();
	feature_scalar_field["suggestive highlights"] = std::vector <double>();
	feature_scalar_field["suggestive contours"] = std::vector <double>();
	feature_scalar_field["contours"] = std::vector <double>();


	feature_paths["silhouette"] = std::vector<std::vector <int>>();
	feature_paths["topolines"] = std::vector<std::vector <int>>();
	feature_paths["misc_K"] = std::vector<std::vector <int>>();
	feature_paths["misc_H"] = std::vector<std::vector <int>>();
	feature_paths["misc_DwKr"] = std::vector<std::vector <int>>();
	feature_paths["ridges"] = std::vector<std::vector <int>>();
	feature_paths["valleys"] = std::vector<std::vector <int>>();
	feature_paths["suggestive highlights"] = std::vector<std::vector <int>>();
	feature_paths["suggestive contours"] = std::vector<std::vector <int>>();
	feature_paths["contours"] = std::vector<std::vector <int>>();

	user_input_feature = std::vector<std::vector<int>>();

	assemble_paths = std::vector < std::vector<int>>();
	assemble_smooth_paths = std::vector<std::vector<Eigen::Vector3d>>();
	len_min_edge = -1;
}

void Feature::compute_feature_size()
{
	int nv = themesh->curv1.size();
	int nsamp = std::min(nv, 500);

	std::vector<float> samples;
	samples.reserve(nsamp * 2);

	for (int i = 0; i < nsamp; i++) {
		// Quick 'n dirty portable random number generator
		static unsigned randq = 0;
		randq = unsigned(1664525) * randq + unsigned(1013904223);

		int ind = randq % nv;
		samples.push_back(fabs(themesh->curv1[ind]));
		samples.push_back(fabs(themesh->curv2[ind]));
	}

	const float frac = 0.1f;
	const float mult = 0.01f;
	themesh->need_bsphere();
	float max_feature_size = 0.05f * themesh->bsphere.r;

	int which = int(frac * samples.size());
	nth_element(samples.begin(), samples.begin() + which, samples.end());

	feature_size = std::min(mult / samples[which], max_feature_size);
}


void Feature::feature_update(Eigen::Matrix4f view)
{
	xf = view;
	/*How can this be wrong in release mode?
	auto viewpos_ = view.inverse() * Eigen::Vector4f(0, 0, 0, 1);
	viewpos = trimesh::vec(viewpos_.x(), viewpos_.y(), viewpos_.z());
	*/
	auto viewpos_ = view.inverse();
	viewpos = trimesh::vec(viewpos_(0,3), viewpos_(1, 3), viewpos_(2, 3));
	draw_feature();
}


void Feature::compute_perview(std::vector<float>& ndotv_, std::vector<float>& kr_,
	std::vector<float>& sctest_num_, std::vector<float>& sctest_den_,
	std::vector<float>& shtest_num_, std::vector<float>& q1_,
	std::vector<trimesh::vec2>& t1_, std::vector<float>& Dt1q1_,
	bool extra_sin2theta = false)
{
		themesh->need_adjacentfaces();

	int nv = themesh->vertices.size();

	float scthresh = sug_thresh / trimesh::sqr(feature_size);
	float shthresh = sh_thresh / trimesh::sqr(feature_size);
	bool need_DwKr = true;

	ndotv.resize(nv);
	kr.resize(nv);
	if (need_DwKr) {
		sctest_num.resize(nv);
		sctest_den.resize(nv);
		shtest_num.resize(nv);
	}

	// Compute quantities at each vertex
#pragma omp parallel for
	for (int i = 0; i < nv; i++) {
		// Compute n DOT v
		trimesh::vec viewdir = viewpos - themesh->vertices[i];
		float rlv = 1.0f / trimesh::len(viewdir);
		viewdir *= rlv;
		ndotv[i] = viewdir DOT themesh->normals[i];

		float u = viewdir DOT themesh->pdir1[i], u2 = u * u;
		float v = viewdir DOT themesh->pdir2[i], v2 = v * v;

		// Note:  this is actually Kr * sin^2 theta
		kr[i] = themesh->curv1[i] * u2 + themesh->curv2[i] * v2;

		
		if (!need_DwKr)
			continue;

		// Use DwKr * sin(theta) / cos(theta) for cutoff test
		sctest_num[i] = u2 * (u * themesh->dcurv[i][0] +
			3.0f * v * themesh->dcurv[i][1]) +
			v2 * (3.0f * u * themesh->dcurv[i][2] +
				v * themesh->dcurv[i][3]);
		float csc2theta = 1.0f / (u2 + v2);
		sctest_num[i] *= csc2theta;
		float tr = (themesh->curv2[i] - themesh->curv1[i]) *
			u * v * csc2theta;
		sctest_num[i] -= 2.0f * ndotv[i] * trimesh::sqr(tr);
		if (extra_sin2theta)
			sctest_num[i] *= u2 + v2;

		sctest_den[i] = ndotv[i];

		if (features_draw_option_["suggestive highlights"] != kDrawingOption::DRAW_IMMEDIATELY_NOTHING) {
			shtest_num[i] = -sctest_num[i];
			shtest_num[i] -= shthresh * sctest_den[i];
		}
		sctest_num[i] -= scthresh * sctest_den[i];
	}
}

void Feature::draw_feature()
{
	compute_perview(ndotv, kr, sctest_num, sctest_den, shtest_num,
		q1, t1, Dt1q1);
	//int nv = themesh->vertices.size();


	draw_silhouette(ndotv, this->features_draw_option_["silhouette"]);
	draw_topolines(ndotv, this->features_draw_option_["topolines"]);
	draw_misc_K(ndotv, this->features_draw_option_["misc_K"]);
	draw_misc_H(ndotv, this->features_draw_option_["misc_H"]);
	draw_misc_DwKr(ndotv, sctest_num, this->features_draw_option_["misc_DwKr"]);
	draw_ridges(this->features_draw_option_["ridges"]);
	draw_valleys(this->features_draw_option_["valleys"]);
	draw_sh(this->features_draw_option_["suggestive highlights"]);
	draw_sc(this->features_draw_option_["suggestive contours"]);
	draw_contour(this->features_draw_option_["contours"]);
}

void Feature::draw_silhouette(const std::vector<float>& ndotv_, int save_drawing_res)
{
	switch (save_drawing_res)
	{
	case kDrawingOption::DRAW_IMMEDIATELY:
		features_["silhouette"] = draw_isolines(ndotv_, std::vector<float>(), std::vector<float>(), ndotv_,
			false, false, false, 0.0f, save_drawing_res); break;
	case kDrawingOption::DRAW_SAVED_RES:
	case kDrawingOption::DRAW_IMMEDIATELY_NOTHING:
	case kDrawingOption::DRAW_SAVED_RES_NOTHING:
		break;
	}
}

void Feature::draw_misc_K(const std::vector<float>& ndotv_, int save_drawing_res)
{
	switch (save_drawing_res)
	{
	case kDrawingOption::DRAW_IMMEDIATELY:
		break;
	case kDrawingOption::DRAW_SAVED_RES:
	case kDrawingOption::DRAW_IMMEDIATELY_NOTHING:
	case kDrawingOption::DRAW_SAVED_RES_NOTHING:
		return;
	}
	std::vector<float>K(themesh->vertices.size());
	for (int i = 0; i < themesh->vertices.size(); i++)
	{
		K[i]= themesh->curv1[i] * themesh->curv2[i];
	}
	features_["misc_K"]=draw_isolines(K, std::vector<float>(), std::vector<float>(), ndotv_,
		false, false, false, 0.0f,save_drawing_res);
}

void Feature::draw_misc_H(const std::vector<float>& ndotv_, int save_drawing_res)
{
	switch (save_drawing_res)
	{
	case kDrawingOption::DRAW_IMMEDIATELY:
		break;
	case kDrawingOption::DRAW_SAVED_RES:
	case kDrawingOption::DRAW_IMMEDIATELY_NOTHING:
	case kDrawingOption::DRAW_SAVED_RES_NOTHING:
		return;
	}
	std::vector<float>H(themesh->vertices.size());
	for (int i = 0; i < themesh->vertices.size(); i++)
	{
		H[i] = 0.5*(themesh->curv1[i] * themesh->curv2[i]);
	}
	features_["misc_H"] = draw_isolines(H, std::vector<float>(), std::vector<float>(), ndotv_,
		false, false, false, 0.0f, save_drawing_res);
}

void Feature::draw_misc_DwKr(const std::vector<float>& ndotv_, const std::vector<float>& DwKr_,int save_drawing_res)
{
	switch (save_drawing_res)
	{
	case kDrawingOption::DRAW_IMMEDIATELY:
		break;
	case kDrawingOption::DRAW_SAVED_RES:
	case kDrawingOption::DRAW_IMMEDIATELY_NOTHING:
	case kDrawingOption::DRAW_SAVED_RES_NOTHING:
		return;
	}
	features_["misc_DwKr"] = draw_isolines(DwKr_, std::vector<float>(), std::vector<float>(), ndotv_,
		false, false, false, 0.0f, save_drawing_res);
}

std::vector<Eigen::RowVector4d> Feature::draw_isolines(const std::vector<float>& val_,
	const std::vector<float>& test_num_,
	const std::vector<float>& test_den_,
	const std::vector<float>& ndotv_,
	bool do_bfcull, bool do_hermite,
	bool do_test, float fade,
	int save_drawing_res)
{
	const int* t = &themesh->tstrips[0];
	const int* stripend = t;
	const int* end = t + themesh->tstrips.size();
	std::vector<Eigen::RowVector4d>line_with_color;
	// Walk through triangle strips
	while (1) 
	{
		if (unlikely(t >= stripend)) 
		{
			if (unlikely(t >= end))
				return line_with_color;
			// New strip: each strip is stored as
			// length followed by indices
			stripend = t + 1 + *t;
			// Skip over length plus first two indices of
			// first face
			t += 3;
		}
		// Draw a line if, among the values in this triangle,
		// at least one is positive and one is negative
		const float& v0 = val_[*t], & v1 = val_[*(t - 1)], & v2 = val_[*(t - 2)];
		if (unlikely((v0 > 0.0f || v1 > 0.0f || v2 > 0.0f) &&
			(v0 < 0.0f || v1 < 0.0f || v2 < 0.0f)))
		{
			auto return_vec = draw_face_isoline(*(t - 2), *(t - 1), *t,
				val_, test_num_, test_den_, ndotv,
				do_bfcull, do_hermite, do_test, fade, save_drawing_res);
			line_with_color.insert(line_with_color.end(), return_vec.begin(), return_vec.end());
		}
		t++;
	}
	return line_with_color;
}

std::vector<Eigen::RowVector4d> Feature::draw_face_isoline(int v0, int v1, int v2,
	const std::vector<float>& val_,
	const std::vector<float>& test_num_,
	const std::vector<float>& test_den_,
	const std::vector<float>& ndotv_,
	bool do_bfcull, bool do_hermite,
	bool do_test, float fade,
	int save_drawing_res)
{
	// Backface culling
	if (likely(do_bfcull && ndotv_[v0] <= 0.0f &&
		ndotv_[v1] <= 0.0f && ndotv_[v2] <= 0.0f))
		return std::vector<Eigen::RowVector4d>();

	// Quick reject if derivs are negative
	if (do_test) {
		if (test_den_.empty()) {
			if (test_num_[v0] <= 0.0f &&
				test_num_[v1] <= 0.0f &&
				test_num_[v2] <= 0.0f)
				return std::vector<Eigen::RowVector4d>();
		}
		else {
			if (test_num_[v0] <= 0.0f && test_den_[v0] >= 0.0f &&
				test_num_[v1] <= 0.0f && test_den_[v1] >= 0.0f &&
				test_num_[v2] <= 0.0f && test_den_[v2] >= 0.0f)
				return std::vector<Eigen::RowVector4d>();
			if (test_num_[v0] >= 0.0f && test_den_[v0] <= 0.0f &&
				test_num_[v1] >= 0.0f && test_den_[v1] <= 0.0f &&
				test_num_[v2] >= 0.0f && test_den_[v2] <= 0.0f)
				return std::vector<Eigen::RowVector4d>();
		}
	}

	// Figure out which val has different sign, and draw
	if ((val_[v0] < 0.0f && val_[v1] >= 0.0f && val_[v2] >= 0.0f) ||
		(val_[v0] > 0.0f && val_[v1] <= 0.0f && val_[v2] <= 0.0f))
		return draw_face_isoline2(v0, v1, v2,
			val_, test_num_, test_den_,
			do_hermite, do_test, fade, save_drawing_res);
	else if ((val_[v1] < 0.0f && val_[v2] >= 0.0f && val_[v0] >= 0.0f) ||
		(val_[v1] > 0.0f && val_[v2] <= 0.0f && val_[v0] <= 0.0f))
		return draw_face_isoline2(v1, v2, v0,
			val_, test_num_, test_den_,
			do_hermite, do_test, fade, save_drawing_res);
	else if ((val_[v2] < 0.0f && val_[v0] >= 0.0f && val_[v1] >= 0.0f) ||
		(val_[v2] > 0.0f && val_[v0] <= 0.0f && val_[v1] <= 0.0f))
		return draw_face_isoline2(v2, v0, v1,
			val_, test_num_, test_den_,
			do_hermite, do_test, fade, save_drawing_res);
}

std::vector<Eigen::RowVector4d> Feature::draw_face_isoline2(int v0, int v1, int v2,
	const std::vector<float>& val_,
	const std::vector<float>& test_num_,
	const std::vector<float>& test_den_,
	bool do_hermite, bool do_test, float fade, int save_drawing_res)
{
	// How far along each edge?
	float w10 = do_hermite ?
		find_zero_hermite(v0, v1, val_[v0], val_[v1],
			gradkr(v0), gradkr(v1)) :
		find_zero_linear(val_[v0], val_[v1]);
	float w01 = 1.0f - w10;
	float w20 = do_hermite ?
		find_zero_hermite(v0, v2, val_[v0], val_[v2],
			gradkr(v0), gradkr(v2)) :
		find_zero_linear(val_[v0], val_[v2]);
	float w02 = 1.0f - w20;

	// Points along edges
	trimesh::point p1 = w01 * themesh->vertices[v0] + w10 * themesh->vertices[v1];
	trimesh::point p2 = w02 * themesh->vertices[v0] + w20 * themesh->vertices[v2];

	float test_num1 = 1.0f, test_num2 = 1.0f;
	float test_den1 = 1.0f, test_den2 = 1.0f;
	float z1 = 0.0f, z2 = 0.0f;
	bool valid1 = true;
	if (do_test) {
		// Interpolate to find value of test at p1, p2
		test_num1 = w01 * test_num_[v0] + w10 * test_num_[v1];
		test_num2 = w02 * test_num_[v0] + w20 * test_num_[v2];
		if (!test_den_.empty()) {
			test_den1 = w01 * test_den_[v0] + w10 * test_den_[v1];
			test_den2 = w02 * test_den_[v0] + w20 * test_den_[v2];
		}
		// First point is valid iff num1/den1 is positive,
		// i.e. the num and den have the same sign
		valid1 = ((test_num1 >= 0.0f) == (test_den1 >= 0.0f));
		// There are two possible zero crossings of the test,
		// corresponding to zeros of the num and den
		if ((test_num1 >= 0.0f) != (test_num2 >= 0.0f))
			z1 = test_num1 / (test_num1 - test_num2);
		if ((test_den1 >= 0.0f) != (test_den2 >= 0.0f))
			z2 = test_den1 / (test_den1 - test_den2);
		// Sort and order the zero crossings
		if (z1 == 0.0f)
			z1 = z2, z2 = 0.0f;
		else if (z2 < z1)
			std::swap(z1, z2);
	}

	std::vector<Eigen::RowVector4d>line_with_color;
	// If the beginning of the segment was not valid, and
	// no zero crossings, then whole segment invalid
	if (!valid1 && !z1 && !z2)
		return line_with_color;

	// Draw the valid piece(s)
	int npts = 0;
	if (valid1) {
		/*glColor4f(currcolor[0], currcolor[1], currcolor[2],
			test_num1 / (test_den1 * fade + test_num1));
		glVertex3fv(p1);*/
		line_with_color.push_back(Eigen::RowVector4d(currcolor[0], currcolor[1], currcolor[2],
			test_num1 / (test_den1 * fade + test_num1)));
		line_with_color.push_back(Eigen::RowVector4d(p1.x, p1.y, p1.z, 0));
		npts++;
	}
	if (z1) {
		float num = (1.0f - z1) * test_num1 + z1 * test_num2;
		float den = (1.0f - z1) * test_den1 + z1 * test_den2;
		/*glColor4f(currcolor[0], currcolor[1], currcolor[2],
			num / (den * fade + num));
		glVertex3fv((1.0f - z1) * p1 + z1 * p2);*/
		auto pt = (1.0f - z1) * p1 + z1 * p2;
		line_with_color.push_back(Eigen::RowVector4d(currcolor[0], currcolor[1], currcolor[2],
			num / (den * fade + num)));
		line_with_color.push_back(Eigen::RowVector4d(pt.x, pt.y, pt.z, 0));
		npts++;
	}
	if (z2) {
		float num = (1.0f - z2) * test_num1 + z2 * test_num2;
		float den = (1.0f - z2) * test_den1 + z2 * test_den2;
		/*glColor4f(currcolor[0], currcolor[1], currcolor[2],
			num / (den * fade + num));
		glVertex3fv((1.0f - z2) * p1 + z2 * p2);*/
		auto pt = (1.0f - z2) * p1 + z2 * p2;
		line_with_color.push_back(Eigen::RowVector4d(currcolor[0], currcolor[1], currcolor[2],
			num / (den * fade + num)));
		line_with_color.push_back(Eigen::RowVector4d(pt.x, pt.y, pt.z, 0));
		npts++;
	}
	if (npts != 2) {
		/*glColor4f(currcolor[0], currcolor[1], currcolor[2],
			test_num2 / (test_den2 * fade + test_num2));
		glVertex3fv(p2);*/
		line_with_color.push_back(Eigen::RowVector4d(currcolor[0], currcolor[1], currcolor[2],
			test_num2 / (test_den2 * fade + test_num2)));
		line_with_color.push_back(Eigen::RowVector4d(p2.x, p2.y, p2.z, 0));
	}

	int f_id = vertex_intersection_face(themesh->adjacentfaces[v0],
		themesh->adjacentfaces[v1], themesh->adjacentfaces[v2]);
	if (line_with_color.size() > 4)
	{
		line_with_color.insert(line_with_color.begin() + 4, (Eigen::RowVector4d(f_id,0,0,0)));
	}
	line_with_color.insert(line_with_color.end(), (Eigen::RowVector4d(f_id, 0, 0, 0)));
	return line_with_color;
}

float Feature::find_zero_hermite(int v0, int v1, float val0, float val1,
	const trimesh::vec& grad0, const trimesh::vec& grad1)
{
	if (unlikely(val0 == val1))
		return 0.5f;

	// Find derivatives along edge (of interpolation parameter in [0,1]
	// which means that e01 doesn't get normalized)
	trimesh::vec e01 = themesh->vertices[v1] - themesh->vertices[v0];
	float d0 = e01 DOT grad0, d1 = e01 DOT grad1;

	// This next line would reduce val to linear interpolation
	//d0 = d1 = (val1 - val0);

	// Use hermite interpolation:
	//   val(s) = h1(s)*val0 + h2(s)*val1 + h3(s)*d0 + h4(s)*d1
	// where
	//  h1(s) = 2*s^3 - 3*s^2 + 1
	//  h2(s) = 3*s^2 - 2*s^3
	//  h3(s) = s^3 - 2*s^2 + s
	//  h4(s) = s^3 - s^2
	//
	//  val(s)  = [2(val0-val1) +d0+d1]*s^3 +
	//            [3(val1-val0)-2d0-d1]*s^2 + d0*s + val0
	// where
	//
	//  val(0) = val0; val(1) = val1; val'(0) = d0; val'(1) = d1
	//

	// Coeffs of cubic a*s^3 + b*s^2 + c*s + d
	float a = 2 * (val0 - val1) + d0 + d1;
	float b = 3 * (val1 - val0) - 2 * d0 - d1;
	float c = d0, d = val0;

	// -- Find a root by bisection
	// (as Newton can wander out of desired interval)

	// Start with entire [0,1] interval
	float sl = 0.0f, sr = 1.0f, valsl = val0, valsr = val1;

	// Check if we're in a (somewhat uncommon) 3-root situation, and pick
	// the middle root if it happens (given we aren't drawing curvy lines,
	// seems the best approach..)
	//
	// Find extrema of derivative (a -> 3a; b -> 2b, c -> c),
	// and check if they're both in [0,1] and have different signs
	float disc = 4 * b - 12 * a * c;
	if (disc > 0 && a != 0) {
		disc = sqrt(disc);
		float r1 = (-2 * b + disc) / (6 * a);
		float r2 = (-2 * b - disc) / (6 * a);
		if (r1 >= 0 && r1 <= 1 && r2 >= 0 && r2 <= 1) {
			float vr1 = (((a * r1 + b) * r1 + c) * r1) + d;
			float vr2 = (((a * r2 + b) * r2 + c) * r2) + d;
			// When extrema have different signs inside an
			// interval with endpoints with different signs,
			// the middle root is in between the two extrema
			if ((vr1 < 0.0f && vr2 >= 0.0f) ||
				(vr1 > 0.0f && vr2 <= 0.0f)) {
				// 3 roots
				if (r1 < r2) {
					sl = r1;
					valsl = vr1;
					sr = r2;
					valsr = vr2;
				}
				else {
					sl = r2;
					valsl = vr2;
					sr = r1;
					valsr = vr1;
				}
			}
		}
	}

	// Bisection method (constant number of interations)
	for (int iter = 0; iter < 10; iter++) {
		float sbi = (sl + sr) / 2.0f;
		float valsbi = (((a * sbi + b) * sbi) + c) * sbi + d;

		// Keep the half which has different signs
		if ((valsl < 0.0f && valsbi >= 0.0f) ||
			(valsl > 0.0f && valsbi <= 0.0f)) {
			sr = sbi;
			valsr = valsbi;
		}
		else {
			sl = sbi;
			valsl = valsbi;
		}
	}

	return 0.5f * (sl + sr);
}

void Feature::draw_topolines(const std::vector<float>& ndotv_, int save_drawing_res)
{	
	switch (save_drawing_res)
	{
	case kDrawingOption::DRAW_IMMEDIATELY:
		break;
	case kDrawingOption::DRAW_SAVED_RES:
	case kDrawingOption::DRAW_IMMEDIATELY_NOTHING:
	case kDrawingOption::DRAW_SAVED_RES_NOTHING:
		return;
	}
	trimesh::vec camdir(xf(0, 2), xf(1, 2), xf(3, 2));
	float depth_scale = 0.5f / themesh->bsphere.r * ntopo;
	float depth_offset = 0.5f * ntopo - topo_offset;
	std::vector<Eigen::RowVector4d>line_with_color;
	// Compute depth
	static std::vector<float> depth;
	int nv = themesh->vertices.size();
	depth.resize(nv);
	for (int i = 0; i < nv; i++) {
		depth[i] = ((themesh->vertices[i] - themesh->bsphere.center)
			DOT camdir) * depth_scale + depth_offset;
	}

	// Draw the topo lines
	for (int it = 0; it < ntopo; it++)
	{
		auto return_res = draw_isolines(depth, std::vector<float>(), std::vector<float>(),
			ndotv_, true, false, false, 0.0f, save_drawing_res);
		line_with_color.insert(line_with_color.end(), return_res.begin(), return_res.end());
		for (int i = 0; i < nv; i++)
			depth[i] -= 1.0f;
	}
	features_["topolines"] = line_with_color;
}

std::vector<Eigen::RowVector4d> Feature::draw_mesh_ridges(bool do_ridge, const std::vector<float>& ndotv_,
	bool do_bfcull, bool do_test, float thresh)
{
	const int* t = &themesh->tstrips[0];
	const int* stripend = t;
	const int* end = t + themesh->tstrips.size();

	std::vector<Eigen::RowVector4d>line_with_color;
	// Walk through triangle strips
	while (1) 
	{
		if (unlikely(t >= stripend)) 
		{
			if (unlikely(t >= end))
				break;
			// New strip: each strip is stored as
			// length followed by indices
			stripend = t + 1 + *t;
			// Skip over length plus first two indices of
			// first face
			t += 3;
		}

		auto return_res=draw_face_ridges(*(t - 2), *(t - 1), *t,
			do_ridge, ndotv_, do_bfcull, do_test, thresh);
		line_with_color.insert(line_with_color.end(), return_res.begin(), return_res.end());
		t++;
	}
	return line_with_color;
}

std::vector<Eigen::RowVector4d> Feature::draw_face_ridges(int v0, int v1, int v2,
	bool do_ridge,
	const std::vector<float>& ndotv_,
	bool do_bfcull, bool do_test, float thresh)
{
	// Backface culling
	if (likely(do_bfcull &&
		ndotv_[v0] <= 0.0f && ndotv_[v1] <= 0.0f && ndotv_[v2] <= 0.0f))
		return std::vector<Eigen::RowVector4d>();

	// Check if ridge possible at vertices just based on curvatures
	if (do_ridge) {
		if ((themesh->curv1[v0] <= 0.0f) ||
			(themesh->curv1[v1] <= 0.0f) ||
			(themesh->curv1[v2] <= 0.0f))
			return std::vector<Eigen::RowVector4d>();
	}
	else {
		if ((themesh->curv1[v0] >= 0.0f) ||
			(themesh->curv1[v1] >= 0.0f) ||
			(themesh->curv1[v2] >= 0.0f))
			return std::vector<Eigen::RowVector4d>();
	}

	// Sign of curvature on ridge/valley
	float rv_sign = do_ridge ? 1.0f : -1.0f;

	// The "tmax" are the principal directions of maximal curvature,
	// flipped to point in the direction in which the curvature
	// is increasing (decreasing for valleys).  Note that this
	// is a bit different from the notation in Ohtake et al.,
	// but the tests below are equivalent.
	const float& emax0 = themesh->dcurv[v0][0];
	const float& emax1 = themesh->dcurv[v1][0];
	const float& emax2 = themesh->dcurv[v2][0];
	trimesh::vec tmax0 = rv_sign * themesh->dcurv[v0][0] * themesh->pdir1[v0];
	trimesh::vec tmax1 = rv_sign * themesh->dcurv[v1][0] * themesh->pdir1[v1];
	trimesh::vec tmax2 = rv_sign * themesh->dcurv[v2][0] * themesh->pdir1[v2];

	// We have a "zero crossing" if the tmaxes along an edge
	// point in opposite directions
	bool z01 = ((tmax0 DOT tmax1) <= 0.0f);
	bool z12 = ((tmax1 DOT tmax2) <= 0.0f);
	bool z20 = ((tmax2 DOT tmax0) <= 0.0f);

	if (z01 + z12 + z20 < 2)
		return std::vector<Eigen::RowVector4d>();

	if (do_test) {
		const trimesh::point& p0 = themesh->vertices[v0],
			& p1 = themesh->vertices[v1],
			& p2 = themesh->vertices[v2];

		// Check whether we have the correct flavor of extremum:
		// Is the curvature increasing along the edge?
		z01 = z01 && ((tmax0 DOT(p1 - p0)) >= 0.0f ||
			(tmax1 DOT(p1 - p0)) <= 0.0f);
		z12 = z12 && ((tmax1 DOT(p2 - p1)) >= 0.0f ||
			(tmax2 DOT(p2 - p1)) <= 0.0f);
		z20 = z20 && ((tmax2 DOT(p0 - p2)) >= 0.0f ||
			(tmax0 DOT(p0 - p2)) <= 0.0f);

		if (z01 + z12 + z20 < 2)
			return std::vector<Eigen::RowVector4d>();
	}

	// Draw line segment
	const float& kmax0 = themesh->curv1[v0];
	const float& kmax1 = themesh->curv1[v1];
	const float& kmax2 = themesh->curv1[v2];
	if (!z01) {
		return draw_segment_ridge(v1, v2, v0,
			emax1, emax2, emax0,
			kmax1, kmax2, kmax0,
			thresh, false);
	}
	else if (!z12) {
		return draw_segment_ridge(v2, v0, v1,
			emax2, emax0, emax1,
			kmax2, kmax0, kmax1,
			thresh, false);
	}
	else if (!z20) {
		return draw_segment_ridge(v0, v1, v2,
			emax0, emax1, emax2,
			kmax0, kmax1, kmax2,
			thresh, false);
	}
	else {
		// All three edges have crossings -- connect all to center
		std::vector<Eigen::RowVector4d> line_with_color;
		auto return_res=draw_segment_ridge(v1, v2, v0,
			emax1, emax2, emax0,
			kmax1, kmax2, kmax0,
			thresh, true);
		line_with_color.insert(line_with_color.end(), return_res.begin(), return_res.end());
		return_res=draw_segment_ridge(v2, v0, v1,
			emax2, emax0, emax1,
			kmax2, kmax0, kmax1,
			thresh, true);
		line_with_color.insert(line_with_color.end(), return_res.begin(), return_res.end());
		return_res=draw_segment_ridge(v0, v1, v2,
			emax0, emax1, emax2,
			kmax0, kmax1, kmax2,
			thresh, true);
		line_with_color.insert(line_with_color.end(), return_res.begin(), return_res.end());
		return line_with_color;
	}
}

std::vector<Eigen::RowVector4d> Feature::draw_segment_ridge(int v0, int v1, int v2,
	float emax0, float emax1, float emax2,
	float kmax0, float kmax1, float kmax2,
	float thresh, bool to_center)
{
	// Interpolate to find ridge/valley line segment endpoints
	// in this triangle and the curvatures there
	float w10 = fabs(emax0) / (fabs(emax0) + fabs(emax1));
	float w01 = 1.0f - w10;
	trimesh::point p01 = w01 * themesh->vertices[v0] + w10 * themesh->vertices[v1];
	float k01 = fabs(w01 * kmax0 + w10 * kmax1);

	trimesh::point p12;
	float k12;
	if (to_center) {
		// Connect first point to center of triangle
		p12 = (themesh->vertices[v0] +
			themesh->vertices[v1] +
			themesh->vertices[v2]) / 3.0f;
		k12 = fabs(kmax0 + kmax1 + kmax2) / 3.0f;
	}
	else {
		// Connect first point to second one (on next edge)
		float w21 = fabs(emax1) / (fabs(emax1) + fabs(emax2));
		float w12 = 1.0f - w21;
		p12 = w12 * themesh->vertices[v1] + w21 * themesh->vertices[v2];
		k12 = fabs(w12 * kmax1 + w21 * kmax2);
	}

	// Don't draw below threshold
	k01 -= thresh;
	if (k01 < 0.0f)
		k01 = 0.0f;
	k12 -= thresh;
	if (k12 < 0.0f)
		k12 = 0.0f;

	// Skip lines that you can't see...
	if (k01 == 0.0f && k12 == 0.0f)
		return std::vector<Eigen::RowVector4d>();

	// Fade lines
	/*
	if (draw_faded) {
		k01 /= (k01 + thresh);
		k12 /= (k12 + thresh);
	}
	else {
		k01 = k12 = 1.0f;
	}
	*/
	k01 = k12 = 1.0f;
	// Draw the line segment
	/*
	glColor4f(currcolor[0], currcolor[1], currcolor[2], k01);
	glVertex3fv(p01);
	glColor4f(currcolor[0], currcolor[1], currcolor[2], k12);
	glVertex3fv(p12);
	*/
	std::vector<Eigen::RowVector4d>line_with_color;
	line_with_color.push_back(Eigen::RowVector4d(currcolor[0], currcolor[1], currcolor[2],k01));
	line_with_color.push_back(Eigen::RowVector4d(p01.x, p01.y, p01.z, 0));
	line_with_color.push_back(Eigen::RowVector4d(currcolor[0], currcolor[1], currcolor[2], k12));
	line_with_color.push_back(Eigen::RowVector4d(p12.x, p12.y, p12.z, 0));
	int f_id = vertex_intersection_face(themesh->adjacentfaces[v0],
		themesh->adjacentfaces[v1], themesh->adjacentfaces[v2]);
	line_with_color.insert(line_with_color.end(), (Eigen::RowVector4d(f_id, 0, 0, 0)));
	return line_with_color;
}

void Feature::draw_ridges(int save_drawing_res)
{
	switch (save_drawing_res)
	{
	case kDrawingOption::DRAW_IMMEDIATELY:
		break;
	case kDrawingOption::DRAW_SAVED_RES:
	case kDrawingOption::DRAW_IMMEDIATELY_NOTHING:
	case kDrawingOption::DRAW_SAVED_RES_NOTHING:
		return;
	}
	features_["ridges"] = draw_mesh_ridges(true, ndotv, false, test_rv,
		rv_thresh / feature_size);
}

void Feature::draw_valleys(int save_drawing_res)
{
	switch (save_drawing_res)
	{
	case kDrawingOption::DRAW_IMMEDIATELY:
		break;
	case kDrawingOption::DRAW_SAVED_RES:
	case kDrawingOption::DRAW_IMMEDIATELY_NOTHING:
	case kDrawingOption::DRAW_SAVED_RES_NOTHING:
		return;
	}
	features_["ridges"] = draw_mesh_ridges(false, ndotv, false, test_rv,
		rv_thresh / feature_size);
}

void Feature::draw_sh(int save_drawing_res)
{
	switch (save_drawing_res)
	{
	case kDrawingOption::DRAW_IMMEDIATELY:
		break;
	case kDrawingOption::DRAW_SAVED_RES:
	case kDrawingOption::DRAW_IMMEDIATELY_NOTHING:
	case kDrawingOption::DRAW_SAVED_RES_NOTHING:
		return;
	}
	features_["suggestive highlights"] = draw_mesh_ridges(false, ndotv, false, test_rv,
		rv_thresh / feature_size);
}

void Feature::draw_sc(int save_drawing_res)
{
	switch (save_drawing_res)
	{
	case kDrawingOption::DRAW_IMMEDIATELY:
		break;
	case kDrawingOption::DRAW_SAVED_RES:
	case kDrawingOption::DRAW_IMMEDIATELY_NOTHING:
	case kDrawingOption::DRAW_SAVED_RES_NOTHING:
		return;
	}
	features_["suggestive contours"] = draw_isolines(kr, sctest_num, sctest_den, ndotv,
		false, 0, 1, 0,save_drawing_res);
}
void Feature::draw_contour(int save_drawing_res)
{
	switch (save_drawing_res)
	{
	case kDrawingOption::DRAW_IMMEDIATELY:
		break;
	case kDrawingOption::DRAW_SAVED_RES:
	case kDrawingOption::DRAW_IMMEDIATELY_NOTHING:
	case kDrawingOption::DRAW_SAVED_RES_NOTHING:
		return;
	}
	features_["contours"] = draw_isolines(ndotv, kr, std::vector<float>(), ndotv,
		false, false, 1, 0.0f,save_drawing_res);
}

void Feature::merge_stripes_pipeline()
{
	for (auto i : features_)
	{
		if (features_draw_option_[i.first] == kDrawingOption::DRAW_SAVED_RES)
		{	
			initialise_stripes(i.first);
			std::vector<size_t>ret_idx; 
			std::vector<double>out_dists_sqr;
			builNNindex(i.first, ret_idx, out_dists_sqr);
			for (int j = 0;; ++j)
			{	
				//////std::cout << j << std::endl;
				std::size_t pre_size=feature_lines[i.first].size();
				merge_strips(i.first, ret_idx, out_dists_sqr);
				if (feature_lines[i.first].size() == pre_size)
				{
					break;
				}
				builNNindex(i.first, ret_idx, out_dists_sqr);
			}
		}
	}
}

void Feature::initialise_stripes(std::string feature_type)
{	
	feature_lines[feature_type] = std::vector<std::vector<Eigen::RowVector3d>>(features_[feature_type].size() / 5);
	feature_lines_cross_faces[feature_type] = std::vector<std::vector<int>>(features_[feature_type].size() / 5);
	for (size_t i = 0; i < (features_[feature_type].size()/5); ++i)
	{
		feature_lines[feature_type][i].push_back(Eigen::RowVector3d(features_[feature_type][i * 5 + 1].data()));
		feature_lines[feature_type][i].push_back(Eigen::RowVector3d(features_[feature_type][i * 5 + 3].data()));
		feature_lines_cross_faces[feature_type][i].push_back(static_cast<int>(features_[feature_type][i * 5 + 4].x()));
		feature_lines_cross_faces[feature_type][i].push_back(feature_lines_cross_faces[feature_type][i].back());
	}
	features_[feature_type].clear();
}

void Feature::builNNindex(std::string feature_type,std::vector<size_t>&ret_idx, std::vector<double>&out_dists_sqr)
{	
	Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic> mat(feature_lines[feature_type].size()*2, 3);
	for (int i = 0; i < feature_lines[feature_type].size(); ++i)
	{
		mat.row(i * 2) = feature_lines[feature_type][i].front();
		mat.row(i * 2 + 1) = feature_lines[feature_type][i].back();
	}
	my_kd_tree_t mat_index(3, mat, 10);
	mat_index.index->buildIndex();

	const std::size_t num_results = 6;
	ret_idx=std::vector<size_t>(2*num_results* feature_lines[feature_type].size());
	out_dists_sqr=std::vector<double>(2*num_results * feature_lines[feature_type].size());

	for (int i = 0; i < feature_lines[feature_type].size(); ++i)
	{
		//std::vectorquery_pt;
		//query_pt.insert(query_pt.end(), feature_lines[feature_type][i].front().data(), 
		//	feature_lines[feature_type][i].front().data() + 3);
		nanoflann::KNNResultSet<double>resultSet(num_results);
		resultSet.init(ret_idx.data()+(i*2*num_results), out_dists_sqr.data()+(i*2*num_results));
		mat_index.index->findNeighbors(resultSet, feature_lines[feature_type][i].front().data(), nanoflann::SearchParams(128));

		//query_pt.clear();
		resultSet= nanoflann::KNNResultSet<double>(num_results);
		//query_pt.insert(query_pt.end(), feature_lines[feature_type][i].back().data(),
		//	feature_lines[feature_type][i].back().data() + 3);
		resultSet.init(ret_idx.data() + ((i * 2 +1)* num_results), out_dists_sqr.data() + ((i * 2 + 1) * num_results));
		mat_index.index->findNeighbors(resultSet, feature_lines[feature_type][i].back().data(), nanoflann::SearchParams(128));
	}
}

void Feature::merge_strips(std::string feature_type, std::vector<size_t>& ret_idx, std::vector<double>& out_dists_sqr)
{
	double max_NN_dist = get_model_min_edge();
	int num_NN_ = 6;
	for (std::size_t i = 0; i < feature_lines[feature_type].size(); ++i)
	{
		for (std::size_t j = 0; j < num_NN_; ++j)
		{
			size_t idx_i_pt1 = 2 * i, idx_i_pt2 = 2 * i + 1;
			size_t idx_NN_pt1 = ret_idx[idx_i_pt1 * num_NN_+j];
			size_t idx_NN_pt2 = ret_idx[idx_i_pt2 * num_NN_+j];
			size_t idx_i, idx_NN;
			if (out_dists_sqr[idx_i_pt1] <= out_dists_sqr[idx_i_pt2])
			{
				idx_i = idx_i_pt1;
				idx_NN = idx_NN_pt1;
				if (out_dists_sqr[idx_i] > max_NN_dist)
				{
					break;
				}
				if ((idx_i / 2) == (idx_NN / 2))
				{
					if (out_dists_sqr[idx_i_pt2] < max_NN_dist)
					{
						idx_i = idx_i_pt2;
						idx_NN = idx_NN_pt2;
					}
					else
					{
						break;
					}
				}
			}
			else
			{
				idx_i = idx_i_pt2;
				idx_NN = idx_NN_pt2;
				if (out_dists_sqr[idx_i] > max_NN_dist)
				{
					break;
				}
				if ((idx_i / 2) == (idx_NN / 2))
				{
					if (out_dists_sqr[idx_i_pt1] < max_NN_dist)
					{
						idx_i = idx_i_pt1;
						idx_NN = idx_NN_pt1;
					}
					else
					{
						break;
					}
				}
			}
			if (((idx_i / 2) != (idx_NN / 2)) && (out_dists_sqr[idx_i] < max_NN_dist) && feature_lines[feature_type][i].size() && feature_lines[feature_type][idx_NN / 2].size())
			{	
				//////std::cout << out_dists_sqr[idx_i]<<" "<<get_model_min_edge() << std::endl;
				//cout<<NN_dists[idx_i][j]<<' '<<j<<endl;
				if (idx_i % 2 == 0)
				{
					if (idx_NN % 2 == 0)
					{	
						auto link_dist = trimesh::sqr((feature_lines[feature_type][idx_NN / 2].front() - feature_lines[feature_type][i].front()).norm());
						if (link_dist < get_model_min_edge())
						{
							feature_lines[feature_type][idx_NN / 2].insert(feature_lines[feature_type][idx_NN / 2].begin(), feature_lines[feature_type][i].rbegin(), feature_lines[feature_type][i].rend() - 1);
							feature_lines_cross_faces[feature_type][idx_NN / 2].insert(feature_lines_cross_faces[feature_type][idx_NN / 2].begin(),
								feature_lines_cross_faces[feature_type][i].rbegin(), feature_lines_cross_faces[feature_type][i].rend() - 1);
							feature_lines[feature_type][i].clear();
							feature_lines_cross_faces[feature_type][i].clear();
							break;
						}
					}
					else
					{	
						auto link_dist = trimesh::sqr((feature_lines[feature_type][idx_NN / 2].back() - feature_lines[feature_type][i].front()).norm());
						if (link_dist < get_model_min_edge())
						{
							feature_lines[feature_type][idx_NN / 2].insert(feature_lines[feature_type][idx_NN / 2].end(), feature_lines[feature_type][i].begin() + 1, feature_lines[feature_type][i].end());
							feature_lines_cross_faces[feature_type][idx_NN / 2].insert(feature_lines_cross_faces[feature_type][idx_NN / 2].end(),
								feature_lines_cross_faces[feature_type][i].begin() + 1, feature_lines_cross_faces[feature_type][i].end());
							feature_lines[feature_type][i].clear();
							feature_lines_cross_faces[feature_type][i].clear();
							break;
						}
					}
				}
				else
				{
					if (idx_NN % 2 == 0)
					{	
						auto link_dist = trimesh::sqr((feature_lines[feature_type][idx_NN / 2].front() - feature_lines[feature_type][i].back()).norm());
						if (link_dist < get_model_min_edge())
						{
							feature_lines[feature_type][idx_NN / 2].insert(feature_lines[feature_type][idx_NN / 2].begin(), feature_lines[feature_type][i].begin(), feature_lines[feature_type][i].end() - 1);
							feature_lines_cross_faces[feature_type][idx_NN / 2].insert(feature_lines_cross_faces[feature_type][idx_NN / 2].begin(),
								feature_lines_cross_faces[feature_type][i].begin(), feature_lines_cross_faces[feature_type][i].end() - 1);
							feature_lines[feature_type][i].clear();
							feature_lines_cross_faces[feature_type][i].clear();
							break;
						}
					}
					else
					{	
						auto link_dist = trimesh::sqr((feature_lines[feature_type][idx_NN / 2].back() - feature_lines[feature_type][i].back()).norm());
						if (link_dist < get_model_min_edge())
						{
							feature_lines[feature_type][idx_NN / 2].insert(feature_lines[feature_type][idx_NN / 2].end(), feature_lines[feature_type][i].rbegin() + 1, feature_lines[feature_type][i].rend());
							feature_lines_cross_faces[feature_type][idx_NN / 2].insert(feature_lines_cross_faces[feature_type][idx_NN / 2].end(),
								feature_lines_cross_faces[feature_type][i].rbegin() + 1, feature_lines_cross_faces[feature_type][i].rend());
							feature_lines[feature_type][i].clear();
							feature_lines_cross_faces[feature_type][i].clear();
							break;
						}
					}
				}
			}
		}
	}
	for (auto iter = feature_lines[feature_type].begin(); iter != feature_lines[feature_type].end();)
	{	
		iter = (iter->size() < 1) ? feature_lines[feature_type].erase(iter) : (iter + 1);
	}
	for (auto iter = feature_lines_cross_faces[feature_type].begin(); iter != feature_lines_cross_faces[feature_type].end();)
	{
		iter = (iter->size() < 1) ? feature_lines_cross_faces[feature_type].erase(iter) : (iter + 1);
	}
}

double Feature::get_model_min_edge()
{
	if (len_min_edge > 0)
	{
		return len_min_edge;
	}
	len_min_edge = std::numeric_limits<double>::max();
	for (int i = 0; i < themesh->vertices.size(); ++i)
	{
		for (auto j:themesh->neighbors[i])
		{
			len_min_edge = std::min(len_min_edge,
				static_cast<double>(trimesh::length2(themesh->vertices[i] - themesh->vertices[j])));
		}
	}
}
void Feature::user_input_attach(std::vector<int>& front_pt_idx, std::vector<Eigen::Vector2d>& front_pts, std::vector<Eigen::Vector2d>& user_input)
{
	Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic> mat(front_pts.size(), 2);
	for (int i = 0; i < front_pts.size(); ++i)
	{
		mat.row(i) = front_pts[i];
	}
	my_kd_tree_t mat_index(2, mat, 10);
	mat_index.index->buildIndex();

	const std::size_t num_results = 1;
	std::vector<size_t>ret_idx_(num_results * user_input.size());
	std::vector<double>out_dists_sqr_(num_results * user_input.size());
	for (int i = 0; i < user_input.size(); ++i)
	{
		nanoflann::KNNResultSet<double>resultSet(num_results);
		resultSet.init(ret_idx_.data() + i, out_dists_sqr_.data() + i);
		mat_index.index->findNeighbors(resultSet, user_input[i].data(), nanoflann::SearchParams(128));
	}
	user_input_feature.push_back(std::vector<int>());
	for (int i = 0; i < ret_idx_.size(); ++i)
	{
		user_input_feature.back().push_back(front_pt_idx[ret_idx_[i]]);
	}
}


void Feature::curve_part_attach(std::vector<Eigen::Vector3d>& smooth_curve_interpolate, std::vector<std::vector<Eigen::Vector3d>>& nearest_pts, std::vector<std::vector<double>>& pts_dist, int assemble_path_idx, int NN_num)
{
	Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic>mat(assemble_paths[assemble_path_idx].size(), 3);
	for (int i = 0; i < assemble_paths[assemble_path_idx].size(); ++i)
	{
		auto pt = themesh->vertices[assemble_paths[assemble_path_idx][i]];
		Eigen::Vector3d pt_(pt.x, pt.t, pt.z);
		mat.row(i) = pt_;
	}
	my_kd_tree_t mat_idx(3, mat, 10);
	mat_idx.index->buildIndex();

	const std::size_t num_results = NN_num;
	std::vector<size_t> ret_idx_ = std::vector<size_t>(num_results * smooth_curve_interpolate.size());
	std::vector<double> out_dists_sqr_ = std::vector<double>(num_results * smooth_curve_interpolate.size());
	nearest_pts.clear();
	pts_dist.clear();
	for (int i = 0; i < smooth_curve_interpolate.size(); ++i)
	{
		nanoflann::KNNResultSet<double>resultSet(num_results);
		resultSet.init(ret_idx_.data() + (i * num_results), out_dists_sqr_.data() + (i * num_results));
		mat_idx.index->findNeighbors(resultSet, smooth_curve_interpolate[i].data(), nanoflann::SearchParams(128));
		nearest_pts.push_back(std::vector<Eigen::Vector3d>());
		pts_dist.push_back(std::vector<double>());
		for (int j = 0; j < num_results; ++j)
		{
			auto pt = themesh->vertices[assemble_paths[assemble_path_idx][ret_idx_[i * num_results + j]]];
			nearest_pts.back().push_back(Eigen::Vector3d(pt.x, pt.t, pt.z));
			pts_dist.back().push_back(std::sqrt(out_dists_sqr_[i * num_results + j]));
		}
	}
}

void Feature::multi_curve_part_attach(std::vector<Eigen::Vector3d>& smooth_curve_interpolate, std::vector<std::vector<Eigen::Vector3d>>& nearest_pts, std::vector<std::vector<double>>& pts_dist, int assemble_path_idx, int NN_num)
{
	int mat_size = 0;
	for (int i = 0; i < multiple_assemble_bridges[assemble_path_idx].size(); ++i)
	{
		mat_size += multiple_assemble_bridges[assemble_path_idx][i].size();
	}
	Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic>mat(mat_size, 3);
	int mat_insert_vec = 0;
	for (int i = 0; i < multiple_assemble_bridges[assemble_path_idx].size(); ++i)
	{
		for (int j = 0; j < multiple_assemble_bridges[assemble_path_idx][i].size(); ++j)
		{
			auto pt = themesh->vertices[multiple_assemble_bridges[assemble_path_idx][i][j]];
			Eigen::Vector3d pt_(pt.x, pt.t, pt.z);
			mat.row(mat_insert_vec) = pt_;
			mat_insert_vec++;
		}
	}
	my_kd_tree_t mat_idx(3, mat, 10);
	mat_idx.index->buildIndex();

	const std::size_t num_results = NN_num;
	std::vector<size_t> ret_idx_ = std::vector<size_t>(num_results * smooth_curve_interpolate.size());
	std::vector<double> out_dists_sqr_ = std::vector<double>(num_results * smooth_curve_interpolate.size());
	nearest_pts.clear();
	pts_dist.clear();
	for (int i = 0; i < smooth_curve_interpolate.size(); ++i)
	{
		nanoflann::KNNResultSet<double>resultSet(num_results);
		resultSet.init(ret_idx_.data() + (i * num_results), out_dists_sqr_.data() + (i * num_results));
		mat_idx.index->findNeighbors(resultSet, smooth_curve_interpolate[i].data(), nanoflann::SearchParams(128));
		nearest_pts.push_back(std::vector<Eigen::Vector3d>());
		pts_dist.push_back(std::vector<double>());
		for (int j = 0; j < num_results; ++j)
		{
			int ret_res = ret_idx_[i * num_results + j];
			int lower_bound = 0;
			int upper_bound = multiple_assemble_bridges[assemble_path_idx].front().size();
			int upper_bound_idx = 0;
			while (!((ret_res >= lower_bound) && (ret_res < upper_bound)))
			{	
				lower_bound = upper_bound;
				upper_bound= multiple_assemble_bridges[assemble_path_idx][upper_bound_idx].size()+ upper_bound;
			}	
			int idx = ret_res - lower_bound;
			auto pt = themesh->vertices[multiple_assemble_bridges[assemble_path_idx][upper_bound_idx][idx]];
			nearest_pts.back().push_back(Eigen::Vector3d(pt.x, pt.t, pt.z));
			pts_dist.back().push_back(std::sqrt(out_dists_sqr_[i * num_results + j]));
			//auto pt = themesh->vertices[assemble_paths[assemble_path_idx][ret_idx_[i * num_results + j]]];
			//nearest_pts.back().push_back(Eigen::Vector3d(pt.x, pt.t, pt.z));
			//pts_dist.back().push_back(std::sqrt(out_dists_sqr_[i * num_results + j]));
		}
	}
}

void Feature::curve_attach_2_feature(std::vector<Eigen::Vector3d>& curve_control_pts, std::vector<double>& pts_dist)
{
	int mat_size = 0;
	for (auto i : this->feature_lines)
	{
		if (this->features_draw_option_[i.first] == kDrawingOption::DRAW_SAVED_RES)
		{
			for (auto j : i.second)
			{
				mat_size += j.size();
			}
		}
	}
	Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic>mat(mat_size, 3);
	int mat_insert_vec = 0;
	for (auto i : this->feature_lines)
	{
		if (this->features_draw_option_[i.first] == kDrawingOption::DRAW_SAVED_RES)
		{
			for (auto j : i.second)
			{	
				for (auto pt : j)
				{
					mat.row(mat_insert_vec) = pt;
					mat_insert_vec++;
				}
			}
		}
	}
	my_kd_tree_t mat_idx(3, mat, 10);
	mat_idx.index->buildIndex();

	const std::size_t num_results = 1;
	std::vector<size_t> ret_idx_ = std::vector<size_t>(num_results * curve_control_pts.size());
	std::vector<double> out_dists_sqr_ = std::vector<double>(num_results * curve_control_pts.size());
	//nearest_pts.clear();
	pts_dist.clear();
	for (int i = 0; i < curve_control_pts.size(); ++i)
	{
		nanoflann::KNNResultSet<double>resultSet(num_results);
		resultSet.init(ret_idx_.data() + (i * num_results), out_dists_sqr_.data() + (i * num_results));
		mat_idx.index->findNeighbors(resultSet, curve_control_pts[i].data(), nanoflann::SearchParams(128));
		pts_dist.push_back(std::sqrt(out_dists_sqr_[i]));
		//nearest_pts.push_back(std::vector<Eigen::Vector3d>());
		//pts_dist.push_back(std::vector<double>());
		/*
		for (int j = 0; j < num_results; ++j)
		{
			auto pt = themesh->vertices[assemble_paths[assemble_path_idx][ret_idx_[i * num_results + j]]];
			nearest_pts.back().push_back(Eigen::Vector3d(pt.x, pt.t, pt.z));
			pts_dist.back().push_back(std::sqrt(out_dists_sqr_[i * num_results + j]));
		}
		*/
	}
}
void Feature::curve_attach_2_path(std::vector<Eigen::Vector3d>&curve_ends, std::vector<std::vector<int>>&path,
	std::vector<int>&return_res)
{
	int mat_size = 0;
	for (auto i : path)
	{
		mat_size += i.size();
	}
	Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic>mat(mat_size, 3);
	int mat_insert_vec = 0;
	for (auto i : path)
	{
		for (auto j : i)
		{	
			auto pt = themesh->vertices[j];
			
			mat.row(mat_insert_vec) = Eigen::Vector3d(pt.x,pt.y,pt.z);
			mat_insert_vec++;
		}
	}
	my_kd_tree_t mat_idx(3, mat, 10);
	mat_idx.index->buildIndex();

	const std::size_t num_results = 1;
	std::vector<size_t> ret_idx_ = std::vector<size_t>(num_results * curve_ends.size());
	std::vector<double> out_dists_sqr_ = std::vector<double>(num_results * curve_ends.size());
	return_res.clear();
	//nearest_pts.clear();
	//pts_dist.clear();
	for (int i = 0; i < curve_ends.size(); ++i)
	{
		nanoflann::KNNResultSet<double>resultSet(num_results);
		resultSet.init(ret_idx_.data() + (i * num_results), out_dists_sqr_.data() + (i * num_results));
		mat_idx.index->findNeighbors(resultSet, curve_ends[i].data(), nanoflann::SearchParams(128));
		//pts_dist.push_back(std::sqrt(out_dists_sqr_[i]));
		return_res.push_back(ret_idx_[i]);
		int path_i = 0;
		while (return_res.back() >= path[path_i].size())
		{
			path_i++;
			return_res.back() -= path[path_i].size();
		}
		return_res.back() = path[path_i][return_res.back()];
	}
}