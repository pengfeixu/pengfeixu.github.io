#pragma once
//Intend to get features based on model info. 
#include <map>
#include <string>
#include <vector>
#include <Eigen/Core>
#include <Eigen/Geometry> 
#include <TriMesh.h>
#include <XForm.h>

#include <nanoflann.hpp>

#include "helper_algo.h"
enum kDrawingOption { DRAW_IMMEDIATELY, DRAW_IMMEDIATELY_NOTHING, DRAW_SAVED_RES, DRAW_SAVED_RES_NOTHING };


typedef nanoflann::KDTreeEigenMatrixAdaptor<Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic>>my_kd_tree_t;
class Feature
{
private:
	//from rtsc by princeton.
	void compute_feature_size();

	void compute_perview(std::vector<float>& ndotv_, std::vector<float>& kr_,
		std::vector<float>& sctest_num_, std::vector<float>& sctest_den_,
		std::vector<float>& shtest_num_, std::vector<float>& q1_,
		std::vector<trimesh::vec2>& t1_, std::vector<float>& Dt1q1_,
		bool extra_sin2theta);
	void draw_silhouette(const std::vector<float>& ndotv_, int save_drawing_res);
	void draw_topolines(const std::vector<float>& ndotv_, int save_drawing_res);
	void draw_misc_K(const std::vector<float>& ndotv_, int save_drawing_res);
	void draw_misc_H(const std::vector<float>& ndotv_, int save_drawing_res);
	void draw_misc_DwKr(const std::vector<float>& ndotv_,const std::vector<float> &DwKr_, int save_drawing_res);
	void draw_sh(int save_drawing_res);
	void draw_sc(int save_drawing_res);
	void draw_contour(int save_drawing_res);
	std::vector<Eigen::RowVector4d> draw_isolines(const std::vector<float>& val_,
		const std::vector<float>& test_num_,
		const std::vector<float>& test_den_,
		const std::vector<float>& ndotv_,
		bool do_bfcull, bool do_hermite,
		bool do_test, float fade,
		int save_drawing_res);
	std::vector<Eigen::RowVector4d> draw_face_isoline(int v0, int v1, int v2,
		const std::vector<float>& val_,
		const std::vector<float>& test_num_,
		const std::vector<float>& test_den_,
		const std::vector<float>& ndotv_,
		bool do_bfcull, bool do_hermite,
		bool do_test, float fade,
		int save_drawing_res);
	std::vector<Eigen::RowVector4d> draw_face_isoline2(int v0, int v1, int v2,
		const std::vector<float>& val_,
		const std::vector<float>& test_num_,
		const std::vector<float>& test_den_,
		bool do_hermite, bool do_test, float fade, int save_drawing_res);

	std::vector<Eigen::RowVector4d> draw_mesh_ridges(bool do_ridge, const std::vector<float>& ndotv_,
		bool do_bfcull, bool do_test, float thresh);
	std::vector<Eigen::RowVector4d> draw_face_ridges(int v0, int v1, int v2,
		bool do_ridge,
		const std::vector<float>& ndotv_,
		bool do_bfcull, bool do_test, float thresh);
	std::vector<Eigen::RowVector4d> draw_segment_ridge(int v0, int v1, int v2,
		float emax0, float emax1, float emax2,
		float kmax0, float kmax1, float kmax2,
		float thresh, bool to_center);
	void draw_ridges(int save_drawing_res);
	void draw_valleys(int save_drawing_res);

	float find_zero_hermite(int v0, int v1, float val0, float val1,
		const trimesh::vec& grad0, const trimesh::vec& grad1);
	inline float find_zero_linear(float val0, float val1)
	{
		return val0 / (val0 - val1);
	}
	inline trimesh::vec gradkr(int i)
	{
		trimesh::vec viewdir = viewpos - themesh->vertices[i];
		float rlen_viewdir = 1.0f / trimesh::len(viewdir);
		viewdir *= rlen_viewdir;

		float ndotv = viewdir DOT themesh->normals[i];
		float sintheta = sqrt(1.0f - trimesh::sqr(ndotv));
		float csctheta = 1.0f / sintheta;
		float u = (viewdir DOT themesh->pdir1[i]) * csctheta;
		float v = (viewdir DOT themesh->pdir2[i]) * csctheta;
		float kr = themesh->curv1[i] * u * u + themesh->curv2[i] * v * v;
		float tr = u * v * (themesh->curv2[i] - themesh->curv1[i]);
		float kt = themesh->curv1[i] * (1.0f - u * u) +
			themesh->curv2[i] * (1.0f - v * v);
		trimesh::vec w = u * themesh->pdir1[i] + v * themesh->pdir2[i];
		trimesh::vec wperp = u * themesh->pdir2[i] - v * themesh->pdir1[i];
		const trimesh::Vec<4>& C = themesh->dcurv[i];

		trimesh::vec g = themesh->pdir1[i] * (u * u * C[0] + 2.0f * u * v * C[1] + v * v * C[2]) +
			themesh->pdir2[i] * (u * u * C[1] + 2.0f * u * v * C[2] + v * v * C[3]) -
			2.0f * csctheta * tr * (rlen_viewdir * wperp +
				ndotv * (tr * w + kt * wperp));
		g *= (1.0f - trimesh::sqr(ndotv));
		g -= 2.0f * kr * sintheta * ndotv * (kr * w + tr * wperp);
		return g;
	}


	void initialise_stripes(std::string feature_type);
	void builNNindex(std::string feature_type, std::vector<size_t>& ret_idx, std::vector<double>& out_dists_sqr);
	void merge_strips(std::string feature_type, std::vector<size_t>& ret_idx, std::vector<double>& out_dists_sqr);
	double get_model_min_edge();


	trimesh::point viewpos;
	Eigen::Matrix4f xf;

	std::vector<float> ndotv, kr;
	std::vector<float> sctest_num, sctest_den, shtest_num;
	std::vector<float> q1, Dt1q1;
	std::vector<trimesh::vec2> t1;

	float currsmooth;
	float feature_size;

	float sug_thresh;
	float sh_thresh;
	int ntopo; float topo_offset;
	int test_rv; float rv_thresh;
	double len_min_edge;

	Eigen::Vector4f currcolor;
public:
	trimesh::TriMesh* themesh;

	std::map<std::string, std::vector<Eigen::RowVector4d>>features_;
	std::map<std::string, std::vector<std::vector<Eigen::RowVector3d>>>feature_lines;
	std::map<std::string, std::vector<std::vector<int>>>feature_lines_cross_faces;
	std::map<std::string, std::vector<Eigen::RowVector3d>>feature_vector_field;
	std::map<std::string, std::vector<double>>feature_scalar_field;
	std::map<std::string, int>features_draw_option_;
	std::map<std::string, std::vector<std::vector<int>>>feature_paths;
	std::vector<std::vector<int>>assemble_paths;
	std::vector<std::vector<Eigen::Vector3d>>assemble_smooth_paths;
	std::vector<std::vector<Eigen::Vector3d>>assemble_smooth_twice_paths;

	std::vector<std::vector<std::vector<int>>>multiple_assemble_paths;
	std::vector<double>multiple_assemble_paths_coveragence;
	std::vector<std::vector<std::vector<int>>>multiple_assemble_bridges;
	std::vector<double>multiple_assemble_bridges_coveragence;
	std::vector<std::string>multiple_bridges_str;
	std::vector<std::vector<std::vector<Eigen::Vector3d>>>multiple_assemble_smooth_paths;
	std::vector<std::vector<std::vector<Eigen::Vector3d>>>multiple_assemble_smooth_twice_paths;
	
	std::vector<std::vector<int>>user_input_feature;
	std::vector<double>user_input_scalar_field;
	std::vector<Eigen::RowVector3d>user_input_vector_field;
	std::vector<my_kd_tree_t>NN_search;
	Feature(std::string filename);
	void draw_feature();
	void feature_update(Eigen::Matrix4f view);
	void merge_stripes_pipeline();
	void user_input_attach(std::vector<int>& front_pt_idx, std::vector<Eigen::Vector2d>& front_pts, std::vector<Eigen::Vector2d>& user_input);
	void curve_part_attach(std::vector<Eigen::Vector3d>& smooth_curve_interpolate, std::vector<std::vector<Eigen::Vector3d>>& nearest_pts, std::vector<std::vector<double>>&pts_dist,int assemble_path_idx, int NN_num);
	void multi_curve_part_attach(std::vector<Eigen::Vector3d>& smooth_curve_interpolate, std::vector<std::vector<Eigen::Vector3d>>& nearest_pts, std::vector<std::vector<double>>& pts_dist, int assemble_path_idx, int NN_num);
	void curve_attach_2_feature(std::vector<Eigen::Vector3d>& curve_control_pts, std::vector<double>& pts_dist);
	void curve_attach_2_path(std::vector<Eigen::Vector3d>& curve_ends, std::vector<std::vector<int>>& path,
		std::vector<int>& return_res);
	trimesh::vec normal(int i) { return themesh->normals[i]; };

};