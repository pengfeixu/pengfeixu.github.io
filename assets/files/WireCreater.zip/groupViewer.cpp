#include"groupViewer.h"

groupViewer::groupViewer(QWidget* parent)
{
    addParam();
    QHBoxLayout* layout = new QHBoxLayout;
    //curveViewer = new CurveViewer(NULL);
    QWidget* mwidget = new QWidget();
    sublayout = new QGridLayout();
    mwidget->setLayout(sublayout);
    layout->addWidget(mwidget, 3);
    layout->addWidget(tabCurveParam, 1);

    QWidget* window = new QWidget();
    window->setLayout(layout);
    this->setCentralWidget(window);
    load_groups = new QAction("Load Group");
    auto fileMenu = menuBar()->addMenu(tr("&File"));
    fileMenu->addAction(load_groups);
    setConnection();
}

void groupViewer::setConnection()
{
    connect(load_groups, SIGNAL(triggered()), this, SLOT(callLoadGroups()));
    connect(tabCurveParam->getVariantManager(), SIGNAL(valueChanged(QtProperty*, const QVariant&)),
        this, SLOT(curveParamsChanged(QtProperty*, const QVariant&)));
}

void groupViewer::addParam()
{
    tabCurveParam = new CPropertyBrowser();
    tabCurveParam->setObjectName(QStringLiteral("tabCurveParam"));
    //ui.PropertyTabWidget->addTab(tabCurveParam, QString());
    //ui.PropertyTabWidget->setTabText(1, "Curve Settings");
    QtVariantProperty* thisProperty, * displayProperty, * curveProperty;
    tabCurveParam->clear();
    curveProperty = tabCurveParam->getOneNewProperty(QtVariantPropertyManager::groupTypeId(), QLatin1String("Curve"), "Curve");
    thisProperty = tabCurveParam->getOneNewProperty(QVariant::Int, QLatin1String("LineSegment"), "Curve.LineSegment");
    thisProperty->setValue(20);
    curveProperty->addSubProperty(thisProperty);

    thisProperty = tabCurveParam->getOneNewProperty(QVariant::Double, QLatin1String("ErrorMagnitude"), "Curve.ErrorMagnitude");
    thisProperty->setValue(2.0);
    curveProperty->addSubProperty(thisProperty);

    thisProperty = tabCurveParam->getOneNewProperty(QVariant::Int, QLatin1String("SmoothIterTime"), "Curve.SmoothIterTime");
    thisProperty->setValue(1);
    curveProperty->addSubProperty(thisProperty);

    thisProperty = tabCurveParam->getOneNewProperty(QVariant::Double, QLatin1String("MinRadiusOfCurvature"), "Curve.MinRadiusOfCurvature");
    thisProperty->setValue(1);
    curveProperty->addSubProperty(thisProperty);

    thisProperty = tabCurveParam->getOneNewProperty(QVariant::Double, QLatin1String("MinRadiusOfCurvature"), "Curve.MinRadiusOfCurvature");
    thisProperty->setValue(1);
    curveProperty->addSubProperty(thisProperty);

    thisProperty = tabCurveParam->getOneNewProperty(QVariant::Color, QLatin1String("LineColor"), "Curve.LineColor");
    thisProperty->setValue(QColor(0,0,0));
    curveProperty->addSubProperty(thisProperty);

    tabCurveParam->addOneProperty(curveProperty);
}
void groupViewer::curveParamsChanged(QtProperty* prop, const QVariant& value)
{
    std::string id = tabCurveParam->getPropertyId(prop);
    if (id == "Curve.LineColor")
    {
        for (int i = 0; i < vec_subviewer.size(); ++i)
        {
            vec_subviewer[i]->wire_color= value.value<QColor>();
            vec_subviewer[i]->update();
        }
    }
}

void groupViewer::readCurve(std::string curve_file_name,Curve &path_res)
{
    std::ifstream input(curve_file_name);
    size_t ctrl_pts_group_num;
    input >> ctrl_pts_group_num;
    std::cout << ctrl_pts_group_num << std::endl;
    std::vector<std::vector<Eigen::Vector3d>>ctrl_pts;
    while (ctrl_pts_group_num--)
    {
        size_t ctrl_pts_num;
        input >> ctrl_pts_num;
        std::cout << ctrl_pts_num << std::endl;
        ctrl_pts.push_back(std::vector<Eigen::Vector3d>());
        while (ctrl_pts_num--)
        {
            double x, y, z;
            Eigen::Vector3d pt;
            input >> x >> y >> z;
            ctrl_pts.back().push_back(Eigen::Vector3d(x, y, z));
        }
    }
    size_t overlap_pts_group_num;
    std::vector<std::vector<std::pair<int, double>>>overlap_pts_vec;
    input.close();
    const double error_mag = tabCurveParam->getVariantProperty("Curve.ErrorMagnitude")->value().toDouble();
    const int segment_times = tabCurveParam->getVariantProperty("Curve.LineSegment")->value().toInt();

    path_res = Curve(ctrl_pts, overlap_pts_vec, segment_times, error_mag);
}

void groupViewer::callLoadGroups()
{
    //say 6 candidate
    QLayoutItem* child;
    while ((child = sublayout->takeAt(0)) != 0) 
    {
        delete child;
    }
    for (int i = 0; i < vec_subviewer.size(); ++i)
    {
        delete vec_subviewer[i];
    }
    vec_subviewer.clear();

    QString filename = QFileDialog::getOpenFileName(NULL, "load curve group", ".//user marker", "*.grp");
    QString dir_path = filename.left(filename.lastIndexOf("/"));
    std::ifstream input(filename.toStdString());
    QString file_name_local = filename.right(filename.size() - filename.lastIndexOf("/") - 1);
    std::string file_name;
    while (!input.eof())
    {
        input >> file_name;
        std::cout << file_name << std::endl;;
        QString file_name_(file_name.c_str());
        file_name_ = dir_path + QString('/') + file_name_;
        //std::ifstream input_(file_name_.toStdString());
        Curve curve;
        readCurve(file_name_.toStdString(), curve);
        vec_subviewer.push_back(new SubViewer());
        vec_subviewer.back()->readCurveGroup(curve);
        sublayout->addWidget(vec_subviewer.back(),
            (vec_subviewer.size()- 1) / 2,
            (vec_subviewer.size() - 1) % 2);
    }
    for (int i = 0; i < vec_subviewer.size(); ++i)
    {   
        for (int j = 0; j < vec_subviewer.size(); ++j)
        {   
            if (j != i)
            {
                connect(vec_subviewer[i], SIGNAL(Viewer_Frame(qglviewer::ManipulatedCameraFrame*)),
                    vec_subviewer[j], SLOT(updateFrame(qglviewer::ManipulatedCameraFrame*)));
            }
        }
    }
}