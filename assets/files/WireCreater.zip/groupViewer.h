#pragma once
#include <QtWidgets/QMainWindow>
#include "PropertyBrowser.h"
#include <qfiledialog.h>
#include <QAction>
#include <QMenu>
#include <QMenuBar>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include "subviewer.h"

class groupViewer : public QMainWindow
{
    Q_OBJECT
public:
    groupViewer(QWidget* parent = Q_NULLPTR);
private:
    QAction* load_groups;
    CPropertyBrowser* tabCurveParam;
    std::vector<SubViewer*>vec_subviewer;
    //std::vector<QWidget*>vec_widget;
    QGridLayout* sublayout;

    void setConnection();
    void addParam();
    void readCurve(std::string curve_file_name, Curve& path_res);
private slots:
    void callLoadGroups();
    void curveParamsChanged(QtProperty* prop, const QVariant& value);
};