#include"helper_algo.h"
int vertex_intersection_face(std::vector<int>& v1, std::vector<int>& v2, std::vector<int>& v3)
{
	std::set<int>s1(v1.begin(), v1.end());
	std::set<int>s2(v2.begin(), v2.end());
	std::set<int>s3(v3.begin(), v3.end());
	std::set<int>s1_sec_s2;
	std::set<int>res;
	std::set_intersection(s1.begin(), s1.end(),
		s2.begin(), s2.end(),
		std::inserter(s1_sec_s2, s1_sec_s2.end()));
	std::set_intersection(s1_sec_s2.begin(), s1_sec_s2.end(),
		s3.begin(), s3.end(),
		std::inserter(res, res.end()));
	return *(res.begin());
}

int get_2_faces_intersection(std::vector<int>& f1, std::vector<int>& f2)
{
	std::set<int>s1(f1.begin(), f1.end());
	std::set<int>s2(f2.begin(), f2.end());
	std::set<int>res;
	std::set_intersection(s1.begin(), s1.end(),
		s2.begin(), s2.end(),
		std::inserter(res, res.end()));
	return res.size();
}