#pragma once
#include <vector>
#include <set>
#include <algorithm>
#include <iterator>
#include <cmath>

//for trimesh2 lib help
const float ML_LOW_TOLERANCE = 0.000001f;
const double ML_2_PI = 6.283185307179586476;
const double ML_PI = 3.141592653589793238;
const double ML_DEG_TO_RAD = 0.017453292519943295;
const double ML_RAD_TO_DEG = 57.29577951308232286;
const double ML_PI_2 = 1.570796326794896558;
const double ML_PI_4 = 0.785398163397448279;

int vertex_intersection_face(std::vector<int>& v1, std::vector<int>& v2, std::vector<int>& v3);

int get_2_faces_intersection(std::vector<int>& f1, std::vector<int>& f2);
template<class T> T AcosR(T f) { return static_cast<T>(std::atan(-f/std::sqrt(-f*f+1))+ ML_PI_2); }
inline bool IsZeroL(double f) { return std::fabs(f) < ML_LOW_TOLERANCE; }
inline double rand_uniform(double low, double high) { double rand_01 = (double)rand() / (RAND_MAX + 1.0); return rand_01 * (high - low) + low; }
template<class T> void get_max_min_val(T& max_val, T& min_val) { T maxi = std::max(max_val, min_val); min_val = std::min(max_val, min_val); max_val = maxi; }
inline double guassian(double x) { return std::exp(-std::pow(x, 2)/2); }
inline double normal_pdf(float x, float m, float s)
{
    static const float inv_sqrt_2pi = 0.3989422804014327;
    float a = (x - m) / s;
    return inv_sqrt_2pi / s * std::exp(-0.5f * a * a);
}
inline double normal_pdf(float x, float s)
{
    static const float inv_sqrt_2pi = 0.3989422804014327;
    float a = (x) / s;
    return std::exp(-0.5f * a * a);
}
// double logistic_1(double x) { return (1 / (1 + std::exp(-x))) * 3 - 1; }
//inline double logistic_1(double x) { return (1.8 / (1 + std::exp(-x))-0.8); }
//inline double logistic_2(double x) { return (1.98 / (1 + std::exp(-x))- 0.98); }
inline double logistic_1(double x) { return (1.98 / (1 + std::exp(-x))-0.98); }
inline double logistic_2(double x) { return (1.998 / (1 + std::exp(-x))- 0.998); }
inline double logistic_1(double x, double a, double b) { return (a / (1 + std::exp(-b*x)) + (1-a)); }
inline double logistic_2(double x,double a,double b) { return (a / (1 + std::exp(-b*x))+ (1-a)); }
template<class T>T sqrt_t(T x) { return static_cast<T>(std::sqrt(static_cast<double>(x))); }
template<class T> int binary_search(std::vector<T>&vec,T val)
{
    int l = 0;
    int r = vec.size() - 1;
    if (val <= vec[l])
        return l;
    if (val >= vec[r])
        return r;
    while (r - l > 1)        
    {
        int mid = (l + r) / 2;
        if (val >= vec[mid])
            l = mid;	  
        else
            r = mid;	  
    }
    T x = abs(vec[l] - val);
    T y = abs(vec[r] - val);
    //return x <= y ? a[l] : a[r];
    return x <= y ? l : r;
}

template<typename T> void finiteDiff(std::vector<T>& input, std::vector<T>& output, float dx = 1)
{
    output.clear();
    output.push_back((input[1] - input[0]) / dx);
    for (int i = 1; i < input.size()-1; ++i)
    {
        output.push_back((input[i - 1] - input[i + 1]) / (2 * dx));
    }
    output.push_back((input.back() - input[input.size() - 2]) / dx);
}

template<typename T>void getCurveSubNormal(std::vector<T>& curve, std::vector<T>&normals , std::vector<T>& subnormals)
{
    subnormals.clear();
    normals.clear();
    std::vector<T>d_dt;
    std::vector<T>dtan_dt;
    finiteDiff(curve, d_dt);
    finiteDiff(d_dt, dtan_dt);
    for (int i = 0; i < curve.size(); ++i)
    {
        T tangent = d_dt[i].normalized();
        T normal = dtan_dt[i].normalized();
        T subnormal = tangent.cross(normal);
        if (subnormal.norm() != 0)
        {
            subnormal.normalize();
        }
        subnormals.push_back(subnormal);
        normals.push_back(normal);
    }
}
template <typename T>
std::vector<size_t> sort_indexes(const std::vector<T>& v) {

    // initialize original index locations
    std::vector<size_t> idx(v.size());
    std::iota(idx.begin(), idx.end(), 0);

    // sort indexes based on comparing values in v
    // using std::stable_sort instead of std::sort
    // to avoid unnecessary index re-orderings
    // when v contains elements of equal values 
    std::stable_sort(idx.begin(), idx.end(),
        [&v](size_t i1, size_t i2) {return v[i1] < v[i2]; });

    return idx;
}