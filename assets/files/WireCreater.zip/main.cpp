#include "WireCreater.h"
#include "CurveSmoother.h"
#include "groupViewer.h"
#include "ResultViewer.h"
#include <QtWidgets/QApplication>

int main(int argc, char *argv[])
{   
    QApplication::setAttribute(Qt::AA_DisableWindowContextHelpButton);
    std::string arg = std::string(argv[1]);
    QApplication a(argc, argv);
    if (arg == "main")
    {
        WireCreater w;
        w.show();
        return a.exec();
    }
    else if (arg == "smoother")
    {
        CurveSmoother c;
        c.show();
        return a.exec();
    }
    else if (arg == "marker")
    {
        groupViewer g;
        g.show();
        return a.exec();
    }
    else if (arg == "result")
    {
        ResultViewer r;
        r.show();
        return a.exec();
    }
}
