#pragma once

// CGAL	stuff
#include <QtWidgets/QMainWindow>
#include <qprogressdialog.h>

#include <CGAL/Cartesian.h>
#include <CGAL/Polyhedron_3.h>
#include <CGAL/HalfedgeDS_vertex_max_base_with_id.h>
#include <CGAL/HalfedgeDS_halfedge_max_base_with_id.h>
#include <CGAL/HalfedgeDS_face_max_base_with_id.h>
#include <CGAL/HalfedgeDS_decorator.h> 
#include <CGAL/Random_access_adaptor.h>
#include <CGAL/intersections.h>
#include <CGAL/Search_traits_3.h>
#include <CGAL/Heat_method_3/Surface_mesh_geodesic_distances_3.h>
#include <boost/graph/graph_traits.hpp>
#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/dijkstra_shortest_paths.hpp>
#include <list>
#include <set>
#include <stack>
#include <map>
#include <queue>
#include <string>
#include <algorithm>
#include <functional>
#include <omp.h>

#include <Eigen/Core>
#include <Eigen/Geometry> 

#include <nanoflann.hpp>


// linear solver
#include "cholmod_matrix.h"
#include "cholmod_vector.h"

#include "helper_algo.h"
#include "segIO.h"
#include "wasserstein.h"
//#include <cholmod.h>
enum kVisit { UNVISIT, VISIT};
enum kLineLink{RADDPATH_RGEODESICPATH_CURPATH,CURPATH_GEODESICPATH_ADDPATH,ADDPATH_RGEODESICPATH_CURPATH, CURPATH_GEODESICPATH_RADDPATH};
typedef boost::adjacency_list < boost::listS, boost::vecS, boost::undirectedS,
	boost::no_property, boost::property < boost::edge_weight_t, double > > graph_t;

#define VH(v) index_to_vertex_map[(v)]
#define VP(v) index_to_vertex_map[(v)]->point()
#define VN(v) index_to_vertex_map[(v)]->normal()
#define VB(v) index_to_vertex_map[(v)]->vertex_begin()
#define VT(v) index_to_vertex_map[(v)]->tag()
#define FH(f) index_to_facet_map[(f)]
#define FN(f) index_to_facet_map[(f)]->normal()
#define FB(f) index_to_facet_map[(f)]->facet_begin()
#define BN (1.0e10)
#define SQBN (1.0e5)

const float ML_TOLERANCE = 0.000100f;
inline bool IsZero(double f) { return fabs(f) < ML_TOLERANCE; }
// a refined facet with a normal and a tag
template <class	Refs, class T, class P, class Norm>
class Enriched_facet : public CGAL::HalfedgeDS_face_max_base_with_id<Refs, CGAL::Tag_false, std::size_t>
{
	// normal
	Norm m_normal;

public:
	// life	cycle
	// no constructors to repeat, since only default constructor mandatory
	Enriched_facet() {}

	// normal
	typedef	Norm Normal_3;
	Normal_3& normal() { return	m_normal; }
	const Normal_3& normal() const { return m_normal; }
};

// a refined halfedge with a general tag and a binary tag to indicate whether it belongs 
// to the control mesh or not
template <class	Refs, class Tprev, class Tvertex, class Tface, class Norm>
class Enriched_halfedge : public CGAL::HalfedgeDS_halfedge_max_base_with_id<Refs, std::size_t>
{
	// normal
	Norm m_vnormal;

public:
	// life	cycle
	Enriched_halfedge() {}

	// normal
	Norm& vnormal() { return m_vnormal; }
	const Norm& vnormal() const { return m_vnormal; }
};

// a refined vertex with a normal and a tag
template <class	Refs, class T, class P, class N, class Kernel>
class Enriched_vertex : public CGAL::HalfedgeDS_vertex_max_base_with_id<Refs, P, std::size_t>
{
public:
	typedef	typename Kernel::FT FT;
	typedef	typename N Normal;
	//typedef typename CCurvature<Kernel> Curvature;

private:
	Normal m_normal;
	std::vector<Normal>vector_fields;
	FT heat_field;

public:
	// life	cycle
	Enriched_vertex() {}
	// repeat mandatory constructors
	Enriched_vertex(const P& pt) : CGAL::HalfedgeDS_vertex_max_base_with_id<Refs, P, std::size_t>(pt) {}

	// normal
	Normal& normal() { return m_normal; }
	const Normal& normal() const { return m_normal; }

	FT& heat_val() { return heat_field; }
	//const FT& heat_val() { return heat_field; }

	Normal& vector_field(int idx) { return vector_fields[idx]; }
	//const Normal& vector_field(int idx) { return vector_fields[idx]; }
};

struct Enriched_items : public CGAL::Polyhedron_items_3
{
	// wrap	vertex
	template <class Refs, class Traits>
	struct Vertex_wrapper
	{
		typedef	typename Traits::Point_3	Point;
		typedef	typename Traits::Vector_3	Normal;
		typedef	Enriched_vertex<Refs, CGAL::Tag_true, Point, Normal, Traits> Vertex;
	};

	// wrap	face
	template <class Refs, class Traits>
	struct Face_wrapper
	{
		typedef	typename Traits::Point_3	Point;
		typedef	typename Traits::Vector_3	Normal;
		typedef	Enriched_facet<Refs, CGAL::Tag_true, Point, Normal> Face;
	};

	// wrap	halfedge
	template <class Refs, class Traits>
	struct Halfedge_wrapper
	{
		typedef	typename Traits::Vector_3	Normal;
		typedef	Enriched_halfedge<Refs, CGAL::Tag_true, CGAL::Tag_true, CGAL::Tag_true, Normal>	Halfedge;
	};
};

struct anchor_point
{
	int anchor_vertex_idx;
	int anchor_seg;
};

struct seg_bound_lines
{
	std::vector<int>seg_lines;
	seg_parts seg_idx;
};

template <class	kernel, class items>
class ROI_vertex;

template <class	kernel,
	class items,
#ifndef CGAL_CFG_NO_TMPL_IN_TMPL_PARAM
	template <class T, class I, class A>
#endif
class T_HDS = CGAL::HalfedgeDS_default,
	class A = CGAL_ALLOCATOR(int)>
	class Enriched_polyhedron : public CGAL::Polyhedron_3<kernel, items>
{
public:
	typedef	typename kernel::FT			FT;
	typedef	typename kernel::Point_3	Point;
	typedef	typename kernel::Vector_3	Vector;
	typedef typename Vertex::Normal		Normal;
	typedef CGAL::Random_access_adaptor<Vertex_iterator>	Random_access_vertex_index;
	typedef CGAL::Random_access_adaptor<Facet_iterator>		Random_access_facet_index;
	typedef CGAL::HalfedgeDS_decorator<HalfedgeDS>			HalfedgeDS_decorator;
	typedef std::stack<std::pair<int, std::list<int>>>		Stack_list;
	typedef CGAL::Search_traits_3<kernel>					STraits;

	typedef Cholmod_matrix<double>			CMatrix;	// CHOLMOD only supports double floating-point number
	typedef Cholmod_vector<double>			CVector;	// CHOLMOD only supports double floating-point number
	typedef std::vector<std::set<int>>				VEC_SI;
	typedef std::vector<std::list<Facet_handle>>	VEC_LFh;
	typedef std::map<int, std::pair<short, short>>	MAP_ISP;	// map int to short pair
	typedef std::map<int, std::pair<Eigen::Vector3d, short>>	MAP_IVS;	// map int to Vector3&short

public:
	std::set<int> picked_vertices;
	std::set<int> picked_facets;

	std::vector<std::vector<double>>vec_4_scalar_field_bridge;
	std::vector<std::vector<std::vector<int>>>vec_4_curve_apt_bridge;
	std::vector<std::vector<std::vector<int>>>vec_4_paths_bridge;
	std::vector<std::vector<std::vector<int>>>vec_4_paths_bridge_origin;

	std::vector<std::vector<double>>sigma_field_paths;
	std::vector<std::vector<double>>feature_field_paths;
	std::vector<std::vector<double>>uncut_line_field_paths;

	std::vector<std::vector<double>>sigma_field_bridges;
	std::vector<std::vector<double>>feature_field_bridges;
	std::vector<std::vector<double>>uncut_line_field_bridges;

	std::vector<std::vector<std::vector<int>>>vec_4_curve_apt;
	std::vector <std::vector<double>>vec_4_scalar_field;
	std::vector <std::vector<std::vector<int>>>vec_4_paths;
	std::vector<std::vector<std::vector<int>>>vec_4_paths_origin;

private:
	//
	std::vector<std::string>feature_types;
	// bounding box
	FT m_min[3];
	FT m_max[3];
	FT m_scale;
	FT m_center[3];

	bool m_is_set_items_id;
	bool m_is_set_id_to_items_map;

	// type
	bool m_pure_quad;
	bool m_pure_triangle;

	FT							m_avg_edge_len;

	std::vector<Eigen::Vector3f>		m_mid_pl;

	std::string					m_s_hf_ws;	// weight
	std::string					m_s_hf_cs;	// constraint

	//
	bool						m_is_s_hvf_utd;
	std::vector<Eigen::Vector3d>m_s_vf;
	FT							m_s_hvm_max;		// maximum magnitude
	FT							m_s_hvm_min;		// minimum magnitude
	cholmod_factor* m_s_hvf_F;
	MAP_IVS					m_hvf_sites;
	MAP_IVS					m_hvf_sites_backup;

	bool hm_init;

	//std::vector<std::vector<std::vector<int>>>vec_4_curve_apt_bridge;
	std::vector<std::vector<Eigen::RowVector3d>>vec_4_vector_field_bridge;
	//std::vector<std::vector<double>>vec_4_scalar_field_bridge;
	//std::vector<std::vector<std::vector<int>>>vec_4_paths_bridge;

	//std::vector<std::vector<std::vector<int>>>vec_4_curve_apt;
	std::vector <int>vec_4_remain_split;
	std::vector <std::vector<int>>vec_extendable_apts;
	std::vector<std::vector<std::pair<int,int>>>vec_extendable_apts_;
	std::vector <std::vector<int>>vec_curve_end;
	//std::vector <std::vector<std::vector<int>>>vec_4_paths;
	std::vector <double>vec_4_paths_length;
	std::vector <std::vector<Eigen::RowVector3d>>vec_4_vector_field;
	//std::vector <std::vector<double>>vec_4_scalar_field;
	std::vector <anchor_point>vec_4_cur_apt;
	//std::vector <int>vec_4_cur_apt_picked_id;
	std::vector <int>vec_4_cur_seg;
	std::vector<int>vec_4_remain_avail;
	std::vector<std::vector<kVisit>>vec_4_is_visit;
	std::vector<double>vec_4_heat_accumulate;
	std::vector<int>vec_4_i;
	std::vector<int>vec_4_vec_i;

	std::vector<double>apt_split_prob;
	std::vector<int>able_split_pt_idx;
	bool is_loop_end;
	std::map<int, std::set<int>>select_pts_rings;
	std::vector<anchor_point>anchor_points;
	std::vector<seg_bound_lines>seg_lines;
	int cur_search_progress;

	graph_t origin_g;
	//std::vector<boost::graph_traits< graph_t >::vertex_descriptor> origin_p;
	//std::vector<double>origin_d;

	//std::vector<graph_t> vec_4_distorsion_g;
public:
	Random_access_vertex_index	index_to_vertex_map;
	Random_access_facet_index	index_to_facet_map;

	// life	cycle
	Enriched_polyhedron()
	{
	}

	Enriched_polyhedron(const Enriched_polyhedron& poly)
		: Polyhedron_3(poly)
	{
	}
	virtual	~Enriched_polyhedron()
	{
	}

	void init() 
	{ 
		m_s_hvf_F = NULL; 
		std::for_each(facets_begin(), facets_end(), Facet_normal<kernel, Facet>());
		std::for_each(vertices_begin(), vertices_end(), Vertex_normal<kernel, Vertex>());
		hm_init=false;
	}
	bool is_set_items_id() { return m_is_set_items_id; }
	bool is_set_id_to_items_map() { return m_is_set_id_to_items_map; }

	// type
	bool is_pure_triangle() { return m_pure_triangle; }
	bool is_pure_quad() { return m_pure_quad; }

	// normals (per	facet, then	per	vertex)
	void compute_normals_per_facet()
	{
		std::for_each(facets_begin(), facets_end(), Facet_normal2<kernel, Facet>());
	}
	void compute_normals_per_vertex()
	{
		std::for_each(vertices_begin(), vertices_end(), Vertex_normal<kernel, Vertex>());
	}
	void compute_normals_per_he_vertex()
	{
		std::for_each(vertices_begin(),
			vertices_end(),
			HalfedgeVertex_normal<kernel, Vertex>(85.0));
	}
	void compute_normals()
	{
		compute_normals_per_facet();
		compute_normals_per_vertex();
		compute_normals_per_he_vertex();
	}
	FT get_avg_edge_len(bool bRecalc = false)
	{
		if (m_avg_edge_len != 0.0 && !bRecalc) {
			return m_avg_edge_len;
		}
		Vector edge;
		FT len_edge = 0.0;
		int num_edge = 0;
		Halfedge_iterator pHalfEdge = halfedges_begin();
		CGAL_For_all(pHalfEdge, halfedges_end())
		{
			const Point& p1 = pHalfEdge->vertex()->point();
			const Point& p2 = pHalfEdge->opposite()->vertex()->point();
			edge = p1 - p2;
			len_edge += (FT)std::sqrt(edge * edge);
			num_edge++;
		}
		m_avg_edge_len = len_edge / (FT)num_edge;
		return m_avg_edge_len;
	}

	// compute bounding	box
	void compute_bounding_box(void)
	{
		if (size_of_vertices() == 0) {
			return;
		}
		Vertex_iterator pVertex = vertices_begin();
		m_min[0] = pVertex->point().x();
		m_max[0] = pVertex->point().x();
		m_min[1] = pVertex->point().y();
		m_max[1] = pVertex->point().y();
		m_min[2] = pVertex->point().z();
		m_max[2] = pVertex->point().z();
		for (; pVertex != vertices_end(); pVertex++)
		{
			const Point& p = pVertex->point();
			m_min[0] = std::min(m_min[0], p.x());
			m_min[1] = std::min(m_min[1], p.y());
			m_min[2] = std::min(m_min[2], p.z());
			m_max[0] = std::max(m_max[0], p.x());
			m_max[1] = std::max(m_max[1], p.y());
			m_max[2] = std::max(m_max[2], p.z());
		}
	}

	// bounding box
	FT xmin() { return m_min[0]; }
	FT xmax() { return m_max[0]; }
	FT ymin() { return m_min[1]; }
	FT ymax() { return m_max[1]; }
	FT zmin() { return m_min[2]; }
	FT zmax() { return m_max[2]; }

	void unitize(void)
	{
		compute_bounding_box();
		FT w, h, d;
		FT scale;
		// calculate model width, height, and depth
		w = m_max[0] - m_min[0];
		h = m_max[1] - m_min[1];
		d = m_max[2] - m_min[2];
		// calculate center of the model
		m_center[0] = (m_max[0] + m_min[0]) / 2.0;
		m_center[1] = (m_max[1] + m_min[1]) / 2.0;
		m_center[2] = (m_max[2] + m_min[2]) / 2.0;
		// calculate unitizing scale factor
		m_scale = m_unitize_sf / std::max(std::max(w, h), d);
		// translate around center then scale
		for (Vertex_iterator pVertex = vertices_begin(); pVertex != vertices_end(); pVertex++)
		{
			Point& point = pVertex->point();
			point = Point((point.x() - m_center[0]) * m_scale,
				(point.y() - m_center[1]) * m_scale,
				(point.z() - m_center[2]) * m_scale);
		}
		for (int i = 0; i < 3; i++)
		{
			m_min[i] *= m_scale;
			m_max[i] *= m_scale;
		}
		m_is_unitized = true;
	}
	void unitize(FT sf)
	{
		compute_bounding_box();
		FT cx, cy, cz, w, h, d;
		FT scale;
		m_unitize_sf = sf;
		// calculate model width, height, and depth
		w = m_max[0] - m_min[0];
		h = m_max[1] - m_min[1];
		d = m_max[2] - m_min[2];
		// calculate center of the model
		m_center[0] = (m_max[0] + m_min[0]) / 2.0;
		m_center[1] = (m_max[1] + m_min[1]) / 2.0;
		m_center[2] = (m_max[2] + m_min[2]) / 2.0;
		// calculate unitizing scale factor
		m_scale = m_unitize_sf / std::max(std::max(w, h), d);
		// translate around center then scale
		for (Vertex_iterator pVertex = vertices_begin(); pVertex != vertices_end(); pVertex++)
		{
			Point& point = pVertex->point();
			point = Point((point.x() - m_center[0]) * m_scale,
				(point.y() - m_center[1]) * m_scale,
				(point.z() - m_center[2]) * m_scale);
		}
		for (int i = 0; i < 3; i++)
		{
			m_min[i] *= m_scale;
			m_max[i] *= m_scale;
		}
		m_is_unitized = true;
	}
	void ununitize(void)
	{
		FT scl = 1.0 / m_scale;
		for (Vertex_iterator pVertex = vertices_begin(); pVertex != vertices_end(); pVertex++)
		{
			Point& point = pVertex->point();
			point = Point(point.x() * scl + m_center[0],
				point.y() * scl + m_center[1],
				point.z() * scl + m_center[2]);
		}
	}
	bool is_unitized(void)
	{
		return m_is_unitized;
	}
	FT	get_unitizing_scale_factor(void)
	{
		return m_unitize_sf;
	}

	static unsigned int degree(Facet_handle pFace)
	{
		return CGAL::circulator_size(pFace->facet_begin());
	}

	// valence of a vertex
	static unsigned int valence(Vertex_handle pVertex)
	{
		return CGAL::circulator_size(pVertex->vertex_begin());
	}

	unsigned int fvid(Facet_handle pFace, int v)
	{
		Halfedge_around_facet_circulator pHE;
		pHE = pFace->facet_begin();
		if (v == 0) {
			return pHE->vertex()->id();
		}
		pHE++;
		if (v == 1) {
			return pHE->vertex()->id();
		}
		pHE++;
		if (v == 2) {
			return pHE->vertex()->id();
		}
		return -1;
	}

	unsigned int fvid(int f, int v)
	{
		Halfedge_around_facet_circulator pHE;
		pHE = FH(f)->facet_begin();
		if (v == 0) {
			return pHE->vertex()->id();
		}
		pHE++;
		if (v == 1) {
			return pHE->vertex()->id();
		}
		pHE++;
		if (v == 2) {
			return pHE->vertex()->id();
		}
		return -1;
	}

	const Point_3& fvp(Facet_handle pFace, int v)
	{
		Halfedge_around_facet_circulator pHE;
		pHE = pFace->facet_begin();
		if (v == 0) {
			return pHE->vertex()->point();
		}
		pHE++;
		if (v == 1) {
			return pHE->vertex()->point();
		}
		pHE++;
		return pHE->vertex()->point();
	}

	const Point_3& fvp(int f, int v)
	{
		Halfedge_around_facet_circulator pHE;
		pHE = FH(f)->facet_begin();
		if (v == 0) {
			return pHE->vertex()->point();
		}
		pHE++;
		if (v == 1) {
			return pHE->vertex()->point();
		}
		pHE++;
		return pHE->vertex()->point();
	}

	// get the id of the opposite facet of v (0, 1 or 2) in facet f
	int fvofid(int f, int v)
	{
		Halfedge_around_facet_circulator pHE;
		pHE = FH(f)->facet_begin();
		if (v == 1) {
			if (pHE->opposite()->is_border()) {
				return -1;
			}
			else {
				return pHE->opposite()->facet()->id();
			}
		}
		else if (v == 2) {
			if (pHE->next()->opposite()->is_border()) {
				return -1;
			}
			else {
				return pHE->next()->opposite()->facet()->id();
			}
		}
		else if (v == 0) {
			if (pHE->next()->next()->opposite()->is_border()) {
				return -1;
			}
			else {
				return pHE->next()->next()->opposite()->facet()->id();
			}
		}
		else {
			return -1;
		}
	}

	// check wether	a vertex is on a boundary or not
	static bool	is_border(Vertex_handle	pVertex)
	{
		Halfedge_around_vertex_circulator	pHalfEdge = pVertex->vertex_begin();
		if (pHalfEdge == NULL)	// isolated	vertex
			return true;
		Halfedge_around_vertex_circulator	d = pHalfEdge;
		CGAL_For_all(pHalfEdge, d)
			if (pHalfEdge->is_border())
				return true;
		return false;
	}
	void set_id_to_items_map()
	{
		index_to_vertex_map = Random_access_vertex_index(vertices_begin(), vertices_end());
		index_to_facet_map = Random_access_facet_index(facets_begin(), facets_end());
		m_is_set_id_to_items_map = true;
	}

	void set_hds_items_id()
	{
		int	index = 0;
		for (Vertex_iterator pVertex = vertices_begin(); pVertex != vertices_end(); pVertex++) {
			pVertex->id() = index++;
		}
		index = 0;
		for (Halfedge_iterator pHalfedge = halfedges_begin(); pHalfedge != halfedges_end(); pHalfedge++) {
			pHalfedge->id() = index++;
		}
		index = 0;
		for (Face_iterator pFacet = facets_begin(); pFacet != facets_end(); pFacet++) {
			pFacet->id() = index++;
		}
		m_is_set_items_id = true;
	}

	// is pure degree ?
	bool is_pure_degree(unsigned int d)
	{
		for (Facet_iterator pFace = facets_begin();
			pFace != facets_end();
			pFace++)
			if (degree(pFace) != d)
				return false;
		return true;
	}

	// compute type
	void compute_type()
	{
		m_pure_quad = is_pure_degree(4);
		m_pure_triangle = is_pure_degree(3);
	}

	// compute facet center
	void compute_facet_center(Facet_handle pFace, Point& center)
	{
		CGAL::Halfedge_around_facet_circulator pHalfEdge = pFace->facet_begin();
		CGAL::Halfedge_around_facet_circulator end = pHalfEdge;
		Vector vec(0.0, 0.0, 0.0);
		int	degree = 0;
		CGAL_For_all(pHalfEdge, end)
		{
			vec = vec + (pHalfEdge->vertex()->point() - CGAL::ORIGIN);
			degree++;
		}
		center = CGAL::ORIGIN + (vec / (kernel::FT)degree);
	}

	FT average_edge_length_around(Vertex_handle pVertex)
	{
		FT sum = 0.0;
		Halfedge_around_vertex_circulator pHalfEdge = pVertex->vertex_begin();
		Halfedge_around_vertex_circulator end = pHalfEdge;
		Vector vec(0.0, 0.0, 0.0);
		int	degree = 0;
		CGAL_For_all(pHalfEdge, end)
		{
			Vector vec = pHalfEdge->vertex()->point() -
				pHalfEdge->opposite()->vertex()->point();
			sum += std::sqrt(vec * vec);
			degree++;
		}
		return sum / (FT)degree;
	}

	// compute average edge length around a vertex
	FT min_edge_length_around(Vertex_handle pVertex)
	{
		FT min_edge_length = 1e38;
		Halfedge_around_vertex_circulator pHalfEdge = pVertex->vertex_begin();
		Halfedge_around_vertex_circulator end = pHalfEdge;
		Vector vec(0.0, 0.0, 0.0);
		int	degree = 0;
		CGAL_For_all(pHalfEdge, end)
		{
			Vector vec = pHalfEdge->vertex()->point() -
				pHalfEdge->opposite()->vertex()->point();
			FT len = std::sqrt(vec * vec);
			if (len < min_edge_length)
				min_edge_length = len;
		}
		return min_edge_length;
	}

	void clear_picked_vertices(void)
	{
		picked_vertices.clear();
	}

	void clamp_harmonic_field(FT* hf, int n)
	{
		for (int i = 0; i < n; i++) {
			if (hf[i] > 1.0) {
				hf[i] = 1.0;
			}
			else if (hf[i] < 0.0) {
				hf[i] = 0.0;
			}
		}
	}

	bool is_s_hf_uptodate(void)
	{
		return m_is_s_hf_utd;
	}
	bool is_s_hvf_uptodate(void)
	{
		return m_is_s_hvf_utd;
	}
	bool is_built_hf_s_vbo(void)
	{
		return m_is_built_sf_color_vbo;
	}
	bool is_built_cluster_vbo(void)
	{
		return m_is_built_cluster_color_vbo;
	}
	bool is_built_vote_vbo(void)
	{
		return m_is_built_vote_vbo;
	}
	bool is_built_tex_vbo(void)
	{
		return m_is_built_tex_color_vbo;
	}
	int get_site_num(void)
	{
		return m_sf_sites.size();
	}
	int get_hvf_site_num(void)
	{
		return m_hvf_sites.size();
	}
	void set_hvf_sites(MAP_IVS& sites)
	{
		m_hvf_sites = sites;
		m_is_s_hvf_utd = false;
	}
	void clear_hvf_sites()
	{
		m_hvf_sites.clear();
		m_is_s_hvf_utd = false;
	}
	void insert_hvf_site(std::pair<int, std::pair<Eigen::Vector3d, short>> item)
	{
		m_hvf_sites.insert(item);
		m_is_s_hvf_utd = false;
	}
	void clear_hf_sites()
	{
		m_sf_sites.clear();
		m_is_s_hf_utd = false;
	}

	/////
	void set_s_hvf_rhs_vec(CVector* tvRHSV, int dim)
	{
		// BNM: d+n is equivallent to d*(1+n/d), where the big number is (1+n/d)
		tvRHSV->clear_zero();
		MAP_IVS::iterator it;
		for (it = m_hvf_sites.begin(); it != m_hvf_sites.end(); it++) {
			(*tvRHSV)[it->first] = BN * ((it->second).first)[dim];
		}
	}

	void set_s_hvf_rhs_vec_single_step(Eigen::SparseMatrix<double>& mat)
	{	
		std::vector <Eigen::Triplet<double>>tris;
		for (auto it = m_hvf_sites.begin(); it != m_hvf_sites.end(); it++) {
			tris.push_back(Eigen::Triplet<double>(it->first, 0, ((it->second).first)[0]));
			tris.push_back(Eigen::Triplet<double>(it->first, 1, ((it->second).first)[1]));
			tris.push_back(Eigen::Triplet<double>(it->first, 2, ((it->second).first)[2]));
		}
		mat.setFromTriplets(tris.begin(), tris.end());
	}
	void set_s_hvf_lap_uniform_PNT(CMatrix* tmAssLM)
	{
		Halfedge_around_vertex_circulator pHalfEdge, end;
		FT diag_sum(0.0);
		short* tag = new short[size_of_vertices()];
		memset(tag, 0, size_of_vertices() * sizeof(short));
		for (MAP_IVS::iterator it = m_hvf_sites.begin(); it != m_hvf_sites.end(); it++) {
			tag[it->first] = 1;
			(it->second).second = 0;
		}
		// Set Laplacian matrix
		// BNM: d+n is equivallent to d*(1+n/d), where the big number is (1+n/d)
		for (int i = 0; i < size_of_vertices(); i++)
		{
			pHalfEdge = index_to_vertex_map[i]->vertex_begin();
			end = pHalfEdge;
			diag_sum = 0.0;
			CGAL_For_all(pHalfEdge, end)
			{
				tmAssLM->set_coef(i, pHalfEdge->opposite()->vertex()->id(), -1.0);
				diag_sum += 1.0;
			}
			if (tag[i] == 1) {
				tmAssLM->set_coef(i, i, diag_sum + BN);
			}
			else {
				tmAssLM->set_coef(i, i, diag_sum);
			}
		}
		//SAFE_DELETE_ARRAY(tag);
	}

	void set_s_hvf_lap_uniform_PNT_single_step(Eigen::SparseMatrix<double>&mat)
	{
		Halfedge_around_vertex_circulator pHalfEdge, end;
		double diag_sum(0.0);
		std::vector < Eigen::Triplet<double>>tris;
		std::vector<int>site_vec_idx;
		for (MAP_IVS::iterator it = m_hvf_sites.begin(); it != m_hvf_sites.end(); it++) {
			//tag[it->first] = 1;
			tris.push_back(Eigen::Triplet<double>(it->first, it->first, 1.0));
			site_vec_idx.push_back(it->first);
		}
		// Set Laplacian matrix
		// BNM: d+n is equivallent to d*(1+n/d), where the big number is (1+n/d)
		for (int i = 0; i < size_of_vertices(); i++)
		{	
			if (std::find(site_vec_idx.begin(), site_vec_idx.end(), i) != site_vec_idx.end())
			{
				continue;
			}
			pHalfEdge = index_to_vertex_map[i]->vertex_begin();
			end = pHalfEdge;
			diag_sum = 0.0;
			CGAL_For_all(pHalfEdge, end)
			{
				//tmAssLM->set_coef(i, pHalfEdge->opposite()->vertex()->id(), -1.0);
				tris.push_back(Eigen::Triplet<double>(i, pHalfEdge->opposite()->vertex()->id(), -1.0));
				diag_sum += 1.0;
			}
			//tmAssLM->set_coef(i, i, diag_sum);
			tris.push_back(Eigen::Triplet<double>(i, i, diag_sum));
		}
		mat.setFromTriplets(tris.begin(), tris.end());
		//SAFE_DELETE_ARRAY(tag);
	}

	const Eigen::Vector3d& get_hvf_v(int i)
	{
		return m_s_vf[i];
	}

	void compute_s_hvf(void)
	{
		if (m_hvf_sites.empty()) {
			return;
		}
		cholmod_common c;
		cholmod_start(&c);	// start CHOLMOD
		if (m_s_hvf_F == NULL) {	// if not existed, compute new factorization
			CMatrix* AM_hf = new CMatrix((int)size_of_vertices(), true, &c);
			set_s_hvf_lap_uniform_PNT(AM_hf);
			m_s_hvf_F = cholmod_analyze((cholmod_sparse*)AM_hf->get_cholmod_sparse(), &c);	// analyze
			cholmod_factorize((cholmod_sparse*)AM_hf->get_cholmod_sparse(), m_s_hvf_F, &c);	// factorize
			delete AM_hf;
		}
		else {
			CMatrix* cmC = new CMatrix((int)size_of_vertices(), false, &c);
			cholmod_sparse* Cnew;
			bool bNeedDown = false;
			bool bNeedUp = false;
			// build downdate sparse
			std::vector<MAP_IVS::iterator> its;
			for (MAP_IVS::iterator it = m_hvf_sites.begin(); it != m_hvf_sites.end(); it++) {
				if ((it->second).second == -1) {	// -1: to be downdated
					cmC->set_coef(it->first, it->first, SQBN);
					its.push_back(it);
					bNeedDown = true;
				}
			}
			// delete doublely
			for (unsigned int i = 0; i < its.size(); i++) {
				m_hvf_sites.erase(its[i]);
			}
			if (bNeedDown) {	// if needed, perform downdating
				Cnew = cholmod_submatrix((cholmod_sparse*)cmC->get_cholmod_sparse(), (int*)m_s_hvf_F->Perm,
					m_s_hvf_F->n, NULL, -1, TRUE, TRUE, &c);
				cholmod_updown(FALSE, Cnew, m_s_hvf_F, &c);
				cholmod_free_sparse(&Cnew, &c);
				cmC->clear_sparse();
			}
			// build update sparse
			for (MAP_IVS::iterator it = m_hvf_sites.begin(); it != m_hvf_sites.end(); it++) {
				if ((it->second).second == 1) {	// +1: to be updated
					cmC->set_coef(it->first, it->first, SQBN);
					(it->second).second = 0;	// turn it back to 0: up-to-date
					bNeedUp = true;
				}
			}
			if (bNeedUp) {	// if needed, perform updating
				Cnew = cholmod_submatrix((cholmod_sparse*)cmC->get_cholmod_sparse(), (int*)m_s_hvf_F->Perm,
					m_s_hvf_F->n, NULL, -1, TRUE, TRUE, &c);
				cholmod_updown(TRUE, Cnew, m_s_hvf_F, &c);
				cholmod_free_sparse(&Cnew, &c);
			}
			delete cmC;
		}
		CVector* RHV_hf = new CVector((int)size_of_vertices(), &c);
		if (m_s_vf.size() < size_of_vertices())
		{
			m_s_vf.resize(size_of_vertices());
		}
		for (int d = 0; d < 3; d++)
		{
			set_s_hvf_rhs_vec(RHV_hf, d);	// set rhs vector
			cholmod_dense* X = cholmod_solve(CHOLMOD_A, m_s_hvf_F, (cholmod_dense*)RHV_hf->get_cholmod_dense(), &c);	// solve Ax=b
			for (int i = 0; i < size_of_vertices(); i++) m_s_vf[i][d] = (FT)((double*)X->x)[i];
			cholmod_free_dense(&X, &c);
		}
		delete RHV_hf;
		// projection
		project_harmonic_vector_field(m_s_vf.data(), 0.04, 0.16);
		cholmod_finish(&c);		// end CHOLMOD
		m_is_s_hvf_utd = true;
	}

	void compute_s_hvf_single_step(std::vector<Eigen::RowVector3d>&f_vf)
	{
		if (m_hvf_sites.empty()) {
			return;
		}
		Eigen::SparseMatrix<double>laplacian(this->size_of_vertices(),this->size_of_vertices());
		set_s_hvf_lap_uniform_PNT_single_step(laplacian);
		Eigen::SparseMatrix<double>b(this->size_of_vertices(), 3);
		set_s_hvf_rhs_vec_single_step(b);
		Eigen::SparseLU< Eigen::SparseMatrix<double>>solver(laplacian);
		Eigen::MatrixXd X= solver.solve(b);
		f_vf.clear();
		for (int i = 0; i < X.rows(); ++i)
		{
			f_vf.push_back(X.row(i).normalized());
		}
	}

	void project_harmonic_vector_field(Eigen::Vector3d* hvf, FT low = 1.0, FT high = 1.0)
	{
		if (hvf == NULL || low > high || low < 0.0) {
			return;
		}
		Eigen::Vector3d vn, pvec;
		if (low == high) {
			m_s_hvm_min = std::numeric_limits<FT>::max();
			m_s_hvm_max = std::numeric_limits<FT>::min();
			for (int i = 0; i < size_of_vertices(); i++) {
				vn=Eigen::Vector3d(VN(i)[0], VN(i)[1], VN(i)[2]);
				pvec = hvf[i].cross(vn);
				FT m(0.0);
				if (IsZeroL(pvec[0]) && IsZeroL(pvec[1]) && IsZeroL(pvec[2])) {
					hvf[i]=Eigen::Vector3d(0.0, 0.0, 0.0);
				}
				else {
					hvf[i] = vn.cross(pvec);
					m = hvf[i].norm();
				}
				if (m > m_s_hvm_max) {
					m_s_hvm_max = m;
				}
				if (m < m_s_hvm_min) {
					m_s_hvm_min = m;
				}
			}
		}
		else {
			FT mmax = std::numeric_limits<FT>::min();
			FT mmin = std::numeric_limits<FT>::max();
			std::vector<FT> mag(size_of_vertices(), 0.0);
			for (int i = 0; i < size_of_vertices(); i++) {
				vn=Eigen::Vector3d(VN(i)[0], VN(i)[1], VN(i)[2]);
				pvec = hvf[i].cross(vn);
				if (IsZeroL(pvec[0]) && IsZeroL(pvec[1]) && IsZeroL(pvec[2])) {
					hvf[i]=Eigen::Vector3d(0.0, 0.0, 0.0);
					mag[i] = 0.0;
				}
				else {
					hvf[i] = vn.cross(pvec);
					mag[i] = hvf[i].norm();
				}
				if (mag[i] > mmax) {
					mmax = mag[i];
				}
				if (mag[i] < mmin) {
					mmin = mag[i];
				}
			}
			FT scl = (high - low) / (mmax - mmin);
			for (int i = 0; i < size_of_vertices(); i++) {
				hvf[i] *= ((low + scl * (mag[i] - mmin)) / mag[i]);
			}
			m_s_hvm_min = low;
			m_s_hvm_max = high;
		}
	}

	void compute_site_vectors(const std::vector<int>& feature_points,
		const std::vector<Eigen::RowVector3d>& line_dir)
	{
		MAP_IVS::iterator it;
		for (int i=0;i<feature_points.size();++i)
		{
			if ((it = m_hvf_sites.find(feature_points[i])) != m_hvf_sites.end())
			{
				if ((it->second).second == 0)
				{	// existed and first time handling in this round
					(it->second).first = Eigen::Vector3d(0.0, 0.0, 0.0);	// reset
					(it->second).second = 2;	// up-to-date, handled this round
				}
				(it->second).first += Eigen::Vector3d(line_dir[i].x(), line_dir[i].y(), line_dir[i].z());
			}
			else
			{
				m_hvf_sites.insert(std::make_pair(feature_points[i], std::make_pair(Eigen::Vector3d(line_dir[i].x(), line_dir[i].y(), line_dir[i].z()) , 1)));
			}
		}

	}

	void compute_site_vectors(const std::vector<Eigen::RowVector3d>& feature_line,
								const std::vector<int>& feature_line_cross_face,
								const std::vector<Eigen::RowVector3d>& line_dir)
	{	
		MAP_IVS::iterator it;
		for (int i = 0; i < feature_line_cross_face.size(); i++)
		{
			// find the closest vertex in triangle m_pCLInfo[i].seg[j].fi
			int face_id = feature_line_cross_face[i];
			FT min_sqd = std::numeric_limits<FT>::max();
			auto facet = index_to_facet_map[face_id];
			int face_it = 0;
			int vid;
			for (auto f_it = facet->facet_begin(); face_it < 3; ++f_it)
			{
				auto pt = f_it->vertex()->point();
				Eigen::RowVector3d pt_(pt.x(), pt.y(), pt.z());
				FT sqd = std::pow((pt_ - feature_line[i]).norm(),2);
				if (sqd < min_sqd)
				{
					min_sqd = sqd;
					vid = f_it->vertex()->id();
					//////////std::cout << "vid" << vid << std::endl;
				}
				face_it++;
			}
			FT w = 1.0 / (min_sqd+0.0001);
			// check if existed
			if ((it = m_hvf_sites.find(vid)) != m_hvf_sites.end()) 
			{
				if ((it->second).second == 0) 
				{	// existed and first time handling in this round
					(it->second).first=Eigen::Vector3d(0.0, 0.0, 0.0);	// reset
					(it->second).second = 2;	// up-to-date, handled this round
				}
				(it->second).first += Eigen::Vector3d(line_dir[i].x(), line_dir[i].y(), line_dir[i].z()) * w;
			}
			else 
			{
				m_hvf_sites.insert(std::make_pair(vid, std::make_pair(Eigen::Vector3d(line_dir[i].x(), line_dir[i].y(), line_dir[i].z()) * w, 1)));
			}
		}
	}

	

	void compute_optimal_orien(const std::vector<int>& feature_points,
		std::vector<Eigen::RowVector3d>& feature_vector_field)
	{
		m_hvf_sites_backup.clear();
		m_hvf_sites.clear();
		m_s_vf.clear();
		std::vector<Eigen::RowVector3d>lines_dir(feature_points.size());
		Eigen::RowVector3d pt1 = Eigen::RowVector3d(index_to_vertex_map[feature_points[1]]->point().x(),
			index_to_vertex_map[feature_points[1]]->point().y(),
			index_to_vertex_map[feature_points[1]]->point().z());
		Eigen::RowVector3d pt2 = Eigen::RowVector3d(index_to_vertex_map[feature_points[0]]->point().x(),
			index_to_vertex_map[feature_points[0]]->point().y(),
			index_to_vertex_map[feature_points[0]]->point().z());
		lines_dir.push_back((pt1-pt2).normalized());
		for (int j = 1; j < feature_points.size() - 1; ++j)
		{	
			pt1 = Eigen::RowVector3d(index_to_vertex_map[feature_points[j-1]]->point().x(),
				index_to_vertex_map[feature_points[j-1]]->point().y(),
				index_to_vertex_map[feature_points[j-1]]->point().z());
			pt2 = Eigen::RowVector3d(index_to_vertex_map[feature_points[j+1]]->point().x(),
				index_to_vertex_map[feature_points[j+1]]->point().y(),
				index_to_vertex_map[feature_points[j+1]]->point().z());
			//lines_dir[i].push_back(((feature_lines[i][j - 1] - feature_lines[i][j + 1]) / 2).normalized());
			lines_dir.push_back((pt1 - pt2).normalized());
		}
		pt1 = Eigen::RowVector3d(index_to_vertex_map[feature_points.back()]->point().x(),
			index_to_vertex_map[feature_points.back()]->point().y(),
			index_to_vertex_map[feature_points.back()]->point().z());
		pt2 = Eigen::RowVector3d(index_to_vertex_map[feature_points[feature_points.size() - 2]]->point().x(),
			index_to_vertex_map[feature_points[feature_points.size() - 2]]->point().y(),
			index_to_vertex_map[feature_points[feature_points.size() - 2]]->point().z());
		lines_dir.push_back((pt1 - pt2).normalized());
		compute_site_vectors(feature_points,lines_dir);
		compute_s_hvf_single_step(feature_vector_field);
	}

	int compute_optimal_orien(const std::vector<std::vector<Eigen::RowVector3d>>& feature_lines,
		const std::vector<std::vector<int>>& feature_lines_cross_face,
		std::vector<Eigen::RowVector3d>&feature_vector_field)
	{	
		m_hvf_sites_backup.clear();
		m_hvf_sites.clear();
		m_s_vf.clear();
		int iMax = 0;
		FT dMaxLen = 0.0;
		int iNumLine = 0;
		std::vector<int> scan(feature_lines.size(), 0);
		std::vector<FT>line_len(feature_lines.size(), 0);
		std::vector<std::vector<Eigen::RowVector3d>>lines_dir(feature_lines.size());
		for (int i = 0; i < feature_lines.size(); i++)
		{	
			for (int j = 0; j < feature_lines[i].size()-1; ++j)
			{
				line_len[i] += (feature_lines[i][j] - feature_lines[i][j + 1]).norm();
			}
			if (line_len[i] > dMaxLen)
			{
				iMax = i;
				dMaxLen = line_len[i];
			}
			lines_dir[i].push_back((feature_lines[i][1] - feature_lines[i][0]).normalized());
			for (int j = 1; j < feature_lines[i].size() - 1; ++j)
			{
				lines_dir[i].push_back(((feature_lines[i][j-1] - feature_lines[i][j+1])/2).normalized());
			}
			lines_dir[i].push_back((feature_lines[i].back() - feature_lines[i][feature_lines[i].size()-2]).normalized());
		}
		scan[iMax] = 1;
		//YZJ:change here compute all lines vector field
		for (int t = 0; t < feature_lines.size(); t++)
		{	
			////////std::cout << "ori" << t << std::endl;
			compute_site_vectors(feature_lines[iMax], feature_lines_cross_face[iMax], lines_dir[iMax]);
			compute_s_hvf();
			FT dMTotalC = std::numeric_limits<FT>::max();
			FT dMAvgC = 0.0;
			bool bMReverse = false;
			bool bFound = false;
			for (int i = 0; i < feature_lines.size(); i++)
			{
				if (scan[i] == 1) 
				{
					continue;
				}
				FT dTotalC, dAvgC;
				bool bReverse;
				compute_consistency(feature_lines[i], feature_lines_cross_face[i], lines_dir[i], 
					dTotalC, dAvgC, bReverse);	// get consistency score
				if (dTotalC < dMTotalC) 
				{
					iMax = i;
					dMTotalC = dTotalC;
					dMAvgC = dAvgC;
					bMReverse = bReverse;
					bFound = true;
				}
				////////std::cout << "consist:" << dTotalC << " " << dMTotalC << std::endl;
			}
			////////std::cout << "bfound" << bFound << std::endl;
			if (!bFound) 
			{
				break;
			}
			//////////////////////////////////////////////////////////////////////////
			if (bMReverse) 
			{
				reverse_line_orien(lines_dir[iMax]);
			}
			//////////////////////////////////////////////////////////////////////////
			scan[iMax] = 1;
		}
		////////std::cout << m_s_vf.size() << "aa" << std::endl;
		feature_vector_field = std::vector<Eigen::RowVector3d>(m_s_vf.begin(), m_s_vf.end());
		if (m_s_hvf_F != NULL) {
			cholmod_common c;
			cholmod_free_factor(&m_s_hvf_F, &c);
			m_s_hvf_F = NULL;
		}
		return 0;
	}

	int compute_optimal_orien(const std::vector<std::vector<int>>& feature_lines_idx,
		//const std::vector<std::vector<int>>& feature_lines_cross_face,
		std::vector<Eigen::RowVector3d>& feature_vector_field)
	{	
		std::vector<std::vector<Eigen::RowVector3d>>feature_lines(feature_lines_idx.size());
		for (int i = 0; i < feature_lines_idx.size(); ++i)
		{
			for (int j = 0; j < feature_lines_idx[i].size(); ++j)
			{	
				auto pt = index_to_vertex_map[feature_lines_idx[i][j]]->point();
				feature_lines[i].push_back(Eigen::RowVector3d(pt.x(), pt.y(), pt.z()));
			}
		}
		m_hvf_sites_backup.clear();
		m_hvf_sites.clear();
		m_s_vf.clear();
		int iMax = 0;
		FT dMaxLen = 0.0;
		int iNumLine = 0;
		std::vector<int> scan(feature_lines.size(), 0);
		std::vector<FT>line_len(feature_lines.size(), 0);
		std::vector<std::vector<Eigen::RowVector3d>>lines_dir(feature_lines.size());
		for (int i = 0; i < feature_lines.size(); i++)
		{
			for (int j = 0; j < feature_lines[i].size() - 1; ++j)
			{
				line_len[i] += (feature_lines[i][j] - feature_lines[i][j + 1]).norm();
			}
			if (line_len[i] > dMaxLen)
			{
				iMax = i;
				dMaxLen = line_len[i];
			}
			lines_dir[i].push_back((feature_lines[i][1] - feature_lines[i][0]).normalized());
			for (int j = 1; j < feature_lines[i].size() - 1; ++j)
			{
				lines_dir[i].push_back(((feature_lines[i][j - 1] - feature_lines[i][j + 1]) / 2).normalized());
			}
			lines_dir[i].push_back((feature_lines[i].back() - feature_lines[i][feature_lines[i].size() - 2]).normalized());
		}
		scan[iMax] = 1;
		//YZJ:change here compute all lines vector field
		for (int t = 0; t < feature_lines.size(); t++)
		{
			////////std::cout << "ori" << t << std::endl;
			compute_site_vectors(feature_lines_idx[iMax], lines_dir[iMax]);
			compute_s_hvf();
			FT dMTotalC = std::numeric_limits<FT>::max();
			FT dMAvgC = 0.0;
			bool bMReverse = false;
			bool bFound = false;
			for (int i = 0; i < feature_lines.size(); i++)
			{
				if (scan[i] == 1)
				{
					continue;
				}
				FT dTotalC, dAvgC;
				bool bReverse;
				compute_consistency(feature_lines_idx[i], lines_dir[i],
					dTotalC, dAvgC, bReverse);	// get consistency score
				if (dTotalC < dMTotalC)
				{
					iMax = i;
					dMTotalC = dTotalC;
					dMAvgC = dAvgC;
					bMReverse = bReverse;
					bFound = true;
				}
				////////std::cout << "consist:" << dTotalC << " " << dMTotalC << std::endl;
			}
			////////std::cout << "bfound" << bFound << std::endl;
			if (!bFound)
			{
				break;
			}
			//////////////////////////////////////////////////////////////////////////
			if (bMReverse)
			{
				reverse_line_orien(lines_dir[iMax]);
			}
			//////////////////////////////////////////////////////////////////////////
			scan[iMax] = 1;
		}
		////////std::cout << m_s_vf.size() << "aa" << std::endl;
		feature_vector_field = std::vector<Eigen::RowVector3d>(m_s_vf.begin(), m_s_vf.end());
		if (m_s_hvf_F != NULL) {
			cholmod_common c;
			cholmod_free_factor(&m_s_hvf_F, &c);
			m_s_hvf_F = NULL;
		}
		return 0;
	}

	void compute_consistency(const std::vector<Eigen::RowVector3d>& feature_line,
		const std::vector<int>& feature_line_cross_face, const std::vector<Eigen::RowVector3d>& line_dir,
		FT& dTC, FT& dAC, bool& bR)
	{
		FT dTC1(0.0), dTC2(0.0);
		int iNumSample = feature_line.size();
		for (int i = 0; i < feature_line_cross_face.size(); i++)
		{
			// find the closest vertex in triangle m_pCLInfo[i].seg[j].fi
			int face_id = feature_line_cross_face[i];
			FT min_sqd = std::numeric_limits<FT>::max();
			auto facet = index_to_facet_map[face_id];
			int face_it = 0;
			int vid;
			for (auto f_it = facet->facet_begin(); face_it < 3; ++f_it)
			{
				auto pt = f_it->vertex()->point();
				Eigen::RowVector3d pt_(pt.x(), pt.y(), pt.z());
				FT sqd = std::pow((pt_ - feature_line[i]).norm(),2);
				if (sqd < min_sqd)
				{
					min_sqd = sqd;
					vid = f_it->vertex()->id();
				}
				face_it++;
			}
			const Eigen::Vector3d& fv = get_hvf_v(vid);
			const Eigen::Vector3d& lv = Eigen::Vector3d(line_dir[i].x(), line_dir[i].y(), line_dir[i].z()); //= m_pCLInfo[l].dir[i];
			FT dAngle = AcosR(fv.dot(lv) / (fv.norm() * lv.norm()+0.00001));
			dTC1 += (ML_PI - dAngle) / (ML_PI + dAngle);
			dAngle = AcosR(fv.dot(lv * (-1.0)) / (fv.norm() * lv.norm()+0.00001));
			dTC2 += (ML_PI - dAngle) / (ML_PI + dAngle);
		}
		dTC = __max(dTC1, dTC2);
		dAC = dTC / (FT)iNumSample;
		bR = (dTC == dTC2);
	}

	void compute_consistency(const std::vector<int>& feature_line,
		const std::vector<Eigen::RowVector3d>& line_dir,
		FT& dTC, FT& dAC, bool& bR)
	{
		FT dTC1(0.0), dTC2(0.0);
		int iNumSample = feature_line.size();
		for (int i = 0; i < feature_line.size(); i++)
		{
			const Eigen::Vector3d& fv = get_hvf_v(feature_line[i]);
			const Eigen::Vector3d& lv = Eigen::Vector3d(line_dir[i].x(), line_dir[i].y(), line_dir[i].z()); //= m_pCLInfo[l].dir[i];
			FT dAngle = AcosR(fv.dot(lv) / (fv.norm() * lv.norm() + 0.00001));
			dTC1 += (ML_PI - dAngle) / (ML_PI + dAngle);
			dAngle = AcosR(fv.dot(lv * (-1.0)) / (fv.norm() * lv.norm() + 0.00001));
			dTC2 += (ML_PI - dAngle) / (ML_PI + dAngle);
		}
		dTC = __max(dTC1, dTC2);
		dAC = dTC / (FT)iNumSample;
		bR = (dTC == dTC2);
	}

	void reverse_line_orien(std::vector<Eigen::RowVector3d>& line_dir)
	{
		for (int i = 0; i < line_dir.size(); ++i)
		{
			line_dir[i] *= -1;
		}
	}
	void compute_heat_val(const std::vector<std::vector<int>>& feature_points,
		std::vector<double>& feature_scalar_field)
	{
		typedef CGAL::Heat_method_3::Surface_mesh_geodesic_distances_3<Polyhedron_3> Heat_method;
		//typedef boost::graph_traits<Polyhedron_3>::vertex_descriptor vertex_descriptor;
		boost::unordered_map<boost::graph_traits<Polyhedron_3>::vertex_descriptor, double>vertex_distance;
		Heat_method hm(*this);
		for (int i = 0; i < feature_points.size(); ++i)
		{	
			for (int j = 0; j < feature_points[i].size(); ++j)
			{
				hm.add_source(index_to_vertex_map[feature_points[i][j]]);
			}
		}
		hm.estimate_geodesic_distances(boost::make_assoc_property_map(vertex_distance));
		feature_scalar_field.resize(vertex_distance.size());
		for (auto i : vertex_distance)
		{
			feature_scalar_field[i.first->id()] = i.second;
		}

		for (int i = 0; i < feature_points.size(); ++i)
		{
			for (int j = 0; j < feature_points[i].size(); ++j)
			{
				feature_scalar_field[feature_points[i][j]] = 0;
			}
		}
	}

	void compute_heat_val(const std::vector<int>& feature_points,
		std::vector<double>& feature_scalar_field)
	{	
		typedef CGAL::Heat_method_3::Surface_mesh_geodesic_distances_3<Polyhedron_3> Heat_method;
		//typedef boost::graph_traits<Polyhedron_3>::vertex_descriptor vertex_descriptor;
		boost::unordered_map<boost::graph_traits<Polyhedron_3>::vertex_descriptor, double>vertex_distance;
		Heat_method hm(*this);
		for (int i = 0; i < feature_points.size(); ++i)
		{
			hm.add_source(index_to_vertex_map[feature_points[i]]);
		}
		hm.estimate_geodesic_distances(boost::make_assoc_property_map(vertex_distance));
		feature_scalar_field.resize(vertex_distance.size());
		for (auto i : vertex_distance)
		{
			feature_scalar_field[i.first->id()] = i.second;
		}
		for (auto i : feature_points)
		{
			feature_scalar_field[i] = 0;
		}
	}

	void compute_heat_val(const std::vector<std::vector<Eigen::RowVector3d>>& feature_lines,
		const std::vector<std::vector<int>>& feature_lines_cross_face,
		std::vector<double>& feature_scalar_field)
	{
		typedef CGAL::Heat_method_3::Surface_mesh_geodesic_distances_3<Polyhedron_3> Heat_method;
		//typedef boost::graph_traits<Polyhedron_3>::vertex_descriptor vertex_descriptor;
		boost::unordered_map<boost::graph_traits<Polyhedron_3>::vertex_descriptor, double>vertex_distance;
		Heat_method hm(*this);
		for (int i = 0; i < feature_lines_cross_face.size(); i++)
		{
			for (int j = 0; j < feature_lines_cross_face[i].size(); ++j)
			{
				int face_id = feature_lines_cross_face[i][j];
				FT min_sqd = std::numeric_limits<FT>::max();
				auto facet = index_to_facet_map[face_id];
				int face_it = 0;
				int vid;
				for (auto f_it = facet->facet_begin(); face_it < 3; ++f_it)
				{
					auto pt = f_it->vertex()->point();
					Eigen::RowVector3d pt_(pt.x(), pt.y(), pt.z());
					FT sqd = std::pow((pt_ - feature_lines[i][j]).norm(), 2);
					if (sqd < min_sqd)
					{
						min_sqd = sqd;
						vid = f_it->vertex()->id();
					}
					face_it++;
				}
				hm.add_source(index_to_vertex_map[vid]);
			}
		}
		hm.estimate_geodesic_distances(boost::make_assoc_property_map(vertex_distance));
		feature_scalar_field.resize(vertex_distance.size());
		for (auto i : vertex_distance)
		{
			feature_scalar_field[i.first->id()] = i.second;
		}
	}

	void detect_seg_lines(segIO &seg)
	{
		std::map<seg_parts, std::set<int>>seg_vertices;
		seg.vertex_in_segment.resize(this->size_of_vertices());
		for (auto v_it = this->vertices_begin(); v_it != this->vertices_end(); ++v_it)
		{
			if (this->is_border(v_it))
			{
				continue;
			}
			int deg_visit = 0;
			bool is_on_segbound=false;
			for (auto he_it = v_it->vertex_begin(); deg_visit < v_it->vertex_degree(); ++he_it)
			{
				int seg_idx_1 = seg[he_it->facet()->id()];
				int seg_idx_2 = seg[he_it->opposite()->facet()->id()];
				get_max_min_val(seg_idx_1, seg_idx_2);
				if (BOOST_UNLIKELY(seg_idx_1 != seg_idx_2))
				{
					if (BOOST_UNLIKELY(seg_vertices.find(seg_parts(seg_idx_1, seg_idx_2)) == seg_vertices.end()))
					{
						seg_vertices[seg_parts(seg_idx_1, seg_idx_2)] = std::set<int>();
					}
					seg_vertices[seg_parts(seg_idx_1, seg_idx_2)].insert(v_it->id());
					is_on_segbound = true;
				}
				deg_visit++;
			}
			if (BOOST_UNLIKELY(is_on_segbound))
			{
				seg.vertex_in_segment[v_it->id()] = -1;
			}
			else
			{
				seg.vertex_in_segment[v_it->id()] = seg[v_it->vertex_begin()->facet()->id()];
			}
		}
		for (auto i : seg_vertices)
		{	
			seg.seg_lines[i.first] = std::vector < std::vector<int>>();
			auto set_backup = i.second;
			while (!seg_vertices[i.first].empty())
			{	
				seg.seg_lines[i.first].push_back(std::vector<int>());
				seg.seg_lines[i.first].back().push_back(*seg_vertices[i.first].begin());
				seg_vertices[i.first].erase(seg_vertices[i.first].begin());
				bool vec_begin_search_stop = false;
				bool vec_end_search_stop = false;
				while (!vec_begin_search_stop)
				{
					auto v_it = this->index_to_vertex_map[seg.seg_lines[i.first].back().front()];
					int deg_visit = 0;
					for (auto he_it = v_it->vertex_begin(); deg_visit < v_it->vertex_degree(); ++he_it)
					{
						auto find_iter = seg_vertices[i.first].find(he_it->opposite()->vertex()->id());
						if (find_iter != seg_vertices[i.first].end())
						{
							seg.seg_lines[i.first].back().insert(seg.seg_lines[i.first].back().begin(), *find_iter);
							seg_vertices[i.first].erase(find_iter);
							break;
						}
						deg_visit++;
					}
					if (deg_visit == v_it->vertex_degree())
					{
						vec_begin_search_stop = true;
					}
				}
				while (!vec_end_search_stop)
				{	
					auto v_it = index_to_vertex_map[seg.seg_lines[i.first].back().back()];
					int deg_visit = 0;
					for (auto he_it = v_it->vertex_begin(); deg_visit < v_it->vertex_degree(); ++he_it)
					{
						auto find_iter = seg_vertices[i.first].find(he_it->opposite()->vertex()->id());
						if (find_iter != seg_vertices[i.first].end())
						{
							seg.seg_lines[i.first].back().push_back(*find_iter);
							seg_vertices[i.first].erase(find_iter);
							break;
						}
						deg_visit++;
					}
					if (deg_visit == v_it->vertex_degree())
					{
						vec_end_search_stop = true;
					}
				}
			}
			seg_vertices[i.first] = set_backup;
		}
		seg.detect_dangling_seg();
	}

	void detect_rings(std::map<int, std::set<int>>& select_pts_rings,std::vector<int>select_pts,int ring_level=4)
	{
		for (auto i : select_pts)
		{
			select_pts_rings[i] = std::set<int>();
			select_pts_rings[i].insert(i);
			for (int j = 0; j < ring_level; ++j)
			{
				for (auto k : select_pts)
				{	
					auto v_it = index_to_vertex_map[k];
					int deg_visit = 0;
					for (auto he_it = v_it->vertex_begin(); deg_visit < v_it->vertex_degree(); ++he_it)
					{
						int neibour_vertex_idx = he_it->opposite()->vertex()->id();
						deg_visit++;
					}
				}
			}
		}
	}

	void init_search_progress(segIO& seg, std::vector<std::vector<int>>& select_pts)
	{
		cur_search_progress = 0;
		is_loop_end = false;
	}

	void init_search_progress(segIO& seg)
	{
		cur_search_progress = 0;
		is_loop_end = false;
	}

	void compute_split_prob(const std::vector<std::vector<Eigen::RowVector3d>>& feature_vector_fields,
		const std::vector<std::vector<double>>& feature_scalar_fields,
		std::vector<std::vector<int>>& select_pts, std::vector<double>& split_prob,
		int max_line_num)
	{
		split_prob = std::vector<double>(select_pts.size(), 1);
	}

	void init_search_progress(segIO& seg, std::vector<int>& select_pts)
	{
		for (auto i : select_pts)
		{
			int spt_in_seg = seg.vertex_in_segment[i];
			anchor_point apt;
			apt.anchor_vertex_idx = i;
			apt.anchor_seg = spt_in_seg;
			anchor_points.push_back(apt);
		}
		cur_search_progress = 0;
		is_loop_end = false;
	}

	void init_search_vecs(int max_line,int initial_vec_len=100)
	{	
		std::set<int>cur_apt_id_set;
		initial_vec_len = std::min(initial_vec_len, int(anchor_points.size()));
		for (int i = 0; i < initial_vec_len; ++i)
		{
			//int cur_apt_id = int(rand_uniform(0, anchor_points.size()));
			int cur_apt_id = i;
			while (cur_apt_id_set.count(cur_apt_id) > 0)
			{
				cur_apt_id = int(rand_uniform(0, anchor_points.size()));
			}
			anchor_point cur_apt = anchor_points[cur_apt_id];
			//int cur_apt_picked_id = int(rand_uniform(0, anchor_points[cur_apt_idx].anchor_set.size()));
			int cur_seg = cur_apt.anchor_seg;
			//vec_4_paths.push_back(std::vector<int>()); vec_4_paths.back().push_back(cur_apt.anchor_vertex_idx);

			vec_4_remain_split.push_back(max_line - 1);
			vec_extendable_apts.push_back(std::vector<int>());
			vec_extendable_apts.back().push_back(cur_apt.anchor_vertex_idx);
			vec_curve_end.push_back(std::vector<int>());
			vec_curve_end.back().push_back(cur_apt.anchor_vertex_idx);
			vec_4_paths.push_back(std::vector<std::vector<int>>());
			vec_4_paths.back().push_back(std::vector<int>());
			vec_4_paths.back().back().push_back(cur_apt.anchor_vertex_idx);
			vec_4_paths_length.push_back(0);
			vec_4_vector_field.push_back(std::vector<Eigen::RowVector3d>(size_of_vertices(), Eigen::RowVector3d(0, 0, 0)));
			vec_4_scalar_field.push_back(std::vector<double>(size_of_vertices(), 0.001));
			vec_4_cur_apt.push_back(cur_apt);
			//vec_4_cur_apt_picked_id.push_back(cur_apt_picked_id);
			vec_4_cur_seg.push_back(cur_seg);
			//vec_4_curve_end.push_back(-1);
			vec_4_is_visit.push_back(std::vector<kVisit>(anchor_points.size(), kVisit::UNVISIT));
			vec_4_is_visit.back()[cur_apt_id] = kVisit::VISIT;
			vec_4_heat_accumulate.push_back(0);
			vec_4_i.push_back(-1);
			//vec_4_remain_avail.push_back(max_lines_num - 1);
			//vec_4_unvisit_num.push_back(anchor_points.size());
		}
	}

	void init_search_vecs_(int max_line, std::vector<std::vector<int>>&select_pts,int initial_vec_len = 100)
	{
		std::set<int>cur_apt_id_set;
		initial_vec_len = std::min(initial_vec_len, int(select_pts.size()));
		for (int i = 0; i < initial_vec_len; ++i)
		{
			//int cur_apt_id = int(rand_uniform(0, anchor_points.size()));
			int cur_apt_id = i;
			if (select_pts[cur_apt_id].size() > 1)
			{
				continue;
			}
			/*
			while (cur_apt_id_set.count(cur_apt_id) > 0)
			{
				cur_apt_id = int(rand_uniform(0, anchor_points.size()));
			}
			*/
			//anchor_point cur_apt = anchor_points[cur_apt_id];
			//int cur_apt_picked_id = int(rand_uniform(0, anchor_points[cur_apt_idx].anchor_set.size()));
			//int cur_seg = cur_apt.anchor_seg;
			//vec_4_paths.push_back(std::vector<int>()); vec_4_paths.back().push_back(cur_apt.anchor_vertex_idx);

			vec_4_remain_split.push_back(max_line - 1);
			vec_extendable_apts.push_back(std::vector<int>());
			vec_extendable_apts.back().push_back(select_pts[cur_apt_id].front());
			vec_curve_end.push_back(std::vector<int>());
			vec_curve_end.back().push_back(select_pts[cur_apt_id].front());
			vec_4_paths.push_back(std::vector<std::vector<int>>());
			vec_4_paths.back().push_back(std::vector<int>());
			vec_4_paths.back().back().push_back(select_pts[cur_apt_id].front());
			vec_4_paths_length.push_back(0);
			vec_4_vector_field.push_back(std::vector<Eigen::RowVector3d>(size_of_vertices(), Eigen::RowVector3d(0, 0, 0)));
			vec_4_scalar_field.push_back(std::vector<double>(size_of_vertices(), 0.001));
			//vec_4_cur_apt.push_back(cur_apt);
			//vec_4_cur_apt_picked_id.push_back(cur_apt_picked_id);
			vec_4_cur_seg.push_back(0);
			//vec_4_curve_end.push_back(-1);
			vec_4_is_visit.push_back(std::vector<kVisit>(select_pts.size(), kVisit::UNVISIT));
			vec_4_is_visit.back()[cur_apt_id] = kVisit::VISIT;
			vec_4_heat_accumulate.push_back(0);
			vec_4_i.push_back(-1);
		}
	}

	void compute_split_prob(const std::vector<std::vector<Eigen::RowVector3d>>& feature_vector_fields, 
		const std::vector<std::vector<double>>& feature_scalar_fields,
		std::vector<int>& select_pts,std::vector<double>&split_prob,
		int max_line_num)
	{	
		split_prob.clear();
		if (feature_vector_fields.size() == 1)
		{
			for (int i = 0; i < select_pts.size(); ++i)
			{	
				//not split opt,may be all to 1?
				split_prob.push_back(1);
			}
		}
		else
		{
			for (int i = 0; i < select_pts.size(); ++i)
			{	
				double max_coeff = -1;
				for (int j = 0; j < feature_vector_fields.size(); ++j)
				{
					for (int k = j + 1; k < feature_vector_fields.size(); ++k)
					{
						auto vec1 = feature_vector_fields[j][select_pts[i]].normalized();
						auto vec2 = feature_vector_fields[k][select_pts[i]].normalized();
						double scalar1 = feature_scalar_fields[j][select_pts[i]];
						double scalar2= feature_scalar_fields[k][select_pts[i]];
						double cos_theta = vec1.dot(vec2);
						double sin_theta = std::sqrt(1 - cos_theta * cos_theta);
						double theta_limited = std::asin(sin_theta);
						max_coeff = std::max(theta_limited * (std::min(scalar1, scalar2) + 0.1 * get_avg_edge_len()) / (std::max(scalar1, scalar2) + 0.01 * get_avg_edge_len()), max_coeff);
					}
				}
				split_prob.push_back(max_coeff);
			}
			auto arg_sort_idx=sort_indexes(split_prob);
			split_prob = std::vector<double>(split_prob.size(), 1);
		}
	}

	void multiple_circuit_traverse(segIO& seg,
		const std::vector<std::vector<Eigen::RowVector3d>>& feature_vector_fields,
		const std::vector<std::vector<double>>& feature_scalar_fields,
		const std::vector<double>& feature_modifier,
		std::vector<int>& select_pts,
		std::vector<std::vector<std::vector<int>>>& paths_res,
		bool line_end_to_end,int max_lines_num,int step, QProgressDialog* progressDialog,
		double feature_modifier_)
	{	
		static omp_lock_t lock;
		omp_init_lock(&lock);
		if (vec_4_paths.empty())
		{
			init_search_progress(seg,select_pts);
			init_search_vecs(max_lines_num);
			compute_split_prob(feature_vector_fields, feature_scalar_fields,select_pts, apt_split_prob,max_lines_num);
		}

		const int each_turn_candidate = 10;
		const int branch_size = 10;
		int unvisit_num = anchor_points.size() - 1;
		if (step < 1) { step = unvisit_num; }
		for(int step_i=0;(step_i<step&&cur_search_progress<unvisit_num);step_i++,cur_search_progress++)
		{	
			progressDialog->setValue(step_i * (80 / step));
			QApplication::processEvents();
			std::vector<int>vec_4_remain_split_local;
			std::vector<std::vector<int>>vec_extendable_apts_local;
			std::vector<std::vector<int>>vec_curve_end_local;
			std::vector<std::vector<std::vector<int>>>vec_4_paths_local;
			std::vector<std::vector<Eigen::RowVector3d>>vec_4_vector_field_local;
			std::vector<std::vector<double>>vec_4_scalar_field_local;

			std::vector<anchor_point>vec_4_cur_apt_local;
			std::vector<int>vec_4_cur_seg_local;
			std::vector<std::vector<kVisit>>vec_4_is_visit_local;
			std::vector<double>vec_4_paths_length_local;
			std::vector<double>vec_4_heat_accumulate_local;
			std::vector<int>vec_4_i_local;

			int cur_level_candidate = vec_4_paths.size();
			std::vector<graph_t> vec_4_distorsion_g = std::vector<graph_t>(cur_level_candidate* feature_vector_fields.size());
			int i, f_i;
			#pragma omp parallel for private(i, f_i) collapse(2)
			for (i = 0; i < cur_level_candidate; ++i)
			{
				for (f_i = 0; f_i < feature_vector_fields.size(); ++f_i)
				{
					graph_t distorsion_g;
					build_paths(seg, feature_vector_fields[f_i], feature_scalar_fields[f_i],
						vec_4_vector_field[i], vec_4_scalar_field[i],distorsion_g,feature_modifier_);
					int idx = i * feature_vector_fields.size() + f_i;
					vec_4_distorsion_g[idx] = distorsion_g;
				}
			}
			int cv_i;
			std::vector<std::vector<bool>>vec_4_going_on(cur_level_candidate* feature_vector_fields.size());
			std::vector<std::vector<bool>>vec_4_is_curve_end(cur_level_candidate * feature_vector_fields.size());
			std::vector<std::vector<std::vector<boost::graph_traits<graph_t>::vertex_descriptor>>>vec_4_p(cur_level_candidate * feature_vector_fields.size());
			std::vector<std::vector<std::vector<double>>>vec_4_d(cur_level_candidate * feature_vector_fields.size());
			std::vector<std::vector<anchor_point>>vec_4_cur_apt_in(cur_level_candidate * feature_vector_fields.size());
			for (i = 0; i < vec_4_going_on.size(); ++i)
			{
				vec_4_going_on[i] = std::vector<bool>(vec_extendable_apts[i/ feature_vector_fields.size()].size());
				vec_4_p[i] = std::vector<std::vector<boost::graph_traits<graph_t>::vertex_descriptor>>(vec_extendable_apts[i/ feature_vector_fields.size()].size());
				vec_4_d[i] = std::vector<std::vector<double>>(vec_extendable_apts[i/ feature_vector_fields.size()].size());
				vec_4_cur_apt_in[i] = std::vector<anchor_point>(vec_extendable_apts[i / feature_vector_fields.size()].size());
				vec_4_is_curve_end[i] = std::vector<bool>(vec_extendable_apts[i / feature_vector_fields.size()].size());
			}
			#pragma omp parallel for private(i, f_i, cv_i) collapse(3)
			for (i = 0; i < cur_level_candidate; ++i)
			{
				for (f_i = 0; f_i < feature_vector_fields.size(); ++f_i)
				{
					for (cv_i = 0; cv_i < vec_extendable_apts[i].size(); cv_i++)
					{	
						int vec_idx = i * feature_vector_fields.size() + f_i;
						anchor_point cur_apt;
						for (int apt_i = 0; apt_i < anchor_points.size(); ++apt_i)
						{
							if (anchor_points[apt_i].anchor_vertex_idx == vec_extendable_apts[i][cv_i])
							{
								cur_apt = anchor_points[apt_i];
							}
						}
						int remain_split_num = vec_4_remain_split[i];
						int cur_apt_slct_idx = std::distance(select_pts.begin(),
							std::find(select_pts.begin(), select_pts.end(), cur_apt.anchor_vertex_idx));
						//bool cur_apt_split_able = (apt_split_prob[cur_apt_slct_idx] > split_prob_threshold);
						std::vector<boost::graph_traits< graph_t >::vertex_descriptor> p;
						std::vector<double> d; 
						int curve_end = vec_extendable_apts[i][cv_i];
						bool is_curve_end = false;
						if (std::find(vec_curve_end[i].begin(), vec_curve_end[i].end(), curve_end) !=
							vec_curve_end[i].end())
						{
							is_curve_end = true;
						}
						/*
						if ((!is_curve_end) && (!cur_apt_split_able))
						{	
							vec_4_going_on[vec_idx][cv_i] = false;
							continue;
						}
						*/
						if ((!is_curve_end) && (!remain_split_num))
						{	
							vec_4_going_on[vec_idx][cv_i] = false;
							continue;
						}
						dijkstra_search(p, d, curve_end,vec_4_distorsion_g[vec_idx]);
						vec_4_going_on[vec_idx][cv_i] = true;
						vec_4_p[vec_idx][cv_i] = p;
						vec_4_d[vec_idx][cv_i] = d;
						vec_4_cur_apt_in[vec_idx][cv_i] = cur_apt;
						vec_4_is_curve_end[vec_idx][cv_i] = is_curve_end;
					}
				}
			}
			std::vector<std::vector<int>>vec_4_unvisit_anchors(cur_level_candidate);
			#pragma omp parallel for
			for (i = 0; i < cur_level_candidate; ++i)
			{
				std::vector<kVisit> is_visit = vec_4_is_visit[i];
				//anchor_point cur_apt = vec_4_cur_apt[i];
				//int cur_apt_picked_id = vec_4_cur_apt_picked_id[i];
				int cur_seg = vec_4_cur_seg[i];

				std::vector<int>unvisit_anchors;
				for (int j = 0; j < anchor_points.size(); ++j)
				{
					if (is_visit[j] == kVisit::UNVISIT)
					{
						unvisit_anchors.push_back(j);
					}
				}
				vec_4_unvisit_anchors[i] = unvisit_anchors;
			}
			int j;
			std::vector<std::vector<std::vector<double>>>min_geodesic_order(cur_level_candidate * feature_vector_fields.size());
			std::vector<std::vector<std::vector<int>>>nearest_apt_geodesic(cur_level_candidate * feature_vector_fields.size());
			for (i = 0; i < min_geodesic_order.size(); ++i)
			{	
				min_geodesic_order[i] = std::vector<std::vector<double>>(vec_extendable_apts[i/ feature_vector_fields.size()].size());
				nearest_apt_geodesic[i] = std::vector<std::vector<int>>(vec_extendable_apts[i / feature_vector_fields.size()].size());
				for (cv_i = 0; cv_i < vec_extendable_apts[i / feature_vector_fields.size()].size(); cv_i++)
				{	
					min_geodesic_order[i][cv_i] = std::vector<double>();
					nearest_apt_geodesic[i][cv_i] = std::vector<int>();
				}
			}
			#pragma omp parallel for private(i, f_i, cv_i, j) collapse(4)
			for (i = 0; i < cur_level_candidate; ++i)
			{
				for (f_i = 0; f_i < feature_vector_fields.size(); ++f_i)
				{
					for (cv_i = 0; cv_i < vec_extendable_apts[i].size(); cv_i++)
					{
						for (j = 0; j < vec_4_unvisit_anchors[i].size(); ++j)
						{	
							int vec_4_p_idx = i * feature_vector_fields.size() + f_i;
							if (!vec_4_going_on[vec_4_p_idx][cv_i])
							{
								break;
							}
							std::vector<boost::graph_traits< graph_t >::vertex_descriptor> p=vec_4_p[vec_4_p_idx][cv_i];
							std::vector<double> d = vec_4_d[vec_4_p_idx][cv_i];
							anchor_point cur_apt = vec_4_cur_apt_in[vec_4_p_idx][cv_i];
							std::vector<int>unvisit_anchors = vec_4_unvisit_anchors[i];


							double dist_2_apt = d[anchor_points[unvisit_anchors[j]].anchor_vertex_idx];
							double dist_across_seg = -1;
							if (cur_apt.anchor_seg != anchor_points[unvisit_anchors[j]].anchor_seg)
							{
								bool get_seg_end = false;
								int end_seg_bound = anchor_points[unvisit_anchors[j]].anchor_vertex_idx;
								std::vector<int>::iterator find_iter;
								while (!get_seg_end)
								{
									for (auto k : seg.seg_lines)
									{
										for (int k1 = 0; k1 < k.second.size(); ++k1)
										{
											auto find_iter = std::find(k.second[k1].begin(), k.second[k1].end(), end_seg_bound);
											if (find_iter != k.second[k1].end())
											{
												get_seg_end = true;
												break;
											}
										}
										if (get_seg_end)break;
									}
									if (get_seg_end)break;
									end_seg_bound = p[end_seg_bound];
								}
								int start_seg_bound = end_seg_bound;
								int curve_pt = start_seg_bound;
								while (curve_pt != cur_apt.anchor_vertex_idx)
								{
									for (auto k : seg.seg_lines)
									{
										for (int k1 = 0; k1 < k.second.size(); ++k1)
										{
											auto find_iter = std::find(k.second[k1].begin(), k.second[k1].end(), end_seg_bound);
											if (find_iter != k.second[k1].end())
											{
												start_seg_bound = curve_pt;
												break;
											}
										}
									}
									curve_pt = p[curve_pt];
								}
							}
							omp_set_lock(&lock);
							auto insert_idx = std::distance(min_geodesic_order[vec_4_p_idx][cv_i].begin(),
								std::upper_bound(min_geodesic_order[vec_4_p_idx][cv_i].begin(), min_geodesic_order[vec_4_p_idx][cv_i].end(),
									dist_2_apt));
							min_geodesic_order[vec_4_p_idx][cv_i].insert(min_geodesic_order[vec_4_p_idx][cv_i].begin() + insert_idx, dist_2_apt);
							nearest_apt_geodesic[vec_4_p_idx][cv_i].insert(nearest_apt_geodesic[vec_4_p_idx][cv_i].begin() + insert_idx, j);

							omp_unset_lock(&lock);
						}
					}
				}
			}
			#pragma omp parallel for private(i, f_i, cv_i, j) collapse(4)
			for (i = 0; i < cur_level_candidate; ++i)
			{
				for (f_i = 0; f_i < feature_vector_fields.size(); ++f_i)
				{
					for (cv_i = 0; cv_i < vec_extendable_apts[i].size(); cv_i++)
					{
						for (j = 0; j < std::min(int(vec_4_unvisit_anchors[i].size()), branch_size); ++j)
						{	
							int vec_4_p_idx = i * feature_vector_fields.size() + f_i;
							if (!vec_4_going_on[vec_4_p_idx][cv_i])
							{
								break;
							}
							std::vector<boost::graph_traits< graph_t >::vertex_descriptor> p = vec_4_p[vec_4_p_idx][cv_i];
							std::vector<double> d = vec_4_d[vec_4_p_idx][cv_i];
							anchor_point cur_apt = vec_4_cur_apt_in[vec_4_p_idx][cv_i];
							std::vector<int>unvisit_anchors = vec_4_unvisit_anchors[i];

							int curve_end = vec_extendable_apts[i][cv_i];
							int cur_apt_idx = unvisit_anchors[nearest_apt_geodesic[vec_4_p_idx][cv_i][j]];
							auto cur_apt_ = anchor_points[cur_apt_idx];
							std::vector<int>geodesic_path;
							int idx = cur_apt_.anchor_vertex_idx;
							while (idx != curve_end)
							{
								geodesic_path.push_back(idx);
								idx = p[idx];
							}
							geodesic_path.push_back(curve_end);
							std::vector<kVisit>is_visit_copy = vec_4_is_visit[i];
							int unvisit_num_copy = unvisit_num;


							is_visit_copy[cur_apt_idx] = kVisit::VISIT;

							std::vector<std::vector<int>>cur_path = vec_4_paths[i];
							std::vector<int>extendable_apts = vec_extendable_apts[i];
							std::vector<int>curve_ends = vec_curve_end[i];
							
							int remain_split_num_copy = vec_4_remain_split[i];
							if (vec_4_is_curve_end[vec_4_p_idx][cv_i])
							{
								for (int k = 0; k < cur_path.size(); ++k)
								{
									if (cur_path[k].back() == geodesic_path.back())
									{	
										auto find_iter = std::find(curve_ends.begin(), curve_ends.end(), cur_path[k].back());
										curve_ends.erase(find_iter);
										cur_path[k].insert(cur_path[k].end(), geodesic_path.rbegin() + 1, geodesic_path.rend());
										curve_ends.push_back(cur_path[k].back());
										if (cur_search_progress == 0)
										{
											extendable_apts.clear();
										}
										extendable_apts.push_back(cur_path[k].back());
										break;
									}
								}
							}
							else
							{	
								std::vector<int>new_spline(geodesic_path.rbegin(), geodesic_path.rend());
								cur_path.push_back(new_spline);
								extendable_apts.erase(extendable_apts.begin() + cv_i);
								curve_ends.push_back(new_spline.back());
								extendable_apts.push_back(new_spline.back());
								remain_split_num_copy--;
							}
							std::vector<double>line_scalar_field;
							std::vector<Eigen::RowVector3d>line_vector_field;
							compute_heat_val(cur_path, line_scalar_field);
							double path_distorsion_len = d[cur_apt_.anchor_vertex_idx];
							double accumulate_length = 0;
							double accumulate_heat = 0;
							for (int k = 0; k < geodesic_path.size() - 1; ++k)
							{
								Eigen::RowVector3d pt1 = Eigen::RowVector3d(
									index_to_vertex_map[geodesic_path[k]]->point().x(),
									index_to_vertex_map[geodesic_path[k]]->point().y(),
									index_to_vertex_map[geodesic_path[k]]->point().z());
								Eigen::RowVector3d pt2 = Eigen::RowVector3d(
									index_to_vertex_map[geodesic_path[k + 1]]->point().x(),
									index_to_vertex_map[geodesic_path[k + 1]]->point().y(),
									index_to_vertex_map[geodesic_path[k + 1]]->point().z());
								accumulate_length += (pt1 - pt2).norm();
								accumulate_heat += 0.5 * (feature_scalar_fields[f_i][geodesic_path[k]] +
									feature_scalar_fields[f_i][geodesic_path[k + 1]]);
							}
							omp_set_lock(&lock);
							vec_4_remain_split_local.push_back(remain_split_num_copy);
							vec_extendable_apts_local.push_back(extendable_apts);
							vec_curve_end_local.push_back(curve_ends);
							vec_4_paths_local.push_back(cur_path);
							vec_4_vector_field_local.push_back(line_vector_field);
							vec_4_scalar_field_local.push_back(line_scalar_field);
							vec_4_cur_apt_local.push_back(cur_apt_);
							vec_4_is_visit_local.push_back(is_visit_copy);

							vec_4_paths_length_local.push_back(accumulate_length);
							vec_4_heat_accumulate_local.push_back(path_distorsion_len);
							vec_4_cur_seg_local.push_back(cur_apt.anchor_seg);
							vec_4_i_local.push_back(i);
							omp_unset_lock(&lock);
						}
					}
				}
			}
			std::vector<std::vector<int>>i_vec(cur_level_candidate);
			std::vector<std::vector<double>>vec_heat_density(cur_level_candidate);
			for (i = 0; i < vec_4_cur_apt_local.size(); ++i)
			{
				int i_i = vec_4_i_local[i];
				double heat_den = vec_4_paths_length_local[i] > 0 ? (vec_4_heat_accumulate_local[i]) : 0;
				auto insert_idx = std::distance(vec_heat_density[i_i].begin(),
					std::lower_bound(vec_heat_density[i_i].begin(),
						vec_heat_density[i_i].end(), heat_den));
				vec_heat_density[i_i].insert(vec_heat_density[i_i].begin() + insert_idx, heat_den);
				i_vec[i_i].insert(i_vec[i_i].begin() + insert_idx, i);
			}
			std::vector<int>extract_idx;
			int i_vec_i = 0;
			for (i = 0; i < vec_4_cur_apt_local.size(); ++i)
			{
				while (i_vec[i_vec_i].empty())
				{
					i_vec_i = (i_vec_i + 1) % i_vec.size();
				}
				extract_idx.push_back(i_vec[i_vec_i].front());
				i_vec[i_vec_i].erase(i_vec[i_vec_i].begin());
				i_vec_i = (i_vec_i + 1) % i_vec.size();
			}
			std::vector<int>extract_idx_;
			std::vector<double>heat_density_;
			for (i = 0; i < extract_idx.size() / 2; ++i)
			{
				int i_i = extract_idx[i];
				double heat_den = vec_4_paths_length_local[i_i] > 0 ? ((vec_4_heat_accumulate_local[i_i]) / vec_4_paths_length_local[i_i]) : 0;
				auto insert_idx = std::distance(heat_density_.begin(),
					std::lower_bound(heat_density_.begin(), heat_density_.end(), heat_den));
				heat_density_.insert(heat_density_.begin() + insert_idx, heat_den);
				extract_idx_.insert(extract_idx_.begin() + insert_idx, i_i);
			}
			////std::cout << "cost F4" << std::endl;
			int non_zero_error_num = 0;
			int pre_vec_size = vec_4_paths.size();


			vec_4_remain_split.clear();
			vec_4_paths.clear();
			vec_4_vector_field.clear();
			vec_4_scalar_field.clear();
			vec_4_cur_apt.clear();
			vec_4_is_visit.clear();
			vec_4_paths_length.clear();
			vec_4_cur_seg.clear();
			vec_4_heat_accumulate.clear();
			vec_extendable_apts.clear();
			vec_curve_end.clear();
			vec_4_i.clear();
			for (i = 0; i < std::min(each_turn_candidate, int(extract_idx_.size())); ++i)
			{
				vec_4_remain_split.push_back(vec_4_remain_split_local[extract_idx_[i]]);
				vec_4_paths.push_back(vec_4_paths_local[extract_idx_[i]]);
				vec_4_vector_field.push_back(vec_4_vector_field_local[extract_idx_[i]]);
				vec_4_scalar_field.push_back(vec_4_scalar_field_local[extract_idx_[i]]);
				vec_4_cur_apt.push_back(vec_4_cur_apt_local[extract_idx_[i]]);
				vec_4_is_visit.push_back(vec_4_is_visit_local[extract_idx_[i]]);
				vec_4_paths_length.push_back(vec_4_paths_length_local[extract_idx_[i]]);
				vec_4_cur_seg.push_back(vec_4_cur_seg_local[extract_idx_[i]]);
				vec_4_heat_accumulate.push_back(vec_4_heat_accumulate_local[extract_idx_[i]]);
				vec_extendable_apts.push_back(vec_extendable_apts_local[extract_idx_[i]]);
				vec_curve_end.push_back(vec_curve_end_local[extract_idx_[i]]);
				vec_4_i.push_back(vec_4_i_local[extract_idx_[i]]);
			}
		}
		vec_4_paths_origin = vec_4_paths;
		paths_res = vec_4_paths;
		vec_4_curve_apt = std::vector<std::vector<std::vector<int>>>(vec_4_paths.size());
		for (int i = 0; i < vec_4_paths.size(); ++i)
		{
			vec_4_curve_apt[i] = std::vector<std::vector<int>>();
			for (int j = 0; j < vec_4_paths[i].size(); ++j)
			{
				vec_4_curve_apt[i].push_back(std::vector<int>());
				for (int k = 0; k < vec_4_paths[i][j].size(); ++k)
				{
					auto path_pt = vec_4_paths[i][j][k];
					if (std::find(select_pts.begin(), select_pts.end(), path_pt)
						!= select_pts.end())
					{
						vec_4_curve_apt[i][j].push_back(path_pt);
					}
				}
			}
		}
		omp_destroy_lock(&lock);
	}

	void multiple_traverse_copy(segIO& seg,
		const std::vector<std::vector<Eigen::RowVector3d>>& feature_vector_fields,
		const std::vector<std::vector<double>>& feature_scalar_fields,
		const std::vector<double>& feature_modifier,
		std::vector<int>& select_pts,
		std::vector<std::vector<std::vector<int>>>& paths_res,
		bool line_end_to_end, int max_lines_num, int step, QProgressDialog* progressDialog,
		int each_turn_candidate,int new_branch_size,double logi1_a,double logi1_b,double logi2_a,double logi2_b)
	{
		static omp_lock_t lock;
		omp_init_lock(&lock);
		if (vec_4_paths.empty())
		{
			init_search_progress(seg, select_pts);
			init_search_vecs(max_lines_num);
			compute_split_prob(feature_vector_fields, feature_scalar_fields, select_pts, apt_split_prob, max_lines_num);
		}

		//const int each_turn_candidate = 10;
		//const int new_branch_size = 5;
		int unvisit_num = anchor_points.size() - 1;
		if (step < 1) { step = unvisit_num; }
		for (int step_i = 0; (step_i < step && cur_search_progress < unvisit_num); step_i++, cur_search_progress++)
		{
			progressDialog->setValue(step_i * (80 / step));
			QApplication::processEvents();
			std::vector<int>vec_4_remain_split_local;
			std::vector<std::vector<int>>vec_extendable_apts_local;
			std::vector<std::vector<int>>vec_curve_end_local;
			std::vector<std::vector<std::vector<int>>>vec_4_paths_local;
			std::vector<std::vector<Eigen::RowVector3d>>vec_4_vector_field_local;
			std::vector<std::vector<double>>vec_4_scalar_field_local;

			std::vector<anchor_point>vec_4_cur_apt_local;
			std::vector<int>vec_4_cur_seg_local;
			std::vector<std::vector<kVisit>>vec_4_is_visit_local;
			std::vector<double>vec_4_paths_length_local;
			std::vector<double>vec_4_heat_accumulate_local;
			std::vector<int>vec_4_i_local;

			int cur_level_candidate = vec_4_paths.size();
			std::vector<graph_t> vec_4_distorsion_g = std::vector<graph_t>(cur_level_candidate * feature_vector_fields.size());
			int i, f_i;
#pragma omp parallel for private(i, f_i) collapse(2)
			for (i = 0; i < cur_level_candidate; ++i)
			{
				for (f_i = 0; f_i < feature_vector_fields.size(); ++f_i)
				{
					graph_t distorsion_g;
					build_paths(seg, feature_vector_fields[f_i], feature_scalar_fields[f_i],
						vec_4_vector_field[i], vec_4_scalar_field[i], distorsion_g, logi1_a, logi1_b, logi2_a, logi2_b);
					int idx = i * feature_vector_fields.size() + f_i;
					vec_4_distorsion_g[idx] = distorsion_g;
				}
			}
			int cv_i;
			std::vector<std::vector<bool>>vec_4_going_on(cur_level_candidate * feature_vector_fields.size());
			std::vector<std::vector<bool>>vec_4_is_curve_end(cur_level_candidate * feature_vector_fields.size());
			std::vector<std::vector<std::vector<boost::graph_traits<graph_t>::vertex_descriptor>>>vec_4_p(cur_level_candidate * feature_vector_fields.size());
			std::vector<std::vector<std::vector<double>>>vec_4_d(cur_level_candidate * feature_vector_fields.size());
			std::vector<std::vector<anchor_point>>vec_4_cur_apt_in(cur_level_candidate * feature_vector_fields.size());
			for (i = 0; i < vec_4_going_on.size(); ++i)
			{
				vec_4_going_on[i] = std::vector<bool>(vec_extendable_apts[i / feature_vector_fields.size()].size());
				vec_4_p[i] = std::vector<std::vector<boost::graph_traits<graph_t>::vertex_descriptor>>(vec_extendable_apts[i / feature_vector_fields.size()].size());
				vec_4_d[i] = std::vector<std::vector<double>>(vec_extendable_apts[i / feature_vector_fields.size()].size());
				vec_4_cur_apt_in[i] = std::vector<anchor_point>(vec_extendable_apts[i / feature_vector_fields.size()].size());
				vec_4_is_curve_end[i] = std::vector<bool>(vec_extendable_apts[i / feature_vector_fields.size()].size());
			}
			#pragma omp parallel for private(i, f_i, cv_i) collapse(3)
			for (i = 0; i < cur_level_candidate; ++i)
			{
				for (f_i = 0; f_i < feature_vector_fields.size(); ++f_i)
				{
					for (cv_i = 0; cv_i < vec_extendable_apts[i].size(); cv_i++)
					{
						int vec_idx = i * feature_vector_fields.size() + f_i;
						anchor_point cur_apt;
						for (int apt_i = 0; apt_i < anchor_points.size(); ++apt_i)
						{
							if (anchor_points[apt_i].anchor_vertex_idx == vec_extendable_apts[i][cv_i])
							{
								cur_apt = anchor_points[apt_i];
							}
						}
						int remain_split_num = vec_4_remain_split[i];
						int cur_apt_slct_idx = std::distance(select_pts.begin(),
							std::find(select_pts.begin(), select_pts.end(), cur_apt.anchor_vertex_idx));
						//bool cur_apt_split_able = (apt_split_prob[cur_apt_slct_idx] > split_prob_threshold);
						std::vector<boost::graph_traits< graph_t >::vertex_descriptor> p;
						std::vector<double> d;
						int curve_end = vec_extendable_apts[i][cv_i];
						bool is_curve_end = false;
						if (std::find(vec_curve_end[i].begin(), vec_curve_end[i].end(), curve_end) !=
							vec_curve_end[i].end())
						{
							is_curve_end = true;
						}
						/*
						if ((!is_curve_end) && (!cur_apt_split_able))
						{
							vec_4_going_on[vec_idx][cv_i] = false;
							continue;
						}
						*/
						if ((!is_curve_end) && (!remain_split_num))
						{
							vec_4_going_on[vec_idx][cv_i] = false;
							continue;
						}
						dijkstra_search(p, d, curve_end, vec_4_distorsion_g[vec_idx]);
						vec_4_going_on[vec_idx][cv_i] = true;
						vec_4_p[vec_idx][cv_i] = p;
						vec_4_d[vec_idx][cv_i] = d;
						vec_4_cur_apt_in[vec_idx][cv_i] = cur_apt;
						vec_4_is_curve_end[vec_idx][cv_i] = is_curve_end;
					}
				}
			}
			std::vector<std::vector<int>>vec_4_unvisit_anchors(cur_level_candidate);
#pragma omp parallel for
			for (i = 0; i < cur_level_candidate; ++i)
			{
				std::vector<kVisit> is_visit = vec_4_is_visit[i];
				//anchor_point cur_apt = vec_4_cur_apt[i];
				//int cur_apt_picked_id = vec_4_cur_apt_picked_id[i];
				int cur_seg = vec_4_cur_seg[i];

				std::vector<int>unvisit_anchors;
				for (int j = 0; j < anchor_points.size(); ++j)
				{
					if (is_visit[j] == kVisit::UNVISIT)
					{
						unvisit_anchors.push_back(j);
					}
				}
				vec_4_unvisit_anchors[i] = unvisit_anchors;
			}
			int j;
			std::vector<std::vector<std::vector<double>>>min_geodesic_order(cur_level_candidate * feature_vector_fields.size());
			std::vector<std::vector<std::vector<int>>>nearest_apt_geodesic(cur_level_candidate * feature_vector_fields.size());
			for (i = 0; i < min_geodesic_order.size(); ++i)
			{
				min_geodesic_order[i] = std::vector<std::vector<double>>(vec_extendable_apts[i / feature_vector_fields.size()].size());
				nearest_apt_geodesic[i] = std::vector<std::vector<int>>(vec_extendable_apts[i / feature_vector_fields.size()].size());
				for (cv_i = 0; cv_i < vec_extendable_apts[i / feature_vector_fields.size()].size(); cv_i++)
				{
					min_geodesic_order[i][cv_i] = std::vector<double>();
					nearest_apt_geodesic[i][cv_i] = std::vector<int>();
				}
			}
#pragma omp parallel for private(i, f_i, cv_i, j) collapse(4)
			for (i = 0; i < cur_level_candidate; ++i)
			{
				for (f_i = 0; f_i < feature_vector_fields.size(); ++f_i)
				{
					for (cv_i = 0; cv_i < vec_extendable_apts[i].size(); cv_i++)
					{
						for (j = 0; j < vec_4_unvisit_anchors[i].size(); ++j)
						{
							int vec_4_p_idx = i * feature_vector_fields.size() + f_i;
							if (!vec_4_going_on[vec_4_p_idx][cv_i])
							{
								break;
							}
							std::vector<boost::graph_traits< graph_t >::vertex_descriptor> p = vec_4_p[vec_4_p_idx][cv_i];
							std::vector<double> d = vec_4_d[vec_4_p_idx][cv_i];
							anchor_point cur_apt = vec_4_cur_apt_in[vec_4_p_idx][cv_i];
							std::vector<int>unvisit_anchors = vec_4_unvisit_anchors[i];


							double dist_2_apt = d[anchor_points[unvisit_anchors[j]].anchor_vertex_idx];
							double dist_across_seg = -1;
							if (cur_apt.anchor_seg != anchor_points[unvisit_anchors[j]].anchor_seg)
							{
								bool get_seg_end = false;
								int end_seg_bound = anchor_points[unvisit_anchors[j]].anchor_vertex_idx;
								std::vector<int>::iterator find_iter;
								while (!get_seg_end)
								{
									for (auto k : seg.seg_lines)
									{
										for (int k1 = 0; k1 < k.second.size(); ++k1)
										{
											auto find_iter = std::find(k.second[k1].begin(), k.second[k1].end(), end_seg_bound);
											if (find_iter != k.second[k1].end())
											{
												get_seg_end = true;
												break;
											}
										}
										if (get_seg_end)break;
									}
									if (get_seg_end)break;
									end_seg_bound = p[end_seg_bound];
								}
								int start_seg_bound = end_seg_bound;
								int curve_pt = start_seg_bound;
								while (curve_pt != cur_apt.anchor_vertex_idx)
								{
									for (auto k : seg.seg_lines)
									{
										for (int k1 = 0; k1 < k.second.size(); ++k1)
										{
											auto find_iter = std::find(k.second[k1].begin(), k.second[k1].end(), end_seg_bound);
											if (find_iter != k.second[k1].end())
											{
												start_seg_bound = curve_pt;
												break;
											}
										}
									}
									curve_pt = p[curve_pt];
								}
							}
							omp_set_lock(&lock);
							auto insert_idx = std::distance(min_geodesic_order[vec_4_p_idx][cv_i].begin(),
								std::upper_bound(min_geodesic_order[vec_4_p_idx][cv_i].begin(), min_geodesic_order[vec_4_p_idx][cv_i].end(),
									dist_2_apt));
							min_geodesic_order[vec_4_p_idx][cv_i].insert(min_geodesic_order[vec_4_p_idx][cv_i].begin() + insert_idx, dist_2_apt);
							nearest_apt_geodesic[vec_4_p_idx][cv_i].insert(nearest_apt_geodesic[vec_4_p_idx][cv_i].begin() + insert_idx, j);

							omp_unset_lock(&lock);
						}
					}
				}
			}
#pragma omp parallel for private(i, f_i, cv_i, j) collapse(4)
			for (i = 0; i < cur_level_candidate; ++i)
			{
				for (f_i = 0; f_i < feature_vector_fields.size(); ++f_i)
				{
					for (cv_i = 0; cv_i < vec_extendable_apts[i].size(); cv_i++)
					{
						for (j = 0; j < vec_4_unvisit_anchors[i].size(); ++j)
						{
							int vec_4_p_idx = i * feature_vector_fields.size() + f_i;
							if (!vec_4_going_on[vec_4_p_idx][cv_i])
							{
								break;
							}
							std::vector<boost::graph_traits< graph_t >::vertex_descriptor> p = vec_4_p[vec_4_p_idx][cv_i];
							std::vector<double> d = vec_4_d[vec_4_p_idx][cv_i];
							anchor_point cur_apt = vec_4_cur_apt_in[vec_4_p_idx][cv_i];
							std::vector<int>unvisit_anchors = vec_4_unvisit_anchors[i];

							int curve_end = vec_extendable_apts[i][cv_i];
							int cur_apt_idx = unvisit_anchors[nearest_apt_geodesic[vec_4_p_idx][cv_i][j]];
							auto cur_apt_ = anchor_points[cur_apt_idx];
							std::vector<int>geodesic_path;
							int idx = cur_apt_.anchor_vertex_idx;
							while (idx != curve_end)
							{
								geodesic_path.push_back(idx);
								idx = p[idx];
							}
							geodesic_path.push_back(curve_end);
							std::vector<kVisit>is_visit_copy = vec_4_is_visit[i];
							int unvisit_num_copy = unvisit_num;


							is_visit_copy[cur_apt_idx] = kVisit::VISIT;

							std::vector<std::vector<int>>cur_path = vec_4_paths[i];
							std::vector<int>extendable_apts = vec_extendable_apts[i];
							std::vector<int>curve_ends = vec_curve_end[i];

							int remain_split_num_copy = vec_4_remain_split[i];
							if (vec_4_is_curve_end[vec_4_p_idx][cv_i])
							{
								for (int k = 0; k < cur_path.size(); ++k)
								{
									if (cur_path[k].back() == geodesic_path.back())
									{
										auto find_iter = std::find(curve_ends.begin(), curve_ends.end(), cur_path[k].back());
										curve_ends.erase(find_iter);
										cur_path[k].insert(cur_path[k].end(), geodesic_path.rbegin() + 1, geodesic_path.rend());
										curve_ends.push_back(cur_path[k].back());
										if (cur_search_progress == 0)
										{
											extendable_apts.clear();
										}
										extendable_apts.push_back(cur_path[k].back());
										break;
									}
								}
							}
							else
							{
								std::vector<int>new_spline(geodesic_path.rbegin(), geodesic_path.rend());
								cur_path.push_back(new_spline);
								extendable_apts.erase(extendable_apts.begin() + cv_i);
								curve_ends.push_back(new_spline.back());
								extendable_apts.push_back(new_spline.back());
								remain_split_num_copy--;
							}
							std::vector<double>line_scalar_field;
							std::vector<Eigen::RowVector3d>line_vector_field;
							compute_heat_val(cur_path, line_scalar_field);
							double path_distorsion_len = d[cur_apt_.anchor_vertex_idx];
							double accumulate_length = 0;
							double accumulate_heat = 0;
							for (int k = 0; k < geodesic_path.size() - 1; ++k)
							{
								Eigen::RowVector3d pt1 = Eigen::RowVector3d(
									index_to_vertex_map[geodesic_path[k]]->point().x(),
									index_to_vertex_map[geodesic_path[k]]->point().y(),
									index_to_vertex_map[geodesic_path[k]]->point().z());
								Eigen::RowVector3d pt2 = Eigen::RowVector3d(
									index_to_vertex_map[geodesic_path[k + 1]]->point().x(),
									index_to_vertex_map[geodesic_path[k + 1]]->point().y(),
									index_to_vertex_map[geodesic_path[k + 1]]->point().z());
								accumulate_length += (pt1 - pt2).norm();
								accumulate_heat += 0.5 * (feature_scalar_fields[f_i][geodesic_path[k]] +
									feature_scalar_fields[f_i][geodesic_path[k + 1]]);
							}
							omp_set_lock(&lock);
							vec_4_remain_split_local.push_back(remain_split_num_copy);
							vec_extendable_apts_local.push_back(extendable_apts);
							vec_curve_end_local.push_back(curve_ends);
							vec_4_paths_local.push_back(cur_path);
							vec_4_vector_field_local.push_back(line_vector_field);
							vec_4_scalar_field_local.push_back(line_scalar_field);
							vec_4_cur_apt_local.push_back(cur_apt_);
							vec_4_is_visit_local.push_back(is_visit_copy);
							
							vec_4_paths_length_local.push_back(accumulate_length);
							vec_4_heat_accumulate_local.push_back(path_distorsion_len);
							vec_4_cur_seg_local.push_back(cur_apt.anchor_seg);
							vec_4_i_local.push_back(i);
							omp_unset_lock(&lock);
						}
					}
				}
			}
			std::vector<std::vector<int>>i_vec(cur_level_candidate);
			std::vector<std::vector<double>>vec_heat_density(cur_level_candidate);
			for (i = 0; i < vec_4_cur_apt_local.size(); ++i)
			{
				int i_i = vec_4_i_local[i];
				double heat_den = vec_4_paths_length_local[i] > 0 ? (vec_4_heat_accumulate_local[i]) : 0;
				auto insert_idx = std::distance(vec_heat_density[i_i].begin(),
					std::lower_bound(vec_heat_density[i_i].begin(),
						vec_heat_density[i_i].end(), heat_den));
				vec_heat_density[i_i].insert(vec_heat_density[i_i].begin() + insert_idx, heat_den);
				i_vec[i_i].insert(i_vec[i_i].begin() + insert_idx, i);
			}
			std::vector<int>extract_idx;
			int i_vec_i = 0;
			for (i = 0; i < cur_level_candidate*std::min(new_branch_size,int(unvisit_num-step_i)); ++i)
			{
				while (i_vec[i_vec_i].empty())
				{
					i_vec_i = (i_vec_i + 1) % i_vec.size();
				}
				extract_idx.push_back(i_vec[i_vec_i].front());
				i_vec[i_vec_i].erase(i_vec[i_vec_i].begin());
				i_vec_i = (i_vec_i + 1) % i_vec.size();
			}
			std::vector<int>extract_idx_;
			std::vector<double>heat_density_;
			for (i = 0; i < std::min(each_turn_candidate,(int)extract_idx.size()); ++i)
			{
				int i_i = extract_idx[i];
				double heat_den = vec_4_paths_length_local[i_i] > 0 ? ((vec_4_heat_accumulate_local[i_i]) / vec_4_paths_length_local[i_i]) : 0;
				auto insert_idx = std::distance(heat_density_.begin(),
					std::lower_bound(heat_density_.begin(), heat_density_.end(), heat_den));
				heat_density_.insert(heat_density_.begin() + insert_idx, heat_den);
				extract_idx_.insert(extract_idx_.begin() + insert_idx, i_i);
			}
			////std::cout << "cost F4" << std::endl;
			int non_zero_error_num = 0;
			int pre_vec_size = vec_4_paths.size();


			vec_4_remain_split.clear();
			vec_4_paths.clear();
			vec_4_vector_field.clear();
			vec_4_scalar_field.clear();
			vec_4_cur_apt.clear();
			vec_4_is_visit.clear();
			vec_4_paths_length.clear();
			vec_4_cur_seg.clear();
			vec_4_heat_accumulate.clear();
			vec_extendable_apts.clear();
			vec_curve_end.clear();
			vec_4_i.clear();
			for (i = 0; i < std::min(each_turn_candidate, int(extract_idx_.size())); ++i)
			{
				vec_4_remain_split.push_back(vec_4_remain_split_local[extract_idx_[i]]);
				vec_4_paths.push_back(vec_4_paths_local[extract_idx_[i]]);
				vec_4_vector_field.push_back(vec_4_vector_field_local[extract_idx_[i]]);
				vec_4_scalar_field.push_back(vec_4_scalar_field_local[extract_idx_[i]]);
				vec_4_cur_apt.push_back(vec_4_cur_apt_local[extract_idx_[i]]);
				vec_4_is_visit.push_back(vec_4_is_visit_local[extract_idx_[i]]);
				vec_4_paths_length.push_back(vec_4_paths_length_local[extract_idx_[i]]);
				vec_4_cur_seg.push_back(vec_4_cur_seg_local[extract_idx_[i]]);
				vec_4_heat_accumulate.push_back(vec_4_heat_accumulate_local[extract_idx_[i]]);
				vec_extendable_apts.push_back(vec_extendable_apts_local[extract_idx_[i]]);
				vec_curve_end.push_back(vec_curve_end_local[extract_idx_[i]]);
				vec_4_i.push_back(vec_4_i_local[extract_idx_[i]]);
			}
		}
		vec_4_paths_origin = vec_4_paths;
		paths_res = vec_4_paths;
		vec_4_curve_apt = std::vector<std::vector<std::vector<int>>>(vec_4_paths.size());
		for (int i = 0; i < vec_4_paths.size(); ++i)
		{
			vec_4_curve_apt[i] = std::vector<std::vector<int>>();
			for (int j = 0; j < vec_4_paths[i].size(); ++j)
			{
				vec_4_curve_apt[i].push_back(std::vector<int>());
				for (int k = 0; k < vec_4_paths[i][j].size(); ++k)
				{
					auto path_pt = vec_4_paths[i][j][k];
					if (std::find(select_pts.begin(), select_pts.end(), path_pt)
						!= select_pts.end())
					{
						vec_4_curve_apt[i][j].push_back(path_pt);
					}
				}
			}
		}
		omp_destroy_lock(&lock);
	}

	void single_traverse(segIO& seg,
		const std::vector<std::vector<Eigen::RowVector3d>>& feature_vector_fields,
		const std::vector<std::vector<double>>& feature_scalar_fields,
		const std::vector<double>& feature_modifier,
		std::vector<int>& select_pts,
		std::vector<std::vector<std::vector<int>>>& paths_res,
		bool line_end_to_end, int max_lines_num, int step, QProgressDialog* progressDialog,
		double logi1_a, double logi1_b, double logi2_a, double logi2_b)
	{
		static omp_lock_t lock;
		omp_init_lock(&lock);
		if (vec_4_paths.empty())
		{
			init_search_progress(seg, select_pts);
			init_search_vecs(max_lines_num,1);
			compute_split_prob(feature_vector_fields, feature_scalar_fields, select_pts, apt_split_prob, max_lines_num);
		}

		//const int each_turn_candidate = 10;
		//const int new_branch_size = 5;
		int unvisit_num = select_pts.size() - 1;
		if (step < 1) { step = unvisit_num; }
		for (int step_i = 0; (step_i < step && cur_search_progress < unvisit_num); step_i++, cur_search_progress++)
		{	
			std::cout << "action 0" << std::endl;
			progressDialog->setValue(step_i * (80 / step));
			QApplication::processEvents();
			std::vector<int>vec_4_remain_split_local;
			std::vector<std::vector<int>>vec_extendable_apts_local;
			std::vector<std::vector<int>>vec_curve_end_local;
			std::vector<std::vector<std::vector<int>>>vec_4_paths_local;
			std::vector<std::vector<Eigen::RowVector3d>>vec_4_vector_field_local;
			std::vector<std::vector<double>>vec_4_scalar_field_local;

			std::vector<anchor_point>vec_4_cur_apt_local;
			std::vector<int>vec_4_cur_seg_local;
			std::vector<std::vector<kVisit>>vec_4_is_visit_local;
			std::vector<double>vec_4_paths_length_local;
			std::vector<double>vec_4_heat_accumulate_local;
			std::vector<int>vec_4_i_local;

			int cur_level_candidate = vec_4_paths.size();
			std::cout << cur_level_candidate << std::endl;
			std::vector<graph_t> vec_4_distorsion_g = std::vector<graph_t>(cur_level_candidate * feature_vector_fields.size());
			int i, f_i;
			#pragma omp parallel for private(i, f_i) collapse(2)
			for (i = 0; i < cur_level_candidate; ++i)
			{	
				for (f_i = 0; f_i < feature_vector_fields.size(); ++f_i)
				{	
					std::cout << "action 2" << std::endl;
					graph_t distorsion_g;
					build_paths(seg, feature_vector_fields[f_i], feature_scalar_fields[f_i],
						vec_4_vector_field[i], vec_4_scalar_field[i], distorsion_g, logi1_a, logi1_b, logi2_a, logi2_b);
					int idx = i * feature_vector_fields.size() + f_i;
					vec_4_distorsion_g[idx] = distorsion_g;
				}
			}
			int cv_i;
			std::vector<std::vector<bool>>vec_4_going_on(cur_level_candidate * feature_vector_fields.size());
			std::vector<std::vector<bool>>vec_4_is_curve_end(cur_level_candidate * feature_vector_fields.size());
			std::vector<std::vector<std::vector<boost::graph_traits<graph_t>::vertex_descriptor>>>vec_4_p(cur_level_candidate * feature_vector_fields.size());
			std::vector<std::vector<std::vector<double>>>vec_4_d(cur_level_candidate * feature_vector_fields.size());
			std::vector<std::vector<anchor_point>>vec_4_cur_apt_in(cur_level_candidate * feature_vector_fields.size());
			for (i = 0; i < vec_4_going_on.size(); ++i)
			{
				vec_4_going_on[i] = std::vector<bool>(vec_extendable_apts[i / feature_vector_fields.size()].size());
				vec_4_p[i] = std::vector<std::vector<boost::graph_traits<graph_t>::vertex_descriptor>>(vec_extendable_apts[i / feature_vector_fields.size()].size());
				vec_4_d[i] = std::vector<std::vector<double>>(vec_extendable_apts[i / feature_vector_fields.size()].size());
				vec_4_cur_apt_in[i] = std::vector<anchor_point>(vec_extendable_apts[i / feature_vector_fields.size()].size());
				vec_4_is_curve_end[i] = std::vector<bool>(vec_extendable_apts[i / feature_vector_fields.size()].size());
			}
			#pragma omp parallel for private(i, f_i, cv_i) collapse(3)
			for (i = 0; i < cur_level_candidate; ++i)
			{
				for (f_i = 0; f_i < feature_vector_fields.size(); ++f_i)
				{
					for (cv_i = 0; cv_i < vec_extendable_apts[i].size(); cv_i++)
					{
						int vec_idx = i * feature_vector_fields.size() + f_i;
						anchor_point cur_apt;
						for (int apt_i = 0; apt_i < anchor_points.size(); ++apt_i)
						{
							if (anchor_points[apt_i].anchor_vertex_idx == vec_extendable_apts[i][cv_i])
							{
								cur_apt = anchor_points[apt_i];
							}
						}
						int remain_split_num = vec_4_remain_split[i];
						int cur_apt_slct_idx = std::distance(select_pts.begin(),
							std::find(select_pts.begin(), select_pts.end(), cur_apt.anchor_vertex_idx));
						//bool cur_apt_split_able = (apt_split_prob[cur_apt_slct_idx] > split_prob_threshold);
						std::vector<boost::graph_traits< graph_t >::vertex_descriptor> p;
						std::vector<double> d;
						int curve_end = vec_extendable_apts[i][cv_i];
						bool is_curve_end = false;
						if (std::find(vec_curve_end[i].begin(), vec_curve_end[i].end(), curve_end) !=
							vec_curve_end[i].end())
						{
							is_curve_end = true;
						}
						/*
						if ((!is_curve_end) && (!cur_apt_split_able))
						{
							vec_4_going_on[vec_idx][cv_i] = false;
							continue;
						}
						*/
						if ((!is_curve_end) && (!remain_split_num))
						{
							vec_4_going_on[vec_idx][cv_i] = false;
							continue;
						}
						dijkstra_search(p, d, curve_end, vec_4_distorsion_g[vec_idx]);
						vec_4_going_on[vec_idx][cv_i] = true;
						vec_4_p[vec_idx][cv_i] = p;
						vec_4_d[vec_idx][cv_i] = d;
						vec_4_cur_apt_in[vec_idx][cv_i] = cur_apt;
						vec_4_is_curve_end[vec_idx][cv_i] = is_curve_end;
					}
				}
			}
			std::vector<std::vector<int>>vec_4_unvisit_anchors(cur_level_candidate);
			#pragma omp parallel for
			for (i = 0; i < cur_level_candidate; ++i)
			{
				std::vector<kVisit> is_visit = vec_4_is_visit[i];
				//anchor_point cur_apt = vec_4_cur_apt[i];
				//int cur_apt_picked_id = vec_4_cur_apt_picked_id[i];
				int cur_seg = vec_4_cur_seg[i];

				std::vector<int>unvisit_anchors;
				for (int j = 0; j < anchor_points.size(); ++j)
				{
					if (is_visit[j] == kVisit::UNVISIT)
					{
						unvisit_anchors.push_back(j);
					}
				}
				vec_4_unvisit_anchors[i] = unvisit_anchors;
			}
			int j;
			#pragma omp parallel for private(i, f_i, cv_i, j) collapse(4)
			for (i = 0; i < cur_level_candidate; ++i)
			{
				for (f_i = 0; f_i < feature_vector_fields.size(); ++f_i)
				{
					for (cv_i = 0; cv_i < vec_extendable_apts[i].size(); cv_i++)
					{
						for (j = 0; j < std::min((int)1,(int)vec_4_unvisit_anchors[i].size()); ++j)
						{	
							std::cout << "action 1" << std::endl;
							int vec_4_p_idx = i * feature_vector_fields.size() + f_i;
							if (!vec_4_going_on[vec_4_p_idx][cv_i])
							{
								break;
							}
							std::vector<boost::graph_traits< graph_t >::vertex_descriptor> p = vec_4_p[vec_4_p_idx][cv_i];
							std::vector<double> d = vec_4_d[vec_4_p_idx][cv_i];
							anchor_point cur_apt = vec_4_cur_apt_in[vec_4_p_idx][cv_i];
							std::vector<int>unvisit_anchors = vec_4_unvisit_anchors[i];

							int curve_end = vec_extendable_apts[i][cv_i];
							int cur_apt_idx = unvisit_anchors[j];
							auto cur_apt_ = anchor_points[cur_apt_idx];
							std::vector<int>geodesic_path;
							int idx = cur_apt_.anchor_vertex_idx;
							while (idx != curve_end)
							{
								geodesic_path.push_back(idx);
								idx = p[idx];
							}
							geodesic_path.push_back(curve_end);
							std::vector<kVisit>is_visit_copy = vec_4_is_visit[i];
							int unvisit_num_copy = unvisit_num;


							is_visit_copy[cur_apt_idx] = kVisit::VISIT;

							std::vector<std::vector<int>>cur_path = vec_4_paths[i];
							std::vector<int>extendable_apts = vec_extendable_apts[i];
							std::vector<int>curve_ends = vec_curve_end[i];

							int remain_split_num_copy = vec_4_remain_split[i];
							if (vec_4_is_curve_end[vec_4_p_idx][cv_i])
							{
								for (int k = 0; k < cur_path.size(); ++k)
								{
									if (cur_path[k].back() == geodesic_path.back())
									{
										auto find_iter = std::find(curve_ends.begin(), curve_ends.end(), cur_path[k].back());
										curve_ends.erase(find_iter);
										cur_path[k].insert(cur_path[k].end(), geodesic_path.rbegin() + 1, geodesic_path.rend());
										curve_ends.push_back(cur_path[k].back());
										if (cur_search_progress == 0)
										{
											extendable_apts.clear();
										}
										extendable_apts.push_back(cur_path[k].back());
										break;
									}
								}
							}
							else
							{
								std::vector<int>new_spline(geodesic_path.rbegin(), geodesic_path.rend());
								cur_path.push_back(new_spline);
								extendable_apts.erase(extendable_apts.begin() + cv_i);
								curve_ends.push_back(new_spline.back());
								extendable_apts.push_back(new_spline.back());
								remain_split_num_copy--;
							}
							std::vector<double>line_scalar_field;
							std::vector<Eigen::RowVector3d>line_vector_field;
							compute_heat_val(cur_path, line_scalar_field);
							double path_distorsion_len = d[cur_apt_.anchor_vertex_idx];
							double accumulate_length = 0;
							double accumulate_heat = 0;
							for (int k = 0; k < geodesic_path.size() - 1; ++k)
							{
								Eigen::RowVector3d pt1 = Eigen::RowVector3d(
									index_to_vertex_map[geodesic_path[k]]->point().x(),
									index_to_vertex_map[geodesic_path[k]]->point().y(),
									index_to_vertex_map[geodesic_path[k]]->point().z());
								Eigen::RowVector3d pt2 = Eigen::RowVector3d(
									index_to_vertex_map[geodesic_path[k + 1]]->point().x(),
									index_to_vertex_map[geodesic_path[k + 1]]->point().y(),
									index_to_vertex_map[geodesic_path[k + 1]]->point().z());
								accumulate_length += (pt1 - pt2).norm();
								accumulate_heat += 0.5 * (feature_scalar_fields[f_i][geodesic_path[k]] +
									feature_scalar_fields[f_i][geodesic_path[k + 1]]);
							}
							omp_set_lock(&lock);
							vec_4_remain_split_local.push_back(remain_split_num_copy);
							vec_extendable_apts_local.push_back(extendable_apts);
							vec_curve_end_local.push_back(curve_ends);
							vec_4_paths_local.push_back(cur_path);
							vec_4_vector_field_local.push_back(line_vector_field);
							vec_4_scalar_field_local.push_back(line_scalar_field);
							vec_4_cur_apt_local.push_back(cur_apt_);
							vec_4_is_visit_local.push_back(is_visit_copy);

							vec_4_paths_length_local.push_back(accumulate_length);
							vec_4_heat_accumulate_local.push_back(path_distorsion_len);
							vec_4_cur_seg_local.push_back(cur_apt.anchor_seg);
							vec_4_i_local.push_back(i);
							omp_unset_lock(&lock);
						}
					}
				}
			}
			vec_4_remain_split.clear();
			vec_4_paths.clear();
			vec_4_vector_field.clear();
			vec_4_scalar_field.clear();
			vec_4_cur_apt.clear();
			vec_4_is_visit.clear();
			vec_4_paths_length.clear();
			vec_4_cur_seg.clear();
			vec_4_heat_accumulate.clear();
			vec_extendable_apts.clear();
			vec_curve_end.clear();
			vec_4_i.clear();
			std::vector<int>extract_idx_;
			extract_idx_.push_back(0);
			for (i = 0; i < std::min(1, (int)extract_idx_.size()); ++i)
			{
				vec_4_remain_split.push_back(vec_4_remain_split_local[extract_idx_[i]]);
				vec_4_paths.push_back(vec_4_paths_local[extract_idx_[i]]);
				vec_4_vector_field.push_back(vec_4_vector_field_local[extract_idx_[i]]);
				vec_4_scalar_field.push_back(vec_4_scalar_field_local[extract_idx_[i]]);
				vec_4_cur_apt.push_back(vec_4_cur_apt_local[extract_idx_[i]]);
				vec_4_is_visit.push_back(vec_4_is_visit_local[extract_idx_[i]]);
				vec_4_paths_length.push_back(vec_4_paths_length_local[extract_idx_[i]]);
				vec_4_cur_seg.push_back(vec_4_cur_seg_local[extract_idx_[i]]);
				vec_4_heat_accumulate.push_back(vec_4_heat_accumulate_local[extract_idx_[i]]);
				vec_extendable_apts.push_back(vec_extendable_apts_local[extract_idx_[i]]);
				vec_curve_end.push_back(vec_curve_end_local[extract_idx_[i]]);
				vec_4_i.push_back(vec_4_i_local[extract_idx_[i]]);
			}
		}
		vec_4_paths_origin = vec_4_paths;
		paths_res = vec_4_paths;
		vec_4_curve_apt = std::vector<std::vector<std::vector<int>>>(vec_4_paths.size());
		for (int i = 0; i < vec_4_paths.size(); ++i)
		{
			vec_4_curve_apt[i] = std::vector<std::vector<int>>();
			for (int j = 0; j < vec_4_paths[i].size(); ++j)
			{
				vec_4_curve_apt[i].push_back(std::vector<int>());
				for (int k = 0; k < vec_4_paths[i][j].size(); ++k)
				{
					auto path_pt = vec_4_paths[i][j][k];
					if (std::find(select_pts.begin(), select_pts.end(), path_pt)
						!= select_pts.end())
					{
						vec_4_curve_apt[i][j].push_back(path_pt);
					}
				}
			}
		}
		omp_destroy_lock(&lock);
	}

	void multiple_circuit_traverse(segIO& seg,
		const std::vector<std::vector<Eigen::RowVector3d>>& feature_vector_fields,
		const std::vector<std::vector<double>>& feature_scalar_fields,
		const std::vector<double>& feature_modifier,
		std::vector<std::vector<int>>& select_pts,
		std::vector<std::vector<std::vector<int>>>& paths_res,
		bool line_end_to_end, int max_lines_num, int step, QProgressDialog* progressDialog,
		int each_turn_candidate, int new_branch_size,
		double logi1a,double logi1b,double logi2a,double logi2b)
	{	
		std::cout << "select_pts.size()" << select_pts.size() << std::endl;
		static omp_lock_t lock;
		omp_init_lock(&lock);
		if (vec_4_paths.empty())
		{
			init_search_progress(seg, select_pts);
			init_search_vecs_(max_lines_num, select_pts);
			compute_split_prob(feature_vector_fields, feature_scalar_fields, select_pts, apt_split_prob, max_lines_num);
		}

		//const int each_turn_candidate = 10;
		//const int branch_size = 2;
		int unvisit_num = select_pts.size() - 1;
		if (step < 1) { step = unvisit_num; }
		for (int step_i = 0; (step_i < step && cur_search_progress < unvisit_num); step_i++, cur_search_progress++)
		{	
			std::cout << "step 1" << std::endl;
			progressDialog->setValue(step_i * (80 / step));
			QApplication::processEvents();
			std::vector<int>vec_4_remain_split_local;
			std::vector<std::vector<int>>vec_extendable_apts_local;
			std::vector<std::vector<int>>vec_curve_end_local;
			std::vector<std::vector<std::vector<int>>>vec_4_paths_local;
			std::vector<std::vector<Eigen::RowVector3d>>vec_4_vector_field_local;
			std::vector<std::vector<double>>vec_4_scalar_field_local;

			//std::vector<anchor_point>vec_4_cur_apt_local;
			std::vector<std::vector<int>>vec_4_cur_apt_local;
			std::vector<int>vec_4_cur_seg_local;
			std::vector<std::vector<kVisit>>vec_4_is_visit_local;
			std::vector<double>vec_4_paths_length_local;
			std::vector<double>vec_4_heat_accumulate_local;
			std::vector<int>vec_4_i_local;

			int cur_level_candidate = vec_4_paths.size();
			std::vector<graph_t> vec_4_distorsion_g = std::vector<graph_t>(cur_level_candidate * feature_vector_fields.size());
			int i, f_i;
#pragma omp parallel for private(i, f_i) collapse(2)
			for (i = 0; i < cur_level_candidate; ++i)
			{
				for (f_i = 0; f_i < feature_vector_fields.size(); ++f_i)
				{	
					std::cout << "step 1.5" << std::endl;
					graph_t distorsion_g;
					build_paths(seg, feature_vector_fields[f_i], feature_scalar_fields[f_i],
						vec_4_vector_field[i], vec_4_scalar_field[i], distorsion_g, logi1a,logi1b,logi2a,logi2b);
					int idx = i * feature_vector_fields.size() + f_i;
					vec_4_distorsion_g[idx] = distorsion_g;
				}
			}
			int cv_i;
			std::cout << "step 2" << std::endl;
			std::vector<std::vector<bool>>vec_4_going_on(cur_level_candidate * feature_vector_fields.size());
			std::vector<std::vector<bool>>vec_4_is_curve_end(cur_level_candidate * feature_vector_fields.size());
			std::vector<std::vector<std::vector<boost::graph_traits<graph_t>::vertex_descriptor>>>vec_4_p(cur_level_candidate * feature_vector_fields.size());
			std::vector<std::vector<std::vector<double>>>vec_4_d(cur_level_candidate * feature_vector_fields.size());
			//std::vector<std::vector<anchor_point>>vec_4_cur_apt_in(cur_level_candidate * feature_vector_fields.size());
			std::vector<std::vector<int>>vec_4_cur_apt_in(cur_level_candidate * feature_vector_fields.size());
			for (i = 0; i < vec_4_going_on.size(); ++i)
			{
				vec_4_going_on[i] = std::vector<bool>(vec_extendable_apts[i / feature_vector_fields.size()].size());
				vec_4_p[i] = std::vector<std::vector<boost::graph_traits<graph_t>::vertex_descriptor>>(vec_extendable_apts[i / feature_vector_fields.size()].size());
				vec_4_d[i] = std::vector<std::vector<double>>(vec_extendable_apts[i / feature_vector_fields.size()].size());
				//vec_4_cur_apt_in[i] = std::vector<int>(vec_extendable_apts_[i / feature_vector_fields.size()].size());
				vec_4_is_curve_end[i] = std::vector<bool>(vec_extendable_apts[i / feature_vector_fields.size()].size());
			}
			#pragma omp parallel for private(i, f_i, cv_i) collapse(3)
			for (i = 0; i < cur_level_candidate; ++i)
			{
				for (f_i = 0; f_i < feature_vector_fields.size(); ++f_i)
				{
					for (cv_i = 0; cv_i < vec_extendable_apts[i].size(); cv_i++)
					{	
						std::cout << "step 2.5" << std::endl;
						int vec_idx = i * feature_vector_fields.size() + f_i;
						int remain_split_num = vec_4_remain_split[i];
						//int cur_apt_slct_idx = std::distance(select_pts.begin(),
						//	std::find(select_pts.begin(), select_pts.end(), cur_apt.anchor_vertex_idx));
						//bool cur_apt_split_able = (apt_split_prob[cur_apt_slct_idx] > split_prob_threshold);
						std::vector<boost::graph_traits< graph_t >::vertex_descriptor> p;
						std::vector<double> d;
						int curve_end = vec_extendable_apts[i][cv_i];
						bool is_curve_end = false;
						if (std::find(vec_curve_end[i].begin(), vec_curve_end[i].end(), curve_end) !=
							vec_curve_end[i].end())
						{
							is_curve_end = true;
						}
						if ((!is_curve_end) && (!remain_split_num))
						{
							vec_4_going_on[vec_idx][cv_i] = false;
							continue;
						}
						dijkstra_search(p, d, curve_end, vec_4_distorsion_g[vec_idx]);
						vec_4_going_on[vec_idx][cv_i] = true;
						vec_4_p[vec_idx][cv_i] = p;
						vec_4_d[vec_idx][cv_i] = d;
						vec_4_is_curve_end[vec_idx][cv_i] = is_curve_end;
					}
				}
			}
			std::cout << "step 3" << std::endl;
			std::vector<std::vector<int>>vec_4_unvisit_anchors(cur_level_candidate);
			#pragma omp parallel for
			for (i = 0; i < cur_level_candidate; ++i)
			{	
				std::cout << "step 3.5" << std::endl;
				std::vector<kVisit> is_visit = vec_4_is_visit[i];
				std::vector<int>unvisit_anchors;
				for (int j = 0; j < select_pts.size(); ++j)
				{
					if (is_visit[j] == kVisit::UNVISIT)
					{
						unvisit_anchors.push_back(j);
					}
				}
				vec_4_unvisit_anchors[i] = unvisit_anchors;
			}
			int j;
			std::cout << "step 4" << std::endl;
			#pragma omp parallel for private(i, f_i, cv_i, j) collapse(4)
			for (i = 0; i < cur_level_candidate; ++i)
			{
				for (f_i = 0; f_i < feature_vector_fields.size(); ++f_i)
				{
					for (cv_i = 0; cv_i < vec_extendable_apts[i].size(); cv_i++)
					{
						for (j = 0; j < vec_4_unvisit_anchors[i].size(); ++j)
						{	
							std::cout << "step 5" << std::endl;
							int vec_4_p_idx = i * feature_vector_fields.size() + f_i;
							if (!vec_4_going_on[vec_4_p_idx][cv_i])
							{
								break;
							}
							std::vector<boost::graph_traits< graph_t >::vertex_descriptor> p = vec_4_p[vec_4_p_idx][cv_i];
							std::vector<double> d = vec_4_d[vec_4_p_idx][cv_i];
							//anchor_point cur_apt = vec_4_cur_apt_in[vec_4_p_idx][cv_i];
							std::vector<int>unvisit_anchors = vec_4_unvisit_anchors[i];
							
							//����Ľڵ�
							auto curve_end = vec_extendable_apts[i][cv_i];
							int cur_apt_idx= unvisit_anchors[j];
							auto cur_apt_ = select_pts[cur_apt_idx];
							std::vector<int>geodesic_path;
							if (d[cur_apt_.front()] < d[cur_apt_.back()])
							{
								int idx = cur_apt_.front();
								while (idx != curve_end)
								{
									geodesic_path.push_back(idx);
									idx = p[idx];
								}
								geodesic_path.push_back(curve_end);
								geodesic_path.insert(geodesic_path.begin(),
									cur_apt_.rbegin(),cur_apt_.rend()-1);
							}
							else
							{
								int idx = cur_apt_.back();
								while (idx != curve_end)
								{
									geodesic_path.push_back(idx);
									idx = p[idx];
								}
								geodesic_path.push_back(curve_end);
								geodesic_path.insert(geodesic_path.begin(),
									cur_apt_.begin(), cur_apt_.end() - 1);
							}

							std::vector<kVisit>is_visit_copy = vec_4_is_visit[i];
							int unvisit_num_copy = unvisit_num;
							is_visit_copy[cur_apt_idx] = kVisit::VISIT;

							std::vector<std::vector<int>>cur_path = vec_4_paths[i];
							std::vector<int>extendable_apts = vec_extendable_apts[i];
							std::vector<int>curve_ends = vec_curve_end[i];
							std::cout << "step 6" << std::endl;
							int remain_split_num_copy = vec_4_remain_split[i];
							if (vec_4_is_curve_end[vec_4_p_idx][cv_i])
							{
								for (int k = 0; k < cur_path.size(); ++k)
								{
									if (cur_path[k].back() == geodesic_path.back())
									{
										auto find_iter = std::find(curve_ends.begin(), curve_ends.end(), cur_path[k].back());
										curve_ends.erase(find_iter);
										cur_path[k].insert(cur_path[k].end(), geodesic_path.rbegin() + 1, geodesic_path.rend());
										curve_ends.push_back(cur_path[k].back());
										if (cur_search_progress == 0)
										{
											extendable_apts.clear();
										}
										extendable_apts.push_back(cur_path[k].back());
										break;
									}
								}
							}
							else
							{
								std::vector<int>new_spline(geodesic_path.rbegin(), geodesic_path.rend());
								cur_path.push_back(new_spline);
								extendable_apts.erase(extendable_apts.begin() + cv_i);
								curve_ends.push_back(new_spline.back());
								extendable_apts.push_back(new_spline.back());
								remain_split_num_copy--;
							}
							std::vector<double>line_scalar_field;
							std::vector<Eigen::RowVector3d>line_vector_field;
							compute_heat_val(cur_path, line_scalar_field);
							double path_distorsion_len = std::min(d[cur_apt_.front()] , d[cur_apt_.back()]);
							double accumulate_length = 0;
							double accumulate_heat = 0;
							for (int k = 0; k < geodesic_path.size() - 1; ++k)
							{
								Eigen::RowVector3d pt1 = Eigen::RowVector3d(
									index_to_vertex_map[geodesic_path[k]]->point().x(),
									index_to_vertex_map[geodesic_path[k]]->point().y(),
									index_to_vertex_map[geodesic_path[k]]->point().z());
								Eigen::RowVector3d pt2 = Eigen::RowVector3d(
									index_to_vertex_map[geodesic_path[k + 1]]->point().x(),
									index_to_vertex_map[geodesic_path[k + 1]]->point().y(),
									index_to_vertex_map[geodesic_path[k + 1]]->point().z());
								accumulate_length += (pt1 - pt2).norm();
								accumulate_heat += 0.5 * (feature_scalar_fields[f_i][geodesic_path[k]] +
									feature_scalar_fields[f_i][geodesic_path[k + 1]]);
							}
							omp_set_lock(&lock);
							std::cout << "step 7" << std::endl;
							vec_4_remain_split_local.push_back(remain_split_num_copy);
							vec_extendable_apts_local.push_back(extendable_apts);
							vec_curve_end_local.push_back(curve_ends);
							vec_4_paths_local.push_back(cur_path);
							vec_4_vector_field_local.push_back(line_vector_field);
							vec_4_scalar_field_local.push_back(line_scalar_field);
							vec_4_cur_apt_local.push_back(cur_apt_);
							vec_4_is_visit_local.push_back(is_visit_copy);

							vec_4_paths_length_local.push_back(accumulate_length);
							vec_4_heat_accumulate_local.push_back(path_distorsion_len);
							vec_4_cur_seg_local.push_back(0);
							vec_4_i_local.push_back(i);
							omp_unset_lock(&lock);
						}
					}
				}
			}
			std::cout << "step 8" << std::endl;
			std::vector<std::vector<int>>i_vec(cur_level_candidate);
			std::vector<std::vector<double>>vec_heat_density(cur_level_candidate);
			for (i = 0; i < vec_4_cur_apt_local.size(); ++i)
			{
				int i_i = vec_4_i_local[i];
				double heat_den = vec_4_paths_length_local[i] > 0 ? (vec_4_heat_accumulate_local[i]) : 0;
				auto insert_idx = std::distance(vec_heat_density[i_i].begin(),
					std::lower_bound(vec_heat_density[i_i].begin(),
						vec_heat_density[i_i].end(), heat_den));
				vec_heat_density[i_i].insert(vec_heat_density[i_i].begin() + insert_idx, heat_den);
				i_vec[i_i].insert(i_vec[i_i].begin() + insert_idx, i);
			}
			std::vector<int>extract_idx;
			int i_vec_i = 0;
			for (i = 0; i < cur_level_candidate * std::min(new_branch_size, int(unvisit_num - step_i)); ++i)
			{
				while (i_vec[i_vec_i].empty())
				{
					i_vec_i = (i_vec_i + 1) % i_vec.size();
				}
				extract_idx.push_back(i_vec[i_vec_i].front());
				i_vec[i_vec_i].erase(i_vec[i_vec_i].begin());
				i_vec_i = (i_vec_i + 1) % i_vec.size();
			}
			std::vector<int>extract_idx_;
			std::vector<double>heat_density_;
			for (i = 0; i < std::min(each_turn_candidate, (int)extract_idx.size()); ++i)
			{
				int i_i = extract_idx[i];
				double heat_den = vec_4_paths_length_local[i_i] > 0 ? ((vec_4_heat_accumulate_local[i_i]) / vec_4_paths_length_local[i_i]) : 0;
				auto insert_idx = std::distance(heat_density_.begin(),
					std::lower_bound(heat_density_.begin(), heat_density_.end(), heat_den));
				heat_density_.insert(heat_density_.begin() + insert_idx, heat_den);
				extract_idx_.insert(extract_idx_.begin() + insert_idx, i_i);
			}
			////std::cout << "cost F4" << std::endl;
			std::cout << "step 9" << std::endl;
			int non_zero_error_num = 0;
			int pre_vec_size = vec_4_paths.size();


			vec_4_remain_split.clear();
			vec_4_paths.clear();
			vec_4_vector_field.clear();
			vec_4_scalar_field.clear();
			//vec_4_cur_apt.clear();
			vec_4_is_visit.clear();
			vec_4_paths_length.clear();
			vec_4_cur_seg.clear();
			vec_4_heat_accumulate.clear();
			vec_extendable_apts.clear();
			vec_curve_end.clear();
			vec_4_i.clear();
			for (i = 0; i < std::min(each_turn_candidate, int(extract_idx_.size())); ++i)
			{
				vec_4_remain_split.push_back(vec_4_remain_split_local[extract_idx_[i]]);
				vec_4_paths.push_back(vec_4_paths_local[extract_idx_[i]]);
				vec_4_vector_field.push_back(vec_4_vector_field_local[extract_idx_[i]]);
				vec_4_scalar_field.push_back(vec_4_scalar_field_local[extract_idx_[i]]);
				//vec_4_cur_apt.push_back(vec_4_cur_apt_local[extract_idx_[i]]);
				vec_4_is_visit.push_back(vec_4_is_visit_local[extract_idx_[i]]);
				vec_4_paths_length.push_back(vec_4_paths_length_local[extract_idx_[i]]);
				vec_4_cur_seg.push_back(vec_4_cur_seg_local[extract_idx_[i]]);
				vec_4_heat_accumulate.push_back(vec_4_heat_accumulate_local[extract_idx_[i]]);
				vec_extendable_apts.push_back(vec_extendable_apts_local[extract_idx_[i]]);
				vec_curve_end.push_back(vec_curve_end_local[extract_idx_[i]]);
				vec_4_i.push_back(vec_4_i_local[extract_idx_[i]]);
			}
			std::cout << "step 10" << std::endl;
		}

		vec_4_paths_origin = vec_4_paths;
		paths_res = vec_4_paths;
		omp_destroy_lock(&lock);
	}



	void auto_bridge(segIO& seg_info, std::vector<std::vector<Eigen::RowVector3d>>& feature_vector_fields,
		std::vector<std::vector<double>>& feature_scalar_fields,
		std::vector<std::vector<std::vector<int>>>& paths_,
		std::vector<std::vector<std::vector<int>>>& bridges_, std::vector<std::string>& bridges_str_,
		std::vector<std::vector<std::vector<Eigen::Vector3d>>>& bridges_smooth,
		double density_threshold,double logi1a,double logi1b,double logi2a,double logi2b)
	{
		static omp_lock_t lock;
		omp_init_lock(&lock);
		auto vec_4_paths_tmp = vec_4_paths;
		auto vec_4_vector_field_tmp = vec_4_vector_field;
		auto vec_4_scalar_field_tmp = vec_4_scalar_field;
		auto vec_4_curve_apt_tmp = vec_4_curve_apt;
		std::vector<std::vector<std::pair<int, int>>>vec_4_path_isolate_ends(vec_4_paths_tmp.size());
		for (int vec_i = 0; vec_i < vec_4_paths.size(); ++vec_i)
		{
			for (int i = 0; i < vec_4_paths[vec_i].size(); ++i)
			{
				bool is_front_isolate = true;
				bool is_back_isolate = true;
				for (int j = 0; j < vec_4_paths[vec_i].size(); ++j)
				{
					if (i == j)continue;
					if (std::find(vec_4_paths[vec_i][j].begin(), vec_4_paths[vec_i][j].end(), vec_4_paths[vec_i][i].front()) != vec_4_paths[vec_i][j].end())
					{
						is_front_isolate = false;
						break;
					}
				}
				for (int j = 0; j < vec_4_paths[vec_i].size(); ++j)
				{
					if (i == j)continue;
					if (std::find(vec_4_paths[vec_i][j].begin(), vec_4_paths[vec_i][j].end(), vec_4_paths[vec_i][i].back()) != vec_4_paths[vec_i][j].end())
					{
						is_back_isolate = false;
						break;
					}
				}
				if (is_front_isolate)
				{
					//this need modified maybe
					vec_4_path_isolate_ends[vec_i].push_back(std::pair<int, int>(i, 0));
				}
				if (is_back_isolate)
				{
					vec_4_path_isolate_ends[vec_i].push_back(std::pair<int, int>(i, 1));
				}
			}
		}
		const int branch_size = 8;
		const int each_turn_candidate = 8;

		std::vector<std::pair<int, int>>path_isolate_ends;
		std::vector<std::vector<std::vector<int>>>vec_4_bridge_res;
		std::vector<std::vector<std::vector<int>>>vec_4_bridge_res_filterd;
		std::vector<double>vec_4_accumulate_heat;
		std::vector<double>vec_4_accumulate_heat_filterd;
		std::vector<bool>vec_4_is_continue;

		std::vector<std::vector<double>>vec_4_line_scalar_fields_bridge = vec_4_scalar_field;
		std::vector<std::vector<std::vector<int>>>vec_4_paths_bridge = vec_4_paths;
		vec_4_curve_apt_bridge = vec_4_curve_apt;
		std::vector<double>vec_4_paths_length;
		std::vector<double>vec_4_paths_length_origin;
		std::vector<int>vec_4_form_idx;

		for (int vec_i = 0; vec_i < vec_4_paths.size(); ++vec_i)
		{
			vec_4_paths_length.push_back(0);
			vec_4_paths_length_origin.push_back(0);
			vec_4_vec_i.push_back(vec_i);
			vec_4_is_continue.push_back(true);
			vec_4_form_idx.push_back(vec_i);
		}
		int is_continue_num = vec_4_form_idx.size();
		int last_loop_candidates = 0;
		while (is_continue_num)
		{	
			//here to modify
			std::vector<std::vector<std::vector<int>>>vec_4_paths_bridge_local;
			std::vector<std::vector<seg_parts>>vec_4_path_isolate_ends_local;
			std::vector<std::vector<std::vector<int>>>vec_4_curve_apts_bridge_local;
			std::vector<std::vector<double>>vec_4_line_scalar_fields_bridge_local;
			std::vector<double>vec_4_paths_length_local;
			std::vector<double>vec_4_paths_length_origin_local;
			std::vector<int>vec_4_vec_i_local;
			std::vector<bool>vec_4_is_continue_local;
			std::vector<int>vec_4_form_idx_local;
			vec_4_vec_i.clear();

			std::cout << "loop in" << std::endl;
			for (int i = 0; i < vec_4_vec_i.size(); ++i)
			{
				vec_4_vec_i[i] = i;
			}
			int pre_vec_size = vec_4_path_isolate_ends.size();
			
			std::vector<std::vector<double>>density_vec(pre_vec_size);
			std::vector<std::vector<std::vector<int>>>bridge_path_vec(pre_vec_size);
			std::vector<std::vector<double>>d_bridge_vec(pre_vec_size);
			std::vector<std::vector<double>>d_bridge_origin_vec(pre_vec_size);
			std::vector<std::vector<std::pair<int, int>>>isolate_ends_bridge_vec(pre_vec_size);
			std::vector<std::vector<graph_t>>distor_g_vec(pre_vec_size);
			std::vector<std::vector<std::vector<std::vector<boost::graph_traits< graph_t >::vertex_descriptor>>>> p_vec(pre_vec_size);
			std::vector<std::vector<std::vector<std::vector<double>>>> d_vec(pre_vec_size);
			std::vector<std::vector<std::vector<std::vector<double>>>>d_origin_vec(pre_vec_size);
			////std::cout << "cost 0" << std::endl;
			int vec_i;
			for (vec_i = 0; vec_i < pre_vec_size; ++vec_i)
			{
				distor_g_vec[vec_i].resize(feature_vector_fields.size());
				d_vec[vec_i].resize(feature_vector_fields.size());
				p_vec[vec_i].resize(feature_vector_fields.size());
				d_origin_vec[vec_i].resize(feature_vector_fields.size());
				for (int f_i = 0; f_i < feature_vector_fields.size(); ++f_i)
				{
					d_vec[vec_i][f_i].resize(vec_4_path_isolate_ends[vec_i].size());
					p_vec[vec_i][f_i].resize(vec_4_path_isolate_ends[vec_i].size());
					d_origin_vec[vec_i][f_i].resize(vec_4_path_isolate_ends[vec_i].size());
				}
			}
			int f_i;
			std::cout << "cost 1" << std::endl;
			#pragma omp parallel for private(vec_i, f_i) collapse(2)
			for (vec_i = 0; vec_i < pre_vec_size; ++vec_i)
			{
				for (f_i = 0; f_i < feature_vector_fields.size(); ++f_i)
				{
					graph_t distorsion_g;
					build_paths(seg_info, feature_vector_fields[f_i], feature_scalar_fields[f_i],
						vec_4_vector_field_tmp.front(), vec_4_line_scalar_fields_bridge[vec_i], distorsion_g,logi1a,logi1b,logi2a,logi2b);
					distor_g_vec[vec_i][f_i] = distorsion_g;
				}
			}
			int pt_i;
			std::cout << "cost 2" << std::endl;
			//here to improve
			#pragma omp parallel for private(vec_i, f_i, pt_i) collapse(3)
			for (vec_i = 0; vec_i < pre_vec_size; ++vec_i)
			{
				for (f_i = 0; f_i < feature_vector_fields.size(); ++f_i)
				{
					for (pt_i = 0; pt_i < vec_4_path_isolate_ends[vec_i].size(); ++pt_i)
					{
						if (!vec_4_is_continue[vec_i])
						{
							continue;
						}
						int start_pt_idx;
						if (vec_4_path_isolate_ends[vec_i][pt_i].second == 0)
						{
							start_pt_idx = vec_4_paths_bridge[vec_i][vec_4_path_isolate_ends[vec_i][pt_i].first].front();
						}
						else
						{
							start_pt_idx = vec_4_paths_bridge[vec_i][vec_4_path_isolate_ends[vec_i][pt_i].first].back();
						}
						dijkstra_search(p_vec[vec_i][f_i][pt_i], d_vec[vec_i][f_i][pt_i], start_pt_idx, distor_g_vec[vec_i][f_i]);
						dijkstra_search(d_origin_vec[vec_i][f_i][pt_i], start_pt_idx);



						for (int cva_i = 0; cva_i < vec_4_curve_apt_bridge[vec_i].size(); ++cva_i)
						{
							for (int cva_j = 0; cva_j < vec_4_curve_apt_bridge[vec_i][cva_i].size(); ++cva_j)
							{
								if (vec_4_curve_apt_bridge[vec_i][cva_i][cva_j] == start_pt_idx)
								{
									continue;
								}
								auto pt_idx = vec_4_curve_apt_bridge[vec_i][cva_i][cva_j];
								if (d_vec[vec_i][f_i][pt_i][pt_idx] > 0)
								{
									omp_set_lock(&lock);
									double den = d_vec[vec_i][f_i][pt_i][pt_idx] / d_origin_vec[vec_i][f_i][pt_i][pt_idx];
									auto insert_idx = std::distance(density_vec[vec_i].begin(),
										std::upper_bound(density_vec[vec_i].begin(), density_vec[vec_i].end(),
											den));
									density_vec[vec_i].insert(density_vec[vec_i].begin() + insert_idx, den);
									omp_unset_lock(&lock);

									std::vector<int>geodesic_path;
									int idx = pt_idx;
									//int idx = paths[path_isolate_ends.front().first][path_isolate_ends.front().second];
									while (idx != start_pt_idx)
									{
										geodesic_path.push_back(idx);
										idx = p_vec[vec_i][f_i][pt_i][idx];
									}
									geodesic_path.push_back(idx);

									omp_set_lock(&lock);
									insert_idx = std::distance(d_bridge_vec[vec_i].begin(),
										std::upper_bound(d_bridge_vec[vec_i].begin(), d_bridge_vec[vec_i].end(),
											d_vec[vec_i][f_i][pt_i][pt_idx]));
									d_bridge_vec[vec_i].insert(d_bridge_vec[vec_i].begin() + insert_idx, d_vec[vec_i][f_i][pt_i][pt_idx]);
									d_bridge_origin_vec[vec_i].insert(d_bridge_origin_vec[vec_i].begin() + insert_idx, d_origin_vec[vec_i][f_i][pt_i][pt_idx]);
									bridge_path_vec[vec_i].insert(bridge_path_vec[vec_i].begin() + insert_idx, geodesic_path);
									isolate_ends_bridge_vec[vec_i].insert(isolate_ends_bridge_vec[vec_i].begin() + insert_idx,
										vec_4_path_isolate_ends[vec_i][pt_i]);
									omp_unset_lock(&lock);
								}
							}
						}
					}
				}
			}
			//here to improve
			std::cout << "cost 3" << std::endl;
			for (vec_i = 0; vec_i < pre_vec_size; ++vec_i)
			{	
				for (int k = 0; k < density_vec[vec_i].size(); ++k)
				{
					std::cout << vec_i << ":density " << density_vec[vec_i][k] << std::endl;
				}
				if (density_vec[vec_i].empty() || (density_vec[vec_i].front() > density_threshold))
				{
					//vec_4_is_continue[vec_i] = true;
					vec_4_is_continue[vec_i] = false;
					continue;
				}
			}
			int vec_j;
			#pragma omp parallel for private(vec_i, vec_j) collapse(2)
			for (vec_i = 0; vec_i < pre_vec_size; ++vec_i)
			{
				for (vec_j = 0; vec_j < std::min(branch_size, int(bridge_path_vec[vec_i].size())); ++vec_j)
				{	
					if (!vec_4_is_continue[vec_i])
					{
						continue;
					}
					auto path = vec_4_paths_bridge[vec_i];
					int find_idx = -1;
					for (int iso_i = 0; iso_i < vec_4_path_isolate_ends[vec_i].size(); ++iso_i)
					{
						int idx_;
						if (vec_4_path_isolate_ends[vec_i][iso_i].second == 0)
						{
							idx_ = path[vec_4_path_isolate_ends[vec_i][iso_i].first].front();
						}
						else
						{
							idx_ = path[vec_4_path_isolate_ends[vec_i][iso_i].first].back();
						}
						if (idx_ == bridge_path_vec[vec_i][vec_j].front())
						{
							find_idx = iso_i;
							break;
						}
					}

					auto path_copy = path;
					auto curve_apts_copy = vec_4_curve_apt_bridge[vec_i];
					auto path_isolate_ends_copy = vec_4_path_isolate_ends[vec_i];
					auto line_scalar_field_copy = vec_4_line_scalar_fields_bridge[vec_i];
					auto path_len_copy = vec_4_paths_length[vec_i] + d_bridge_vec[vec_i][vec_j];
					auto path_len_origin_copy = vec_4_paths_length_origin[vec_i] + d_bridge_origin_vec[vec_i][vec_j];


					if (isolate_ends_bridge_vec[vec_i][vec_j].second == 0)
					{
						path_copy[isolate_ends_bridge_vec[vec_i][vec_j].first].insert(path_copy[isolate_ends_bridge_vec[vec_i][vec_j].first].begin(),
							bridge_path_vec[vec_i][vec_j].begin(), bridge_path_vec[vec_i][vec_j].end() - 1);
						curve_apts_copy[isolate_ends_bridge_vec[vec_i][vec_j].first].insert(curve_apts_copy[isolate_ends_bridge_vec[vec_i][vec_j].first].begin(),
							path_copy[isolate_ends_bridge_vec[vec_i][vec_j].first].front());
					}
					else
					{
						path_copy[isolate_ends_bridge_vec[vec_i][vec_j].first].insert(path_copy[isolate_ends_bridge_vec[vec_i][vec_j].first].end(),
							bridge_path_vec[vec_i][vec_j].rbegin() + 1, bridge_path_vec[vec_i][vec_j].rend());
						curve_apts_copy[isolate_ends_bridge_vec[vec_i][vec_j].first].push_back(path_copy[isolate_ends_bridge_vec[vec_i][vec_j].first].back());
					}
					if (find_idx != -1)
					{
						path_isolate_ends_copy.erase(path_isolate_ends_copy.begin() + find_idx);
					}
					path_isolate_ends_copy.erase(path_isolate_ends_copy.begin());
					compute_heat_val(path_copy, line_scalar_field_copy);
					omp_set_lock(&lock);


					vec_4_paths_bridge_local.push_back(path_copy);
					vec_4_path_isolate_ends_local.push_back(path_isolate_ends_copy);
					vec_4_curve_apts_bridge_local.push_back(curve_apts_copy);
					vec_4_line_scalar_fields_bridge_local.push_back(line_scalar_field_copy);
					vec_4_paths_length_local.push_back(path_len_copy);
					vec_4_paths_length_origin_local.push_back(path_len_origin_copy);
					vec_4_vec_i_local.push_back(vec_i);
					//vec_4_is_continue_local.push_back(false);
					vec_4_is_continue_local.push_back(true);
					vec_4_form_idx_local.push_back(vec_4_form_idx[vec_i]);
					omp_unset_lock(&lock);
				}
			}
			std::cout << "cost 4" << std::endl;
			std::vector<std::vector<int>>i_vec(pre_vec_size);
			std::vector<std::vector<double>>vec_heat_density(pre_vec_size);
			std::cout << pre_vec_size << std::endl;
			std::cout << vec_4_paths_bridge_local.size() << std::endl;
			std::cout << vec_4_path_isolate_ends_local.size() << std::endl;
			std::cout << vec_4_curve_apts_bridge_local.size() << std::endl;
			std::cout << vec_4_line_scalar_fields_bridge_local.size() << std::endl;
			std::cout << vec_4_paths_length_local.size() << std::endl;
			std::cout << vec_4_paths_length_origin_local.size() << std::endl;
			std::cout << vec_4_vec_i_local.size() << std::endl;
			std::cout << vec_4_is_continue_local.size() << std::endl;
			std::cout << vec_4_form_idx_local.size() << std::endl;
			for (vec_i = 0; vec_i < last_loop_candidates; ++vec_i)
			{
				if (!vec_4_is_continue[vec_i])
				{	
					vec_4_paths_bridge_local.push_back(vec_4_paths_bridge[vec_i]);
					vec_4_path_isolate_ends_local.push_back(vec_4_path_isolate_ends[vec_i]);
					vec_4_curve_apts_bridge_local.push_back(vec_4_curve_apt_bridge[vec_i]);
					vec_4_line_scalar_fields_bridge_local.push_back(vec_4_line_scalar_fields_bridge[vec_i]);
					vec_4_paths_length_local.push_back(vec_4_paths_length[vec_i]);
					vec_4_paths_length_origin_local.push_back(vec_4_paths_length_origin[vec_i]);
					vec_4_vec_i_local.push_back(vec_i);
					//here not -1
					vec_4_is_continue_local.push_back(false);
					vec_4_form_idx_local.push_back(vec_4_form_idx[vec_i]);
				}
			}
			std::cout << "cost 5" << std::endl;

			for (vec_i = 0; vec_i < vec_4_paths_bridge_local.size(); ++vec_i)
			{	
				int i_i = vec_4_vec_i_local[vec_i];
				double heat_den = vec_4_paths_length_local[vec_i];
				auto insert_idx = std::distance(vec_heat_density[i_i].begin(),
					std::lower_bound(vec_heat_density[i_i].begin(),
						vec_heat_density[i_i].end(), heat_den));
				vec_heat_density[i_i].insert(vec_heat_density[i_i].begin() + insert_idx, heat_den);
				i_vec[i_i].insert(i_vec[i_i].begin() + insert_idx, vec_i);
			}
			std::cout << "cost 5.5" << std::endl;
			std::vector<int>extract_idx;
			int i_vec_i = 0;
			for (vec_i = 0; vec_i < vec_4_paths_bridge_local.size(); ++vec_i)
			{	
				while (i_vec[i_vec_i].empty())
				{
					i_vec_i = (i_vec_i + 1) % i_vec.size();
				}
				extract_idx.push_back(i_vec[i_vec_i].front());
				i_vec[i_vec_i].erase(i_vec[i_vec_i].begin());
				i_vec_i = (i_vec_i + 1) % i_vec.size();
			}
			std::cout << "cost 6" << std::endl;
			std::vector<int>extract_idx_;
			std::vector<double>heat_density_;
			for (vec_i = 0; vec_i < extract_idx.size() / 2; ++vec_i)
			{
				int i_i = extract_idx[vec_i];
				double heat_den = vec_4_paths_length_origin[i_i] > 0 ? ((vec_4_paths_length[i_i]) / vec_4_paths_length_origin[i_i]) : 0;
				auto insert_idx = std::distance(heat_density_.begin(),
					std::lower_bound(heat_density_.begin(), heat_density_.end(), heat_den));
				heat_density_.insert(heat_density_.begin() + insert_idx, heat_den);
				extract_idx_.insert(extract_idx_.begin() + insert_idx, i_i);

			}
			pre_vec_size = vec_4_paths_bridge.size();

			vec_4_paths_bridge.clear();
			vec_4_path_isolate_ends.clear();
			vec_4_curve_apt_bridge.clear();
			vec_4_line_scalar_fields_bridge.clear();
			vec_4_paths_length.clear();
			vec_4_paths_length_origin.clear();
			vec_4_vec_i.clear();
			vec_4_is_continue.clear();
			vec_4_form_idx.clear();
			for (vec_i = 0; vec_i < std::min(each_turn_candidate, int(extract_idx_.size())); ++vec_i)
			{
				vec_4_paths_bridge.push_back(vec_4_paths_bridge_local[extract_idx_[vec_i]]);
				vec_4_path_isolate_ends.push_back(vec_4_path_isolate_ends_local[extract_idx_[vec_i]]);
				vec_4_curve_apt_bridge.push_back(vec_4_curve_apts_bridge_local[extract_idx_[vec_i]]);
				vec_4_line_scalar_fields_bridge.push_back(vec_4_line_scalar_fields_bridge_local[extract_idx_[vec_i]]);
				vec_4_paths_length.push_back(vec_4_paths_length_local[extract_idx_[vec_i]]);
				vec_4_paths_length_origin.push_back(vec_4_paths_length_origin_local[extract_idx_[vec_i]]);
				vec_4_vec_i.push_back(vec_4_vec_i_local[extract_idx_[vec_i]]);
				vec_4_is_continue.push_back(vec_4_is_continue_local[extract_idx_[vec_i]]);
				vec_4_form_idx.push_back(vec_4_form_idx_local[extract_idx_[vec_i]]);
			}
			is_continue_num = 0;
			for (vec_i = 0; vec_i < vec_4_is_continue.size(); ++vec_i)
			{
				if (vec_4_is_continue[vec_i])
				{
					is_continue_num++;
				}
			}
			last_loop_candidates = vec_4_paths_bridge.size();
			std::cout << "loop out" << std::endl;
		}
		////std::cout << "in" << std::endl;
		std::vector<std::string>bridges_str_copy;
		std::vector<std::vector<std::vector<int>>>bridges_copy;
		std::vector<std::vector<std::vector<Eigen::Vector3d>>>bridges_smooth_copy;
		std::vector<int>bridges_res_idx(vec_4_paths.size(), 0);
		for (int i = 0; i < vec_4_paths_bridge.size(); ++i)
		{
			bridges_copy.push_back(vec_4_paths_bridge[i]);
			auto idx = vec_4_form_idx[i];
			bridges_str_copy.push_back(std::string("c") + std::to_string(idx)
				+ std::string("b") + std::to_string(bridges_res_idx[idx]));
			bridges_res_idx[idx]++;
			bridges_smooth_copy.push_back(std::vector < std::vector<Eigen::Vector3d>>());
		}
		bridges_ = bridges_copy;
		vec_4_paths_bridge_origin = bridges_copy;
		bridges_str_ = bridges_str_copy;
		bridges_smooth = bridges_smooth_copy;
		omp_destroy_lock(&lock);
		////std::cout << "out" << std::endl;
	}

	void BackProject2Mesh(std::vector<std::vector<Eigen::Vector3d>>& smooth_path,
		double error_magnitude,bool is_bridge,int curve_idx,bool modify_field=false)
	{	
		Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic>mat(this->size_of_vertices(), 3);
		for (int i=0;i< this->size_of_vertices();++i)
		{
			auto v = index_to_vertex_map[i]->point();
			mat.row(index_to_vertex_map[i]->id()) = Eigen::Vector3d(v.x(), v.y(), v.z());
		}
		typedef nanoflann::KDTreeEigenMatrixAdaptor<Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic>>polygon_kd_tree_t;
		polygon_kd_tree_t mat_idx(3, mat, 10);
		mat_idx.index->buildIndex();

		const std::size_t num_results = 1;
		std::vector<std::vector<double>>out_dists(smooth_path.size());
		std::vector<std::vector<size_t>>smooth_project_idx(smooth_path.size());
		for (int i = 0; i < smooth_path.size(); ++i)
		{
			out_dists[i] = std::vector<double>(smooth_path[i].size());
			smooth_project_idx[i] = std::vector<size_t>(smooth_path[i].size());
		}
		for (int i = 0; i < smooth_path.size(); ++i)
		{
			for (int j = 0; j < smooth_path[i].size(); ++j)
			{
				nanoflann::KNNResultSet<double>resultSet(num_results);
				resultSet.init(smooth_project_idx[i].data()+j, out_dists[i].data()+j);
				mat_idx.index->findNeighbors(resultSet, smooth_path[i][j].data(), nanoflann::SearchParams(128));
				out_dists[i][j] = std::sqrt(out_dists[i][j]);
				if (out_dists[i][j] > error_magnitude)
				{
					smooth_project_idx[i][j] = -1;
				}
			}
		}
		if (modify_field)
		{	
			std::vector<double>line_scalar_field(this->size_of_vertices(), 0);
			if (is_bridge)
			{	
				//vec_4_paths_bridge[curve_idx] = smooth_project_idx;
				vec_4_paths_bridge[curve_idx].clear();
				for (int i = 0; i < smooth_project_idx.size(); ++i)
				{
					vec_4_paths_bridge[curve_idx].push_back(std::vector<int>(smooth_project_idx[i].begin(), smooth_project_idx[i].end()));
				}
				compute_heat_val(vec_4_paths_bridge[curve_idx], line_scalar_field);
				vec_4_scalar_field_bridge[curve_idx] = line_scalar_field;
				std::vector<std::vector<int>>curve_apts = vec_4_curve_apt_bridge[curve_idx];
				for (int i = 0; i < vec_4_curve_apt_bridge[curve_idx].size(); ++i)
				{
					vec_4_curve_apt_bridge[curve_idx][i].clear();
					for (int j = 0; j < vec_4_paths_bridge[curve_idx][i].size(); ++j)
					{	
						if (std::find(curve_apts[i].begin(),
							curve_apts[i].end(),
							vec_4_paths_bridge[curve_idx][i][j]) != curve_apts[i].end())
						{
							vec_4_curve_apt_bridge[curve_idx][i].push_back(vec_4_paths_bridge[curve_idx][i][j]);
						}
					}
				}
			}
			else
			{	
				//vec_4_paths[curve_idx] = smooth_project_idx;
				vec_4_paths[curve_idx].clear();
				for (int i = 0; i < smooth_project_idx.size(); ++i)
				{
					vec_4_paths[curve_idx].push_back(std::vector<int>(smooth_project_idx[i].begin(), smooth_project_idx[i].end()));
				}
				compute_heat_val(vec_4_paths[curve_idx], line_scalar_field);
				vec_4_scalar_field[curve_idx] = line_scalar_field;
				/*
				std::vector<std::vector<int>>curve_apts = vec_4_curve_apt[curve_idx];
				for (int i = 0; i < vec_4_curve_apt[curve_idx].size(); ++i)
				{
					vec_4_curve_apt[curve_idx][i].clear();
					for (int j = 0; j < vec_4_paths[curve_idx][i].size(); ++j)
					{
						if (std::find(curve_apts[i].begin(),
							curve_apts[i].end(),
							vec_4_paths[curve_idx][i][j]) != curve_apts[i].end())
						{
							vec_4_curve_apt[curve_idx][i].push_back(vec_4_paths[curve_idx][i][j]);
						}
					}
				}
				*/
			}
		}
	}

	void BackProject2Mesh(std::vector<std::vector<Eigen::Vector3d>>& smooth_path,
		double error_magnitude, std::vector<double>&line_scalar_field,std::vector<std::vector<int>>&res_path)
	{
		Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic>mat(this->size_of_vertices(), 3);
		for (int i = 0; i < this->size_of_vertices(); ++i)
		{
			auto v = index_to_vertex_map[i]->point();
			mat.row(index_to_vertex_map[i]->id()) = Eigen::Vector3d(v.x(), v.y(), v.z());
		}
		typedef nanoflann::KDTreeEigenMatrixAdaptor<Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic>>polygon_kd_tree_t;
		polygon_kd_tree_t mat_idx(3, mat, 10);
		mat_idx.index->buildIndex();

		const std::size_t num_results = 1;
		std::vector<std::vector<double>>out_dists(smooth_path.size());
		std::vector<std::vector<size_t>>smooth_project_idx(smooth_path.size());
		for (int i = 0; i < smooth_path.size(); ++i)
		{
			out_dists[i] = std::vector<double>(smooth_path[i].size());
			smooth_project_idx[i] = std::vector<size_t>(smooth_path[i].size());
		}
		for (int i = 0; i < smooth_path.size(); ++i)
		{
			for (int j = 0; j < smooth_path[i].size(); ++j)
			{
				nanoflann::KNNResultSet<double>resultSet(num_results);
				resultSet.init(smooth_project_idx[i].data() + j, out_dists[i].data() + j);
				mat_idx.index->findNeighbors(resultSet, smooth_path[i][j].data(), nanoflann::SearchParams(128));
				out_dists[i][j] = std::sqrt(out_dists[i][j]);
				if (out_dists[i][j] > error_magnitude)
				{
					smooth_project_idx[i][j] = -1;
				}
			}
		}
		//std::vector<double>line_scalar_field(this->size_of_vertices(), 0);
		std::vector<std::vector<int>>path_idx;
		for (int i = 0; i < smooth_project_idx.size(); ++i)
		{
			path_idx.push_back(std::vector<int>(smooth_project_idx[i].begin(), smooth_project_idx[i].end()));
		}
		compute_heat_val(path_idx, line_scalar_field);
		res_path = path_idx;
		//vec_4_scalar_field_bridge[curve_idx] = line_scalar_field;
	}

	void BackProject2Mesh(std::vector<std::vector<Eigen::Vector3d>>& smooth_path,
		std::vector<std::vector<int>>&smooth_project_idx_, double error_magnitude)
	{
		Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic>mat(this->size_of_vertices(), 3);
		for (int i = 0; i < this->size_of_vertices(); ++i)
		{
			auto v = index_to_vertex_map[i]->point();
			mat.row(index_to_vertex_map[i]->id()) = Eigen::Vector3d(v.x(), v.y(), v.z());
		}
		typedef nanoflann::KDTreeEigenMatrixAdaptor<Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic>>polygon_kd_tree_t;
		polygon_kd_tree_t mat_idx(3, mat, 10);
		mat_idx.index->buildIndex();

		const std::size_t num_results = 1;
		std::vector<std::vector<double>>out_dists(smooth_path.size());
		std::vector<std::vector<size_t>>smooth_project_idx(smooth_path.size());
		smooth_project_idx_ = std::vector<std::vector<int>>(smooth_path.size());
		for (int i = 0; i < smooth_path.size(); ++i)
		{
			out_dists[i] = std::vector<double>(smooth_path[i].size());
			smooth_project_idx[i] = std::vector<size_t>(smooth_path[i].size());
			smooth_project_idx_[i] = std::vector<int>(smooth_path[i].size());
		}
		for (int i = 0; i < smooth_path.size(); ++i)
		{
			for (int j = 0; j < smooth_path[i].size(); ++j)
			{
				nanoflann::KNNResultSet<double>resultSet(num_results);
				resultSet.init(smooth_project_idx[i].data() + j, out_dists[i].data() + j);
				mat_idx.index->findNeighbors(resultSet, smooth_path[i][j].data(), nanoflann::SearchParams(128));
				out_dists[i][j] = std::sqrt(out_dists[i][j]);
				smooth_project_idx_[i][j] = (out_dists[i][j] > error_magnitude) ? -1 : smooth_project_idx[i][j];
			}
		}
	}

	void attachToNearestLine(std::vector<std::vector<Eigen::Vector3d>>& smooth_path,
		std::vector<std::vector<int>>& smooth_project_idx,
		std::vector<std::pair<int, int>>& overlap_pts,
		std::vector<int>&res_geodesic_path)
	{
		overlap_pts = std::vector<std::pair<int, int>>(2);
		double min_dist = std::numeric_limits<double>::max();
		int cur_min_end = -1;
		int cur_min_idx = -1;
		std::vector<int>geodesic_path;
		{
			std::vector<boost::graph_traits< graph_t >::vertex_descriptor> p0, p1;
			std::vector<double> d0, d1;

			dijkstra_search(p0, d0, smooth_project_idx.back().front(), origin_g);
			dijkstra_search(p1, d1, smooth_project_idx.back().back(), origin_g);
			for (int i = 0; i < smooth_project_idx.size()-1; ++i)
			{
				for (int j = 0; j < smooth_project_idx[i].size(); ++j)
				{
					if (smooth_project_idx[i][j] < 0)
					{
						continue;
					}
					if (d0[smooth_project_idx[i][j]] < min_dist)
					{
						min_dist = d0[smooth_project_idx[i][j]];
						cur_min_end = 0;
						cur_min_idx = smooth_project_idx[i][j];
						overlap_pts.front().first = i;
						overlap_pts.front().second = j;
					}
					if (d1[smooth_project_idx[i][j]] < min_dist)
					{
						min_dist = d1[smooth_project_idx[i][j]];
						cur_min_end = 1;
						cur_min_idx = smooth_project_idx[i][j];
						overlap_pts.front().first = i;
						overlap_pts.front().second = j;
					}
				}
			}


			if (cur_min_end == 0)
			{
				geodesic_path.clear();
				int idx = cur_min_idx;
				while (idx != smooth_project_idx.back().front())
				{
					geodesic_path.push_back(idx);
					idx = p0[idx];
				}
			}
			else if (cur_min_end == 1)
			{
				geodesic_path.clear();
				int idx = cur_min_idx;
				while (idx != smooth_project_idx.back().back())
				{
					geodesic_path.push_back(idx);
					idx = p1[idx];
				}
			}
		}
		res_geodesic_path = geodesic_path;
		/*
		////std::cout << "wrong::" << cur_min_idx << std::endl;
		std::vector<int>res_path = curve_add;
		if (cur_min_end == 0)
		{
			res_path.insert(res_path.begin(), geodesic_path.begin(), geodesic_path.end());
		}
		else if (cur_min_end == 1)
		{
			res_path.insert(res_path.end(), geodesic_path.rbegin(), geodesic_path.rend());
		}
		*/
		overlap_pts.back().first = smooth_project_idx.size();
		overlap_pts.back().second = (cur_min_end==0)?0: smooth_project_idx.back().size()-1;
		
	}

	void ComputeBridgeRes(std::vector<std::vector<std::vector<int>>>&bridges,
		std::vector<int>&select_pts)
	{
		vec_4_paths_bridge = bridges;
		vec_4_scalar_field_bridge = std::vector<std::vector<double>>(vec_4_paths_bridge.size());
		//vec_4_scalar_field_bridge.clear();
		#pragma omp parallel for
		for (int i = 0; i < vec_4_paths_bridge.size(); ++i)
		{	
			std::vector<double>scalar_fields;
			compute_heat_val(vec_4_paths_bridge[i], scalar_fields);
			vec_4_scalar_field_bridge[i]=scalar_fields;
		}
		vec_4_curve_apt_bridge = std::vector<std::vector<std::vector<int>>>(vec_4_paths_bridge.size());

		for (int i = 0; i < vec_4_paths_bridge.size(); ++i)
		{
			vec_4_curve_apt_bridge[i] = std::vector<std::vector<int>>();
			for (int j = 0; j < vec_4_paths_bridge[i].size(); ++j)
			{
				vec_4_curve_apt_bridge[i].push_back(std::vector<int>());
			}
		}
		int i = 0; int j = 0; int k = 0;
		#pragma omp parallel for private(i, j, k) collapse(3)
		for (i = 0; i < vec_4_paths_bridge.size(); ++i)
		{
			for (j = 0; j < vec_4_paths_bridge[i].size(); ++j)
			{
				for (k = 0; k < vec_4_paths_bridge[i][j].size(); ++k)
				{
					auto path_pt = vec_4_paths_bridge[i][j][k];
					if (std::find(select_pts.begin(), select_pts.end(), path_pt)
						!= select_pts.end())
					{
						vec_4_curve_apt_bridge[i][j].push_back(path_pt);
					}
				}
			}
		}
	}


	void connect_apts(segIO& seg_info,std::vector<std::vector<Eigen::RowVector3d>>& feature_vector_fields,
		std::vector<std::vector<double>>& feature_scalar_fields,
		int select_curve_candidate_idx, int pt_idx1, int pt_idx2,
		std::vector<std::vector<std::vector<int>>>&paths_,double feature_modifier)
	{
		auto paths = vec_4_paths[select_curve_candidate_idx];
		auto line_vector_field = vec_4_vector_field[select_curve_candidate_idx];
		auto line_scalar_field = vec_4_scalar_field[select_curve_candidate_idx];
		auto curve_apts = vec_4_curve_apt[select_curve_candidate_idx];

		//or curve_start?
		bool is_pt1_start = false;
		bool is_pt1_end = false;
		int pt1_path_idx = -1;
		bool is_pt2_start = false;
		bool is_pt2_end = false;
		int pt2_path_idx = -1;
		for (int i = 0; i < paths.size(); ++i)
		{
			if (paths[i].front() == pt_idx1)
			{
				is_pt1_start = true;
				pt1_path_idx = i;
				break;
			}
			if (paths[i].front() == pt_idx2)
			{
				is_pt2_start = true;
				pt2_path_idx = i;
				break;
			}
			if (paths[i].back() == pt_idx1)
			{
				is_pt1_end = true;
				pt1_path_idx = i;
				break;
			}
			if (paths[i].back() == pt_idx2)
			{
				is_pt2_end = true;
				pt2_path_idx = i;
				break;
			}
		}
		int start_pt_idx = -1;
		int end_pt_idx;
		bool split = false;
		//////std::cout << "there" << std::endl;
		start_pt_idx = pt_idx1;
		end_pt_idx = pt_idx2;
		std::vector<int>shortest_path;
		double shortest_dist = std::numeric_limits<double>::max();
		for (int f_i = 0; f_i < feature_vector_fields.size(); ++f_i)
		{	
			graph_t distorsion_g;
			build_paths(seg_info, feature_vector_fields[f_i], feature_scalar_fields[f_i],
				line_vector_field, line_scalar_field, distorsion_g,feature_modifier);
			std::vector<boost::graph_traits< graph_t >::vertex_descriptor> p;
			std::vector<double> d;
			dijkstra_search(p, d, start_pt_idx, distorsion_g);
			if (d[end_pt_idx] >= shortest_dist)
			{
				continue;
			}
			std::vector<int>geodesic_path;
			int idx = end_pt_idx;
			while (idx != start_pt_idx)
			{
				geodesic_path.push_back(idx);
				idx = p[idx];
			}
			geodesic_path.push_back(start_pt_idx);
			shortest_path = geodesic_path;
		}
		//////std::cout << "there" << std::endl;
		//////std::cout << shortest_path.size() << std::endl;
		if (is_pt1_start)
		{
			paths[pt1_path_idx].insert(paths[pt1_path_idx].begin(), shortest_path.begin(), shortest_path.end()-1);
			curve_apts[pt1_path_idx].insert(curve_apts[pt1_path_idx].begin(), shortest_path.front());
		}
		else if (is_pt1_end)
		{
			paths[pt1_path_idx].insert(paths[pt1_path_idx].end(), shortest_path.rbegin() + 1, shortest_path.rend());
			curve_apts[pt1_path_idx].push_back(paths[pt1_path_idx].front());
		}
		else if (is_pt2_start)
		{
			paths[pt2_path_idx].insert(paths[pt2_path_idx].begin(), shortest_path.rbegin(), shortest_path.rend()-1);
			curve_apts[pt2_path_idx].insert(curve_apts[pt2_path_idx].begin(), shortest_path.back());
		}
		else if (is_pt2_end)
		{
			paths[pt2_path_idx].insert(paths[pt2_path_idx].end(), shortest_path.begin() + 1, shortest_path.end());
			curve_apts[pt2_path_idx].push_back(paths[pt2_path_idx].back());
		}
		else
		{
			paths.push_back(shortest_path);
			curve_apts.push_back(std::vector<int>());
			curve_apts.back().push_back(shortest_path.front());
			curve_apts.back().push_back(shortest_path.back());
		}
		//////std::cout << "there" << std::endl;
		//update fields
		vec_4_paths[select_curve_candidate_idx] = paths;
		compute_heat_val(paths, line_scalar_field);
		vec_4_scalar_field[select_curve_candidate_idx] = line_scalar_field;
		vec_4_curve_apt[select_curve_candidate_idx] = curve_apts;
		paths_ = vec_4_paths;
	}


	void modify_curve(segIO& seg,
		std::vector<std::vector<Eigen::RowVector3d>>& feature_vector_fields,
		std::vector<std::vector<double>>& feature_scalar_fields,
		bool is_bridge, int curve_idx, std::vector<int>&curve_modify_part,
		std::vector<std::vector<int>>& paths,double feature_modifier)
	{	
		////std::cout << "act A" << std::endl;
		////std::cout << curve_modify_part.size() << std::endl;
		/*
		auto path = is_bridge ? vec_4_paths_bridge[curve_idx] : vec_4_paths[curve_idx];
		auto line_vector_field = vec_4_vector_field.front();
		auto line_scalar_field = is_bridge ? vec_4_scalar_field_bridge[curve_idx] : vec_4_scalar_field[curve_idx];
		auto curve_apts = is_bridge ? vec_4_curve_apt_bridge[curve_idx] : vec_4_curve_apt[curve_idx];
		//here find out which path belong to this.
		double min_dist = std::numeric_limits<double>::max();
		//maybe pt0_idx pt1_idx wrong?
		int overlap_curve_idx = curve_modify_part.front();
		int pt0_idx = path[overlap_curve_idx][curve_modify_part[1]];
		int pt1_idx = path[overlap_curve_idx][curve_modify_part[2]];
		{
			std::vector<int>geodesic_path;
			for (int f_i = 0; f_i < feature_scalar_fields.size(); ++f_i)
			{	
				graph_t distorsion_g;
				build_paths(seg, feature_vector_fields[f_i], feature_scalar_fields[f_i],
					line_vector_field, line_scalar_field, distorsion_g,feature_modifier);
				std::vector<boost::graph_traits< graph_t >::vertex_descriptor> p;
				std::vector<double> d;

				dijkstra_search(p, d, pt0_idx, distorsion_g);
				if (d[pt1_idx] < min_dist)
				{	
					min_dist = d[pt1_idx];
					geodesic_path.clear();
					int idx = pt1_idx;
					while (idx != pt0_idx)
					{
						geodesic_path.push_back(idx);
						idx = p[idx];
					}
					geodesic_path.push_back(idx);
				}
			}
			auto find_iter0 = std::find(path[overlap_curve_idx].begin(),
				path[overlap_curve_idx].end(), pt0_idx);
			auto find_iter1 = std::find(path[overlap_curve_idx].begin(),
				path[overlap_curve_idx].end(), pt1_idx);
			auto id0 = std::distance(path[overlap_curve_idx].begin(), find_iter0);
			auto id1 = std::distance(path[overlap_curve_idx].begin(), find_iter1);
			if (id0 < id1)
			{
				path.push_back(std::vector<int>(geodesic_path.rbegin(), geodesic_path.rend()));
			}
			else
			{	
				path.push_back(std::vector<int>(geodesic_path.begin(), geodesic_path.end()));
			}
		}
		paths = path;
		*/
	}

	void append_curve_part(segIO& seg, std::vector<std::vector<Eigen::RowVector3d>>& feature_vector_fields, 
		std::vector<std::vector<double>>&feature_scalar_fields,std::vector<double>&line_scalar_field, 
		std::vector<Eigen::RowVector3d>&line_vector_field,int curve_start,int curve_end,
		std::vector<int>&res_path,double logi1_a,double logi1_b,double logi2_a,double logi2_b)
	{	
		std::vector<graph_t> vec_4_distorsion_g = std::vector<graph_t>(feature_vector_fields.size());
		std::vector<std::vector<boost::graph_traits<graph_t>::vertex_descriptor>>vec_4_p(feature_vector_fields.size());
		//std::vector<std::vector<double>>vec_4_d(feature_vector_fields.size());
		std::vector<double>vec_4_d(feature_vector_fields.size());
		std::vector<std::vector<int>>vec_4_shortest_path(feature_vector_fields.size());
		int f_i;
		#pragma omp parallel for
		for (f_i = 0; f_i < feature_vector_fields.size(); ++f_i)
		{
			graph_t distorsion_g;
			build_paths(seg, feature_vector_fields[f_i], feature_scalar_fields[f_i],
				line_vector_field, line_scalar_field, distorsion_g, logi1_a, logi1_b, logi2_a, logi2_b);
			vec_4_distorsion_g[f_i] = distorsion_g;
		}
		#pragma omp parallel for
		for (f_i = 0; f_i < feature_vector_fields.size(); ++f_i)
		{
			std::vector<boost::graph_traits< graph_t >::vertex_descriptor> p;
			std::vector<double> d;
			dijkstra_search(p, d, curve_start, vec_4_distorsion_g[f_i]);
			vec_4_p[f_i] = p;
			vec_4_d[f_i] = d[curve_end];
		}
		#pragma omp parallel for
		for (f_i = 0; f_i < feature_vector_fields.size(); ++f_i)
		{	
			std::vector<int>geodesic_path;
			int idx = curve_end;
			while (idx != curve_start)
			{
				geodesic_path.push_back(idx);
				idx = vec_4_p[f_i][idx];
			}
			geodesic_path.push_back(curve_start);
			vec_4_shortest_path[f_i] = geodesic_path;
		}
		int shortest_path_idx = std::distance(vec_4_d.begin(), std::min_element(vec_4_d.begin(), vec_4_d.end()));
		res_path = std::vector<int>(vec_4_shortest_path[shortest_path_idx].rbegin(), vec_4_shortest_path[shortest_path_idx].rend());
	}


	void add_curve(segIO& seg,
		std::vector<std::vector<Eigen::RowVector3d>>& feature_vector_fields,
		std::vector<std::vector<double>>& feature_scalar_fields,
		bool is_bridge, int curve_idx, std::vector<int>& curve_add,
		std::vector<std::vector<int>>& smooth_project_idx,
		std::vector<std::pair<int,int>>& overlap_pts)
	{	
		overlap_pts = std::vector<std::pair<int, int>>(2);
		auto path = is_bridge ? vec_4_paths_bridge[curve_idx] : vec_4_paths[curve_idx];
		auto line_vector_field = vec_4_vector_field.front();
		auto line_scalar_field = is_bridge ? vec_4_scalar_field_bridge[curve_idx] : vec_4_scalar_field[curve_idx];
		auto curve_apts = is_bridge ? vec_4_curve_apt_bridge[curve_idx] : vec_4_curve_apt[curve_idx];
		if (curve_add.empty())
		{
			return;
		}
		double min_dist = std::numeric_limits<double>::max();
		int cur_min_end = -1;
		int cur_min_idx = -1;
		std::vector<int>geodesic_path;
		{
			std::vector<boost::graph_traits< graph_t >::vertex_descriptor> p0, p1;
			std::vector<double> d0, d1;

			dijkstra_search(p0, d0, curve_add.front(), origin_g);
			dijkstra_search(p1, d1, curve_add.back(), origin_g);
			for (int i = 0; i < path.size(); ++i)
			{
				for (int j = 0; j < path[i].size(); ++j)
				{	
					if (path[i][j] < 0)
					{
						continue;
					}
					if (d0[path[i][j]] < min_dist)
					{
						min_dist = d0[path[i][j]];
						cur_min_end = 0;
						cur_min_idx = path[i][j];
						overlap_pts.front().first = i;
						overlap_pts.front().second = j;
					}
					if (d1[path[i][j]] < min_dist)
					{
						min_dist = d1[path[i][j]];
						cur_min_end = 1;
						cur_min_idx = path[i][j];
						overlap_pts.front().first = i;
						overlap_pts.front().second = j;
					}
				}
			}


			if (cur_min_end == 0)
			{
				geodesic_path.clear();
				int idx = cur_min_idx;
				while (idx != curve_add.front())
				{
					geodesic_path.push_back(idx);
					idx = p0[idx];
				}
				geodesic_path.push_back(idx);
			}
			else if (cur_min_end == 1)
			{
				geodesic_path.clear();
				int idx = cur_min_idx;
				while (idx != curve_add.back())
				{
					geodesic_path.push_back(idx);
					idx = p1[idx];
				}
				geodesic_path.push_back(idx);
			}
		}
		std::vector<int>res_path = curve_add;
		smooth_project_idx = std::vector < std::vector<int>>();
		if (cur_min_end == 0)
		{
			//res_path.insert(res_path.begin(), geodesic_path.begin(), geodesic_path.end());
			overlap_pts.back().first = path.size();
			overlap_pts.back().second = 0;
			smooth_project_idx.push_back(std::vector<int>(geodesic_path.begin(), geodesic_path.end()));
			//smooth_project_idx.back().insert(smooth_project_idx.back().end(), curve_add.begin() + 1, curve_add.end());
		}
		else if (cur_min_end == 1)
		{
			//res_path.insert(res_path.end(), geodesic_path.rbegin(), geodesic_path.rend());
			overlap_pts.back().first = path.size();
			overlap_pts.back().second = -1;
			smooth_project_idx.push_back(std::vector<int>(geodesic_path.begin(), geodesic_path.end()));
			//smooth_project_idx.back().insert(smooth_project_idx.back().end(), curve_add.rbegin() + 1, curve_add.rend());
		}
		path.push_back(res_path);
		curve_apts.push_back(std::vector<int>());
		curve_apts.back().push_back(res_path.front());
		curve_apts.back().push_back(res_path.back());
	}

	void curve_attach_to_curve(segIO& seg,
		std::vector<std::vector<Eigen::RowVector3d>>& feature_vector_fields,
		std::vector<std::vector<double>>& feature_scalar_fields,
		std::vector<double>&line_scalar_field,std::vector<Eigen::RowVector3d>&line_vector_field,
		std::vector<std::vector<int>>&path,
		std::vector<int>& insert_path,
		std::vector<int>& res, std::vector<int>& insert_idx, double logi1_a,double logi1_b,double logi2_a,double logi2_b)
	{	
		/*
		auto path = is_bridge ? vec_4_paths_bridge[curve_idx] : vec_4_paths[curve_idx];
		auto line_vector_field = vec_4_vector_field.front();
		auto line_scalar_field = is_bridge ? vec_4_scalar_field_bridge[curve_idx] : vec_4_scalar_field[curve_idx];
		*/
		//auto curve_apts = is_bridge ? vec_4_curve_apt_bridge[curve_idx] : vec_4_curve_apt[curve_idx];
		typedef CGAL::Heat_method_3::Surface_mesh_geodesic_distances_3<Polyhedron_3> Heat_method;
		boost::unordered_map<boost::graph_traits<Polyhedron_3>::vertex_descriptor, double>vertex_distance;
		Heat_method hm(*this);
		for (auto i : insert_path)
		{
			hm.add_source(index_to_vertex_map[i]);
		}
		hm.estimate_geodesic_distances(boost::make_assoc_property_map(vertex_distance));
		std::vector<double>dist_vec(vertex_distance.size());
		for (auto i : vertex_distance)
		{
			dist_vec[i.first->id()] = i.second;
		}

		double n_dist = std::numeric_limits<double>::max();
		int n_apt_idx_i, n_apt_idx_j;
		for (int i = 0; i < path.size(); ++i)
		{
			for (int j = 0; j < path[i].size(); ++j)
			{
				if (path[i][j] > -1 && dist_vec[path[i][j]] < n_dist)
				{
					n_dist = dist_vec[path[i][j]];
					n_apt_idx_i = i;
					n_apt_idx_j = j;
				}
			}
		}

		int start_apt_idx, end_apt_idx;
		int origin_curve_start_idx, origin_curve_end_idx;
		std::vector<boost::graph_traits< graph_t >::vertex_descriptor> p0, p1;
		std::vector<double> d0, d1;
		dijkstra_search(p0, d0, insert_path.front(), origin_g);
		dijkstra_search(p1, d1, insert_path.back(), origin_g);
		n_dist = std::numeric_limits<double>::max();
		std::vector<int>start_2_mid_path;
		std::vector<int>mid_2_end_path;

		for (int i = 0; i < path[n_apt_idx_i].size(); ++i)
		{
			if (d0[path[n_apt_idx_i][i]] < n_dist)
			{
				n_dist = d0[path[n_apt_idx_i][i]];
				origin_curve_start_idx = i;
			}
		}
		n_dist = std::numeric_limits<double>::max();
		for (int i = 0; i < path[n_apt_idx_i].size(); ++i)
		{
			if (d1[path[n_apt_idx_i][i]] < n_dist)
			{
				n_dist = d1[path[n_apt_idx_i][i]];
				origin_curve_end_idx = i;
			}
		}

		////std::cout << origin_curve_start_idx << " " << origin_curve_end_idx << std::endl;
		int pt_start = path[n_apt_idx_i][origin_curve_start_idx];
		int pt_end = path[n_apt_idx_i][origin_curve_end_idx];


		//need copy here.
		compute_heat_val(path, line_scalar_field);
		double dist = std::numeric_limits<double>::max();
		for (int f_i = 0; f_i < feature_vector_fields.size(); ++f_i)
		{
			graph_t distorsion_g;
			build_paths(seg, feature_vector_fields[f_i], feature_scalar_fields[f_i],
				line_vector_field, line_scalar_field, distorsion_g, logi1_a,logi1_b,logi2_a,logi2_b);
			std::vector<boost::graph_traits< graph_t >::vertex_descriptor> p;
			std::vector<double> d;
			dijkstra_search(p, d, insert_path.front(), distorsion_g);
			if (d[pt_start] < dist)
			{
				dist = d[pt_start];
				int idx = pt_start;
				start_2_mid_path.clear();
				while (idx != insert_path.front())
				{
					start_2_mid_path.push_back(idx);
					idx = p[idx];
				}
			}
		}
		path.push_back(start_2_mid_path);
		path.push_back(insert_path);
		compute_heat_val(path, line_scalar_field);
		dist = std::numeric_limits<double>::max();

		for (int f_i = 0; f_i < feature_vector_fields.size(); ++f_i)
		{
			graph_t distorsion_g;
			build_paths(seg, feature_vector_fields[f_i], feature_scalar_fields[f_i],
				line_vector_field, line_scalar_field, distorsion_g, logi1_a, logi1_b, logi2_a, logi2_b);
			std::vector<boost::graph_traits< graph_t >::vertex_descriptor> p;
			std::vector<double> d;
			dijkstra_search(p, d, insert_path.back(), distorsion_g);
			if (d[pt_end] < dist)
			{
				dist = d[pt_end];
				int idx = pt_end;
				mid_2_end_path.clear();
				while (idx != insert_path.back())
				{
					mid_2_end_path.push_back(idx);
					idx = p[idx];
				}
			}
		}
		path.erase(path.end() - 2, path.end());


		std::vector<int>res_path = start_2_mid_path;
		res_path.insert(res_path.end(), insert_path.begin(), insert_path.end());
		res_path.insert(res_path.end(), mid_2_end_path.rbegin(), mid_2_end_path.rend());
		insert_idx = std::vector<int>();
		insert_idx.push_back(n_apt_idx_i);
		insert_idx.push_back(origin_curve_start_idx);
		insert_idx.push_back(origin_curve_end_idx);
		res = res_path;
	}

	void curve_attach_to_curve(segIO& seg,
		std::vector<std::vector<Eigen::RowVector3d>>& feature_vector_fields,
		std::vector<std::vector<double>>& feature_scalar_fields,
		bool is_bridge, int curve_idx, std::vector<int>& insert_path,
		std::vector<int>&res,std::vector<int>&insert_idx,
		double logi1_a,double logi1_b,double logi2_a,double logi2_b)
	{	
		auto path = is_bridge ? vec_4_paths_bridge[curve_idx] : vec_4_paths[curve_idx];
		auto line_vector_field = vec_4_vector_field.front();
		auto line_scalar_field = is_bridge ? vec_4_scalar_field_bridge[curve_idx] : vec_4_scalar_field[curve_idx];
		auto curve_apts = is_bridge ? vec_4_curve_apt_bridge[curve_idx] : vec_4_curve_apt[curve_idx];
		typedef CGAL::Heat_method_3::Surface_mesh_geodesic_distances_3<Polyhedron_3> Heat_method;
		boost::unordered_map<boost::graph_traits<Polyhedron_3>::vertex_descriptor, double>vertex_distance;
		Heat_method hm(*this);
		for (auto i : insert_path)
		{
			hm.add_source(index_to_vertex_map[i]);
		}
		hm.estimate_geodesic_distances(boost::make_assoc_property_map(vertex_distance));
		std::vector<double>dist_vec(vertex_distance.size());
		for (auto i : vertex_distance)
		{
			dist_vec[i.first->id()] = i.second;
		}

		double n_dist = std::numeric_limits<double>::max();
		int n_apt_idx_i, n_apt_idx_j;
		for (int i = 0; i < path.size(); ++i)
		{
			for (int j = 0; j < path[i].size(); ++j)
			{
				if (path[i][j]>-1&&dist_vec[path[i][j]] < n_dist)
				{
					n_dist = dist_vec[path[i][j]];
					n_apt_idx_i = i;
					n_apt_idx_j = j;
				}
			}
		}

		int start_apt_idx, end_apt_idx;
		int origin_curve_start_idx, origin_curve_end_idx;
		std::vector<boost::graph_traits< graph_t >::vertex_descriptor> p0, p1;
		std::vector<double> d0, d1;
		dijkstra_search(p0, d0, insert_path.front(), origin_g);
		dijkstra_search(p1, d1, insert_path.back(), origin_g);
		n_dist = std::numeric_limits<double>::max();
		std::vector<int>start_2_mid_path;
		std::vector<int>mid_2_end_path;

		for (int i = 0; i < path[n_apt_idx_i].size(); ++i)
		{
			if (d0[path[n_apt_idx_i][i]] < n_dist)
			{
				n_dist = d0[path[n_apt_idx_i][i]];
				origin_curve_start_idx = i;
			}
		}
		n_dist = std::numeric_limits<double>::max();
		for (int i = 0; i < path[n_apt_idx_i].size(); ++i)
		{
			if (d1[path[n_apt_idx_i][i]] < n_dist)
			{
				n_dist = d1[path[n_apt_idx_i][i]];
				origin_curve_end_idx = i;
			}
		}

		////std::cout << origin_curve_start_idx << " " << origin_curve_end_idx << std::endl;
		int pt_start = path[n_apt_idx_i][origin_curve_start_idx];
		int pt_end = path[n_apt_idx_i][origin_curve_end_idx];
		

		//need copy here.
		compute_heat_val(path, line_scalar_field);
		double dist = std::numeric_limits<double>::max();
		for (int f_i = 0; f_i < feature_vector_fields.size(); ++f_i)
		{
			graph_t distorsion_g;
			build_paths(seg, feature_vector_fields[f_i], feature_scalar_fields[f_i],
				line_vector_field, line_scalar_field, distorsion_g, logi1_a, logi1_b, logi2_a, logi2_b);
			std::vector<boost::graph_traits< graph_t >::vertex_descriptor> p;
			std::vector<double> d;
			dijkstra_search(p, d, insert_path.front(), distorsion_g);
			if (d[pt_start] < dist)
			{	
				dist = d[pt_start];
				int idx = pt_start;
				start_2_mid_path.clear();
				while (idx != insert_path.front())
				{
					start_2_mid_path.push_back(idx);
					idx = p[idx];
				}
			}
		}
		path.push_back(start_2_mid_path);
		path.push_back(insert_path);
		compute_heat_val(path, line_scalar_field);
		dist = std::numeric_limits<double>::max();

		for (int f_i = 0; f_i < feature_vector_fields.size(); ++f_i)
		{
			graph_t distorsion_g;
			build_paths(seg, feature_vector_fields[f_i], feature_scalar_fields[f_i],
				line_vector_field, line_scalar_field, distorsion_g, logi1_a, logi1_b, logi2_a, logi2_b);
			std::vector<boost::graph_traits< graph_t >::vertex_descriptor> p;
			std::vector<double> d;
			dijkstra_search(p, d, insert_path.back(), distorsion_g);
			if (d[pt_end] < dist)
			{
				dist = d[pt_end];
				int idx = pt_end;
				mid_2_end_path.clear();
				while (idx != insert_path.back())
				{
					mid_2_end_path.push_back(idx);
					idx = p[idx];
				}
			}
		}
		path.erase(path.end() - 2, path.end());


		std::vector<int>res_path = start_2_mid_path;
		res_path.insert(res_path.end(), insert_path.begin(), insert_path.end());
		res_path.insert(res_path.end(), mid_2_end_path.rbegin(), mid_2_end_path.rend());
		insert_idx = std::vector<int>();
		insert_idx.push_back(n_apt_idx_i);
		insert_idx.push_back(origin_curve_start_idx);
		insert_idx.push_back(origin_curve_end_idx);
		res = res_path;
	}


	void user_study_link_ends(std::vector<int>& cur_path, std::vector<int>& res_path)
	{
		std::vector<boost::graph_traits< graph_t >::vertex_descriptor> p;
		std::vector<double> d;
		std::vector<int>geodesic_path;
		dijkstra_search(p, d, cur_path.back(), origin_g);
		int idx = cur_path.front();
		while (idx != cur_path.back())
		{
			geodesic_path.push_back(idx);
			idx = p[idx];
		}
		res_path = cur_path;
		res_path.insert(res_path.end(), geodesic_path.rbegin(), geodesic_path.rend());
	}

	void user_study_connect_path(std::vector<std::vector<int>>& cur_path, std::vector<int>& add_path, std::vector<int>& res_path, std::vector<std::pair<int, int>>overlap_pts)
	{	
		std::vector<boost::graph_traits< graph_t >::vertex_descriptor> p0, p1;
		std::vector<double> d0, d1;
		//res_path.clear();
		std::vector<int>geodesic_path;
		dijkstra_search(p0, d0, add_path.front(), origin_g);
		dijkstra_search(p1, d1, add_path.back(), origin_g);

		int cur_path_idx = overlap_pts.front().first;
		int ctrl_pt_idx = overlap_pts.front().second;

		double min_geodesic_path = std::numeric_limits<double>::max();
		if (d0[cur_path[cur_path_idx][ctrl_pt_idx]] < min_geodesic_path)
		{
			min_geodesic_path = d0[cur_path[cur_path_idx][ctrl_pt_idx]];
			geodesic_path.clear();
			res_path.clear();
			int idx = cur_path[cur_path_idx][ctrl_pt_idx];
			while (idx != add_path.front())
			{
				geodesic_path.push_back(idx);
				idx = p0[idx];
			}
			if (!geodesic_path.empty())
			{
				geodesic_path.erase(geodesic_path.begin());
			}
			res_path.clear();
			res_path.insert(res_path.begin(), geodesic_path.begin(), geodesic_path.end());
			res_path.insert(res_path.end(), add_path.begin(), add_path.end());
			overlap_pts.push_back(std::pair<int, int>(cur_path.size(),0));
		}
		if (d1[cur_path[cur_path_idx][ctrl_pt_idx]] < min_geodesic_path)
		{
			min_geodesic_path = d1[cur_path[cur_path_idx][ctrl_pt_idx]];
			geodesic_path.clear();
			res_path.clear();
			int idx = cur_path[cur_path_idx][ctrl_pt_idx];
			while (idx != add_path.back())
			{
				geodesic_path.push_back(idx);
				idx = p1[idx];
			}
			if (!geodesic_path.empty())
			{
				geodesic_path.erase(geodesic_path.begin());
			}
			res_path.clear();
			res_path.insert(res_path.begin(), geodesic_path.begin(), geodesic_path.end());
			res_path.insert(res_path.end(), add_path.rbegin(), add_path.rend());
			overlap_pts.push_back(std::pair<int, int>(cur_path.size(), 0));
		}
	}

	void user_study_connect_path(std::vector<int>&cur_path,std::vector<int>&add_path,std::vector<int>&res_path,kLineLink &link)
	{
		std::vector<boost::graph_traits< graph_t >::vertex_descriptor> p0, p1;
		std::vector<double> d0, d1;
		//res_path.clear();
		std::vector<int>geodesic_path;
		dijkstra_search(p0, d0, add_path.front(), origin_g);
		dijkstra_search(p1, d1, add_path.back(), origin_g);
		double min_geodesic_path=std::numeric_limits<double>::max();
		if (d0[cur_path.front()] < min_geodesic_path)
		{	
			min_geodesic_path = d0[cur_path.front()];
			geodesic_path.clear();
			res_path.clear();
			int idx = cur_path.front();
			while (idx != add_path.front())
			{
				geodesic_path.push_back(idx);
				idx = p0[idx];
			}
			link = kLineLink::RADDPATH_RGEODESICPATH_CURPATH;
			geodesic_path.erase(geodesic_path.begin());
			res_path = cur_path;
			res_path.insert(res_path.begin(), geodesic_path.rbegin(), geodesic_path.rend());
			res_path.insert(res_path.begin(), add_path.rbegin(), add_path.rend());
		}
		if (d0[cur_path.back()] < min_geodesic_path)
		{	
			min_geodesic_path = d0[cur_path.back()];
			geodesic_path.clear();
			res_path.clear();
			int idx = cur_path.back();
			while (idx != add_path.front())
			{
				geodesic_path.push_back(idx);
				idx = p0[idx];
			}
			link = kLineLink::CURPATH_GEODESICPATH_ADDPATH;
			geodesic_path.erase(geodesic_path.begin());
			res_path = cur_path;
			res_path.insert(res_path.end(), geodesic_path.begin(), geodesic_path.end());
			res_path.insert(res_path.end(), add_path.begin(), add_path.end());
		}
		if (d1[cur_path.front()] < min_geodesic_path)
		{	
			min_geodesic_path = d1[cur_path.front()];
			geodesic_path.clear();
			res_path.clear();
			int idx = cur_path.front();
			while (idx != add_path.back())
			{
				geodesic_path.push_back(idx);
				idx = p1[idx];
			}
			link = kLineLink::ADDPATH_RGEODESICPATH_CURPATH;
			geodesic_path.erase(geodesic_path.begin());
			res_path = cur_path;
			res_path.insert(res_path.begin(), geodesic_path.rbegin(), geodesic_path.rend());
			res_path.insert(res_path.begin(), add_path.begin(), add_path.end());
		}
		if (d1[cur_path.back()] < min_geodesic_path)
		{	
			min_geodesic_path = d1[cur_path.back()];
			geodesic_path.clear();
			res_path.clear();
			int idx = cur_path.back();
			while (idx != add_path.back())
			{
				geodesic_path.push_back(idx);
				idx = p1[idx];
			}
			link = kLineLink::CURPATH_GEODESICPATH_RADDPATH;
			geodesic_path.erase(geodesic_path.begin());
			res_path = cur_path;
			res_path.insert(res_path.end(), geodesic_path.begin(), geodesic_path.end());
			res_path.insert(res_path.end(), add_path.rbegin(), add_path.rend());
		}
	}

	void compute_coveragence(std::vector<std::vector<std::vector<int>>>& paths,
							std::vector<std::vector<std::vector<int>>>& feature_paths_apt,
							std::vector<double>& coveragence,
							std::vector<std::vector<std::vector<int>>>& feature_paths,
							std::vector<std::vector<double>>&s_f,
							std::vector<std::vector<double>>&vec_sigma_field,
							std::vector<std::vector<double>>&vec_feature_field,
							std::vector<std::vector<double>>&vec_uncut_line_field,
							double  redundancy_weight)
	{
		vec_sigma_field = std::vector<std::vector<double>>(paths.size());
		vec_feature_field = std::vector<std::vector<double>>(paths.size());
		vec_uncut_line_field = std::vector<std::vector<double>>(paths.size());

		std::cout << "cpt 1" << std::endl;
		const double feature2path_weight = 0.8;
		coveragence = std::vector<double>(paths.size(),0);
		//std::vector<double> line_scalar_field(this->size_of_vertices(),0);
		std::vector<double> weight(this->size_of_vertices(), 1);
		typedef CGAL::Heat_method_3::Surface_mesh_geodesic_distances_3<Polyhedron_3> Heat_method;
		Heat_method hm(*this);
		std::vector<double>feature_distribution(this->size_of_vertices(),std::numeric_limits<double>::max());
		for (int i = 0; i < feature_distribution.size(); ++i)
		{
			for (int j = 0; j < s_f.size(); ++j)
			{
				feature_distribution[i] = std::min(feature_distribution[i], s_f[j][i]);
			}
		}
		double sigma = 4 * this->get_avg_edge_len();
		for (int i = 0; i < feature_distribution.size(); ++i)
		{
			feature_distribution[i] = normal_pdf(feature_distribution[i], sigma);
		}

		std::cout << "cpt 2" << std::endl;
		for (int i = 0; i < feature_paths_apt.size(); ++i)
		{	
			std::vector<double> line_scalar_field(this->size_of_vertices(), 0);
			std::vector<double> line_scalar_field_uncut(this->size_of_vertices(), 0);
			std::cout << "cpt 3" << std::endl;
			for (int j = 0; j < paths[i].size(); ++j)
			{
				for (int k = 0; k < paths[i][j].size(); ++k)
				{
					hm.add_source(index_to_vertex_map[paths[i][j][k]]);
				}
			}
			boost::unordered_map<boost::graph_traits<Polyhedron_3>::vertex_descriptor, double>vertex_distance_uncut;
			hm.estimate_geodesic_distances(boost::make_assoc_property_map(vertex_distance_uncut));
			hm.clear_sources();
			for (auto v : vertex_distance_uncut)
			{
				line_scalar_field_uncut[v.first->id()] = normal_pdf(v.second, sigma);
			}

			std::cout << "cpt 4" << std::endl;
			int cut_candidate_num = 0;
			std::vector<std::vector<int>>feature_path_candidate;
			for (int j = 0; j < feature_paths_apt[i].size(); ++j)
			{
				std::vector<int>apt_idx;
				apt_idx.push_back(0);
				std::cout << std::endl;
				for (int k = 1; k < feature_paths_apt[i][j].size(); ++k)
				{
					auto dist = std::distance(paths[i][j].begin() + apt_idx.back(),
						std::find(paths[i][j].begin() + apt_idx.back(),
							paths[i][j].end(), feature_paths_apt[i][j][k]));
					apt_idx.push_back(dist + apt_idx.back());
					std::cout << apt_idx.back() << " " << paths[i][j].size() << std::endl;
				}
				for (int k = 1; k < apt_idx.size(); ++k)
				{	
					auto cur_candidate = std::vector<int>();
					for (int k1 = apt_idx[k - 1]; k1 < apt_idx[k] + 1; ++k1)
					{
						cur_candidate.push_back(paths[i][j][k1]);
					}
					feature_path_candidate.push_back(cur_candidate);
				}
				cut_candidate_num += apt_idx.size() - 1;
			}

			std::cout << "cpt 5" << std::endl;
			for (int j = 0; j < feature_path_candidate.size(); ++j)
			{
				for (int k = 0; k < feature_path_candidate[j].size(); ++k)
				{
					hm.add_source(index_to_vertex_map[feature_path_candidate[j][k]]);
				}
				boost::unordered_map<boost::graph_traits<Polyhedron_3>::vertex_descriptor, double>vertex_distance;
				hm.estimate_geodesic_distances(boost::make_assoc_property_map(vertex_distance));
				hm.clear_sources();
				for (auto v : vertex_distance)
				{
					line_scalar_field[v.first->id()] += normal_pdf(v.second, sigma);
				}
			}
			vec_feature_field[i] = feature_distribution;
			vec_sigma_field[i] = line_scalar_field;
			vec_uncut_line_field[i] = line_scalar_field_uncut;

			std::cout << "cpt 6" << std::endl;
			double m0 = 0; double m1 = 0;
			for (int j = 0; j < feature_distribution.size(); ++j)
			{	
				m0 += std::pow(feature_distribution[j] - line_scalar_field_uncut[j], 2);
				m1 += std::pow(line_scalar_field[j] - line_scalar_field_uncut[j], 2);
			}
			coveragence[i] = std::sqrt(m0) + redundancy_weight*std::sqrt(m1);
		}
	}

	void build_paths()
	{
		typedef std::pair<int, int> Edge;
		std::vector<Edge> edge_array;
		std::vector<double>edge_weight_array;
		const double alpha = 0.01;
		for (int i = 0; i < this->size_of_vertices(); ++i)
		{
			auto pt = index_to_vertex_map[i];
			int pt_degree = 0;
			for (auto v_it = pt->vertex_begin(); pt_degree < pt->vertex_degree(); ++v_it)
			{
				pt_degree++;
				int opposite_pt_id = v_it->opposite()->vertex()->id();
				if (pt->id() < opposite_pt_id)
					continue;
				auto vt1 = pt->point();
				auto vt2 = v_it->opposite()->vertex()->point();
				edge_array.push_back(Edge(i, opposite_pt_id));
				Eigen::RowVector3d edge_dir = Eigen::RowVector3d(vt1.x() - vt2.x(), vt1.y() - vt2.y(), vt1.z() - vt2.z());
				double edge_len = edge_dir.norm() ;
				edge_weight_array.push_back(edge_len);
			}
		}
		origin_g = graph_t(edge_array.data(), edge_array.data() + edge_array.size(), edge_weight_array.data(), this->size_of_vertices());
	}


	void build_paths(segIO& seg_info,
		const std::vector<Eigen::RowVector3d>& feature_vector_fields,
const std::vector<double>& feature_scalar_fields,
const std::vector<Eigen::RowVector3d>& line_vector_fields,
const std::vector<double>& line_scalar_fields,
graph_t& distorsion_g,
double logi1_a, double logi1_b, double logi2_a, double logi2_b)
	{
	typedef std::pair<int, int> Edge;
	std::vector<Edge> edge_array;
	std::vector<double>edge_weight_array;
	const double alpha = 0.01;
	for (int i = 0; i < this->size_of_vertices(); ++i)
	{
		auto pt = index_to_vertex_map[i];
		int pt_degree = 0;
		for (auto v_it = pt->vertex_begin(); pt_degree < pt->vertex_degree(); ++v_it)
		{
			pt_degree++;
			int opposite_pt_id = v_it->opposite()->vertex()->id();
			if (pt->id() < opposite_pt_id)
				continue;
			auto vt1 = pt->point();
			auto vt2 = v_it->opposite()->vertex()->point();
			edge_array.push_back(Edge(i, opposite_pt_id));
			Eigen::RowVector3d edge_dir = Eigen::RowVector3d(vt1.x() - vt2.x(), vt1.y() - vt2.y(), vt1.z() - vt2.z());
			//double feature_scalar_factor =  logistic_1(feature_modifier*(feature_scalar_fields[i] + feature_scalar_fields[opposite_pt_id]) / get_avg_edge_len(false), logi1_a, logi1_b);
			//double line_scalar_factor = logistic_2(0.1 * (line_scalar_fields[i] + line_scalar_fields[opposite_pt_id]) / get_avg_edge_len(false), logi1_a, logi1_b);
			double feature_scalar_factor = logistic_1((feature_scalar_fields[i] + feature_scalar_fields[opposite_pt_id]) / get_avg_edge_len(false), logi1_a, logi1_b);
			double line_scalar_factor = logistic_2((line_scalar_fields[i] + line_scalar_fields[opposite_pt_id]) / get_avg_edge_len(false), logi2_a, logi2_b);
			double edge_len_coff = feature_scalar_factor / line_scalar_factor;
			double edge_len = edge_dir.norm() * edge_len_coff;
			edge_dir.normalize();
			double angle = AcosR(edge_dir.dot((feature_vector_fields[i] + feature_vector_fields[opposite_pt_id]).normalized()));
			edge_len *= (1 - std::max((ML_PI - angle) / (ML_PI + angle), angle / (ML_2_PI - angle))) + 2;
			edge_weight_array.push_back(edge_len);
		}
	}
	distorsion_g = graph_t(edge_array.data(), edge_array.data() + edge_array.size(), edge_weight_array.data(), this->size_of_vertices());
	}

void dijkstra_search(std::vector<boost::graph_traits< graph_t >::vertex_descriptor>& p,
	std::vector<double>& d, int origin_pt_idx,
	graph_t& distorsion_g)
{
	boost::property_map<graph_t, boost::edge_weight_t>::type weightmap = boost::get(boost::edge_weight, distorsion_g);
	boost::graph_traits < graph_t >::vertex_descriptor s = boost::vertex(origin_pt_idx, distorsion_g);
	p = std::vector<boost::graph_traits < graph_t >::vertex_descriptor>(num_vertices(distorsion_g));
	d = std::vector<double>(num_vertices(distorsion_g));
	boost::dijkstra_shortest_paths(distorsion_g, s,
		boost::predecessor_map(boost::make_iterator_property_map(p.begin(), boost::get(boost::vertex_index, distorsion_g))).
		distance_map(boost::make_iterator_property_map(d.begin(), boost::get(boost::vertex_index, distorsion_g))));
}

void dijkstra_search(std::vector<double>& origin_d, int origin_pt_idx)
{
	boost::property_map<graph_t, boost::edge_weight_t>::type weightmap = boost::get(boost::edge_weight, origin_g);
	boost::graph_traits < graph_t >::vertex_descriptor s = boost::vertex(origin_pt_idx, origin_g);
	//if (origin_p.empty())
	//{
	std::vector<int>origin_p(num_vertices(origin_g));
	//}
	if (origin_d.empty())
	{
		origin_d = std::vector<double>(num_vertices(origin_g));
	}
	//origin_p = std::vector<boost::graph_traits < graph_t >::vertex_descriptor>(num_vertices(origin_g));
	//origin_d = std::vector<double>(num_vertices(distorsion_g));
	boost::dijkstra_shortest_paths(origin_g, s,
		boost::predecessor_map(boost::make_iterator_property_map(origin_p.begin(), boost::get(boost::vertex_index, origin_g))).
		distance_map(boost::make_iterator_property_map(origin_d.begin(), boost::get(boost::vertex_index, origin_g))));
}



void getExtremePts(segIO& seg, std::vector<int>& select_pts)
{
	typedef CGAL::Heat_method_3::Surface_mesh_geodesic_distances_3<Polyhedron_3> Heat_method;
	typedef boost::graph_traits<Polyhedron_3>::vertex_descriptor vertex_descriptor;
	boost::unordered_map<boost::graph_traits<Polyhedron_3>::vertex_descriptor, double>vertex_distance;
	std::vector<double>vertex_dist(this->size_of_vertices());
	Heat_method hm(*this);
	std::vector<std::vector<double>>vec_dist;
	const int iter_time = 1;
	double longest_geodesic_dist = 1;
	for (int iter_t = 0; iter_t < iter_time; ++iter_t)
	{
		Eigen::Vector3d center_pt = Eigen::Vector3d::Zero();
		for (int i = 0; i < this->size_of_vertices(); ++i)
		{
			auto pt = index_to_vertex_map[i];
			auto vt = pt->point();
			center_pt = center_pt + Eigen::Vector3d(vt.x(), vt.y(), vt.z());
		}
		center_pt = center_pt / this->size_of_vertices();
		double nn_center_dist = std::numeric_limits<double>::max();
		int rdm_pt_0 = 0;
		for (int i = 0; i < this->size_of_vertices(); ++i)
		{
			auto pt = index_to_vertex_map[i];
			auto vt = pt->point();
			if ((Eigen::Vector3d(vt.x(), vt.y(), vt.z()) - center_pt).norm() < nn_center_dist)
			{
				nn_center_dist = (Eigen::Vector3d(vt.x(), vt.y(), vt.z()) - center_pt).norm();
				rdm_pt_0 = i;
			}
		}
			hm.clear_sources();
			vertex_distance.clear();
			//int rdm_pt_0 = rand_uniform(0, this->size_of_vertices());
			std::vector<int>select_pt_candidate_0;
			std::vector<double>select_pt_candidate_distance_0;
			hm.add_source(index_to_vertex_map[rdm_pt_0]);
			hm.estimate_geodesic_distances(boost::make_assoc_property_map(vertex_distance));
			for (auto v : vertex_distance)
			{
				vertex_dist[v.first->id()] = v.second;
			}
			int far_pt_id_0 = std::distance(vertex_dist.begin(),
				std::max_element(vertex_dist.begin(), vertex_dist.end()));

			hm.clear_sources();
			vertex_distance.clear();
			hm.add_source(index_to_vertex_map[far_pt_id_0]);
			hm.estimate_geodesic_distances(boost::make_assoc_property_map(vertex_distance));
			for (auto v : vertex_distance)
			{
				vertex_dist[v.first->id()] = v.second;
			}

			for (int i = 0; i < this->size_of_vertices(); ++i)
			{
				auto pt = index_to_vertex_map[i];
				auto pt_id = pt->id();
				int pt_degree = 0;
				int minimum_count = 0, maximum_count = 0;
				std::set<int>neighbours;
				n_ring_neighbours(neighbours, i, 15);
				//std::cout << neighbours.size() << " " << "size" << std::endl;
				neighbours.erase(neighbours.find(i));
				for (int v_it : neighbours)
				{
					if (vertex_dist[pt_id] > vertex_dist[v_it])
					{
						maximum_count++;
					}
					else if(vertex_dist[pt_id] < vertex_dist[v_it])
					{
						minimum_count++;
					}
				}
				if (maximum_count == neighbours.size() || minimum_count == neighbours.size())
				{	
					std::cout << "yes i"<<i << std::endl;
					select_pt_candidate_0.push_back(i);
					select_pt_candidate_distance_0.push_back(vertex_dist[i]);
				}
				/*
				for (auto v_it = pt->vertex_begin(); pt_degree < pt->vertex_degree(); ++v_it)
				{
					pt_degree++;
					auto opposite_pt_id = v_it->opposite()->vertex()->id();
					if (vertex_dist[pt_id] > vertex_dist[opposite_pt_id])
					{
						maximum_count++;
					}
					else
					{
						minimum_count++;
					}
				}
				if (maximum_count == pt_degree || minimum_count == pt_degree)
				{
					select_pt_candidate_0.push_back(i);
					select_pt_candidate_distance_0.push_back(vertex_dist[i]);
				}
				*/
			}
			if (iter_t == 0)
			{
				hm.clear_sources();
				vertex_distance.clear();

				auto arg_sort = sort_indexes(select_pt_candidate_distance_0);
				select_pts.push_back(select_pt_candidate_0[arg_sort.front()]);
				hm.add_source(index_to_vertex_map[select_pt_candidate_0[arg_sort.front()]]);
				hm.estimate_geodesic_distances(boost::make_assoc_property_map(vertex_distance));
				for (auto v : vertex_distance)
				{
					vertex_dist[v.first->id()] = v.second;
				}
				longest_geodesic_dist = *std::max_element(vertex_dist.begin(), vertex_dist.end());
				for (int v_it = arg_sort.size() - 1; v_it >= 1; --v_it)
				{	
					if (v_it == arg_sort.size() - 1)
					{
						select_pts.push_back(select_pt_candidate_0[arg_sort[v_it]]);
						hm.add_source(index_to_vertex_map[select_pt_candidate_0[arg_sort[v_it]]]);
						hm.estimate_geodesic_distances(boost::make_assoc_property_map(vertex_distance));
						for (auto v : vertex_distance)
						{
							vertex_dist[v.first->id()] = v.second;
						}
						//longest_geodesic_dist = *std::max_element(vertex_dist.begin(), vertex_dist.end());
					}
					else
					{
						if (vertex_dist[select_pt_candidate_0[arg_sort[v_it]]] > 0.2 * longest_geodesic_dist)
						{
							select_pts.push_back(select_pt_candidate_0[arg_sort[v_it]]);
							hm.add_source(index_to_vertex_map[select_pt_candidate_0[arg_sort[v_it]]]);
							hm.estimate_geodesic_distances(boost::make_assoc_property_map(vertex_distance));
							for (auto v : vertex_distance)
							{
								vertex_dist[v.first->id()] = v.second;
							}
							longest_geodesic_dist = std::max(longest_geodesic_dist, vertex_dist[select_pt_candidate_0[arg_sort[v_it]]]);
						}
					}
					/*
					if (v_it == arg_sort.size() - 1)
					{
						select_pts.push_back(select_pt_candidate_0[arg_sort[v_it]]);
						select_pts.push_back(select_pt_candidate_0[arg_sort[arg_sort.size() - 1 - v_it]]);
						hm.add_source(index_to_vertex_map[select_pt_candidate_0[arg_sort[v_it]]]);
						hm.add_source(index_to_vertex_map[select_pt_candidate_0[arg_sort[arg_sort.size() - 1 - v_it]]]);
						hm.estimate_geodesic_distances(boost::make_assoc_property_map(vertex_distance));
						for (auto v : vertex_distance)
						{
							vertex_dist[v.first->id()] = v.second;
						}
						longest_geodesic_dist = (*std::max_element(vertex_dist.begin(), vertex_dist.end()));
					}
					else
					{	
						if (v_it < (arg_sort.size() - 1 - v_it))
						{
							break;
						}
						bool insert = false;
						if (vertex_dist[select_pt_candidate_0[arg_sort[v_it]]] > 0.3 * longest_geodesic_dist)
						{
							select_pts.push_back(select_pt_candidate_0[arg_sort[v_it]]);
							hm.add_source(index_to_vertex_map[select_pt_candidate_0[arg_sort[v_it]]]);
							insert = true;
						}
						if ((v_it != (arg_sort.size() - 1 - v_it)) &&
							vertex_dist[select_pt_candidate_0[arg_sort[(arg_sort.size() - 1 - v_it)]]] > 0.3 * longest_geodesic_dist)
						{
							select_pts.push_back(select_pt_candidate_0[arg_sort[(arg_sort.size() - 1 - v_it)]]);
							hm.add_source(index_to_vertex_map[select_pt_candidate_0[arg_sort[(arg_sort.size() - 1 - v_it)]]]);
							insert = true;
						}
						if (insert)
						{
							hm.estimate_geodesic_distances(boost::make_assoc_property_map(vertex_distance));
							for (auto v : vertex_distance)
							{
								vertex_dist[v.first->id()] = v.second;
							}
							longest_geodesic_dist = std::max(longest_geodesic_dist, vertex_dist[select_pt_candidate_0[arg_sort[v_it]]]);
						}
					}
					*/
				}
			}
			else
			{
				hm.clear_sources();
				vertex_distance.clear();
				auto arg_sort = sort_indexes(select_pt_candidate_distance_0);
				for (int i = 0; i < select_pts.size(); ++i)
				{
					hm.add_source(index_to_vertex_map[select_pts[i]]);
				}
				hm.estimate_geodesic_distances(boost::make_assoc_property_map(vertex_distance));
				for (auto v : vertex_distance)
				{
					vertex_dist[v.first->id()] = v.second;
				}
				//longest_geodesic_dist = *std::max_element(vertex_dist.begin(), vertex_dist.end());
				for (int v_it = arg_sort.size() - 1; v_it >= 0; --v_it)
				{
					if (v_it < (arg_sort.size() - 1 - v_it))
					{
						break;
					}
					bool insert = false;
					if (vertex_dist[select_pt_candidate_0[arg_sort[v_it]]] > 0.2 * longest_geodesic_dist)
					{
						select_pts.push_back(select_pt_candidate_0[arg_sort[v_it]]);
						hm.add_source(index_to_vertex_map[select_pt_candidate_0[arg_sort[v_it]]]);
						insert = true;
					}
					if ((v_it != (arg_sort.size() - 1 - v_it)) &&
						vertex_dist[select_pt_candidate_0[arg_sort[(arg_sort.size() - 1 - v_it)]]] > 0.2 * longest_geodesic_dist)
					{
						select_pts.push_back(select_pt_candidate_0[arg_sort[(arg_sort.size() - 1 - v_it)]]);
						hm.add_source(index_to_vertex_map[select_pt_candidate_0[arg_sort[(arg_sort.size() - 1 - v_it)]]]);
						insert = true;
					}
					if (insert)
					{
						hm.estimate_geodesic_distances(boost::make_assoc_property_map(vertex_distance));
						for (auto v : vertex_distance)
						{
							vertex_dist[v.first->id()] = v.second;
						}
						longest_geodesic_dist = std::max(longest_geodesic_dist, vertex_dist[select_pt_candidate_0[arg_sort[v_it]]]);
					}
				}
			}
		}
	}

	void n_ring_neighbours(std::set<int>&neighbours,int candidate,int level)
	{	
		if (neighbours.find(candidate) != neighbours.end())
		{
			return;
		}
		if (level <= 0)
		{
			return;
		}
		auto pt = index_to_vertex_map[candidate];
		int pt_degree = 0;
		neighbours.insert(candidate);
		for (auto v_it = pt->vertex_begin(); pt_degree < pt->vertex_degree(); ++v_it)
		{
			pt_degree++;
			auto opposite_pt_id = v_it->opposite()->vertex()->id();
			//neighbours.insert(opposite_pt_id);
			n_ring_neighbours(neighbours, opposite_pt_id, level - 1);
			/*
			if (vertex_dist[pt_id] > vertex_dist[opposite_pt_id])
			{
				maximum_count++;
			}
			else
			{
				minimum_count++;
			}
			*/
		}
	}
};

template <class	Kernel, class Vertex>
struct Vertex_normal //	(functor)
{
	typedef typename Kernel::FT FT;
	typedef typename Vertex::Normal Normal;
	void operator()(Vertex& v)
	{
		Normal	normal = CGAL::NULL_VECTOR;
		Vertex::Halfedge_around_vertex_const_circulator	pHalfedge = v.vertex_begin();
		Vertex::Halfedge_around_vertex_const_circulator	begin = pHalfedge;
		CGAL_For_all(pHalfedge, begin) {
			if (!pHalfedge->is_border()) {
				normal = normal + pHalfedge->facet()->normal();
			}
		}
		FT sqnorm = normal * normal;
		if (sqnorm != 0.0f) {
			v.normal() = normal / (float)std::sqrt(sqnorm);
		}
		else {
			v.normal() = CGAL::NULL_VECTOR;
		}
	}
};

// compute facet normal
template <class	Kernel, class Facet>
struct Facet_normal	// (functor)
{
	typedef typename Kernel::FT FT;
	typedef typename typename Facet::Halfedge_handle Halfedge_handle;
	typedef typename Facet::Normal_3 FNormal;
	void operator()(Facet& f)
	{
		FNormal sum = CGAL::NULL_VECTOR;
		Facet::Halfedge_around_facet_circulator h = f.facet_begin();
		do {
			FNormal normal = CGAL::cross_product(
				h->next()->vertex()->point() - h->vertex()->point(),
				h->next()->next()->vertex()->point() - h->next()->vertex()->point());
			FT sqnorm = normal * normal;
			if (sqnorm != 0)
				normal = normal / (float)std::sqrt(sqnorm);
			sum = sum + normal;
		} while (++h != f.facet_begin());
		FT sqnorm = sum * sum;
		if (sqnorm != 0.0) {
			f.normal() = sum / std::sqrt(sqnorm);
		}
		else {
			f.normal() = CGAL::NULL_VECTOR;
		}
	}
};


