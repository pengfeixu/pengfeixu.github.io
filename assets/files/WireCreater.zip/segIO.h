#pragma once
#include<vector>
#include<set>
#include<qcolor.h>
#include<string>
#include<fstream>
#include<map>
#include <CGAL/Exact_predicates_inexact_constructions_kernel.h>
#include <boost/config.hpp>
#include <boost/graph/iteration_macros.hpp>
#include <boost/graph/graph_traits.hpp>
#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/copy.hpp>
#include <boost/graph/undirected_graph.hpp>
#include <boost/graph/filtered_graph.hpp>
#include <boost/iterator/filter_iterator.hpp>
#include <boost/graph/prim_minimum_spanning_tree.hpp>
#include "helper_algo.h"

struct vertex_info
{
	int vertex_idx;
	int level;
};
typedef CGAL::Exact_predicates_inexact_constructions_kernel Kernel;
typedef std::pair<int, int> seg_parts;
//template <typename EdgeWeightMap>struct positive_edge_weight;
//template<typename VertexRemoveFlag>struct vertex_remove_flag;
//typedef boost::filtered_graph<Graph, positive_edge_weight<std::vector<int>>, vertex_remove_flag<std::vector<int>>>Filtered_Level_Graph;
class segIO
{
private:
	std::vector<int>seg_info;
	std::vector<QColor>seg_color;
	std::vector<std::vector<int>>cycles;
public:
	std::vector<std::vector<int>>segments;
	std::map<seg_parts, std::vector<std::vector<int>>>seg_lines;
	std::vector<int>vertex_in_segment;
	std::vector<int>dangling_segs;
	segIO(){}
	void clear_info() { seg_info.clear(); seg_color.clear(); }
	void info_push_back(int seg_idx) { seg_info.push_back(seg_idx); }
	void color_push_back(double r,double g,double b) { seg_color.push_back(QColor(r,g,b)); }
	QColor color(int seg_idx) { return seg_color[seg_idx]; }
	int& operator[](int i){return seg_info[i];}
	bool empty() { return seg_info.empty(); }
	std::size_t size() { return seg_info.size(); }
	//void detect_seg_lines(Enriched_polyhedron<Kernel, Enriched_items>& polygon);
	void detect_dangling_seg()
	{	
		typedef boost::adjacency_list<boost::vecS, boost::vecS, boost::bidirectionalS> Graph;
		typedef std::pair<int, int> Edge;
		// Make convenient labels for the vertices
		std::set<Edge>edge_set;
		for (auto i : seg_lines)
		{
			edge_set.insert(i.first);
		}
		std::vector<Edge>edge_array(edge_set.begin(), edge_set.end());
		std::vector<double>weights(edge_array.size(), 1);
		// writing out the edges in the graph
		//here to modify
		Graph g(edge_array.data(), edge_array.data() + edge_array.size(), seg_info.size());
		boost::graph_traits<Graph>::vertex_iterator vi, vi_end, next;
		boost::tie(vi, vi_end) = boost::vertices(g);
		for (; vi != vi_end; vi++)
		{	
			if (boost::degree(*vi, g) == 1)
			{
				dangling_segs.push_back(*vi);
			}
		}
	};
};

inline std::istream& operator >>(std::istream& in, segIO& seg)
{
	seg.clear_info();
	int seg_idx, seg_num=0;
	while (!in.eof())
	{
		in >> seg_idx;
		seg.info_push_back(seg_idx);
		seg_num = std::max(seg_num, seg_idx);
	}
	assert(!seg.empty());
	for (int i = 0; i < (seg_num+1); ++i)
	{
		seg.color_push_back(rand_uniform(0, 255), rand_uniform(0, 255), rand_uniform(0, 255));
	}
	seg.segments = std::vector<std::vector<int>>(seg_num + 1);
	for (int i = 0; i < seg.size(); ++i)
	{
		seg.segments[seg[i]].push_back(i);
	}
	return in;
}



/*
struct cycle_recorder
{
	cycle_recorder(std::vector<std::vector<int>>& circuits)
		: cycles(circuits)
	{ }
	//cycle_recorder():cycles(nullptr) {}

	template <typename Path, typename Graph>
	void cycle(const Path& p, const Graph& g)
	{
		// Get the property map containing the vertex indices
		// so we can print them.
		typedef typename boost::property_map<Graph, boost::vertex_index_t>::const_type IndexMap;
		IndexMap indices = boost::get(boost::vertex_index, g);

		// Iterate over path printing each vertex that forms the cycle.
		typename Path::const_iterator i, end = p.end();
		cycles.push_back(std::vector<int>());
		for (i = p.begin(); i != end; ++i)
		{
			//os << get(indices, *i) << " ";
			cycles.back().push_back(boost::get(indices, *i));
		}
		//os << endl;
	}
	std::vector<std::vector<int>>& cycles;
};
*/