#include "subviewer.h"

void SubViewer::readCurveGroup(Curve curve)
{
    this->curve = curve;
}

void SubViewer::init()
{
    this->setBackgroundColor(QColor(255, 255, 255));
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH| GLUT_MULTISAMPLE);
    glDisable(GL_LIGHTING);
    /*
    glDisable(GL_LIGHT0);
    glEnable(GL_LIGHT1);

    // Light default parameters
    const GLfloat light_ambient[4] = { 1.0, 1.0, 1.0, 1.0 };
    const GLfloat light_specular[4] = { 1.0, 1.0, 1.0, 1.0 };
    const GLfloat light_diffuse[4] = { 1.0, 1.0, 1.0, 1.0 };

    glLightf(GL_LIGHT1, GL_SPOT_EXPONENT, 3.0);
    glLightf(GL_LIGHT1, GL_SPOT_CUTOFF, 10.0);
    glLightf(GL_LIGHT1, GL_CONSTANT_ATTENUATION, 0.1f);
    glLightf(GL_LIGHT1, GL_LINEAR_ATTENUATION, 0.3f);
    glLightf(GL_LIGHT1, GL_QUADRATIC_ATTENUATION, 0.3f);
    glLightfv(GL_LIGHT1, GL_AMBIENT, light_ambient);
    glLightfv(GL_LIGHT1, GL_SPECULAR, light_specular);
    glLightfv(GL_LIGHT1, GL_DIFFUSE, light_diffuse);
    */
    wire_color = QColor(0, 0, 0);
}

void SubViewer::draw()
{   
    /*
    const qglviewer::Vec cameraPos = camera()->position();
    const GLfloat pos[4] = { (float)cameraPos[0], (float)cameraPos[1],
                            (float)cameraPos[2], 1.0f };
    glLightfv(GL_LIGHT1, GL_POSITION, pos);

    // Orientate light along view direction
    glLightfv(GL_LIGHT1, GL_SPOT_DIRECTION, camera()->viewDirection());
    */
    glEnable(GL_SMOOTH);
    glEnable(GL_MULTISAMPLE);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_COLOR, GL_SRC_COLOR);
    curve.draw(true, false, false, -1, -1, wire_color);
    glDisable(GL_MULTISAMPLE);
    glDisable(GL_SMOOTH);
    glDisable(GL_BLEND);
}

void SubViewer::updateFrame(qglviewer::ManipulatedCameraFrame* thisframe)
{
    this->camera()->frame()->setFromMatrix(thisframe->matrix());
    this->repaint();
}

void SubViewer::setFrame(qglviewer::ManipulatedCameraFrame* thisframe)
{
    this->camera()->frame()->setFromMatrix(thisframe->matrix());
    this->repaint();
}

void SubViewer::mouseMoveEvent(QMouseEvent* e)
{
    QGLViewer::mouseMoveEvent(e);
    emit Viewer_Frame(camera()->frame());
}

void SubViewer::mousePressEvent(QMouseEvent* e)
{
    QGLViewer::mousePressEvent(e);
    emit Viewer_Frame(camera()->frame());
}

void SubViewer::mouseReleaseEvent(QMouseEvent* e)
{
    QGLViewer::mouseReleaseEvent(e);
    emit Viewer_Frame(camera()->frame());
}

void SubViewer::wheelEvent(QWheelEvent* e)
{
    QGLViewer::wheelEvent(e);
    emit Viewer_Frame(camera()->frame());
}