#pragma once
#pragma once
#include<string>
#include<iostream>
#include<fstream>
#include <vector>
#include <Eigen/Core>
#include <Eigen/Geometry> 
#include <glew.h>
#include <GL/freeglut.h>
#include <GL/GL.h>
#include <GL/GLU.h>
#include <QGLViewer/qglviewer.h>
#include <QGLViewer/camera.h>
#include <QGLViewer/manipulatedCameraFrame.h>
#include "curve.h"
//class qglviewer::ManipulatedCameraFramel;
class SubViewer : public QGLViewer {
    Q_OBJECT
signals:
    void Viewer_Frame(qglviewer::ManipulatedCameraFrame* _t1);
public:
    void readCurveGroup(Curve curve);
    void setFrame(qglviewer::ManipulatedCameraFrame* thisframe);
    QColor wire_color;
    void setColor(QColor color) { wire_color = color; }
public slots:
    void updateFrame(qglviewer::ManipulatedCameraFrame* thisframe);
private:
    Curve curve;
protected:
    virtual void draw();
    virtual void init();
    virtual void mousePressEvent(QMouseEvent* e);
    virtual void mouseMoveEvent(QMouseEvent* e);
    virtual void mouseReleaseEvent(QMouseEvent* e);
    virtual void wheelEvent(QWheelEvent* e);
};